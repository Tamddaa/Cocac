# Hướng dẫn khôi phục và sử dụng DDoS Pro

## 1. Khôi phục từ file backup

### Bước 1: Tạo thư mục đích

```bash
mkdir ddos_pro
cd ddos_pro
```

### Bước 2: Giải nén file backup

```bash
# Nếu bạn sử dụng file backup đầy đủ
tar -xzvf /đường/dẫn/tới/ddos_tool_backup_full.tar.gz -C .

# HOẶC nếu bạn dùng file backup cơ bản
tar -xzvf /đường/dẫn/tới/ddos_tool_backup.tar.gz -C .
```

## 2. Cài đặt các thư viện cần thiết

### Cách 1: Sử dụng script cài đặt (Khuyến nghị)

```bash
python setup.py
```

### Cách 2: Cài đặt thủ công

```bash
pip install flask flask-socketio psutil scapy gunicorn
```

## 3. Khởi động ứng dụng

### Khởi động giao diện web

```bash
python main.py
```

Sau đó truy cập vào: http://localhost:5000

### Hoặc chạy công cụ từ dòng lệnh

```bash
python ddos_attack_real.py --host IP_MỤC_TIÊU --port CỔNG_MỤC_TIÊU --processes 4 --duration 30
```

## 4. Kiểm tra cài đặt

Sau khi khôi phục và cài đặt, bạn có thể kiểm tra bằng cách chạy lệnh:

```bash
python -c "import flask; import psutil; import scapy; print('Cài đặt thành công!')"
```

Nếu không có lỗi nào xuất hiện, cài đặt đã thành công.

## 5. Khắc phục sự cố

### Lỗi thiếu thư viện

```
ModuleNotFoundError: No module named 'xxx'
```

Giải pháp: Cài đặt thư viện thiếu

```bash
pip install xxx
```

### Lỗi quyền truy cập khi gửi gói

```
Permission denied
```

Giải pháp: Chạy với quyền admin/root, hoặc sử dụng tùy chọn `--socket-only`

### Lỗi không thể kết nối đến mục tiêu

```
Connection timed out
```

Giải pháp: Kiểm tra lại thông tin mục tiêu và kết nối mạng