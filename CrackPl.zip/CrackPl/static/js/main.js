// Khởi tạo các biến toàn cục
let attackChart = null;
let realtimeChart = null;
let statusPollTimer = null;
let lastStats = null;
const dataHistory = {
    timestamps: [],
    cpuData: [],
    memoryData: [],
    rateData: [],
    packetsData: []
};

/**
 * Initialize Chart.js charts
 */
function initializeCharts() {
    // Attack Type Chart
    const attackChartCtx = document.getElementById('attack-chart').getContext('2d');
    attackChart = new Chart(attackChartCtx, {
        type: 'doughnut',
        data: {
            labels: ['SYN', 'UDP', 'ACK', 'HTTP', 'Query'],
            datasets: [{
                data: [0, 0, 0, 0, 0],
                backgroundColor: [
                    '#dc3545', // danger
                    '#fd7e14', // orange
                    '#ffc107', // warning
                    '#0dcaf0', // info
                    '#6f42c1'  // purple
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });

    // Realtime Metrics Chart
    const realtimeChartCtx = document.getElementById('realtime-chart').getContext('2d');
    realtimeChart = new Chart(realtimeChartCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Gói/giây',
                    data: [],
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.2)',
                    fill: true,
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: 'CPU (%)',
                    data: [],
                    borderColor: '#0d6efd',
                    backgroundColor: 'transparent',
                    borderDash: [5, 5],
                    tension: 0.3,
                    yAxisID: 'y1'
                },
                {
                    label: 'RAM (%)',
                    data: [],
                    borderColor: '#198754',
                    backgroundColor: 'transparent',
                    borderDash: [3, 3],
                    tension: 0.3,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top'
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Thời gian'
                    },
                    min: 0
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Tốc độ (gói/giây)'
                    },
                    min: 0
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'CPU/RAM (%)'
                    },
                    min: 0,
                    max: 100,
                    grid: {
                        drawOnChartArea: false,
                    }
                }
            }
        }
    });
}

/**
 * Setup all event listeners
 */
function setupEventListeners() {
    // Attack form submission
    document.getElementById('attack-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Disable start button
        document.getElementById('start-attack-btn').disabled = true;
        document.getElementById('stop-attack-btn').disabled = false;
        document.getElementById('start-attack-btn').classList.remove('animate__pulse', 'animate__infinite');
        
        // Get form data
        const formData = new FormData(this);
        const params = Object.fromEntries(formData.entries());
        
        // Convert checkboxes to boolean
        params.socket_only = document.getElementById('socket_only').checked;
        params.aggressive = document.getElementById('aggressive').checked;
        
        // Add log message
        addLogMessage(`Bắt đầu tấn công đến ${params.host}:${params.port}...`, 'primary');
        
        // Update status
        updateAttackStatus('starting');
        
        // Send request to start attack
        fetch('/api/start_attack', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(params),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                addLogMessage('Tấn công đã bắt đầu thành công', 'success');
                updateAttackStatus('running');
                
                // Add animation to stats cards
                anime({
                    targets: '.stat-card',
                    translateY: [
                        {value: -5, duration: 1500, easing: 'easeOutQuad'},
                        {value: 0, duration: 1500, easing: 'easeInQuad'}
                    ],
                    delay: anime.stagger(100),
                    loop: true
                });
                
                // Start polling for status updates
                pollAttackStatus();
            } else {
                addLogMessage(`Lỗi: ${data.error}`, 'danger');
                document.getElementById('start-attack-btn').disabled = false;
                document.getElementById('stop-attack-btn').disabled = true;
                updateAttackStatus('error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            addLogMessage(`Lỗi kết nối: ${error}`, 'danger');
            document.getElementById('start-attack-btn').disabled = false;
            document.getElementById('stop-attack-btn').disabled = true;
            updateAttackStatus('error');
        });
    });
    
    // Stop attack button
    document.getElementById('stop-attack-btn').addEventListener('click', function() {
        fetch('/api/stop_attack', {
            method: 'POST',
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                addLogMessage('Đã dừng tấn công', 'warning');
                updateAttackStatus('stopped');
                
                // Stop animation
                anime.remove('.stat-card');
                document.getElementById('start-attack-btn').disabled = false;
                document.getElementById('stop-attack-btn').disabled = true;
                document.getElementById('start-attack-btn').classList.add('animate__pulse', 'animate__infinite');
            } else {
                addLogMessage(`Lỗi: ${data.error}`, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            addLogMessage(`Lỗi kết nối: ${error}`, 'danger');
        });
    });
    
    // Clear log button
    document.getElementById('clear-log-btn').addEventListener('click', function() {
        document.getElementById('log-output').innerHTML = '';
        addLogMessage('Log đã được xóa', 'info');
    });
    
    // Preset buttons
    document.querySelectorAll('.dropdown-menu .dropdown-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const preset = this.getAttribute('data-preset');
            if (preset) {
                applyPreset(preset);
            }
        });
    });
}

/**
 * Apply a preset configuration
 */
function applyPreset(preset) {
    switch(preset) {
        case 'light':
            document.getElementById('host').value = '1.1.1.1';
            document.getElementById('port').value = '80';
            document.getElementById('processes').value = '1';
            document.getElementById('duration').value = '10';
            document.getElementById('attack_ratio').value = '40:30:20:10';
            document.getElementById('batch_size').value = '50';
            document.getElementById('delay').value = '0.05';
            if (document.getElementById('aggressive')) {
                document.getElementById('aggressive').checked = false;
            }
            if (document.getElementById('socket_only')) {
                document.getElementById('socket_only').checked = true;
            }
            addLogMessage('Đã áp dụng cấu hình nhẹ (Test)', 'info');
            break;
        case 'medium':
            document.getElementById('host').value = '1.1.1.1';
            document.getElementById('port').value = '80';
            document.getElementById('processes').value = '2';
            document.getElementById('duration').value = '30';
            document.getElementById('attack_ratio').value = '40:30:20:10';
            document.getElementById('batch_size').value = '200';
            document.getElementById('delay').value = '0.01';
            if (document.getElementById('aggressive')) {
                document.getElementById('aggressive').checked = false;
            }
            if (document.getElementById('socket_only')) {
                document.getElementById('socket_only').checked = true;
            }
            addLogMessage('Đã áp dụng cấu hình trung bình', 'primary');
            break;
        case 'heavy':
            document.getElementById('host').value = '1.1.1.1';
            document.getElementById('port').value = '80';
            document.getElementById('processes').value = '4';
            document.getElementById('duration').value = '30';
            document.getElementById('attack_ratio').value = '40:30:30:0';
            document.getElementById('batch_size').value = '500';
            document.getElementById('delay').value = '0.005';
            if (document.getElementById('aggressive')) {
                document.getElementById('aggressive').checked = false;
            }
            if (document.getElementById('socket_only')) {
                document.getElementById('socket_only').checked = true;
            }
            addLogMessage('Đã áp dụng cấu hình nặng', 'warning');
            break;
        case 'extreme':
            document.getElementById('host').value = '1.1.1.1';
            document.getElementById('port').value = '80';
            document.getElementById('processes').value = '6';
            document.getElementById('duration').value = '30';
            document.getElementById('attack_ratio').value = '50:40:10:0';
            document.getElementById('batch_size').value = '1000';
            document.getElementById('delay').value = '0.001';
            if (document.getElementById('aggressive')) {
                document.getElementById('aggressive').checked = true;
            }
            if (document.getElementById('socket_only')) {
                document.getElementById('socket_only').checked = true;
            }
            addLogMessage('Đã áp dụng cấu hình cực đoan', 'danger');
            break;
        default:
            // Default config if no matching preset
            document.getElementById('host').value = '1.1.1.1';
            document.getElementById('port').value = '80';
            document.getElementById('processes').value = '2';
            document.getElementById('duration').value = '30';
            document.getElementById('attack_ratio').value = '40:30:20:10';
            document.getElementById('batch_size').value = '100';
            document.getElementById('delay').value = '0.01';
            if (document.getElementById('aggressive')) {
                document.getElementById('aggressive').checked = false;
            }
            if (document.getElementById('socket_only')) {
                document.getElementById('socket_only').checked = true;
            }
            addLogMessage('Đã áp dụng cấu hình mặc định', 'primary');
    }
}

/**
 * Start polling for system resources
 */
function startSystemResourcesPolling() {
    // Poll every second
    setInterval(() => {
        fetch('/api/system_resources')
            .then(response => response.json())
            .then(data => {
                updateSystemResources(data);
            })
            .catch(error => {
                console.error('Error fetching system resources:', error);
            });
    }, 1000);
}

/**
 * Poll attack status
 */
function pollAttackStatus() {
    // Clear existing timer
    if (statusPollTimer) {
        clearInterval(statusPollTimer);
    }
    
    // Set new timer
    statusPollTimer = setInterval(() => {
        if (document.getElementById('stop-attack-btn').disabled === true) {
            // Không cần poll nếu đã dừng
            clearInterval(statusPollTimer);
            return;
        }
        
        fetch('/api/status')
            .then(response => response.json())
            .then(data => {
                console.log('Attack status update:', data);
                if (data.stats) {
                    updateStats(data.stats);
                    
                    // Kiểm tra nếu tấn công đã hoàn thành
                    if (data.stats.status === 'completed' || data.stats.status === 'stopped') {
                        updateAttackStatus(data.stats.status);
                        
                        // Dừng animation và cập nhật UI
                        anime.remove('.stat-card');
                        document.getElementById('start-attack-btn').disabled = false;
                        document.getElementById('stop-attack-btn').disabled = true;
                        document.getElementById('start-attack-btn').classList.add('animate__pulse', 'animate__infinite');
                        
                        if (data.stats.status === 'completed') {
                            addLogMessage(`Tấn công hoàn thành. Đã gửi ${data.stats.packets_sent.toLocaleString()} gói tin.`, 'success');
                        } else {
                            addLogMessage(`Tấn công đã bị dừng. Đã gửi ${data.stats.packets_sent.toLocaleString()} gói tin.`, 'warning');
                        }
                        
                        clearInterval(statusPollTimer);
                    }
                }
                
                if (data.output && data.output.length > 0) {
                    // Chỉ hiển thị 1 dòng log mới nhất để tránh spam
                    addLogMessage(data.output[data.output.length - 1], 'info', false);
                }
            })
            .catch(error => {
                console.error('Error fetching attack status:', error);
            });
    }, 500); // Cập nhật 2 lần mỗi giây
}

/**
 * Update system resources display
 */
function updateSystemResources(data) {
    if (!data || typeof data.cpu_percent !== 'number' || typeof data.memory_percent !== 'number') {
        console.warn('Dữ liệu tài nguyên hệ thống không hợp lệ:', data);
        return;
    }

    // Update CPU percentage text
    const cpuPercent = document.getElementById('cpu-percent');
    const ramPercent = document.getElementById('ram-percent');
    
    if (cpuPercent) cpuPercent.textContent = data.cpu_percent.toFixed(1);
    if (ramPercent) ramPercent.textContent = data.memory_percent.toFixed(1);
    
    // Update CPU progress bar
    const cpuBar = document.getElementById('cpu-progress');
    if (cpuBar) {
        cpuBar.style.width = `${data.cpu_percent}%`;
        if (data.cpu_percent > 80) {
            cpuBar.className = 'progress-bar bg-danger';
        } else if (data.cpu_percent > 50) {
            cpuBar.className = 'progress-bar bg-warning';
        } else {
            cpuBar.className = 'progress-bar bg-success';
        }
    }
    
    // Update RAM progress bar
    const ramBar = document.getElementById('ram-progress');
    if (ramBar) {
        ramBar.style.width = `${data.memory_percent}%`;
        if (data.memory_percent > 80) {
            ramBar.className = 'progress-bar bg-danger';
        } else if (data.memory_percent > 50) {
            ramBar.className = 'progress-bar bg-warning';
        } else {
            ramBar.className = 'progress-bar bg-success';
        }
    }
    
    // Update timestamp
    const timestamp = document.getElementById('timestamp');
    if (timestamp) timestamp.textContent = new Date().toLocaleTimeString();
    
    // Update realtime chart
    if (realtimeChart && data.cpu_percent && data.memory_percent) {
        // Add data to history
        const timeString = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'});
        
        // Ensure dataHistory is properly initialized
        if (!dataHistory || !dataHistory.timestamps) {
            dataHistory = {
                timestamps: [],
                cpuData: [],
                ramData: [],
                rateData: [],
                packetsData: []
            };
        }
        
        dataHistory.timestamps.push(timeString);
        dataHistory.cpuData.push(data.cpu_percent);
        dataHistory.ramData.push(data.memory_percent);
        
        // Keep only the last 20 data points
        if (dataHistory.timestamps.length > 20) {
            dataHistory.timestamps.shift();
            dataHistory.cpuData.shift();
            dataHistory.ramData.shift();
            
            if (dataHistory.packetsData && dataHistory.packetsData.length > 0) {
                dataHistory.packetsData.shift();
                dataHistory.rateData.shift();
            }
        }
        
        // Update chart data safely
        if (realtimeChart && realtimeChart.data && realtimeChart.data.datasets) {
            realtimeChart.data.labels = dataHistory.timestamps;
            if (realtimeChart.data.datasets[1]) realtimeChart.data.datasets[1].data = dataHistory.cpuData;
            if (realtimeChart.data.datasets[2]) realtimeChart.data.datasets[2].data = dataHistory.ramData;
        
            if (lastStats && lastStats.current_rate) {
                if (dataHistory.rateData.length < dataHistory.timestamps.length) {
                    // Fill with zeros if we don't have rate data yet
                    while (dataHistory.rateData.length < dataHistory.timestamps.length - 1) {
                        dataHistory.rateData.push(0);
                        dataHistory.packetsData.push(0);
                    }
                    dataHistory.rateData.push(lastStats.current_rate);
                    dataHistory.packetsData.push(lastStats.packets_sent);
                }
                if (realtimeChart.data.datasets[0]) {
                    realtimeChart.data.datasets[0].data = dataHistory.rateData;
                }
            }
            
            // Update chart safely
            if (realtimeChart) {
                realtimeChart.update();
            }
        }
    }
}

/**
 * Update attack status display
 */
function updateAttackStatus(status) {
    const statusEl = document.getElementById('attack-status');
    const statusText = document.getElementById('status-text');
    
    if (!statusEl || !statusText) {
        console.warn('Phần tử hiển thị trạng thái không tồn tại trong DOM');
        return;
    }
    
    // Reset classes
    statusEl.className = 'alert';
    
    // Set appropriate class and text based on status
    switch(status) {
        case 'idle':
            statusEl.classList.add('alert-secondary');
            statusText.textContent = 'Chưa chạy';
            break;
        case 'starting':
            statusEl.classList.add('alert-primary', 'alert-pulse');
            statusText.textContent = 'Đang khởi động...';
            break;
        case 'running':
            statusEl.classList.add('alert-info', 'alert-pulse');
            statusText.textContent = 'Đang chạy...';
            break;
        case 'completed':
            statusEl.classList.add('alert-success');
            statusText.textContent = 'Hoàn thành';
            break;
        case 'error':
            statusEl.classList.add('alert-danger');
            statusText.textContent = 'Lỗi';
            break;
        case 'stopped':
            statusEl.classList.add('alert-warning');
            statusText.textContent = 'Đã dừng thủ công';
            break;
    }
}

/**
 * Update statistics display
 */
function updateStats(stats) {
    if (!stats) {
        console.warn('Dữ liệu thống kê không hợp lệ:', stats);
        return;
    }
    
    // Update counter elements with animation
    updateCounter('packets-sent', stats.packets_sent || 0);
    updateCounter('current-rate', stats.current_rate || 0);
    updateCounter('peak-rate', stats.peak_rate || 0);
    
    // Đảm bảo average_rate là số hợp lệ
    const avgRate = typeof stats.average_rate === 'number' ? stats.average_rate.toFixed(1) : '0.0';
    updateCounter('average-rate', parseFloat(avgRate) || 0);
    
    // Cập nhật số lượng gói tin theo loại - kiểm tra trước khi cập nhật
    const updateElementIfExists = (id, value) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = (value || 0).toLocaleString();
        }
    };
    
    updateElementIfExists('syn-count', stats.syn_count);
    updateElementIfExists('udp-count', stats.udp_count);
    updateElementIfExists('ack-count', stats.ack_count);
    updateElementIfExists('http-count', stats.http_count);
    updateElementIfExists('query-count', stats.query_count);
    
    // Update time display
    updateElementIfExists('elapsed-time', Math.floor(stats.elapsed || 0));
    updateElementIfExists('total-time', stats.duration || 0);

    // Update progress bar
    const progress = (stats.elapsed / stats.duration) * 100;
    const progressBar = document.getElementById('time-progress');
    if (progressBar) {
        progressBar.style.width = `${Math.min(100, progress || 0)}%`;
    }
    
    // Update attack chart
    updateAttackChart(stats);
}

/**
 * Update counter with animation
 */
function updateCounter(id, newValue) {
    const counterElement = document.getElementById(id);
    
    if (!counterElement) {
        console.warn(`Phần tử counter '${id}' không tồn tại trong DOM`);
        return;
    }
    
    // Parse current counter value
    let currentValue = 0;
    try {
        currentValue = parseInt(counterElement.textContent.replace(/,/g, '')) || 0;
    } catch (e) {
        console.warn(`Không thể parse giá trị hiện tại của counter '${id}'`, e);
    }
    
    // If value hasn't changed, no need to update
    if (currentValue === newValue) return;
    
    // Update with animation
    anime({
        targets: { value: currentValue },
        value: newValue,
        duration: 500,
        easing: 'easeInOutExpo',
        round: 1,
        update: function(anim) {
            const value = anim.animations[0].currentValue;
            counterElement.textContent = value.toLocaleString();
        }
    });
}

/**
 * Update attack type chart
 */
function updateAttackChart(stats) {
    if (attackChart) {
        attackChart.data.datasets[0].data = [
            stats.syn_count,
            stats.udp_count,
            stats.ack_count,
            stats.http_count,
            stats.query_count
        ];
        attackChart.update();
    }
}

/**
 * Update realtime metrics chart
 */
function updateRealtimeChart(stats) {
    if (realtimeChart && stats.current_rate !== undefined) {
        // Add rate to history if not already added by system resources update
        if (dataHistory.rateData.length < dataHistory.timestamps.length) {
            dataHistory.rateData.push(stats.current_rate);
            dataHistory.packetsData.push(stats.packets_sent);
            realtimeChart.data.datasets[0].data = dataHistory.rateData;
            realtimeChart.update();
        }
    }
}

/**
 * Add a message to the log output
 */
function addLogMessage(message, type = 'info', withTimestamp = true) {
    const logOutput = document.getElementById('log-output');
    if (!logOutput) return;
    
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry`;
    
    // Add timestamp if requested
    let formattedMessage = message;
    if (withTimestamp) {
        const now = new Date();
        const timeString = now.toLocaleTimeString();
        formattedMessage = `[${timeString}] ${message}`;
    }
    
    // Set message with appropriate styling
    switch(type) {
        case 'success':
            logEntry.innerHTML = `<span class="text-success"><i class="fas fa-check-circle me-1"></i>${formattedMessage}</span>`;
            break;
        case 'info':
            logEntry.innerHTML = `<span class="text-info"><i class="fas fa-info-circle me-1"></i>${formattedMessage}</span>`;
            break;
        case 'warning':
            logEntry.innerHTML = `<span class="text-warning"><i class="fas fa-exclamation-triangle me-1"></i>${formattedMessage}</span>`;
            break;
        case 'danger':
        case 'error':
            logEntry.innerHTML = `<span class="text-danger"><i class="fas fa-times-circle me-1"></i>${formattedMessage}</span>`;
            break;
        case 'primary':
            logEntry.innerHTML = `<span class="text-primary"><i class="fas fa-arrow-right me-1"></i>${formattedMessage}</span>`;
            break;
        default:
            logEntry.innerHTML = `<span class="text-secondary"><i class="fas fa-circle me-1"></i>${formattedMessage}</span>`;
    }
    
    // Add to log with fade-in animation
    logEntry.style.opacity = '0';
    logOutput.appendChild(logEntry);
    
    // Auto-scroll to bottom
    logOutput.scrollTop = logOutput.scrollHeight;
    
    // Fade in
    setTimeout(() => {
        logEntry.style.transition = 'opacity 0.3s ease-in';
        logEntry.style.opacity = '1';
    }, 10);
    
    // Limit log size
    const maxLogEntries = 100;
    while (logOutput.children.length > maxLogEntries) {
        logOutput.removeChild(logOutput.firstChild);
    }
}

/**
 * Initialize animations
 */
function initializeAnimations() {
    // Pulsing effect for status
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.6; }
            100% { opacity: 1; }
        }
        .alert-pulse {
            animation: pulse 1.5s ease-in-out infinite;
        }
    `;
    document.head.appendChild(style);
    
    // Animated stat cards on page load
    anime({
        targets: '.stat-card',
        translateY: [20, 0],
        opacity: [0, 1],
        delay: anime.stagger(100),
        easing: 'easeOutQuad',
        duration: 800
    });
    
    // Add infinite pulse to start button
    document.getElementById('start-attack-btn').classList.add('animate__pulse', 'animate__infinite');
}

/**
 * Document ready event
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    initializeCharts();
    
    // Setup event listeners
    setupEventListeners();
    
    // Start polling for system resources
    startSystemResourcesPolling();
    
    // Initialize animations
    initializeAnimations();
    
    // Welcome message
    addLogMessage('Chào mừng đến với DDoS Pro Tool. Sẵn sàng để bắt đầu!', 'primary');
});