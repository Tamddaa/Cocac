import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for
import json
import threading
import time
import subprocess
import queue
import re
import random
from datetime import datetime
from flask_socketio import SocketIO, emit

# Tải psutil với xử lý lỗi
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logging.warning("psutil không khả dụng, một số tính năng giám sát sẽ bị giới hạn")

# Khởi tạo ứng dụng
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

# Cấu hình logging
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s [%(levelname)s] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')

# Biến global
attack_process = None
attack_output_queue = queue.Queue()
attack_stats = {
    "status": "idle", 
    "packets_sent": 0,
    "current_rate": 0,
    "peak_rate": 0,
    "average_rate": 0,
    "elapsed": 0,
    "duration": 0,
    "syn_count": 0,
    "udp_count": 0,
    "ack_count": 0,
    "http_count": 0,
    "query_count": 0,
    "start_time": None,
    "cpu_usage": 0,
    "ram_usage": 0
}
output_buffer = []
stats_lock = threading.Lock()
update_thread = None
stop_update_thread = threading.Event()

def run_network_test(host, port, processes, duration, batch_size=200, delay=0.01, 
                     attack_ratio="40:30:20:10", socket_only=True, verbose=True, aggressive=False):
    """Chạy công cụ kiểm thử mạng với các tham số"""
    command = [
        "python", "ddos_attack_real.py",  # Sử dụng công cụ tấn công thực tế
        "--host", str(host),
        "--port", str(port),
        "--processes", str(processes),
        "--duration", str(duration),
        "--batch-size", str(batch_size),
        "--delay", str(delay),
        "--attack-ratio", attack_ratio
    ]
    
    # Thêm các tùy chọn tấn công
    if socket_only:
        command.append("--socket-only")
    if aggressive:
        command.append("--aggressive")
    
    # Ghi lại lệnh hoàn chỉnh vào log
    logging.info(f"Executing command: {' '.join(command)}")
    
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        logging.info(f"Đã khởi tạo tiến trình mô phỏng tấn công, PID: {process.pid}")
        return process
    except Exception as e:
        logging.error(f"Lỗi khi chạy lệnh: {e}")
        return None

def parse_output_line(line):
    """Phân tích dòng đầu ra từ công cụ DDoS"""
    line = line.strip()
    
    # Phát hiện dòng thống kê
    if "Gói (SYN/UDP/ACK)" in line:
        stats_match = re.search(r'Gói \(SYN/UDP/ACK\): (\d+) \| Tốc độ: (\d+) gói/giây \| Query: (\d+) \| Tốc độ Query: (\d+) query/giây \| CPU: (\d+\.\d+)% \| Thời gian: (\d+\.\d+)s', line)
        if stats_match:
            packets, rate, queries, query_rate, cpu, elapsed = stats_match.groups()
            with stats_lock:
                attack_stats["packets_sent"] = int(packets) + int(queries)
                attack_stats["current_rate"] = int(rate) + int(query_rate)
                attack_stats["peak_rate"] = max(attack_stats["peak_rate"], attack_stats["current_rate"])
                attack_stats["elapsed"] = float(elapsed)
                attack_stats["cpu_usage"] = float(cpu)
                
                # Tính tốc độ trung bình
                if attack_stats["elapsed"] > 0:
                    attack_stats["average_rate"] = attack_stats["packets_sent"] / attack_stats["elapsed"]
                    
                # Ước tính phân phối gói dựa trên tỷ lệ tấn công
                # Sửa lỗi: ddos_tester.py chỉ hỗ trợ 4 phần (SYN:UDP:ACK:QUERY) không phải 5 phần
                parts = attack_stats.get("attack_ratio", "40:30:20:10").split(":")
                total_parts = sum(int(p) for p in parts)
                if len(parts) >= 4 and total_parts > 0:
                    attack_stats["syn_count"] = int(attack_stats["packets_sent"] * int(parts[0]) / total_parts)
                    attack_stats["udp_count"] = int(attack_stats["packets_sent"] * int(parts[1]) / total_parts)
                    attack_stats["ack_count"] = int(attack_stats["packets_sent"] * int(parts[2]) / total_parts)
                    attack_stats["query_count"] = int(attack_stats["packets_sent"] * int(parts[3]) / total_parts)
                    attack_stats["http_count"] = 0  # HTTP không được hỗ trợ trong ddos_tester.py
                
            return {"type": "stats", "data": line}
    
    # Phát hiện dòng khởi động
    elif "Bắt đầu kiểm thử đến" in line:
        match = re.search(r'Bắt đầu kiểm thử đến (\S+):(\d+)', line)
        if match:
            host, port = match.groups()
            with stats_lock:
                attack_stats["target_host"] = host
                attack_stats["target_port"] = port
                attack_stats["status"] = "running"
                attack_stats["start_time"] = datetime.now()
            return {"type": "start", "data": line}
    
    # Phát hiện dòng kết thúc
    elif "Kết thúc! Tổng gói" in line:
        match = re.search(r'Kết thúc! Tổng gói \(SYN/UDP/ACK\): (\d+) \| Tổng Query: (\d+)', line)
        if match:
            packets, queries = match.groups()
            with stats_lock:
                attack_stats["packets_sent"] = int(packets) + int(queries)
                attack_stats["status"] = "completed"
            return {"type": "end", "data": line}
            
    # Dòng thông thường
    return {"type": "log", "data": line}

def monitor_process_output(process):
    """Theo dõi và phân tích đầu ra từ tiến trình tấn công"""
    if process is None:
        logging.error("Không thể theo dõi tiến trình: process là None")
        with stats_lock:
            attack_stats["status"] = "error"
            attack_output_queue.put({"type": "error", "data": "Không thể khởi tạo tiến trình tấn công"})
        return
        
    logging.info(f"Bắt đầu theo dõi tiến trình {process.pid}")
    
    try:
        for line in iter(process.stdout.readline, ''):
            if not line:
                break
                
            logging.debug(f"Process output: {line.strip()}")
            result = parse_output_line(line)
            # Thêm vào buffer để client có thể truy xuất
            output_buffer.append(result["data"])
            if len(output_buffer) > 100:  # Giữ kích thước buffer hợp lý
                output_buffer.pop(0)
                
            # Đưa thông tin vào queue để gửi đến client
            attack_output_queue.put(result)
            
        # Đánh dấu là đã hoàn thành khi tiến trình kết thúc
        if process.poll() is not None:
            logging.info(f"Tiến trình {process.pid} đã kết thúc với mã trạng thái: {process.returncode}")
            with stats_lock:
                if attack_stats["status"] != "completed" and attack_stats["status"] != "stopped":
                    attack_stats["status"] = "error"
                    attack_output_queue.put({"type": "error", "data": f"Tiến trình kết thúc bất ngờ với mã lỗi: {process.returncode}"})
    except Exception as e:
        logging.error(f"Lỗi khi theo dõi tiến trình: {str(e)}")
        with stats_lock:
            attack_stats["status"] = "error"
            attack_output_queue.put({"type": "error", "data": f"Lỗi khi theo dõi tiến trình: {str(e)}"})

def start_attack(params):
    """Bắt đầu một cuộc tấn công mới"""
    global attack_process
    
    # Nếu đã có cuộc tấn công đang chạy, hãy dừng nó
    if attack_process and attack_process.poll() is None:
        stop_attack()
    
    try:
        # Sửa lỗi: đảm bảo attack_ratio đúng định dạng SYN:UDP:ACK:QUERY và tổng = 100
        attack_ratio = params.get("attack_ratio", "40:30:20:10")
        # Nếu có 5 phần (định dạng cũ với HTTP), chuyển sang định dạng mới
        parts = attack_ratio.split(":")
        if len(parts) == 5:
            # Phân bổ lại phần HTTP vào các phần khác
            syn_part = int(parts[0])
            udp_part = int(parts[1])
            ack_part = int(parts[2])
            http_part = int(parts[3])
            query_part = int(parts[4])
            
            # Phân phối lại phần HTTP
            syn_part += http_part // 3
            udp_part += http_part // 3
            ack_part += http_part - (http_part // 3) * 2
            
            # Tạo tỷ lệ mới
            attack_ratio = f"{syn_part}:{udp_part}:{ack_part}:{query_part}"
            logging.info(f"Đã chuyển đổi tỷ lệ tấn công sang định dạng SYN:UDP:ACK:QUERY: {attack_ratio}")
            
        # Khởi tạo lại thống kê
        with stats_lock:
            attack_stats.update({
                "status": "starting",
                "packets_sent": 0,
                "current_rate": 0,
                "peak_rate": 0,
                "average_rate": 0,
                "elapsed": 0,
                "duration": int(params.get("duration", 30)),
                "syn_count": 0,
                "udp_count": 0,
                "ack_count": 0,
                "http_count": 0,
                "query_count": 0,
                "target_host": params.get("host", "127.0.0.1"),
                "target_port": params.get("port", 80),
                "start_time": datetime.now(),
                "attack_ratio": attack_ratio,
                "cpu_usage": 0,
                "ram_usage": 0
            })
            
        # Xóa buffer đầu ra
        output_buffer.clear()
        
        # Đảm bảo attack_ratio không bao gồm HTTP (chỉ SYN:UDP:ACK:QUERY)
        # Khởi tạo quá trình tấn công
        attack_process = run_network_test(
            host=params.get("host", "127.0.0.1"),
            port=int(params.get("port", 80)),
            processes=int(params.get("processes", 2)),
            duration=int(params.get("duration", 30)),
            batch_size=int(params.get("batch_size", 200)),
            delay=float(params.get("delay", 0.01)),
            attack_ratio=attack_ratio,  # Sử dụng tỷ lệ đã được chuyển đổi ở trên
            socket_only=params.get("socket_only", True),
            verbose=True,
            aggressive=params.get("aggressive", False)
        )
        
        # Log thông tin cho debugging
        logging.debug(f"Attack process PID: {attack_process.pid if attack_process else 'None'}")
        
        # Bắt đầu theo dõi đầu ra
        output_thread = threading.Thread(target=monitor_process_output, args=(attack_process,))
        output_thread.daemon = True
        output_thread.start()
        
        # Bắt đầu theo dõi tài nguyên hệ thống
        system_thread = threading.Thread(target=monitor_system_resources)
        system_thread.daemon = True
        system_thread.start()
        
        return True, "Cuộc tấn công đã bắt đầu thành công"
    except Exception as e:
        logging.error(f"Error starting attack: {str(e)}")
        with stats_lock:
            attack_stats["status"] = "error"
        return False, f"Lỗi khi bắt đầu tấn công: {str(e)}"

def stop_attack():
    """Dừng cuộc tấn công đang chạy"""
    global attack_process, stop_update_thread
    
    if attack_process and attack_process.poll() is None:
        try:
            # Ghi log trước khi kết thúc
            logging.info(f"Đang dừng tiến trình tấn công PID: {attack_process.pid}")
            
            # Thử kết thúc nhẹ nhàng trước
            attack_process.terminate()
            
            # Đợi một chút
            time.sleep(1)
            
            # Nếu vẫn chạy, buộc kết thúc
            if attack_process.poll() is None:
                logging.info(f"Tiến trình không phản hồi, buộc kết thúc PID: {attack_process.pid}")
                attack_process.kill()
                
            with stats_lock:
                attack_stats["status"] = "stopped"
                
            # Gửi thông báo dừng tấn công
            socketio.emit('attack_stopped', {'packets_sent': attack_stats.get('packets_sent', 0)})
            
            # Dừng thread cập nhật
            stop_update_thread.set()
                
            # Đảm bảo process là None sau khi kết thúc
            return True, "Cuộc tấn công đã dừng thành công"
        except Exception as e:
            logging.error(f"Error stopping attack: {str(e)}")
            return False, f"Lỗi khi dừng tấn công: {str(e)}"
    else:
        logging.warning("Không tìm thấy tiến trình tấn công đang chạy để dừng")
        return False, "Không có cuộc tấn công đang chạy"

def monitor_system_resources():
    """Giám sát tài nguyên hệ thống"""
    while attack_process and attack_process.poll() is None:
        try:
            # Lấy thông tin CPU và RAM
            if PSUTIL_AVAILABLE:
                cpu_percent = psutil.cpu_percent(interval=0.5)
                memory_percent = psutil.virtual_memory().percent
            else:
                # Giá trị mô phỏng nếu không có psutil
                cpu_percent = random.randint(40, 80)
                memory_percent = random.randint(20, 60)
            
            with stats_lock:
                attack_stats["cpu_usage"] = cpu_percent
                attack_stats["ram_usage"] = memory_percent
                
            time.sleep(1.5)  # Cập nhật mỗi 2 giây
        except Exception as e:
            logging.error(f"Error monitoring system resources: {str(e)}")
            time.sleep(2)

# Routes
@app.route('/')
def index():
    """Trang chủ"""
    return render_template('index.html')

@app.route('/results')
def results():
    """Trang kết quả"""
    return render_template('results.html')

@app.route('/about')
def about():
    """Trang thông tin"""
    return render_template('about.html')

@app.route('/api/start_attack', methods=['POST'])
def api_start_attack():
    """API để bắt đầu một cuộc tấn công mới"""
    params = request.json
    success, message = start_attack(params)
    
    if success:
        return jsonify({
            "success": True,
            "message": message,
            "params": params
        })
    else:
        return jsonify({
            "success": False,
            "message": message
        }), 400

@app.route('/api/stop_attack', methods=['POST'])
def api_stop_attack():
    """API để dừng một cuộc tấn công đang chạy"""
    success, message = stop_attack()
    
    if success:
        return jsonify({
            "success": True,
            "message": message,
            "stats": attack_stats
        })
    else:
        return jsonify({
            "success": False,
            "message": message
        }), 400

@app.route('/api/status', methods=['GET'])
def api_status():
    """API để lấy trạng thái hiện tại của cuộc tấn công"""
    with stats_lock:
        status_copy = dict(attack_stats)
        
    # Lấy đầu ra mới nhất
    latest_output = list(output_buffer)
    
    return jsonify({
        "stats": status_copy,
        "output": latest_output
    })

@app.route('/api/system_resources', methods=['GET'])
def api_system_resources():
    """API để lấy thông tin về tài nguyên hệ thống"""
    global attack_stats
    
    # Luôn cung cấp thời gian và simulated flag để tránh lỗi
    response_data = {
        "timestamp": datetime.now().isoformat(),
        "simulated": True
    }
    
    try:
        # Ưu tiên lấy giá trị từ attack_stats nếu đang tấn công
        with stats_lock:
            if attack_stats.get("status") in ["running", "starting"]:
                response_data.update({
                    "cpu_percent": attack_stats.get("cpu_usage", 50),
                    "memory_percent": attack_stats.get("ram_usage", 30)
                })
                response_data["from_attack_stats"] = True
                return jsonify(response_data)
        
        # Nếu không có tấn công đang chạy, sử dụng psutil nếu có
        if PSUTIL_AVAILABLE:
            try:
                cpu_percent = psutil.cpu_percent(interval=0.05)
                memory_percent = psutil.virtual_memory().percent
                
                response_data.update({
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory_percent,
                    "simulated": False
                })
            except Exception as e:
                logging.warning(f"Lỗi khi dùng psutil: {str(e)}")
                # Sử dụng giá trị mô phỏng nếu psutil gặp lỗi
                response_data.update({
                    "cpu_percent": random.randint(40, 70),
                    "memory_percent": random.randint(20, 50),
                    "error_with_psutil": str(e)
                })
        else:
            # Nếu psutil không có sẵn, trả về giá trị mô phỏng
            response_data.update({
                "cpu_percent": random.randint(40, 70),
                "memory_percent": random.randint(20, 50)
            })
            
        return jsonify(response_data)
    except Exception as e:
        logging.error(f"Error getting system resources: {str(e)}")
        # Trả về giá trị mặc định nếu gặp lỗi
        return jsonify({
            "cpu_percent": 50,
            "memory_percent": 30,
            "timestamp": datetime.now().isoformat(),
            "simulated": True,
            "error": str(e)
        })

# Tạo cấu trúc thư mục cần thiết
def create_directories():
    """Tạo cấu trúc thư mục cần thiết"""
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    os.makedirs('static/img', exist_ok=True)
    os.makedirs('templates', exist_ok=True)

if __name__ == '__main__':
    create_directories()
    app.run(host='0.0.0.0', port=5000, debug=True)