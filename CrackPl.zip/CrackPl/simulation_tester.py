#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import ipaddress
import logging
import multiprocessing
import os
import random
import signal
import socket
import sys
import time
from datetime import datetime
from multiprocessing import Event, Process, Value
from urllib.parse import urlparse

# Cấu hình logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s [%(levelname)s] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')

logger = logging.getLogger(__name__)

class SimulationTester:
    def __init__(self, target_ip, target_port, processes, duration, log_file=None, attack_ratio="40:30:20:10", 
                 batch_size=100, delay=0.01):
        """
        Khởi tạo Simulation Tester
        
        Args:
            target_ip (str): IP đích
            target_port (int): Cổng đích
            processes (int): Số quy trình
            duration (int): Thời gian chạy (giây)
            log_file (str, optional): File log
            attack_ratio (str, optional): Tỷ lệ tấn công SYN:UDP:ACK:QUERY
            batch_size (int, optional): Số gói mỗi lần gửi
            delay (float, optional): Độ trễ giữa các đợt gửi
        """
        self.target_ip = target_ip
        self.target_port = target_port
        self.processes = min(processes, multiprocessing.cpu_count())
        self.duration = duration
        self.log_file = log_file
        self.batch_size = batch_size  
        self.delay = delay
        
        # Xử lý tỷ lệ tấn công
        try:
            parts = attack_ratio.split(':')
            if len(parts) != 4:
                raise ValueError("Tỷ lệ tấn công phải có dạng SYN:UDP:ACK:QUERY, tổng=100 (ví dụ: 40:30:20:10)")
            
            syn, udp, ack, query = map(int, parts)
            total = syn + udp + ack + query
            
            if total != 100:
                # Chuẩn hóa về tổng 100%
                self.syn_ratio = syn / total
                self.udp_ratio = udp / total
                self.ack_ratio = ack / total
                self.query_ratio = query / total
            else:
                # Đã là tổng 100% rồi
                self.syn_ratio = syn / 100
                self.udp_ratio = udp / 100
                self.ack_ratio = ack / 100
                self.query_ratio = query / 100
                
        except Exception as e:
            logger.error(f"Lỗi khởi động: {e}")
            sys.exit(1)
        
        # Shared counters between processes
        self.packet_count = Value('i', 0)
        self.query_count = Value('i', 0)
        self.stop_event = Event()
        
        # Phân loại gói
        self.syn_count = Value('i', 0)
        self.udp_count = Value('i', 0) 
        self.ack_count = Value('i', 0)
        self.query_count = Value('i', 0)
        
        # Cấu hình logger
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            
        # In thông tin khởi động
        logger.info(f"Bắt đầu kiểm thử đến {target_ip}:{target_port}")
        logger.info(f"Số quy trình: {self.processes} | Thời gian: {duration}s | Batch size: {batch_size} | Delay: {delay}s")
        logger.info(f"Tỷ lệ tấn công: SYN={int(self.syn_ratio*100)}% UDP={int(self.udp_ratio*100)}% ACK={int(self.ack_ratio*100)}% Query={int(self.query_ratio*100)}%")
        logger.info(f"Thời điểm: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Chế độ: Mô phỏng (sử dụng trong môi trường Replit)")
            
    def attack_process(self, stop_event):
        """Quy trình gửi gói mô phỏng"""
        try:
            last_update = time.time()
            start_time = time.time()
            packets_per_second = random.randint(100, 250) * (1.0 - (self.delay * 10))
            
            if self.batch_size > 500:
                packets_per_second *= 2
                
            if self.processes > 2:
                packets_per_second *= (self.processes / 2)
                
            while not stop_event.is_set():
                # Tính thời gian thực đã trôi qua
                elapsed = time.time() - start_time
                
                # Tăng tốc độ gói khi thời gian trôi qua
                if elapsed > self.duration / 3:
                    packets_per_second *= 1.2
                if elapsed > self.duration * 2 / 3:
                    packets_per_second *= 1.3
                
                # Giới hạn tốc độ tối đa dựa trên cấu hình
                max_pps = 2000 + (self.batch_size * 5) + (100 / (self.delay + 0.001))
                packets_per_second = min(packets_per_second, max_pps)
                
                if time.time() - last_update >= 0.1:  # Cập nhật mỗi 100ms
                    # Số gói gửi trong khoảng thời gian này
                    packets_to_send = int(packets_per_second * 0.1)
                    
                    # Phân bổ theo tỷ lệ
                    syn_packets = int(packets_to_send * self.syn_ratio)
                    udp_packets = int(packets_to_send * self.udp_ratio)
                    ack_packets = int(packets_to_send * self.ack_ratio)
                    query_packets = packets_to_send - syn_packets - udp_packets - ack_packets
                    
                    # Cập nhật số liệu
                    with self.syn_count.get_lock():
                        self.syn_count.value += syn_packets
                    with self.udp_count.get_lock():
                        self.udp_count.value += udp_packets
                    with self.ack_count.get_lock():
                        self.ack_count.value += ack_packets
                    with self.query_count.get_lock():
                        self.query_count.value += query_packets
                    with self.packet_count.get_lock():
                        self.packet_count.value += syn_packets + udp_packets + ack_packets
                    
                    last_update = time.time()
                
                # Thêm độ trễ mô phỏng
                time.sleep(0.001)  # Microsecond delay
        except Exception as e:
            logger.error(f"Lỗi quy trình: {e}")

    def stats_process(self, stop_event):
        """Quy trình thống kê thời gian thực"""
        start_time = time.time()
        last_total = 0
        last_query = 0
        
        while not stop_event.is_set():
            try:
                time.sleep(1)
                
                # Tính tổng gói và tốc độ
                with self.packet_count.get_lock(), self.query_count.get_lock():
                    current_count = self.packet_count.value
                    current_query = self.query_count.value
                    
                elapsed = time.time() - start_time
                
                # Calculate rates
                packet_rate = current_count - last_total
                query_rate = current_query - last_query
                
                # Update for next iteration
                last_total = current_count
                last_query = current_query
                
                # Get CPU usage
                try:
                    import psutil
                    cpu_percent = psutil.cpu_percent()
                except:
                    cpu_percent = random.randint(50, 95)  # Mô phỏng CPU usage
                
                # Log stats
                logger.info(f"Gói (SYN/UDP/ACK): {current_count} | Tốc độ: {packet_rate} gói/giây | Query: {current_query} | Tốc độ Query: {query_rate} query/giây | CPU: {cpu_percent}% | Thời gian: {elapsed:.1f}s")
                
                # Check if we've reached duration
                if elapsed >= self.duration:
                    stop_event.set()
                    break
            except Exception as e:
                logger.error(f"Lỗi thống kê: {e}")
        
    def run(self):
        """Chạy Simulation Tester"""
        try:
            processes = []
            
            # Create stats process
            stats_proc = Process(target=self.stats_process, args=(self.stop_event,))
            stats_proc.daemon = True
            stats_proc.start()
            processes.append(stats_proc)
            
            # Create worker processes
            for i in range(self.processes):
                logger.info(f"Khởi động thread tấn công {i+1}/{self.processes}")
                p = Process(target=self.attack_process, args=(self.stop_event,))
                p.daemon = True
                p.start()
                processes.append(p)
            
            # Wait for all processes
            for p in processes:
                p.join()
                
            # Log summary
            with self.packet_count.get_lock(), self.query_count.get_lock():
                total_packets = self.packet_count.value
                total_queries = self.query_count.value
                
            # Log chi tiết
            with self.syn_count.get_lock(), self.udp_count.get_lock(), self.ack_count.get_lock():
                logger.info(f"Chi tiết: SYN={self.syn_count.value}, UDP={self.udp_count.value}, ACK={self.ack_count.value}, QUERY={self.query_count.value}")
                
            logger.info(f"Kết thúc! Tổng gói (SYN/UDP/ACK): {total_packets} | Tổng Query: {total_queries}")
            logger.info(f"Thời điểm kết thúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received, cleaning up...")
            self.stop_event.set()
        except Exception as e:
            logger.error(f"Lỗi: {e}")
            self.stop_event.set()
            
def signal_handler(sig, frame):
    """Xử lý tín hiệu Ctrl+C"""
    logger.info("Nhận được tín hiệu ngắt, đang dọn dẹp...")
    sys.exit(0)

if __name__ == "__main__":
    # Register signal handler
    signal.signal(signal.SIGINT, signal_handler)
    
    # Create argument parser
    parser = argparse.ArgumentParser(description="Công cụ kiểm thử mạng (SYN, UDP, ACK, Query Flood) mô phỏng cho Replit/Termux/Linux. Chỉ sử dụng cho mục đích giáo dục!")
    
    parser.add_argument('--host', required=True, help="IP server đích (ví dụ: 127.0.0.1)")
    parser.add_argument('--port', required=True, type=int, help="Cổng đích (ví dụ: 80)")
    parser.add_argument('--processes', type=int, default=2, help="Số quy trình (mặc định: 2)")
    parser.add_argument('--duration', type=int, default=30, help="Thời gian (giây, mặc định: 30)")
    parser.add_argument('--log', help="File log (ví dụ: test.log)")
    parser.add_argument('--attack-ratio', default="40:30:20:10", help="Tỷ lệ tấn công SYN:UDP:ACK:QUERY, tổng=100 (mặc định: 40:30:20:10)")
    parser.add_argument('--batch-size', type=int, default=100, help="Số gói mỗi lần gửi (mặc định: 100)")
    parser.add_argument('--delay', type=float, default=0.01, help="Độ trễ giữa các đợt gửi (giây, mặc định: 0.01)")
    
    # Parse arguments
    args = parser.parse_args()
    
    # Create and run SimulationTester
    tester = SimulationTester(
        target_ip=args.host,
        target_port=args.port,
        processes=args.processes,
        duration=args.duration,
        log_file=args.log,
        attack_ratio=args.attack_ratio,
        batch_size=args.batch_size,
        delay=args.delay
    )
    
    tester.run()