# DDoS Pro - Công cụ DDoS thực tế

Đây là công cụ tấn công DDoS thực tế với giao diện web được tối ưu hóa cho hiệu suất cao và trực quan. Công cụ này được thiết kế để thực hiện các kiểm tra bảo mật mạng và đánh giá khả năng chịu tải của hệ thống.

## Các tính năng chính

- Tấn công đa luồng với hiệu suất cao
- Hỗ trợ tấn công SYN, UDP, ACK và HTTP Flood
- Giao diện web tương tác với biểu đồ trực quan
- Chế độ tấn công tích cực với khả năng tùy chỉnh
- Thống kê thời gian thực về tốc độ gói tin và hiệu suất
- Hỗ trợ môi trường Replit với các giới hạn phù hợp
- Tự động phát hiện và sử dụng psutil nếu có sẵn

## Cách khôi phục từ backup

Để khôi phục toàn bộ ứng dụng từ tệp backup:

```bash
tar -xzvf ddos_tool_backup.tar.gz -C /path/to/restore
```

## Cấu trúc thư mục

```
.
├── main.py                # Ứng dụng Flask chính
├── ddos_attack_real.py    # Module tấn công DDoS thực tế
├── ddos_pro_fixed.py      # Module DDoS cơ bản đã được tối ưu
├── static/                # Tài nguyên tĩnh
│   ├── css/               # Stylesheet
│   ├── js/                # JavaScript 
│   └── img/               # Hình ảnh
└── templates/             # Templates HTML
    ├── index.html         # Trang chủ với giao diện điều khiển
    ├── results.html       # Trang hiển thị kết quả chi tiết
    └── about.html         # Trang thông tin
```

## Sử dụng

1. Chạy ứng dụng web:
   ```
   python main.py
   ```
   
2. Hoặc chạy công cụ DDoS trực tiếp từ dòng lệnh:
   ```
   python ddos_attack_real.py --host TARGET_IP --port TARGET_PORT --processes 4 --duration 30 --attack-ratio "40:30:20:10" --aggressive
   ```

## Các tùy chọn dòng lệnh

- `--host`: Địa chỉ IP/Domain mục tiêu
- `--port`: Cổng mục tiêu
- `--processes`: Số luồng tấn công (mặc định: 4)
- `--duration`: Thời gian tấn công (giây) (mặc định: 30)
- `--batch-size`: Số gói mỗi đợt gửi (mặc định: 100)
- `--delay`: Độ trễ giữa các đợt gửi (giây) (mặc định: 0.01)
- `--attack-ratio`: Tỷ lệ tấn công SYN:UDP:ACK:HTTP (mặc định: 40:30:20:10)
- `--socket-only`: Chỉ sử dụng socket thông thường (không dùng Scapy)
- `--aggressive`: Chế độ tấn công tích cực (giảm độ trễ)

## Lưu ý quan trọng

Tool này chỉ được sử dụng cho mục đích thử nghiệm và học tập. Việc sử dụng tool này để tấn công các hệ thống mà không có sự đồng ý trước là bất hợp pháp và phi đạo đức. Người sử dụng chịu hoàn toàn trách nhiệm về mọi hậu quả phát sinh.