# Hướng dẫn cài đặt và sử dụng DDoS Pro

## 1. Cài đặt

### 1.1. Cài đặt thủ công

1. Giải nén file backup (nếu bạn đang sử dụng):
   ```bash
   tar -xzvf ddos_tool_backup.tar.gz -C thư_mục_đích
   ```

2. Cài đặt các thư viện cần thiết:
   ```bash
   pip install flask flask-socketio psutil scapy gunicorn
   ```

### 1.2. Cài đặt tự động

Sử dụng script cài đặt (khuyến nghị):
```bash
python setup.py
```

Script này sẽ tự động kiểm tra và cài đặt các phụ thuộc cần thiết.

## 2. Khởi động

### 2.1. Khởi động giao diện web

```bash
python main.py
```

Sau khi khởi động, truy cập vào đường dẫn http://localhost:5000 từ trình duyệt của bạn.

### 2.2. Chạy từ dòng lệnh

```bash
python ddos_attack_real.py --host TARGET_IP --port TARGET_PORT --processes 4
```

## 3. Sử dụng giao diện web

### 3.1. Giao diện chính

- **Cấu hình mục tiêu**: Nhập địa chỉ IP/tên miền và cổng của mục tiêu
- **Cấu hình tấn công**: Thiết lập số luồng, thời gian, và tỷ lệ tấn công
- **Tùy chọn nâng cao**: 
  - Chế độ tấn công tích cực (Aggressive mode)
  - Chỉ sử dụng socket (Socket only)
  - Kích thước batch và độ trễ

### 3.2. Giám sát

- **Thống kê thời gian thực**: Theo dõi tốc độ gói tin và CPU/RAM
- **Biểu đồ phân phối tấn công**: Hiển thị tỷ lệ các loại gói tin
- **Log**: Xem các thông báo và trạng thái tấn công

## 4. Khắc phục lỗi thường gặp

### 4.1. Lỗi "Error fetching system resources"

- **Nguyên nhân**: Thư viện psutil không được cài đặt hoặc gặp vấn đề khi truy cập tài nguyên hệ thống
- **Giải pháp**: 
  - Cài đặt psutil: `pip install psutil`
  - Hoặc khởi động lại ứng dụng

### 4.2. Lỗi "Module not found"

- **Nguyên nhân**: Thiếu một hoặc nhiều thư viện
- **Giải pháp**: Chạy script cài đặt `python setup.py`

### 4.3. Lỗi "Permission denied" khi gửi gói

- **Nguyên nhân**: Không có quyền root/admin khi thực hiện một số loại tấn công
- **Giải pháp**:
  - Chạy với quyền root/admin
  - Hoặc sử dụng tùy chọn `--socket-only` để chỉ sử dụng socket thông thường

## 5. Tối ưu hóa hiệu suất

### 5.1. Trong môi trường Replit

- Giới hạn số luồng tấn công (2-4)
- Tăng độ trễ gửi gói (>0.01s)
- Sử dụng tỷ lệ tấn công thiên về SYN (ví dụ: 60:30:10:0)

### 5.2. Trên máy tính cá nhân

- Tăng số luồng tấn công (4-8)
- Giảm độ trễ gửi gói (<0.005s)
- Sử dụng chế độ tấn công tích cực (--aggressive)

## 6. Sao lưu và khôi phục

### 6.1. Sao lưu

```bash
tar -czvf ddos_tool_backup.tar.gz main.py ddos_attack_real.py static/ templates/
```

### 6.2. Khôi phục

```bash
tar -xzvf ddos_tool_backup.tar.gz -C thư_mục_đích
```

## 7. Đóng góp và phát triển

Nếu bạn muốn đóng góp vào dự án, vui lòng xem xét các phần sau:

- Cải thiện giao diện người dùng
- Thêm các kỹ thuật tấn công mới
- Tối ưu hóa hiệu suất gửi gói
- Hỗ trợ IPv6 và các giao thức mới

## 8. Lưu ý pháp lý

Tool này chỉ được phát triển và sử dụng cho mục đích nghiên cứu, kiểm tra bảo mật, và học tập. Việc sử dụng tool này để tấn công các hệ thống mà không có sự đồng ý trước là bất hợp pháp và phi đạo đức. Người sử dụng chịu hoàn toàn trách nhiệm về mọi hậu quả phát sinh.