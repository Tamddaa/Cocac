# DDoS Pro - Hướng dẫn nhanh

## 1. Cài đặt

```bash
# Giải nén backup
tar -xzvf ddos_tool_backup_full.tar.gz -C thư_mục_đích

# Cài đặt thư viện
python setup.py
```

## 2. Khởi động

```bash
# Chạy giao diện web
python main.py

# HOẶC chạy từ dòng lệnh
python ddos_attack_real.py --host TARGET_IP --port TARGET_PORT --duration 30
```

## 3. Ý nghĩa thông số

| Thông số | Mô tả | Giá trị đề xuất |
|----------|-------|----------------|
| Host | Địa chỉ IP/Tên miền mục tiêu | 1.1.1.1 |
| Port | Cổng mục tiêu | 80 |
| Processes | Số luồng tấn công | 2-4 |
| Duration | Thời gian tấn công (giây) | 30-60 |
| Attack ratio | Tỷ lệ SYN:UDP:ACK:HTTP | 40:30:20:10 |
| Batch size | Số gói mỗi đợt gửi | 100-500 |
| Delay | Độ trễ giữa các đợt (giây) | 0.01-0.05 |

## 4. Tùy chọn nâng cao

- **Aggressive mode**: Tấn công tích cực, giảm độ trễ
- **Socket only**: Chỉ sử dụng socket thông thường (không cần quyền root)

## 5. Mẹo sử dụng

1. Bắt đầu với cấu hình "Light" trước khi dùng các cấu hình mạnh hơn
2. Giám sát CPU và RAM để điều chỉnh thông số phù hợp
3. Trong môi trường Replit, giữ số tiến trình thấp (tối đa 4)
4. Sử dụng chế độ "Socket only" trên máy không có quyền root