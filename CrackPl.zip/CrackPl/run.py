from main import app, socketio

if __name__ == '__main__':
    try:
        print("Khởi động ứng dụng tấn công DDoS...")
        socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)
    except KeyboardInterrupt:
        print("Đã dừng ứng dụng.")