import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for
import psutil
import json
import threading
import time
import subprocess
import queue
import re
from datetime import datetime
from flask_socketio import SocketIO, emit

# Khởi tạo ứng dụng
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

# Cấu hình logging
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s [%(levelname)s] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')

# Biến global
attack_process = None
attack_output_queue = queue.Queue()
attack_stats = {
    "status": "idle", 
    "packets_sent": 0,
    "current_rate": 0,
    "peak_rate": 0,
    "average_rate": 0,
    "elapsed": 0,
    "duration": 0,
    "syn_count": 0,
    "udp_count": 0,
    "ack_count": 0,
    "http_count": 0,
    "query_count": 0,
    "start_time": None,
    "cpu_usage": 0,
    "ram_usage": 0
}
output_buffer = []
stats_lock = threading.Lock()
update_thread = None
stop_update_thread = threading.Event()

def run_network_test(host, port, processes, duration, batch_size=200, delay=0.01, 
                     attack_ratio="40:30:20:10", socket_only=True, verbose=True):
    """Chạy công cụ kiểm thử mạng với các tham số"""
    command = [
        "python", "simulation_tester.py",  # Sử dụng công cụ mô phỏng
        "--host", str(host),
        "--port", str(port),
        "--processes", str(processes),
        "--duration", str(duration),
        "--batch-size", str(batch_size),
        "--delay", str(delay),
        "--attack-ratio", attack_ratio
    ]
    
    # Ghi lại lệnh hoàn chỉnh vào log
    logging.info(f"Executing command: {' '.join(command)}")
    
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        logging.info(f"Đã khởi tạo tiến trình mô phỏng tấn công, PID: {process.pid}")
        return process
    except Exception as e:
        logging.error(f"Lỗi khi chạy lệnh: {e}")
        return None

def parse_output_line(line):
    """Phân tích dòng đầu ra từ công cụ DDoS"""
    line = line.strip()
    
    # Phát hiện dòng thống kê
    if "Gói (SYN/UDP/ACK)" in line:
        stats_match = re.search(r'Gói \(SYN/UDP/ACK\): (\d+) \| Tốc độ: (\d+) gói/giây \| Query: (\d+) \| Tốc độ Query: (\d+) query/giây \| CPU: (\d+\.\d+)% \| Thời gian: (\d+\.\d+)s', line)
        if stats_match:
            packets, rate, queries, query_rate, cpu, elapsed = stats_match.groups()
            with stats_lock:
                attack_stats["packets_sent"] = int(packets) + int(queries)
                attack_stats["current_rate"] = int(rate) + int(query_rate)
                attack_stats["peak_rate"] = max(attack_stats["peak_rate"], attack_stats["current_rate"])
                attack_stats["elapsed"] = float(elapsed)
                attack_stats["cpu_usage"] = float(cpu)
                
                # Tính tốc độ trung bình
                if attack_stats["elapsed"] > 0:
                    attack_stats["average_rate"] = attack_stats["packets_sent"] / attack_stats["elapsed"]
                    
                # Ước tính phân phối gói dựa trên tỷ lệ tấn công
                # Sửa lỗi: ddos_tester.py chỉ hỗ trợ 4 phần (SYN:UDP:ACK:QUERY) không phải 5 phần
                parts = attack_stats.get("attack_ratio", "40:30:20:10").split(":")
                total_parts = sum(int(p) for p in parts)
                if len(parts) >= 4 and total_parts > 0:
                    attack_stats["syn_count"] = int(attack_stats["packets_sent"] * int(parts[0]) / total_parts)
                    attack_stats["udp_count"] = int(attack_stats["packets_sent"] * int(parts[1]) / total_parts)
                    attack_stats["ack_count"] = int(attack_stats["packets_sent"] * int(parts[2]) / total_parts)
                    attack_stats["query_count"] = int(attack_stats["packets_sent"] * int(parts[3]) / total_parts)
                    attack_stats["http_count"] = 0  # HTTP không được hỗ trợ trong ddos_tester.py
                
            return {"type": "stats", "data": line}
    
    # Phát hiện dòng khởi động
    elif "Bắt đầu kiểm thử đến" in line:
        match = re.search(r'Bắt đầu kiểm thử đến (\S+):(\d+)', line)
        if match:
            host, port = match.groups()
            with stats_lock:
                attack_stats["target_host"] = host
                attack_stats["target_port"] = port
                attack_stats["status"] = "running"
                attack_stats["start_time"] = datetime.now()
            return {"type": "start", "data": line}
    
    # Phát hiện dòng kết thúc
    elif "Kết thúc! Tổng gói" in line:
        match = re.search(r'Kết thúc! Tổng gói \(SYN/UDP/ACK\): (\d+) \| Tổng Query: (\d+)', line)
        if match:
            packets, queries = match.groups()
            with stats_lock:
                attack_stats["packets_sent"] = int(packets) + int(queries)
                attack_stats["status"] = "completed"
            return {"type": "end", "data": line}
            
    # Dòng thông thường
    return {"type": "log", "data": line}

def monitor_process_output(process):
    """Theo dõi và phân tích đầu ra từ tiến trình tấn công"""
    if process is None:
        logging.error("Không thể theo dõi tiến trình: process là None")
        with stats_lock:
            attack_stats["status"] = "error"
            attack_output_queue.put({"type": "error", "data": "Không thể khởi tạo tiến trình tấn công"})
        return
        
    logging.info(f"Bắt đầu theo dõi tiến trình {process.pid}")
    
    try:
        for line in iter(process.stdout.readline, ''):
            if not line:
                break
                
            logging.debug(f"Process output: {line.strip()}")
            result = parse_output_line(line)
            # Thêm vào buffer để client có thể truy xuất
            output_buffer.append(result["data"])
            if len(output_buffer) > 100:  # Giữ kích thước buffer hợp lý
                output_buffer.pop(0)
                
            # Đưa thông tin vào queue để gửi đến client
            attack_output_queue.put(result)
            
            # Emit socketio event với dữ liệu mới
            if result["type"] == "stats":
                with stats_lock:
                    socketio.emit('attack_update', {'stats': attack_stats, 'output': [result["data"]]})
            elif result["type"] == "start":
                socketio.emit('attack_started', {
                    'target': attack_stats.get('target_host', 'unknown'),
                    'port': attack_stats.get('target_port', 0),
                    'duration': attack_stats.get('duration', 0)
                })
            elif result["type"] == "end":
                socketio.emit('attack_completed', {
                    'packets_sent': attack_stats.get('packets_sent', 0),
                    'average_rate': attack_stats.get('average_rate', 0),
                    'peak_rate': attack_stats.get('peak_rate', 0),
                    'duration': attack_stats.get('duration', 0)
                })
                
        # Đánh dấu là đã hoàn thành khi tiến trình kết thúc
        if process.poll() is not None:
            logging.info(f"Tiến trình {process.pid} đã kết thúc với mã trạng thái: {process.returncode}")
            with stats_lock:
                if attack_stats["status"] != "completed" and attack_stats["status"] != "stopped":
                    attack_stats["status"] = "error"
                    attack_output_queue.put({"type": "error", "data": f"Tiến trình kết thúc bất ngờ với mã lỗi: {process.returncode}"})
                    socketio.emit('attack_error', {'error': f"Tiến trình kết thúc bất ngờ với mã lỗi: {process.returncode}"})
    except Exception as e:
        logging.error(f"Lỗi khi theo dõi tiến trình: {str(e)}")
        with stats_lock:
            attack_stats["status"] = "error"
            attack_output_queue.put({"type": "error", "data": f"Lỗi khi theo dõi tiến trình: {str(e)}"})
            socketio.emit('attack_error', {'error': f"Lỗi khi theo dõi tiến trình: {str(e)}"})

def emit_updates():
    """Gửi cập nhật định kỳ qua socket.io"""
    while not stop_update_thread.is_set():
        try:
            with stats_lock:
                # Cập nhật CPU và RAM
                attack_stats["cpu_usage"] = psutil.cpu_percent()
                attack_stats["ram_usage"] = psutil.virtual_memory().percent
                
                socketio.emit('status_update', {'stats': attack_stats})
                
            # Khoảng cách giữa các lần cập nhật
            time.sleep(1)
        except Exception as e:
            logging.error(f"Lỗi khi gửi cập nhật: {str(e)}")
            time.sleep(1)

def start_attack(params):
    """Bắt đầu một cuộc tấn công mới"""
    global attack_process, update_thread, stop_update_thread
    
    # Nếu đã có cuộc tấn công đang chạy, hãy dừng nó
    if attack_process and attack_process.poll() is None:
        stop_attack()
    
    try:
        # Sửa lỗi: đảm bảo attack_ratio đúng định dạng SYN:UDP:ACK:QUERY và tổng = 100
        attack_ratio = params.get("attack_ratio", "40:30:20:10")
        # Nếu có 5 phần (định dạng cũ với HTTP), chuyển sang định dạng mới
        parts = attack_ratio.split(":")
        if len(parts) == 5:
            # Phân bổ lại phần HTTP vào các phần khác
            syn_part = int(parts[0])
            udp_part = int(parts[1])
            ack_part = int(parts[2])
            http_part = int(parts[3])
            query_part = int(parts[4])
            
            # Phân phối lại phần HTTP
            syn_part += http_part // 3
            udp_part += http_part // 3
            ack_part += http_part - (http_part // 3) * 2
            
            # Tạo tỷ lệ mới
            attack_ratio = f"{syn_part}:{udp_part}:{ack_part}:{query_part}"
            logging.info(f"Đã chuyển đổi tỷ lệ tấn công sang định dạng SYN:UDP:ACK:QUERY: {attack_ratio}")
            
        # Khởi tạo lại thống kê
        with stats_lock:
            attack_stats.update({
                "status": "starting",
                "packets_sent": 0,
                "current_rate": 0,
                "peak_rate": 0,
                "average_rate": 0,
                "elapsed": 0,
                "duration": int(params.get("duration", 30)),
                "syn_count": 0,
                "udp_count": 0,
                "ack_count": 0,
                "http_count": 0,
                "query_count": 0,
                "target_host": params.get("host", "127.0.0.1"),
                "target_port": params.get("port", 80),
                "start_time": datetime.now(),
                "attack_ratio": attack_ratio,
                "cpu_usage": 0,
                "ram_usage": 0
            })
            
        # Xóa buffer đầu ra
        output_buffer.clear()
        
        # Đảm bảo attack_ratio không bao gồm HTTP (chỉ SYN:UDP:ACK:QUERY)
        # Khởi tạo quá trình tấn công
        attack_process = run_network_test(
            host=params.get("host", "127.0.0.1"),
            port=int(params.get("port", 80)),
            processes=int(params.get("processes", 2)),
            duration=int(params.get("duration", 30)),
            batch_size=int(params.get("batch_size", 200)),
            delay=float(params.get("delay", 0.01)),
            attack_ratio=attack_ratio,  # Sử dụng tỷ lệ đã được chuyển đổi ở trên
            socket_only=params.get("socket_only", True),
            verbose=True
        )
        
        # Log thông tin cho debugging
        logging.debug(f"Attack process PID: {attack_process.pid if attack_process else 'None'}")
        
        # Gửi thông báo bắt đầu tấn công
        socketio.emit('attack_started', {
            'target': params.get("host", "127.0.0.1"),
            'port': params.get("port", 80),
            'duration': params.get("duration", 30)
        })
        
        # Bắt đầu theo dõi đầu ra
        output_thread = threading.Thread(target=monitor_process_output, args=(attack_process,))
        output_thread.daemon = True
        output_thread.start()
        
        # Khởi động thread cập nhật
        stop_update_thread.clear()
        update_thread = threading.Thread(target=emit_updates)
        update_thread.daemon = True
        update_thread.start()
        
        return True, "Cuộc tấn công đã bắt đầu thành công"
    except Exception as e:
        logging.error(f"Error starting attack: {str(e)}")
        with stats_lock:
            attack_stats["status"] = "error"
            
        # Gửi thông báo lỗi
        socketio.emit('attack_error', {'error': str(e)})
        return False, f"Lỗi khi bắt đầu tấn công: {str(e)}"

def stop_attack():
    """Dừng cuộc tấn công đang chạy"""
    global attack_process, stop_update_thread
    
    if attack_process and attack_process.poll() is None:
        try:
            # Ghi log trước khi kết thúc
            logging.info(f"Đang dừng tiến trình tấn công PID: {attack_process.pid}")
            
            # Thử kết thúc nhẹ nhàng trước
            attack_process.terminate()
            
            # Đợi một chút
            time.sleep(1)
            
            # Nếu vẫn chạy, buộc kết thúc
            if attack_process.poll() is None:
                logging.info(f"Tiến trình không phản hồi, buộc kết thúc PID: {attack_process.pid}")
                attack_process.kill()
                
            with stats_lock:
                attack_stats["status"] = "stopped"
                
            # Gửi thông báo dừng tấn công
            socketio.emit('attack_stopped', {'packets_sent': attack_stats.get('packets_sent', 0)})
            
            # Dừng thread cập nhật
            stop_update_thread.set()
            
            # Đảm bảo process là None sau khi kết thúc
            return True, "Cuộc tấn công đã dừng thành công"
        except Exception as e:
            logging.error(f"Error stopping attack: {str(e)}")
            return False, f"Lỗi khi dừng tấn công: {str(e)}"
    else:
        logging.warning("Không tìm thấy tiến trình tấn công đang chạy để dừng")
        return False, "Không có cuộc tấn công đang chạy"

# SocketIO events
@socketio.on('connect')
def handle_connect():
    logging.info(f"Client connected: {request.sid}")

@socketio.on('disconnect')
def handle_disconnect():
    logging.info(f"Client disconnected: {request.sid}")

# Routes
@app.route('/')
def index():
    """Trang chủ"""
    return render_template('index.html')

@app.route('/results')
def results():
    """Trang kết quả"""
    return render_template('results.html')

@app.route('/about')
def about():
    """Trang thông tin"""
    return render_template('about.html')

@app.route('/api/start_attack', methods=['POST'])
def api_start_attack():
    """API để bắt đầu một cuộc tấn công mới"""
    params = request.json
    success, message = start_attack(params)
    
    if success:
        return jsonify({
            "success": True,
            "message": message,
            "params": params
        })
    else:
        return jsonify({
            "success": False,
            "message": message
        }), 400

@app.route('/api/stop_attack', methods=['POST'])
def api_stop_attack():
    """API để dừng một cuộc tấn công đang chạy"""
    success, message = stop_attack()
    
    if success:
        return jsonify({
            "success": True,
            "message": message,
            "stats": attack_stats
        })
    else:
        return jsonify({
            "success": False,
            "message": message
        }), 400

@app.route('/api/status', methods=['GET'])
def api_status():
    """API để lấy trạng thái hiện tại của cuộc tấn công"""
    with stats_lock:
        status_copy = dict(attack_stats)
        
    # Lấy đầu ra mới nhất
    latest_output = list(output_buffer)
    
    return jsonify({
        "stats": status_copy,
        "output": latest_output
    })

@app.route('/api/system_resources', methods=['GET'])
def api_system_resources():
    """API để lấy thông tin về tài nguyên hệ thống"""
    cpu_percent = psutil.cpu_percent(interval=0.1)
    memory_percent = psutil.virtual_memory().percent
    
    return jsonify({
        "cpu_percent": cpu_percent,
        "memory_percent": memory_percent,
        "timestamp": datetime.now().isoformat()
    })

# Tạo cấu trúc thư mục cần thiết
def create_directories():
    """Tạo cấu trúc thư mục cần thiết"""
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    os.makedirs('static/img', exist_ok=True)
    os.makedirs('templates', exist_ok=True)

if __name__ == '__main__':
    create_directories()
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)