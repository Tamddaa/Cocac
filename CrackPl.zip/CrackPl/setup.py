#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DDoS Pro - Script cài đặt
--------------------------
Script này sẽ kiểm tra các thư viện cần thiết và cài đặt chúng nếu thiếu.
"""

import os
import sys
import subprocess
import importlib.util
import platform

# Danh sách thư viện cần thiết
REQUIRED_PACKAGES = [
    "flask",
    "flask_socketio",
    "psutil",
    "scapy"
]

# Danh sách thư viện tùy chọn
OPTIONAL_PACKAGES = [
    "mcstatus",
    "flask_sqlalchemy"
]

def check_python_version():
    """Kiểm tra phiên bản Python."""
    print("Kiểm tra phiên bản Python...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print(f"[CẢNH BÁO] Python {version.major}.{version.minor} quá cũ. Khuyến nghị sử dụng Python 3.7+")
        return False
    print(f"[OK] Python {version.major}.{version.minor}.{version.micro}")
    return True

def check_package(package_name):
    """Kiểm tra xem gói đã được cài đặt chưa."""
    spec = importlib.util.find_spec(package_name)
    return spec is not None

def install_package(package):
    """Cài đặt gói bằng pip."""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        return True
    except subprocess.CalledProcessError:
        return False

def main():
    """Hàm chính."""
    print("=" * 60)
    print("DDoS Pro - Công cụ cài đặt")
    print("=" * 60)
    
    # Kiểm tra phiên bản Python
    check_python_version()
    
    # Kiểm tra pip
    print("\nKiểm tra pip...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"], 
                              stdout=subprocess.PIPE, 
                              stderr=subprocess.PIPE)
        print("[OK] pip đã được cài đặt")
    except:
        print("[LỖI] pip không được tìm thấy. Vui lòng cài đặt pip trước.")
        sys.exit(1)
    
    # Kiểm tra và cài đặt các gói bắt buộc
    print("\nKiểm tra các thư viện bắt buộc...")
    for package in REQUIRED_PACKAGES:
        if check_package(package):
            print(f"[OK] {package} đã được cài đặt")
        else:
            print(f"[THIẾU] {package} chưa được cài đặt. Đang cài đặt...")
            if install_package(package):
                print(f"[OK] Đã cài đặt {package} thành công")
            else:
                print(f"[LỖI] Không thể cài đặt {package}")
    
    # Kiểm tra các gói tùy chọn
    print("\nKiểm tra các thư viện tùy chọn...")
    for package in OPTIONAL_PACKAGES:
        if check_package(package):
            print(f"[OK] {package} đã được cài đặt")
        else:
            print(f"[THIẾU] {package} là thư viện tùy chọn, có thể cài đặt để sử dụng đầy đủ tính năng")
            choice = input(f"Bạn có muốn cài đặt {package}? (y/n): ").strip().lower()
            if choice == 'y':
                if install_package(package):
                    print(f"[OK] Đã cài đặt {package} thành công")
                else:
                    print(f"[LỖI] Không thể cài đặt {package}")
    
    # Kiểm tra quyền root (chỉ trên Linux/Mac)
    if platform.system() != "Windows":
        print("\nKiểm tra quyền root...")
        is_root = os.geteuid() == 0 if hasattr(os, "geteuid") else False
        if is_root:
            print("[OK] Bạn đang chạy với quyền root. Tất cả tính năng sẽ hoạt động")
        else:
            print("[LƯU Ý] Bạn không chạy với quyền root. Một số tính năng tấn công nâng cao sẽ bị giới hạn")
    
    # Kiểm tra môi trường Replit
    print("\nKiểm tra môi trường...")
    if os.environ.get('REPL_ID') is not None:
        print("[LƯU Ý] Đang chạy trong môi trường Replit. Một số giới hạn sẽ được áp dụng")
    else:
        print("[OK] Đang chạy trên máy chủ/máy tính cá nhân")
    
    # Hoàn tất
    print("\n" + "=" * 60)
    print("Cài đặt hoàn tất! Bạn có thể chạy DDoS Pro bằng lệnh:")
    print("   python main.py")
    print("=" * 60)

if __name__ == "__main__":
    main()