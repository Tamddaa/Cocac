package me.omh.solarcrate.monitoring;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;
import me.omh.solarcrate.SolarCrate;

public class PerformanceMonitor {
   private final SolarCrate plugin;
   private final Map<String, AtomicLong> timingMetrics = new ConcurrentHashMap();
   private final Map<String, AtomicInteger> counterMetrics = new ConcurrentHashMap();
   private final Map<String, PerformanceMonitor.OperationTracker> operationTrackers = new ConcurrentHashMap();
   private final AtomicLong memoryUsage = new AtomicLong();
   private final AtomicInteger activeThreads = new AtomicInteger();
   private final AtomicLong diskUsage = new AtomicLong();
   private final AtomicLong lastDiskCalculation = new AtomicLong(0L);
   private static final long DISK_CALCULATION_INTERVAL_MS = 300000L;
   private boolean healthCheckEnabled;
   private final Map<String, PerformanceMonitor.HealthStatus> healthStatuses = new ConcurrentHashMap();

   public PerformanceMonitor(SolarCrate plugin) {
      this.plugin = plugin;
      this.healthCheckEnabled = plugin.getConfig().getBoolean("monitoring.health_checks", true);
      this.initialize();
   }

   private void initialize() {
      this.registerMetric("crate_opens", PerformanceMonitor.MetricType.COUNTER);
      this.registerMetric("key_usage", PerformanceMonitor.MetricType.COUNTER);
      this.registerMetric("gui_interactions", PerformanceMonitor.MetricType.COUNTER);
      this.registerMetric("data_saves", PerformanceMonitor.MetricType.COUNTER);
      this.registerMetric("cache_hits", PerformanceMonitor.MetricType.COUNTER);
      this.registerMetric("cache_misses", PerformanceMonitor.MetricType.COUNTER);
      this.registerMetric("crate_open_time", PerformanceMonitor.MetricType.TIMING);
      this.registerMetric("data_save_time", PerformanceMonitor.MetricType.TIMING);
      this.registerMetric("cache_lookup_time", PerformanceMonitor.MetricType.TIMING);
      this.startSystemMonitoring();
      if (this.healthCheckEnabled) {
         this.startHealthChecks();
      }

      Logger var10000 = this.plugin.getLogger();
      int var10001 = this.timingMetrics.size();
      var10000.info("PerformanceMonitor initialized with " + var10001 + " timing metrics and " + this.counterMetrics.size() + " counters");
   }

   public void registerMetric(String name, PerformanceMonitor.MetricType type) {
      switch(type.ordinal()) {
      case 0:
         this.counterMetrics.putIfAbsent(name, new AtomicInteger(0));
         break;
      case 1:
         this.timingMetrics.putIfAbsent(name, new AtomicLong(0L));
         this.operationTrackers.putIfAbsent(name, new PerformanceMonitor.OperationTracker());
      }

   }

   public void incrementCounter(String metricName) {
      this.incrementCounter(metricName, 1);
   }

   public void incrementCounter(String metricName, int amount) {
      AtomicInteger counter = (AtomicInteger)this.counterMetrics.get(metricName);
      if (counter != null) {
         counter.addAndGet(amount);
      }

   }

   public void recordTiming(String metricName, long durationMs) {
      AtomicLong timing = (AtomicLong)this.timingMetrics.get(metricName);
      PerformanceMonitor.OperationTracker tracker = (PerformanceMonitor.OperationTracker)this.operationTrackers.get(metricName);
      if (timing != null && tracker != null) {
         timing.addAndGet(durationMs);
         tracker.recordOperation(durationMs);
      }

   }

   public PerformanceMonitor.TimingContext startTiming(String metricName) {
      return new PerformanceMonitor.TimingContext(this, metricName);
   }

   public int getCounter(String metricName) {
      AtomicInteger counter = (AtomicInteger)this.counterMetrics.get(metricName);
      return counter != null ? counter.get() : 0;
   }

   public PerformanceMonitor.TimingStats getTimingStats(String metricName) {
      PerformanceMonitor.OperationTracker tracker = (PerformanceMonitor.OperationTracker)this.operationTrackers.get(metricName);
      return tracker != null ? tracker.getStats() : null;
   }

   public PerformanceMonitor.PerformanceReport getPerformanceReport() {
      PerformanceMonitor.PerformanceReport report = new PerformanceMonitor.PerformanceReport();
      Iterator var2 = this.counterMetrics.entrySet().iterator();

      while(var2.hasNext()) {
         Entry<String, AtomicInteger> entry = (Entry)var2.next();
         report.addCounter((String)entry.getKey(), ((AtomicInteger)entry.getValue()).get());
      }

      var2 = this.timingMetrics.keySet().iterator();

      while(var2.hasNext()) {
         String metricName = (String)var2.next();
         PerformanceMonitor.TimingStats stats = this.getTimingStats(metricName);
         if (stats != null) {
            report.addTiming(metricName, stats);
         }
      }

      report.setMemoryUsage(this.memoryUsage.get());
      report.setActiveThreads(this.activeThreads.get());
      report.setDiskUsage(this.diskUsage.get());
      report.setHealthStatuses(new ArrayList(this.healthStatuses.values()));
      return report;
   }

   public void updateHealthStatus(String component, boolean healthy, String message) {
      PerformanceMonitor.HealthStatus status = new PerformanceMonitor.HealthStatus(component, healthy, message, System.currentTimeMillis());
      this.healthStatuses.put(component, status);
      if (!healthy) {
         this.plugin.getLogger().warning("Health check failed for " + component + ": " + message);
      }

   }

   public boolean isSystemHealthy() {
      return this.healthStatuses.values().stream().allMatch(PerformanceMonitor.HealthStatus::isHealthy);
   }

   private void startSystemMonitoring() {
      this.plugin.getFoliaLib().getImpl().runTimer(() -> {
         Runtime runtime = Runtime.getRuntime();
         long usedMemory = runtime.totalMemory() - runtime.freeMemory();
         this.memoryUsage.set(usedMemory);
         this.activeThreads.set(Thread.activeCount());
         long currentTime = System.currentTimeMillis();
         long lastCalculation = this.lastDiskCalculation.get();
         if (currentTime - lastCalculation > 300000L && this.lastDiskCalculation.compareAndSet(lastCalculation, currentTime)) {
            long diskSpace = this.calculateDirectorySize(this.plugin.getDataFolder());
            this.diskUsage.set(diskSpace);
            if (this.plugin.getConfigManager().getCachedBoolean("debug", false)) {
               this.plugin.getSLF4JLogger().debug("Updated disk usage cache: {} bytes", diskSpace);
            }
         }

      }, 200L, 200L);
   }

   private void startHealthChecks() {
      this.plugin.getFoliaLib().getImpl().runTimer(() -> {
         this.performHealthChecks();
      }, 600L, 600L);
   }

   private void performHealthChecks() {
      Runtime runtime = Runtime.getRuntime();
      long maxMemory = runtime.maxMemory();
      long usedMemory = runtime.totalMemory() - runtime.freeMemory();
      double memoryPercent = (double)usedMemory / (double)maxMemory * 100.0D;
      this.updateHealthStatus("memory", memoryPercent < 85.0D, String.format("Memory usage: %.1f%%", memoryPercent));
      int threadCount = Thread.activeCount();
      this.updateHealthStatus("threads", threadCount < 100, "Active threads: " + threadCount);
      long freeSpace = this.plugin.getDataFolder().getFreeSpace();
      long totalSpace = this.plugin.getDataFolder().getTotalSpace();
      double diskPercent = (double)(totalSpace - freeSpace) / (double)totalSpace * 100.0D;
      this.updateHealthStatus("disk", diskPercent < 90.0D, String.format("Disk usage: %.1f%%", diskPercent));
      int cacheHits = this.getCounter("cache_hits");
      int cacheMisses = this.getCounter("cache_misses");
      double hitRate = cacheHits + cacheMisses > 0 ? (double)cacheHits / (double)(cacheHits + cacheMisses) * 100.0D : 100.0D;
      this.updateHealthStatus("cache", hitRate > 70.0D, String.format("Cache hit rate: %.1f%%", hitRate));
   }

   private long calculateDirectorySize(File directory) {
      long size = 0L;
      if (directory.isDirectory()) {
         File[] files = directory.listFiles();
         if (files != null) {
            File[] var5 = files;
            int var6 = files.length;

            for(int var7 = 0; var7 < var6; ++var7) {
               File file = var5[var7];
               if (file.isDirectory()) {
                  size += this.calculateDirectorySize(file);
               } else {
                  size += file.length();
               }
            }
         }
      } else {
         size = directory.length();
      }

      return size;
   }

   public String getPerformanceSummary() {
      StringBuilder summary = new StringBuilder();
      summary.append("§6=== SolarCrate Performance Summary ===\n");
      summary.append("§eCrate Opens: §f").append(this.getCounter("crate_opens")).append("\n");
      summary.append("§eKey Usage: §f").append(this.getCounter("key_usage")).append("\n");
      summary.append("§eGUI Interactions: §f").append(this.getCounter("gui_interactions")).append("\n");
      int hits = this.getCounter("cache_hits");
      int misses = this.getCounter("cache_misses");
      double hitRate = hits + misses > 0 ? (double)hits / (double)(hits + misses) * 100.0D : 0.0D;
      summary.append("§eCache Hit Rate: §f").append(String.format("%.1f%%", hitRate)).append("\n");
      summary.append("§eSystem Health: ").append(this.isSystemHealthy() ? "§aHealthy" : "§cIssues Detected").append("\n");
      Runtime runtime = Runtime.getRuntime();
      long usedMemory = runtime.totalMemory() - runtime.freeMemory();
      summary.append("§eMemory Usage: §f").append(this.formatFileSize(usedMemory)).append("\n");
      return summary.toString();
   }

   private String formatFileSize(long bytes) {
      if (bytes < 1024L) {
         return bytes + " B";
      } else {
         int exp = (int)(Math.log((double)bytes) / Math.log(1024.0D));
         String pre = "KMGTPE".charAt(exp - 1).makeConcatWithConstants<invokedynamic>("KMGTPE".charAt(exp - 1));
         return String.format("%.1f %sB", (double)bytes / Math.pow(1024.0D, (double)exp), pre);
      }
   }

   public void resetMetrics() {
      this.counterMetrics.values().forEach((counter) -> {
         counter.set(0);
      });
      this.timingMetrics.values().forEach((timing) -> {
         timing.set(0L);
      });
      this.operationTrackers.values().forEach(PerformanceMonitor.OperationTracker::reset);
      this.plugin.getLogger().info("Performance metrics reset");
   }

   public void shutdown() {
      this.counterMetrics.clear();
      this.timingMetrics.clear();
      this.operationTrackers.clear();
      this.healthStatuses.clear();
      this.plugin.getLogger().info("PerformanceMonitor shutdown completed");
   }

   public static enum MetricType {
      COUNTER,
      TIMING;

      // $FF: synthetic method
      private static PerformanceMonitor.MetricType[] $values() {
         return new PerformanceMonitor.MetricType[]{COUNTER, TIMING};
      }
   }

   private static class OperationTracker {
      private final AtomicInteger count = new AtomicInteger();
      private final AtomicLong totalTime = new AtomicLong();
      private final AtomicLong minTime = new AtomicLong(Long.MAX_VALUE);
      private final AtomicLong maxTime = new AtomicLong();

      public void recordOperation(long durationMs) {
         this.count.incrementAndGet();
         this.totalTime.addAndGet(durationMs);

         for(long currentMin = this.minTime.get(); durationMs < currentMin && !this.minTime.compareAndSet(currentMin, durationMs); currentMin = this.minTime.get()) {
         }

         for(long currentMax = this.maxTime.get(); durationMs > currentMax && !this.maxTime.compareAndSet(currentMax, durationMs); currentMax = this.maxTime.get()) {
         }

      }

      public PerformanceMonitor.TimingStats getStats() {
         int operationCount = this.count.get();
         if (operationCount == 0) {
            return new PerformanceMonitor.TimingStats(0, 0L, 0L, 0L);
         } else {
            long total = this.totalTime.get();
            long avg = total / (long)operationCount;
            long min = this.minTime.get() == Long.MAX_VALUE ? 0L : this.minTime.get();
            long max = this.maxTime.get();
            return new PerformanceMonitor.TimingStats(operationCount, avg, min, max);
         }
      }

      public void reset() {
         this.count.set(0);
         this.totalTime.set(0L);
         this.minTime.set(Long.MAX_VALUE);
         this.maxTime.set(0L);
      }
   }

   public static class TimingContext implements AutoCloseable {
      private final PerformanceMonitor monitor;
      private final String metricName;
      private final long startTime;

      public TimingContext(PerformanceMonitor monitor, String metricName) {
         this.monitor = monitor;
         this.metricName = metricName;
         this.startTime = System.currentTimeMillis();
      }

      public void close() {
         long duration = System.currentTimeMillis() - this.startTime;
         this.monitor.recordTiming(this.metricName, duration);
      }
   }

   public static class TimingStats {
      private final int count;
      private final long average;
      private final long minimum;
      private final long maximum;

      public TimingStats(int count, long average, long minimum, long maximum) {
         this.count = count;
         this.average = average;
         this.minimum = minimum;
         this.maximum = maximum;
      }

      public int getCount() {
         return this.count;
      }

      public long getAverage() {
         return this.average;
      }

      public long getMinimum() {
         return this.minimum;
      }

      public long getMaximum() {
         return this.maximum;
      }
   }

   public static class PerformanceReport {
      private final Map<String, Integer> counters = new ConcurrentHashMap();
      private final Map<String, PerformanceMonitor.TimingStats> timings = new ConcurrentHashMap();
      private long memoryUsage;
      private int activeThreads;
      private long diskUsage;
      private List<PerformanceMonitor.HealthStatus> healthStatuses = new ArrayList();

      public void addCounter(String name, int value) {
         this.counters.put(name, value);
      }

      public void addTiming(String name, PerformanceMonitor.TimingStats stats) {
         this.timings.put(name, stats);
      }

      public Map<String, Integer> getCounters() {
         return this.counters;
      }

      public Map<String, PerformanceMonitor.TimingStats> getTimings() {
         return this.timings;
      }

      public long getMemoryUsage() {
         return this.memoryUsage;
      }

      public void setMemoryUsage(long memoryUsage) {
         this.memoryUsage = memoryUsage;
      }

      public int getActiveThreads() {
         return this.activeThreads;
      }

      public void setActiveThreads(int activeThreads) {
         this.activeThreads = activeThreads;
      }

      public long getDiskUsage() {
         return this.diskUsage;
      }

      public void setDiskUsage(long diskUsage) {
         this.diskUsage = diskUsage;
      }

      public List<PerformanceMonitor.HealthStatus> getHealthStatuses() {
         return this.healthStatuses;
      }

      public void setHealthStatuses(List<PerformanceMonitor.HealthStatus> healthStatuses) {
         this.healthStatuses = healthStatuses;
      }
   }

   public static class HealthStatus {
      private final String component;
      private final boolean healthy;
      private final String message;
      private final long timestamp;

      public HealthStatus(String component, boolean healthy, String message, long timestamp) {
         this.component = component;
         this.healthy = healthy;
         this.message = message;
         this.timestamp = timestamp;
      }

      public String getComponent() {
         return this.component;
      }

      public boolean isHealthy() {
         return this.healthy;
      }

      public String getMessage() {
         return this.message;
      }

      public long getTimestamp() {
         return this.timestamp;
      }
   }
}
