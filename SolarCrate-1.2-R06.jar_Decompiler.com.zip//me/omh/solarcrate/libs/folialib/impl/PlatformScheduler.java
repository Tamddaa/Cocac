package me.omh.solarcrate.libs.folialib.impl;

public interface PlatformScheduler extends ServerImplementation {
}
