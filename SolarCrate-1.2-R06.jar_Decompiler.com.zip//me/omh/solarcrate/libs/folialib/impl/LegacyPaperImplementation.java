package me.omh.solarcrate.libs.folialib.impl;

import me.omh.solarcrate.libs.folialib.FoliaLib;

public class LegacyPaperImplementation extends LegacySpigotImplementation {
   public LegacyPaperImplementation(FoliaLib foliaLib) {
      super(foliaLib);
   }
}
