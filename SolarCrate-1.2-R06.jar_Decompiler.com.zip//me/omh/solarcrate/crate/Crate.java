package me.omh.solarcrate.crate;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

public class Crate {
   private final String name;
   private Location location;
   private final Map<Integer, ItemStack> items = new HashMap();
   private String countdownTitle = "&e&l⏰ {count} ⏰";
   private String countdownSubtitle = "&7Chuẩn bị nhận phần thưởng...";
   private String successTitle = "&a&l✨ CHÚC MỪNG! ✨";
   private String successSubtitle = "&7Bạn đã nhận được: &e&l{item}";
   private boolean particlesEnabled = true;
   private String ambientParticle = "DUST";
   private int ambientColorRed = 0;
   private int ambientColorGreen = 252;
   private int ambientColorBlue = 255;
   private String openingParticle = "FIREWORK";
   private String celebrationParticle = "HAPPY_VILLAGER";
   private int particleDensity = 10;

   public Crate(String name, Location location) {
      this.name = name;
      this.location = location;
   }

   public String getName() {
      return this.name;
   }

   public Location getLocation() {
      return this.location;
   }

   public void setLocation(Location location) {
      this.location = location;
   }

   public Map<Integer, ItemStack> getItems() {
      return this.items;
   }

   public void setItem(int slot, ItemStack item) {
      this.items.put(slot, item);
   }

   public ItemStack getItem(int slot) {
      return (ItemStack)this.items.get(slot);
   }

   public void removeItem(int slot) {
      this.items.remove(slot);
   }

   public void setItems(Map<Integer, ItemStack> items) {
      this.items.clear();
      if (items != null) {
         this.items.putAll(items);
      }

   }

   public String getCountdownTitle() {
      return this.countdownTitle;
   }

   public void setCountdownTitle(String countdownTitle) {
      this.countdownTitle = countdownTitle != null ? countdownTitle : "&e&l⏰ {count} ⏰";
   }

   public String getCountdownSubtitle() {
      return this.countdownSubtitle;
   }

   public void setCountdownSubtitle(String countdownSubtitle) {
      this.countdownSubtitle = countdownSubtitle != null ? countdownSubtitle : "&7Chuẩn bị nhận phần thưởng...";
   }

   public String getSuccessTitle() {
      return this.successTitle;
   }

   public void setSuccessTitle(String successTitle) {
      this.successTitle = successTitle != null ? successTitle : "&a&l✨ CHÚC MỪNG! ✨";
   }

   public String getSuccessSubtitle() {
      return this.successSubtitle;
   }

   public void setSuccessSubtitle(String successSubtitle) {
      this.successSubtitle = successSubtitle != null ? successSubtitle : "&7Bạn đã nhận được: &e&l{item}";
   }

   public boolean isParticlesEnabled() {
      return this.particlesEnabled;
   }

   public void setParticlesEnabled(boolean particlesEnabled) {
      this.particlesEnabled = particlesEnabled;
   }

   public String getAmbientParticle() {
      return this.ambientParticle;
   }

   public void setAmbientParticle(String ambientParticle) {
      this.ambientParticle = ambientParticle != null ? ambientParticle : "DUST";
   }

   public int getAmbientColorRed() {
      return this.ambientColorRed;
   }

   public void setAmbientColorRed(int ambientColorRed) {
      this.ambientColorRed = Math.max(0, Math.min(255, ambientColorRed));
   }

   public int getAmbientColorGreen() {
      return this.ambientColorGreen;
   }

   public void setAmbientColorGreen(int ambientColorGreen) {
      this.ambientColorGreen = Math.max(0, Math.min(255, ambientColorGreen));
   }

   public int getAmbientColorBlue() {
      return this.ambientColorBlue;
   }

   public void setAmbientColorBlue(int ambientColorBlue) {
      this.ambientColorBlue = Math.max(0, Math.min(255, ambientColorBlue));
   }

   public String getOpeningParticle() {
      return this.openingParticle;
   }

   public void setOpeningParticle(String openingParticle) {
      this.openingParticle = openingParticle != null ? openingParticle : "FIREWORK";
   }

   public String getCelebrationParticle() {
      return this.celebrationParticle;
   }

   public void setCelebrationParticle(String celebrationParticle) {
      this.celebrationParticle = celebrationParticle != null ? celebrationParticle : "HAPPY_VILLAGER";
   }

   public int getParticleDensity() {
      return this.particleDensity;
   }

   public void setParticleDensity(int particleDensity) {
      this.particleDensity = Math.max(1, particleDensity);
   }

   public boolean validateLocation() {
      if (this.location == null) {
         return false;
      } else if (this.location.getWorld() == null) {
         return false;
      } else {
         double y = this.location.getY();
         return !(y < -64.0D) && !(y > 320.0D);
      }
   }

   public boolean validateItems() {
      if (this.items == null) {
         return true;
      } else {
         Iterator var1 = this.items.entrySet().iterator();

         while(var1.hasNext()) {
            Entry<Integer, ItemStack> entry = (Entry)var1.next();
            int slot = (Integer)entry.getKey();
            if (slot >= 0 && slot < 54) {
               ItemStack item = (ItemStack)entry.getValue();
               if (item != null && item.getType() != null && !item.getType().isAir()) {
                  continue;
               }

               return false;
            }

            return false;
         }

         return true;
      }
   }

   public boolean validateParticleSettings() {
      if (this.ambientColorRed >= 0 && this.ambientColorRed <= 255) {
         if (this.ambientColorGreen >= 0 && this.ambientColorGreen <= 255) {
            if (this.ambientColorBlue >= 0 && this.ambientColorBlue <= 255) {
               return this.particleDensity >= 1 && this.particleDensity <= 100;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public int getItemCount() {
      return this.items != null ? this.items.size() : 0;
   }

   public boolean hasLocation() {
      return this.location != null && this.location.getWorld() != null;
   }

   public boolean isEmpty() {
      return this.items == null || this.items.isEmpty();
   }
}
