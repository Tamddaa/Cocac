package me.omh.solarcrate.placeholders;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public class SolarCratePlaceholder extends PlaceholderExpansion {
   private final SolarCrate plugin;

   public SolarCratePlaceholder(SolarCrate plugin) {
      this.plugin = plugin;
   }

   @NotNull
   public String getIdentifier() {
      return "sc";
   }

   @NotNull
   public String getAuthor() {
      List<String> authors = this.plugin.getDescription().getAuthors();
      return authors.isEmpty() ? "Omh" : (String)authors.get(0);
   }

   @NotNull
   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onRequest(OfflinePlayer player, @NotNull String params) {
      if (params != null && !params.trim().isEmpty()) {
         if (this.plugin.getTimerManager() != null && this.plugin.getConfigManager() != null && this.plugin.getKeyManager() != null) {
            try {
               String var3 = params.toLowerCase();
               byte var4 = -1;
               switch(var3.hashCode()) {
               case -1012222381:
                  if (var3.equals("online")) {
                     var4 = 7;
                  }
                  break;
               case -892481550:
                  if (var3.equals("status")) {
                     var4 = 3;
                  }
                  break;
               case 113745:
                  if (var3.equals("sec")) {
                     var4 = 2;
                  }
                  break;
               case 3288564:
                  if (var3.equals("keys")) {
                     var4 = 5;
                  }
                  break;
               case 3560141:
                  if (var3.equals("time")) {
                     var4 = 0;
                  }
                  break;
               case 351608024:
                  if (var3.equals("version")) {
                     var4 = 6;
                  }
                  break;
               case 570418373:
                  if (var3.equals("interval")) {
                     var4 = 4;
                  }
                  break;
               case 1121048433:
                  if (var3.equals("time_color")) {
                     var4 = 1;
                  }
               }

               switch(var4) {
               case 0:
                  return this.formatTimeHMS(this.plugin.getTimerManager().getTimeUntilNext());
               case 1:
                  return SolarUtils.c("&a" + this.formatTimeHMS(this.plugin.getTimerManager().getTimeUntilNext()));
               case 2:
                  return String.valueOf(this.plugin.getTimerManager().getTimeUntilNext());
               case 3:
                  boolean isRunning = this.plugin.getTimerManager().isRunning();
                  return SolarUtils.c(isRunning ? "&a✓ Hoạt động" : "&c✗ Tắt");
               case 4:
                  return String.valueOf(this.plugin.getConfigManager().getTimerInterval());
               case 5:
                  if (player == null) {
                     return "0";
                  }

                  return String.valueOf(this.getTotalKeysForPlayer(player.getUniqueId()));
               case 6:
                  return this.plugin.getDescription().getVersion();
               case 7:
                  return "true";
               default:
                  if (params.startsWith("key_") && player != null && params.length() > 4) {
                     try {
                        String crateName = params.substring(4).trim();
                        if (!crateName.isEmpty()) {
                           return String.valueOf(this.plugin.getKeyManager().getKeys(player.getUniqueId(), crateName));
                        }
                     } catch (NullPointerException var7) {
                        this.plugin.getLogger().warning("Null value processing key placeholder '" + params + "': " + var7.getMessage());
                        var7.printStackTrace();
                        return "0";
                     } catch (IllegalArgumentException var8) {
                        this.plugin.getLogger().warning("Invalid argument in key placeholder '" + params + "': " + var8.getMessage());
                        return "0";
                     } catch (RuntimeException var9) {
                        this.plugin.getLogger().severe("Runtime error processing key placeholder '" + params + "': " + var9.getClass().getSimpleName() + " - " + var9.getMessage());
                        var9.printStackTrace();
                        return "0";
                     }
                  }

                  return "";
               }
            } catch (NullPointerException var10) {
               this.plugin.getLogger().severe("Null value in placeholder request '" + params + "': " + var10.getMessage());
               var10.printStackTrace();
               return "";
            } catch (IllegalArgumentException var11) {
               this.plugin.getLogger().warning("Invalid argument in placeholder request '" + params + "': " + var11.getMessage());
               return "";
            } catch (IllegalStateException var12) {
               this.plugin.getLogger().warning("Invalid state processing placeholder '" + params + "': " + var12.getMessage());
               return "";
            } catch (RuntimeException var13) {
               this.plugin.getLogger().severe("Runtime error processing placeholder '" + params + "': " + var13.getClass().getSimpleName() + " - " + var13.getMessage());
               var13.printStackTrace();
               return "";
            }
         } else {
            this.plugin.getLogger().warning("PlaceholderAPI request '" + params + "' failed: Plugin managers not initialized");
            return "";
         }
      } else {
         return "";
      }
   }

   private String formatTimeHMS(long seconds) {
      if (seconds <= 0L) {
         return "0s";
      } else {
         long hours = seconds / 3600L;
         long minutes = seconds % 3600L / 60L;
         long secs = seconds % 60L;
         StringBuilder sb = new StringBuilder();
         if (hours > 0L) {
            sb.append(hours).append("h");
         }

         if (minutes > 0L) {
            if (sb.length() > 0) {
               sb.append(" ");
            }

            sb.append(minutes).append("m");
         }

         if (secs > 0L || sb.length() == 0) {
            if (sb.length() > 0) {
               sb.append(" ");
            }

            sb.append(secs).append("s");
         }

         return sb.toString();
      }
   }

   private int getTotalKeysForPlayer(UUID uuid) {
      if (uuid == null) {
         return 0;
      } else {
         Logger var10000;
         String var10001;
         try {
            int total = 0;
            Map<String, Crate> crates = this.plugin.getCrateManager().getCrates();
            if (crates != null) {
               Iterator var4 = crates.keySet().iterator();

               while(var4.hasNext()) {
                  String crateName = (String)var4.next();
                  if (crateName != null) {
                     total += this.plugin.getKeyManager().getKeys(uuid, crateName);
                  }
               }
            }

            return total;
         } catch (NullPointerException var6) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Null value calculating total keys for player " + var10001 + ": " + var6.getMessage());
            var6.printStackTrace();
            return 0;
         } catch (IllegalStateException var7) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.warning("Invalid state calculating total keys for player " + var10001 + ": " + var7.getMessage());
            return 0;
         } catch (RuntimeException var8) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Runtime error calculating total keys for player " + var10001 + ": " + var8.getClass().getSimpleName() + " - " + var8.getMessage());
            var8.printStackTrace();
            return 0;
         }
      }
   }
}
