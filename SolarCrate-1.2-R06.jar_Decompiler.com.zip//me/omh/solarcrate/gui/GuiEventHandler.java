package me.omh.solarcrate.gui;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicLong;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.libs.folialib.wrapper.task.WrappedTask;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.inventory.Inventory;

public class GuiEventHandler implements Listener {
   private final SolarCrate plugin;
   private final GuiManager guiManager;
   private final AtomicLong eventCount = new AtomicLong(0L);
   private volatile boolean isShutdown = false;
   private WrappedTask periodicCleanupTask;

   public GuiEventHandler(SolarCrate plugin, GuiManager guiManager) {
      if (plugin == null) {
         throw new IllegalArgumentException("Plugin cannot be null");
      } else if (guiManager == null) {
         throw new IllegalArgumentException("GuiManager cannot be null");
      } else {
         this.plugin = plugin;
         this.guiManager = guiManager;
         this.periodicCleanupTask = plugin.getFoliaLib().getImpl().runTimer(this::performPeriodicCleanup, 12000L, 12000L);
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onInventoryClick(InventoryClickEvent event) {
      if (!this.isShutdown && event.getWhoClicked() instanceof Player) {
         this.eventCount.incrementAndGet();
         Player player = (Player)event.getWhoClicked();

         try {
            if (this.guiManager == null) {
               event.setCancelled(true);
               return;
            }

            BaseGui gui = this.guiManager.getCurrentGui(player);
            if (gui != null) {
               if (!this.isValidGui(gui, player)) {
                  this.guiManager.closeCurrentGui(player);
                  event.setCancelled(true);
                  return;
               }

               boolean handled = false;

               try {
                  handled = this.handleAdvancedClick(event, gui, player);
               } catch (Exception var7) {
                  handled = true;
               }

               if (handled) {
                  event.setCancelled(true);
               }
            }
         } catch (Exception var8) {
            try {
               this.guiManager.closeCurrentGui(player);
            } catch (Exception var6) {
            }

            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onInventoryDrag(InventoryDragEvent event) {
      if (!this.isShutdown && event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();

         try {
            BaseGui gui = this.guiManager.getCurrentGui(player);
            if (gui != null) {
               if (!this.isValidGui(gui, player)) {
                  this.guiManager.closeCurrentGui(player);
                  event.setCancelled(true);
                  return;
               }

               boolean allowDrag = false;

               try {
                  allowDrag = this.handleDragEvent(event, gui, player);
               } catch (Exception var7) {
                  allowDrag = false;
               }

               if (!allowDrag) {
                  event.setCancelled(true);
               }
            }
         } catch (Exception var8) {
            try {
               this.guiManager.closeCurrentGui(player);
            } catch (Exception var6) {
            }

            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onInventoryClose(InventoryCloseEvent event) {
      if (!this.isShutdown && event.getPlayer() instanceof Player) {
         Player player = (Player)event.getPlayer();

         try {
            BaseGui gui = this.guiManager.getCurrentGui(player);
            if (gui != null) {
               Inventory eventInventory = event.getInventory();
               if (eventInventory != null && gui.getInventory() != null && gui.getInventory().equals(eventInventory)) {
                  this.plugin.getFoliaLib().getImpl().runLater(() -> {
                     try {
                        this.guiManager.closeCurrentGui(player);
                     } catch (Exception var3) {
                     }

                  }, 1L);
               }
            }
         } catch (Exception var6) {
            try {
               this.guiManager.closeCurrentGui(player);
            } catch (Exception var5) {
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.handlePlayerDisconnect(event.getPlayer(), "quit");
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerKick(PlayerKickEvent event) {
      this.handlePlayerDisconnect(event.getPlayer(), "kick");
   }

   private void handlePlayerDisconnect(Player player, String reason) {
      if (!this.isShutdown) {
         try {
            if (this.guiManager.hasOpenGui(player)) {
               this.guiManager.closeCurrentGui(player);
            }
         } catch (Exception var4) {
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onInventoryPickupItem(InventoryPickupItemEvent event) {
      if (!this.isShutdown) {
         Inventory inventory = event.getInventory();
         if (inventory != null && inventory.getHolder() instanceof Player) {
            Player player = (Player)inventory.getHolder();
            BaseGui gui = this.guiManager.getCurrentGui(player);
            if (gui != null && gui.getInventory().equals(inventory)) {
               event.setCancelled(true);
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPluginDisable(PluginDisableEvent event) {
      if (event.getPlugin().equals(this.plugin)) {
         this.shutdown();
      }

   }

   private boolean isValidGui(BaseGui gui, Player player) {
      if (gui != null && player != null) {
         if (!gui.belongsTo(player)) {
            return false;
         } else {
            return gui.getInventory() != null;
         }
      } else {
         return false;
      }
   }

   private void performPeriodicCleanup() {
      if (!this.isShutdown) {
         try {
            this.guiManager.getCacheStats();
         } catch (Exception var2) {
         }

      }
   }

   private boolean handleAdvancedClick(InventoryClickEvent event, BaseGui gui, Player player) {
      if (event.getClick().isShiftClick()) {
         return this.handleShiftClick(event, gui, player);
      } else {
         return event.getClick().isKeyboardClick() ? this.handleNumberKeyClick(event, gui, player) : gui.handleClick(event);
      }
   }

   private boolean handleShiftClick(InventoryClickEvent event, BaseGui gui, Player player) {
      boolean isGuiInventory = event.getClickedInventory() != null && event.getClickedInventory().equals(gui.getInventory());
      int i;
      BaseGui.SlotPermission permission;
      if (isGuiInventory) {
         i = event.getSlot();
         permission = gui.getSlotPermission(i);
         if (permission == BaseGui.SlotPermission.EDITABLE) {
            return gui.handleClick(event);
         } else {
            event.setCancelled(true);
            return true;
         }
      } else {
         for(i = 0; i < gui.getInventory().getSize(); ++i) {
            permission = gui.getSlotPermission(i);
            if (permission == BaseGui.SlotPermission.EDITABLE && gui.getInventory().getItem(i) == null) {
               return gui.handleClick(event);
            }
         }

         event.setCancelled(true);
         return true;
      }
   }

   private boolean handleNumberKeyClick(InventoryClickEvent event, BaseGui gui, Player player) {
      boolean isGuiInventory = event.getClickedInventory() != null && event.getClickedInventory().equals(gui.getInventory());
      if (isGuiInventory) {
         int slot = event.getSlot();
         BaseGui.SlotPermission permission = gui.getSlotPermission(slot);
         if (permission == BaseGui.SlotPermission.EDITABLE) {
            return gui.handleClick(event);
         } else {
            event.setCancelled(true);
            return true;
         }
      } else {
         return gui.handleClick(event);
      }
   }

   private boolean handleDragEvent(InventoryDragEvent event, BaseGui gui, Player player) {
      boolean allowDrag = true;
      Iterator var5 = event.getRawSlots().iterator();

      while(var5.hasNext()) {
         Integer rawSlot = (Integer)var5.next();
         if (rawSlot < gui.getInventory().getSize()) {
            BaseGui.SlotPermission permission = gui.getSlotPermission(rawSlot);
            if (permission != BaseGui.SlotPermission.EDITABLE) {
               allowDrag = false;
               break;
            }
         }
      }

      return allowDrag;
   }

   public void shutdown() {
      this.isShutdown = true;
      if (this.periodicCleanupTask != null && !this.periodicCleanupTask.isCancelled()) {
         try {
            this.periodicCleanupTask.cancel();
         } catch (Exception var5) {
         } finally {
            this.periodicCleanupTask = null;
         }
      }

   }
}
