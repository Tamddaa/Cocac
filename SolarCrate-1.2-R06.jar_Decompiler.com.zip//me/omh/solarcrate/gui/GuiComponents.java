package me.omh.solarcrate.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class GuiComponents {
   public static ItemStack createGlassPane(Material material, String name, String... lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(name));
         if (lore.length > 0) {
            meta.setLore(Arrays.stream(lore).map(SolarUtils::c).toList());
         }

         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createNavigationButton(Material material, String name, String action, String... lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&f&l" + name));
         List<String> fullLore = new ArrayList();
         fullLore.addAll(Arrays.stream(lore).map(SolarUtils::c).toList());
         fullLore.add("");
         fullLore.add(SolarUtils.c("&7▸ &e" + action));
         fullLore.add(SolarUtils.c("&8▸ Nhấp để thực hiện"));
         meta.setLore(fullLore);
         meta.addEnchant(Enchantment.UNBREAKING, 1, true);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createInfoDisplay(Material material, String title, String value, String description) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&b&l" + title));
         List<String> lore = Arrays.asList(SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&f&l▸ &a" + value), SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&7" + description), "", SolarUtils.c("&8▸ Chỉ hiển thị thông tin"));
         meta.setLore(lore);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createConfirmButton(boolean confirm) {
      Material material = confirm ? Material.GREEN_WOOL : Material.RED_WOOL;
      String name = confirm ? "&a&l✓ XÁC NHẬN" : "&c&l✕ HỦY BỎ";
      String action = confirm ? "Xác nhận thao tác" : "Hủy bỏ thao tác";
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(name));
         List<String> lore = Arrays.asList(SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&f&l▸ &7" + action), SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), "", SolarUtils.c("&e⚡ Nhấp để " + (confirm ? "xác nhận" : "hủy bỏ")));
         meta.setLore(lore);
         if (confirm) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
         }

         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createCrateDisplay(String crateName, int itemCount, int keyCount, String world, double x, double y, double z) {
      ItemStack item = new ItemStack(Material.CHEST);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&6&l⚡ " + crateName.toUpperCase()));
         String[] var10000 = new String[]{SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&f&l\ud83d\udcca THỐNG KÊ"), SolarUtils.c("&7▸ Items: &a" + itemCount + "&7/&a54"), SolarUtils.c("&7▸ Keys: &b" + keyCount), SolarUtils.c("&7▸ Vị trí: &e" + world), null, null, null, null, null};
         Object[] var10004 = new Object[]{x, y, z};
         var10000[5] = SolarUtils.c("&7▸ Tọa độ: &f" + String.format("%.1f, %.1f, %.1f", var10004));
         var10000[6] = SolarUtils.c("&7━━━━━━━━━━━━━━━━━━");
         var10000[7] = "";
         var10000[8] = SolarUtils.c("&e⚡ &lNhấp để mở crate");
         var10000[9] = SolarUtils.c("&8▸ Cần chìa khóa để sử dụng");
         List<String> lore = Arrays.asList(var10000);
         meta.setLore(lore);
         meta.addEnchant(Enchantment.UNBREAKING, 1, true);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createKeyDisplay(String keyName, int amount) {
      ItemStack item = new ItemStack(Material.TRIPWIRE_HOOK);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&e&l\ud83d\udddd " + keyName.toUpperCase() + " KEY"));
         List<String> lore = Arrays.asList(SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&f&l\ud83d\udcca SỐ LƯỢNG: &a" + amount), SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&7Chìa khóa để mở crate &e" + keyName), "", SolarUtils.c("&a&l✓ &7Có thể sử dụng"), SolarUtils.c("&8▸ Nhấp chuột phải để sử dụng"));
         meta.setLore(lore);
         if (amount > 0) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
         }

         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createProgressBar(int current, int max, String title) {
      double percentage = max > 0 ? (double)current / (double)max : 0.0D;
      Material material = percentage >= 1.0D ? Material.GREEN_STAINED_GLASS_PANE : (percentage >= 0.5D ? Material.YELLOW_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE);
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&f&l" + title));
         String progressBar = createProgressBarVisual(percentage);
         List<String> lore = Arrays.asList(SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"), SolarUtils.c("&f" + progressBar), SolarUtils.c("&7Tiến độ: &a" + current + "&7/&a" + max + " &7(" + String.format("%.1f%%", percentage * 100.0D) + ")"), SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"));
         meta.setLore(lore);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createDecoration(Material material, String name) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&8&l" + name));
         meta.setLore(Arrays.asList(SolarUtils.c("&8▸ Trang trí giao diện")));
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
         item.setItemMeta(meta);
      }

      return item;
   }

   public static ItemStack createPlayerHead(String playerName, String title, String... lore) {
      ItemStack item = new ItemStack(Material.PLAYER_HEAD);
      SkullMeta meta = (SkullMeta)item.getItemMeta();
      if (meta != null) {
         meta.setOwner(playerName);
         meta.setDisplayName(SolarUtils.c("&b&l" + title));
         List<String> fullLore = new ArrayList();
         fullLore.add(SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"));
         fullLore.add(SolarUtils.c("&f&l▸ Người chơi: &a" + playerName));
         fullLore.addAll(Arrays.stream(lore).map(SolarUtils::c).toList());
         fullLore.add(SolarUtils.c("&7━━━━━━━━━━━━━━━━━━"));
         meta.setLore(fullLore);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   private static String createProgressBarVisual(double percentage) {
      int totalBars = 20;
      int filledBars = (int)(percentage * (double)totalBars);
      StringBuilder bar = new StringBuilder();

      for(int i = 0; i < totalBars; ++i) {
         if (i < filledBars) {
            bar.append("&a█");
         } else {
            bar.append("&7█");
         }
      }

      return bar.toString();
   }

   public static class EditSession {
      private boolean dirty = false;
      private boolean closed = false;
      private String crateName = "";
      private int itemCount = 0;

      public boolean isDirty() {
         return this.dirty;
      }

      public void setDirty(boolean dirty) {
         this.dirty = dirty;
      }

      public boolean isClosed() {
         return this.closed;
      }

      public void close() {
         this.closed = true;
      }

      public String getCrateName() {
         return this.crateName;
      }

      public void setCrateName(String crateName) {
         this.crateName = crateName;
      }

      public int getItemCount() {
         return this.itemCount;
      }

      public void setItemCount(int itemCount) {
         this.itemCount = itemCount;
      }
   }

   public static class PermissionGlass {
      public static final GuiComponents.PermissionGlass DENY;
      public static final GuiComponents.PermissionGlass ALLOW;
      public static final GuiComponents.PermissionGlass NEUTRAL;
      private final Material material;
      private final String displayName;

      private PermissionGlass(Material material, String displayName) {
         this.material = material;
         this.displayName = displayName;
      }

      public ItemStack createItem() {
         ItemStack item = new ItemStack(this.material);
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            meta.setDisplayName(SolarUtils.c(this.displayName));
            item.setItemMeta(meta);
         }

         return item;
      }

      public ItemStack getItemStack() {
         return this.createItem();
      }

      public static GuiComponents.PermissionGlass configurableEditable(SolarCrate plugin) {
         return ALLOW;
      }

      static {
         DENY = new GuiComponents.PermissionGlass(Material.RED_STAINED_GLASS_PANE, "&c✘ Không có quyền");
         ALLOW = new GuiComponents.PermissionGlass(Material.GREEN_STAINED_GLASS_PANE, "&a✓ Được phép");
         NEUTRAL = new GuiComponents.PermissionGlass(Material.GRAY_STAINED_GLASS_PANE, "&7━");
      }
   }

   public static class ItemButton {
      private final ItemStack item;
      private final Consumer<InventoryClickEvent> clickHandler;

      public ItemButton(ItemStack item, Consumer<InventoryClickEvent> clickHandler) {
         this.item = item;
         this.clickHandler = clickHandler;
      }

      public ItemButton(ItemStack item) {
         this.item = item;
         this.clickHandler = null;
      }

      public ItemStack getItem() {
         return this.item;
      }

      public void handleClick(InventoryClickEvent event) {
         if (this.clickHandler != null) {
            this.clickHandler.accept(event);
         }

      }
   }
}
