package me.omh.solarcrate.gui;

import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CrateSelectionGui extends BaseGui {
   private final String crateName;
   private final Crate crate;
   private boolean isLoading = false;

   public CrateSelectionGui(SolarCrate plugin, String crateName) {
      super(plugin, getSelectionTitle(plugin, crateName), 27);
      this.crateName = crateName;
      this.crate = plugin.getCrateManager().getCrate(crateName);
      this.setData("crateName", crateName);
   }

   private static String getSelectionTitle(SolarCrate plugin, String crateName) {
      String title = plugin.getConfigManager().getConfig().getString("crate_display.selection_title", "&8✨ {crate_name} &8- Select Item");
      title = title.replace("{crate_name}", crateName != null ? crateName : "Unknown").replace("{crate}", crateName != null ? crateName : "Unknown");
      return SolarUtils.c(title);
   }

   protected void setupGui() {
      if (this.crate != null) {
         this.isLoading = true;
         this.setupGlassPanes();
         this.setupCrateItems();
         this.isLoading = false;
      }
   }

   private void setupGlassPanes() {
      ItemStack glassPane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
      ItemMeta meta = glassPane.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(" "));
         glassPane.setItemMeta(meta);
      }

      for(int i = 0; i < 27; ++i) {
         this.setItem(i, glassPane, BaseGui.SlotPermission.BACKGROUND);
      }

   }

   private void setupCrateItems() {
      if (this.crate != null) {
         this.crate.getItems().forEach((slot, item) -> {
            if (slot < 27) {
               this.setItem(slot, item, BaseGui.SlotPermission.BUTTON, (event) -> {
                  this.handleItemSelection(event, item);
               });
            }

         });
      }
   }

   private void handleItemSelection(InventoryClickEvent event, ItemStack selectedItem) {
      if (this.viewer == null) {
         this.plugin.getLogger().warning("Viewer is null in handleItemSelection - GUI state may be corrupted");
      } else if (this.isLoading) {
         this.playErrorSound(this.viewer);
      } else if (this.plugin.getGuiManager().hasPendingConfirmation(this.viewer.getUniqueId(), this.crateName)) {
         this.playDenySound(this.viewer);
      } else {
         int keys = this.plugin.getKeyManager().getKeys(this.viewer.getUniqueId(), this.crateName);
         if (keys <= 0) {
            this.playErrorSound(this.viewer);
            this.viewer.sendMessage(SolarUtils.c(this.plugin.getConfigManager().getMessage("no-key-for-crate")));
         } else {
            this.plugin.getGuiManager().setPendingConfirmation(this.viewer.getUniqueId(), this.crateName);
            this.playClickSound(this.viewer);
            this.plugin.getFoliaLib().getImpl().runLater(() -> {
               ItemStack finalItem = selectedItem.clone();
               this.plugin.getGuiManager().openConfirmationGui(this.viewer, finalItem, this.crateName);
            }, 5L);
         }
      }
   }

   public void cleanup() {
      if (this.viewer != null) {
         this.plugin.getGuiManager().clearPendingConfirmation(this.viewer.getUniqueId(), this.crateName);
      }

      super.cleanup();
   }
}
