package me.omh.solarcrate.gui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.libs.folialib.wrapper.task.WrappedTask;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GuiManager {
   private final SolarCrate plugin;
   private final Map<UUID, BaseGui> playerGuis = new ConcurrentHashMap();
   private final Map<UUID, Long> lastGuiAccess = new ConcurrentHashMap();
   private final Map<String, Object> componentCache = new ConcurrentHashMap();
   private final Map<String, Long> pendingConfirmations = new ConcurrentHashMap();
   private final long GUI_TIMEOUT_MS = 300000L;
   private final long CONFIRMATION_TIMEOUT_MS = 30000L;
   private WrappedTask cleanupTask;

   public GuiManager(SolarCrate plugin) {
      if (plugin == null) {
         throw new IllegalArgumentException("Plugin cannot be null");
      } else {
         this.plugin = plugin;
         this.startCleanupTask();
      }
   }

   private void startCleanupTask() {
      this.cleanupTask = this.plugin.getFoliaLib().getImpl().runTimer(() -> {
         this.cleanupExpiredGuis();
      }, 6000L, 6000L);
   }

   private void cleanupExpiredGuis() {
      try {
         long currentTime = System.currentTimeMillis();
         ArrayList<UUID> expiredPlayers = new ArrayList();
         ArrayList<String> expiredConfirmations = new ArrayList();
         Iterator var5 = this.lastGuiAccess.entrySet().iterator();

         Entry entry;
         long timestamp;
         while(var5.hasNext()) {
            entry = (Entry)var5.next();
            UUID playerId = (UUID)entry.getKey();
            timestamp = (Long)entry.getValue();
            if (currentTime - timestamp > 300000L) {
               expiredPlayers.add(playerId);
            }
         }

         var5 = this.pendingConfirmations.entrySet().iterator();

         while(var5.hasNext()) {
            entry = (Entry)var5.next();
            String key = (String)entry.getKey();
            timestamp = (Long)entry.getValue();
            if (currentTime - timestamp > 30000L) {
               expiredConfirmations.add(key);
            }
         }

         var5 = expiredPlayers.iterator();

         while(var5.hasNext()) {
            UUID playerId = (UUID)var5.next();

            try {
               BaseGui gui = (BaseGui)this.playerGuis.remove(playerId);
               this.lastGuiAccess.remove(playerId);
               if (gui != null) {
                  gui.cleanup();
               }
            } catch (Exception var10) {
            }
         }

         var5 = expiredConfirmations.iterator();

         while(var5.hasNext()) {
            String key = (String)var5.next();
            this.pendingConfirmations.remove(key);
         }
      } catch (Exception var11) {
      }

   }

   public void openCrateSelectionGui(Player player, String crateName) {
      this.plugin.getFoliaLib().getImpl().runAtEntity(player, (task) -> {
         this.openGuiSafely(player, () -> {
            CrateSelectionGui gui = new CrateSelectionGui(this.plugin, crateName);
            gui.setData("openTime", System.currentTimeMillis());
            gui.setData("crateName", crateName);
            return gui;
         }, "crate selection", crateName);
      });
   }

   public void openConfirmationGui(Player player, ItemStack selectedItem, String crateName) {
      this.plugin.getFoliaLib().getImpl().runAtEntity(player, (task) -> {
         this.openGuiSafely(player, () -> {
            ConfirmationGui gui = new ConfirmationGui(this.plugin, selectedItem, crateName);
            gui.setData("selectedItem", selectedItem);
            gui.setData("crateName", crateName);
            gui.setData("openTime", System.currentTimeMillis());
            return gui;
         }, "confirmation", (String)null);
      });
   }

   public void openCrateEditGui(Player player, String crateName) {
      this.plugin.getFoliaLib().getImpl().runAtEntity(player, (task) -> {
         this.openGuiSafely(player, () -> {
            EditWorkbenchGui gui = new EditWorkbenchGui(this.plugin, crateName);
            gui.setData("crateName", crateName);
            gui.setData("openTime", System.currentTimeMillis());
            return gui;
         }, "crate edit", crateName);
      });
   }

   private void openGuiSafely(Player player, GuiManager.GuiSupplier guiSupplier, String guiType, String context) {
      try {
         if (!player.isOnline()) {
            return;
         }

         UUID playerId = player.getUniqueId();
         this.closeCurrentGui(player);
         BaseGui gui = guiSupplier.create();
         if (gui == null) {
            return;
         }

         gui.open(player);
         long currentTime = System.currentTimeMillis();
         this.playerGuis.put(playerId, gui);
         this.lastGuiAccess.put(playerId, currentTime);
      } catch (Exception var9) {
         this.closeCurrentGui(player);
      }

   }

   public void closeCurrentGui(Player player) {
      UUID playerId = player.getUniqueId();
      BaseGui currentGui = (BaseGui)this.playerGuis.remove(playerId);
      this.lastGuiAccess.remove(playerId);
      if (currentGui != null) {
         try {
            currentGui.cleanup();
         } catch (Exception var5) {
         }
      }

   }

   public void forceCloseAll() {
      this.playerGuis.values().forEach(BaseGui::forceClose);
      this.playerGuis.clear();
      this.lastGuiAccess.clear();
   }

   public BaseGui getCurrentGui(Player player) {
      UUID playerId = player.getUniqueId();
      BaseGui gui = (BaseGui)this.playerGuis.get(playerId);
      if (gui != null) {
         this.lastGuiAccess.put(playerId, System.currentTimeMillis());
      }

      return gui;
   }

   public boolean hasOpenGui(Player player) {
      return this.playerGuis.containsKey(player.getUniqueId());
   }

   public boolean isGuiExpired(Player player) {
      Long lastAccess = (Long)this.lastGuiAccess.get(player.getUniqueId());
      if (lastAccess == null) {
         return true;
      } else {
         return System.currentTimeMillis() - lastAccess > 300000L;
      }
   }

   public void refreshGui(Player player) {
      BaseGui gui = (BaseGui)this.playerGuis.get(player.getUniqueId());
      if (gui != null) {
         gui.refresh();
         this.lastGuiAccess.put(player.getUniqueId(), System.currentTimeMillis());
      }

   }

   public int getActiveGuiCount() {
      return this.playerGuis.size();
   }

   public Map<UUID, String> getActiveGuiTypes() {
      Map<UUID, String> guiTypes = new ConcurrentHashMap();
      this.playerGuis.forEach((uuid, gui) -> {
         if (gui != null) {
            guiTypes.put(uuid, gui.getClass().getSimpleName());
         }

      });
      return guiTypes;
   }

   public boolean hasPendingConfirmation(UUID playerId, String crateName) {
      String var10000 = String.valueOf(playerId);
      String key = var10000 + "_" + crateName;
      Long timestamp = (Long)this.pendingConfirmations.get(key);
      if (timestamp == null) {
         return false;
      } else if (System.currentTimeMillis() - timestamp > 30000L) {
         this.pendingConfirmations.remove(key);
         return false;
      } else {
         return true;
      }
   }

   public void setPendingConfirmation(UUID playerId, String crateName) {
      String var10000 = String.valueOf(playerId);
      String key = var10000 + "_" + crateName;
      this.pendingConfirmations.put(key, System.currentTimeMillis());
   }

   public void clearPendingConfirmation(UUID playerId, String crateName) {
      String var10000 = String.valueOf(playerId);
      String key = var10000 + "_" + crateName;
      this.pendingConfirmations.remove(key);
   }

   public void cleanup() {
      if (this.cleanupTask != null && !this.cleanupTask.isCancelled()) {
         try {
            this.cleanupTask.cancel();
         } catch (Exception var5) {
         } finally {
            this.cleanupTask = null;
         }
      }

      this.playerGuis.values().forEach((gui) -> {
         if (gui != null) {
            try {
               gui.cleanup();
            } catch (Exception var2) {
            }
         }

      });
      this.playerGuis.clear();
      this.lastGuiAccess.clear();
      this.pendingConfirmations.clear();
   }

   public <T> T getCachedComponent(String key, Class<T> type) {
      Object cached = this.componentCache.get(key);
      return type.isInstance(cached) ? cached : null;
   }

   public void cacheComponent(String key, Object component) {
      if (key != null && component != null) {
         this.componentCache.put(key, component);
      }

   }

   public void clearComponentCache() {
      this.componentCache.clear();
   }

   public String getCacheStats() {
      return String.format("Active GUIs: %d, Last Access Entries: %d, Cached Components: %d", this.playerGuis.size(), this.lastGuiAccess.size(), this.componentCache.size());
   }

   @FunctionalInterface
   private interface GuiSupplier {
      BaseGui create() throws Exception;
   }
}
