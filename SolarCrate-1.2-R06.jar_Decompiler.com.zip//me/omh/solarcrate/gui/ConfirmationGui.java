package me.omh.solarcrate.gui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import me.clip.placeholderapi.PlaceholderAPI;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ConfirmationGui extends BaseGui {
   private final ItemStack selectedItem;
   private final String crateName;
   private boolean isProcessing = false;
   private UUID playerUUID;
   private String playerName;

   public ConfirmationGui(SolarCrate plugin, ItemStack selectedItem, String crateName) {
      super(plugin, SolarUtils.c(plugin.getConfigManager().getConfig().getString("crate_display.confirmation_title", "&8Xác nhận")), 27);
      this.selectedItem = selectedItem.clone();
      this.crateName = crateName;
      this.setData("selectedItem", selectedItem);
      this.setData("crateName", crateName);
      this.setAllowClose(true);
   }

   public void open(Player player) {
      if (player != null) {
         this.playerUUID = player.getUniqueId();
         this.playerName = player.getName();
      }

      super.open(player);
   }

   protected void setupGui() {
      this.setupBackgroundGlass();
      this.setupSelectedItemDisplay();
      this.setupCancelButton();
      this.setupConfirmButton();
   }

   private void setupBackgroundGlass() {
      if (this.plugin.getConfigManager().getConfig().getBoolean("confirmation_gui.background_glass.enabled", false)) {
         String materialName = this.plugin.getConfigManager().getConfig().getString("confirmation_gui.background_glass.material", "BLACK_STAINED_GLASS_PANE");
         String displayName = this.plugin.getConfigManager().getConfig().getString("confirmation_gui.background_glass.name", " ");
         int cancelSlot = this.plugin.getConfigManager().getConfig().getInt("confirmation_gui.cancel_button.slot", 11);
         int confirmSlot = this.plugin.getConfigManager().getConfig().getInt("confirmation_gui.confirm_button.slot", 15);
         int itemSlot = this.plugin.getConfigManager().getConfig().getInt("confirmation_gui.selected_item_slot", 13);

         try {
            Material material = Material.valueOf(materialName.toUpperCase());
            ItemStack glassPane = new ItemStack(material);
            ItemMeta meta = glassPane.getItemMeta();
            if (meta != null) {
               meta.setDisplayName(SolarUtils.c(displayName));
               glassPane.setItemMeta(meta);
            }

            for(int i = 0; i < 27; ++i) {
               if (i != cancelSlot && i != confirmSlot && i != itemSlot) {
                  this.setItem(i, glassPane, BaseGui.SlotPermission.DISPLAY_ONLY);
               }
            }
         } catch (IllegalArgumentException var10) {
            this.plugin.getLogger().warning("Invalid material for background glass: " + materialName);
         }

      }
   }

   private void setupSelectedItemDisplay() {
      int slot = this.plugin.getConfigManager().getConfig().getInt("confirmation_gui.selected_item_slot", 13);
      this.setItem(slot, this.selectedItem.clone(), BaseGui.SlotPermission.DISPLAY_ONLY);
   }

   private void setupCancelButton() {
      int slot = this.plugin.getConfigManager().getConfig().getInt("confirmation_gui.cancel_button.slot", 11);
      String materialName = this.plugin.getConfigManager().getConfig().getString("confirmation_gui.cancel_button.material", "RED_CONCRETE");
      String displayName = this.plugin.getConfigManager().getConfig().getString("confirmation_gui.cancel_button.name", "&c✖ Hủy bỏ");
      List loreList = this.plugin.getConfigManager().getConfig().getStringList("confirmation_gui.cancel_button.lore");

      try {
         Material material = Material.valueOf(materialName.toUpperCase());
         ItemStack cancelBtn = new ItemStack(material);
         ItemMeta meta = cancelBtn.getItemMeta();
         if (meta != null) {
            meta.setDisplayName(SolarUtils.c(displayName));
            if (!loreList.isEmpty()) {
               meta.setLore(loreList.stream().map(SolarUtils::c).toList());
            }

            cancelBtn.setItemMeta(meta);
         }

         this.setButton(slot, cancelBtn, (event) -> {
            if (!this.isProcessing) {
               this.clearPendingFlag();
               this.playSound(this.viewer, Sound.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.8F);
               this.plugin.getFoliaLib().getImpl().runLater(() -> {
                  if (this.viewer != null && this.viewer.isOnline()) {
                     this.viewer.closeInventory();
                  }

               }, 5L);
            }
         });
      } catch (IllegalArgumentException var8) {
         this.plugin.getLogger().warning("Invalid material for cancel button: " + materialName);
      }

   }

   private void setupConfirmButton() {
      int slot = this.plugin.getConfigManager().getConfig().getInt("confirmation_gui.confirm_button.slot", 15);
      String materialName = this.plugin.getConfigManager().getConfig().getString("confirmation_gui.confirm_button.material", "LIME_CONCRETE");
      String displayName = this.plugin.getConfigManager().getConfig().getString("confirmation_gui.confirm_button.name", "&a✓ Xác nhận");
      List loreList = this.plugin.getConfigManager().getConfig().getStringList("confirmation_gui.confirm_button.lore");

      try {
         Material material = Material.valueOf(materialName.toUpperCase());
         ItemStack confirmBtn = new ItemStack(material);
         ItemMeta meta = confirmBtn.getItemMeta();
         if (meta != null) {
            meta.setDisplayName(SolarUtils.c(displayName));
            if (!loreList.isEmpty()) {
               meta.setLore(loreList.stream().map(SolarUtils::c).toList());
            }

            confirmBtn.setItemMeta(meta);
         }

         this.setButton(slot, confirmBtn, (event) -> {
            if (this.isProcessing) {
               this.playErrorSound(this.viewer);
            } else {
               this.handleConfirm();
            }
         });
      } catch (IllegalArgumentException var8) {
         this.plugin.getLogger().warning("Invalid material for confirm button: " + materialName);
      }

   }

   private void handleConfirm() {
      this.isProcessing = true;
      Crate crate = this.plugin.getCrateManager().getCrate(this.crateName);
      if (crate == null) {
         this.handleError("&c❌ Crate không tồn tại!");
      } else if (this.plugin.getKeyManager().getKeys(this.viewer.getUniqueId(), this.crateName) <= 0) {
         this.handleError("&c❌ Không đủ keys!");
      } else {
         ItemStack reward = this.selectedItem.clone();
         HashMap<Integer, ItemStack> leftovers = this.viewer.getInventory().addItem(new ItemStack[]{reward});
         if (!leftovers.isEmpty()) {
            Iterator var4 = leftovers.values().iterator();

            while(var4.hasNext()) {
               ItemStack leftover = (ItemStack)var4.next();
               this.viewer.getWorld().dropItemNaturally(this.viewer.getLocation(), leftover);
            }

            this.viewer.sendMessage(SolarUtils.c("&e⚠ Inventory đầy! Item đã rơi xuống đất."));
         }

         boolean keyRemoved = this.plugin.getKeyManager().removeKey(this.viewer.getUniqueId(), this.crateName);
         if (!keyRemoved) {
            this.plugin.getLogger().warning("Failed to remove key for player " + this.viewer.getName() + " after giving item - this shouldn't happen!");
         }

         this.executeRewardSequence();
      }
   }

   private void executeRewardSequence() {
      Crate crate = this.plugin.getCrateManager().getCrate(this.crateName);
      this.viewer.closeInventory();
      this.clearPendingFlag();
      this.showSuccessTitle(crate);
      this.playSuccessEffects();
      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         this.broadcastMessage();
      }, 20L);
   }

   private void handleError(String message) {
      this.isProcessing = false;
      this.clearPendingFlag();
      if (this.viewer != null) {
         this.viewer.sendMessage(SolarUtils.c(message));
         this.playErrorSound(this.viewer);
      }

      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         if (this.viewer != null && this.viewer.isOnline()) {
            this.viewer.closeInventory();
         }

      }, 30L);
   }

   private void showSuccessTitle(Crate crate) {
      String var10000;
      String itemName;
      if (this.selectedItem.hasItemMeta()) {
         ItemMeta meta = this.selectedItem.getItemMeta();
         if (meta != null && meta.hasDisplayName()) {
            var10000 = meta.getDisplayName();
         } else {
            var10000 = this.selectedItem.getType().name().toLowerCase();
            var10000 = SolarUtils.c("&e" + var10000.replace('_', ' '));
         }

         itemName = var10000;
      } else {
         var10000 = this.selectedItem.getType().name().toLowerCase();
         itemName = SolarUtils.c("&e" + var10000.replace('_', ' '));
      }

      String subtitle;
      String title;
      if (crate != null && crate.getSuccessTitle() != null && !crate.getSuccessTitle().isEmpty()) {
         title = crate.getSuccessTitle();
         subtitle = crate.getSuccessSubtitle() != null ? crate.getSuccessSubtitle() : "&7Bạn đã nhận: &e{item}";
      } else {
         title = this.plugin.getConfigManager().getMessage("item-received-title");
         subtitle = this.plugin.getConfigManager().getMessage("item-received-subtitle");
      }

      subtitle = subtitle.replace("{item}", itemName);
      if (this.plugin.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         title = PlaceholderAPI.setPlaceholders(this.viewer, title);
         subtitle = PlaceholderAPI.setPlaceholders(this.viewer, subtitle);
      }

      this.viewer.sendTitle(SolarUtils.c(title), SolarUtils.c(subtitle), 10, 60, 15);
   }

   private void clearPendingFlag() {
      UUID uuid = this.playerUUID != null ? this.playerUUID : (this.viewer != null ? this.viewer.getUniqueId() : null);
      if (uuid != null) {
         this.plugin.getGuiManager().clearPendingConfirmation(uuid, this.crateName);
      }

   }

   private void playSuccessEffects() {
      this.playSound(this.viewer, Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 2.0F);
      this.playSound(this.viewer, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.8F, 1.5F);
      this.plugin.getSoundManager().playSuccessSound(this.viewer);
   }

   private String determineItemRarity() {
      if (!this.selectedItem.hasItemMeta()) {
         return "Common";
      } else {
         ItemMeta meta = this.selectedItem.getItemMeta();
         if (meta != null && meta.hasEnchants()) {
            int enchantCount = meta.getEnchants().size();
            if (enchantCount >= 3) {
               return "Legendary";
            } else {
               return enchantCount >= 2 ? "Epic" : "Rare";
            }
         } else {
            String materialName = this.selectedItem.getType().name();
            if (!materialName.contains("NETHERITE") && !materialName.contains("DRAGON")) {
               if (!materialName.contains("DIAMOND") && !materialName.contains("EMERALD")) {
                  if (!materialName.contains("GOLD") && !materialName.contains("IRON")) {
                     return !materialName.contains("STONE") && !materialName.contains("LEATHER") ? "Uncommon" : "Common";
                  } else {
                     return "Rare";
                  }
               } else {
                  return "Epic";
               }
            } else {
               return "Legendary";
            }
         }
      }
   }

   private void broadcastMessage() {
      String displayPlayerName;
      try {
         String itemName;
         if (this.selectedItem != null && this.selectedItem.hasItemMeta()) {
            ItemMeta meta = this.selectedItem.getItemMeta();
            if (meta != null && meta.hasDisplayName()) {
               itemName = meta.getDisplayName();
            } else {
               itemName = this.selectedItem.getType().toString().toLowerCase().replace('_', ' ');
            }
         } else if (this.selectedItem != null) {
            itemName = this.selectedItem.getType().toString().toLowerCase().replace('_', ' ');
         } else {
            itemName = "Unknown Item";
         }

         displayPlayerName = this.playerName != null ? this.playerName : (this.viewer != null && this.viewer.isOnline() ? this.viewer.getName() : "Unknown Player");
         String broadcastMsg = this.plugin.getConfigManager().getMessage("item-received-broadcast");
         if (broadcastMsg == null || broadcastMsg.isEmpty()) {
            broadcastMsg = "&7Người chơi #0EFF90{player}&7 đã nhận vật phẩm #FFD700{item}&7 từ crate #FFA500{crate}&7!";
         }

         String successMsg = broadcastMsg.replace("{player}", displayPlayerName).replace("{item}", itemName).replace("{crate}", this.crateName);
         Bukkit.getServer().broadcastMessage(SolarUtils.c(successMsg));
         this.plugin.getLogger().info("Broadcast sent: " + displayPlayerName + " received " + itemName + " from " + this.crateName);
      } catch (Exception var5) {
         this.plugin.getLogger().severe("Failed to broadcast item received message: " + var5.getMessage());
         var5.printStackTrace();
         displayPlayerName = "&7[SolarCrate] &eNgười chơi đã nhận vật phẩm từ crate " + this.crateName + "!";
         Bukkit.getServer().broadcastMessage(SolarUtils.c(displayPlayerName));
      }

   }

   public void cleanup() {
      this.clearPendingFlag();
      super.cleanup();
   }

   public void close() {
      this.clearPendingFlag();
      super.close();
   }

   public void forceClose() {
      this.clearPendingFlag();
      super.forceClose();
   }
}
