package me.omh.solarcrate.gui;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public abstract class BaseGui {
   protected final SolarCrate plugin;
   protected final String title;
   protected final int size;
   protected Inventory inventory;
   protected final Map<Integer, Consumer<InventoryClickEvent>> clickHandlers = new ConcurrentHashMap();
   protected final Map<Integer, BaseGui.SlotPermission> slotPermissions = new ConcurrentHashMap();
   protected final Set<Integer> protectedSlots = ConcurrentHashMap.newKeySet();
   protected final Map<String, Object> components = new ConcurrentHashMap();
   protected Player viewer;
   protected boolean isOpen = false;
   protected boolean allowClose = true;
   protected long lastInteraction = 0L;
   protected final Map<String, Object> guiData = new ConcurrentHashMap();
   protected Consumer<Player> onClose;
   protected Consumer<Player> onOpen;

   public BaseGui(SolarCrate plugin, String title, int size) {
      this.plugin = plugin;
      this.title = SolarUtils.c(title);
      this.size = Math.min(54, Math.max(9, (size + 8) / 9 * 9));
      this.inventory = Bukkit.createInventory((InventoryHolder)null, this.size, this.title);
      this.lastInteraction = System.currentTimeMillis();
   }

   protected abstract void setupGui();

   public BaseGui setOnClose(Consumer<Player> onClose) {
      this.onClose = onClose;
      return this;
   }

   public BaseGui setOnOpen(Consumer<Player> onOpen) {
      this.onOpen = onOpen;
      return this;
   }

   public BaseGui setData(String key, Object value) {
      this.guiData.put(key, value);
      return this;
   }

   public <T> T getData(String key, Class<T> type) {
      Object value = this.guiData.get(key);
      return type.isInstance(value) ? value : null;
   }

   protected void setSlotPermission(int slot, BaseGui.SlotPermission permission) {
      if (this.isValidSlot(slot)) {
         this.slotPermissions.put(slot, permission);
         if (permission == BaseGui.SlotPermission.BACKGROUND || permission == BaseGui.SlotPermission.BUTTON || permission == BaseGui.SlotPermission.LOCKED) {
            this.protectedSlots.add(slot);
         }
      }

   }

   protected void setSlotPermissions(int[] slots, BaseGui.SlotPermission permission) {
      int[] var3 = slots;
      int var4 = slots.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         int slot = var3[var5];
         this.setSlotPermission(slot, permission);
      }

   }

   public BaseGui.SlotPermission getSlotPermission(int slot) {
      return (BaseGui.SlotPermission)this.slotPermissions.getOrDefault(slot, BaseGui.SlotPermission.EDITABLE);
   }

   private boolean isValidSlot(int slot) {
      return slot >= 0 && slot < this.size;
   }

   public void open(Player player) {
      if (player != null && player.isOnline()) {
         this.viewer = player;
         this.isOpen = true;
         this.lastInteraction = System.currentTimeMillis();
         this.setupGui();
         player.openInventory(this.inventory);
         if (this.onOpen != null) {
            this.onOpen.accept(player);
         }

         this.playSound(player, Sound.BLOCK_CHEST_OPEN, 1.0F, 1.0F);
      }
   }

   protected void setItem(int slot, ItemStack item, BaseGui.SlotPermission permission) {
      if (this.isValidSlot(slot) && item != null) {
         this.inventory.setItem(slot, item);
         this.setSlotPermission(slot, permission);
      }

   }

   protected void setButton(int slot, ItemStack item, Consumer<InventoryClickEvent> clickHandler) {
      if (this.isValidSlot(slot) && item != null && clickHandler != null) {
         this.inventory.setItem(slot, item);
         this.clickHandlers.put(slot, clickHandler);
         this.setSlotPermission(slot, BaseGui.SlotPermission.BUTTON);
      }

   }

   protected void setItem(int slot, ItemStack item) {
      if (this.isValidSlot(slot) && item != null) {
         this.inventory.setItem(slot, item);
      }

   }

   protected void setItem(int slot, ItemStack item, Consumer<InventoryClickEvent> clickHandler) {
      this.setItem(slot, item);
      if (clickHandler != null) {
         this.clickHandlers.put(slot, clickHandler);
         this.setSlotPermission(slot, BaseGui.SlotPermission.BUTTON);
      }

   }

   protected void setItem(int slot, ItemStack item, BaseGui.SlotPermission permission, Consumer<InventoryClickEvent> clickHandler) {
      this.setItem(slot, item);
      this.setSlotPermission(slot, permission);
      if (clickHandler != null) {
         this.clickHandlers.put(slot, clickHandler);
      }

   }

   protected void addComponent(int slot, GuiComponents.ItemButton button, BaseGui.SlotPermission permission, Consumer<InventoryClickEvent> clickHandler) {
      if (this.isValidSlot(slot) && button != null) {
         ItemStack item = button.getItem();
         if (item != null) {
            this.inventory.setItem(slot, item);
            this.setSlotPermission(slot, permission);
            if (clickHandler != null) {
               this.clickHandlers.put(slot, clickHandler);
            }
         }
      }

   }

   protected void fillEmpty(ItemStack item) {
      this.fillEmpty(item, BaseGui.SlotPermission.BACKGROUND);
   }

   protected void fillEmpty(ItemStack item, BaseGui.SlotPermission permission) {
      for(int i = 0; i < this.size; ++i) {
         if (this.inventory.getItem(i) == null) {
            this.inventory.setItem(i, item);
            this.setSlotPermission(i, permission);
         }
      }

   }

   protected void fillRow(int row, ItemStack item) {
      this.fillRow(row, item, BaseGui.SlotPermission.BACKGROUND);
   }

   protected void fillRow(int row, ItemStack item, BaseGui.SlotPermission permission) {
      int start = row * 9;
      int end = Math.min(start + 9, this.size);

      for(int i = start; i < end; ++i) {
         this.inventory.setItem(i, item);
         this.setSlotPermission(i, permission);
      }

   }

   protected void fillBorder(ItemStack item) {
      this.fillBorder(item, BaseGui.SlotPermission.BACKGROUND);
   }

   protected void fillBorder(ItemStack item, BaseGui.SlotPermission permission) {
      int rows = this.size / 9;

      int row;
      for(row = 0; row < 9 && row < this.size; ++row) {
         this.inventory.setItem(row, item);
         this.setSlotPermission(row, permission);
      }

      int leftSlot;
      if (rows > 1) {
         row = (rows - 1) * 9;

         for(leftSlot = row; leftSlot < this.size; ++leftSlot) {
            this.inventory.setItem(leftSlot, item);
            this.setSlotPermission(leftSlot, permission);
         }
      }

      for(row = 1; row < rows - 1; ++row) {
         leftSlot = row * 9;
         int rightSlot = row * 9 + 8;
         if (leftSlot < this.size) {
            this.inventory.setItem(leftSlot, item);
            this.setSlotPermission(leftSlot, permission);
         }

         if (rightSlot < this.size) {
            this.inventory.setItem(rightSlot, item);
            this.setSlotPermission(rightSlot, permission);
         }
      }

   }

   protected void fillPattern(int[] pattern, ItemStack item, BaseGui.SlotPermission permission) {
      int[] var4 = pattern;
      int var5 = pattern.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         int slot = var4[var6];
         if (this.isValidSlot(slot)) {
            this.inventory.setItem(slot, item);
            this.setSlotPermission(slot, permission);
         }
      }

   }

   public boolean handleClick(InventoryClickEvent event) {
      if (event.getClickedInventory() != null && event.getClickedInventory().equals(this.inventory)) {
         this.lastInteraction = System.currentTimeMillis();
         int slot = event.getSlot();
         BaseGui.SlotPermission permission = this.getSlotPermission(slot);
         if (event.isShiftClick()) {
            return this.handleShiftClick(event, slot, permission);
         } else if (event.getClick().isKeyboardClick()) {
            return this.handleKeyboardClick(event, slot, permission);
         } else {
            switch(permission.ordinal()) {
            case 0:
               Consumer<InventoryClickEvent> editHandler = (Consumer)this.clickHandlers.get(slot);
               if (editHandler != null) {
                  try {
                     editHandler.accept(event);
                     this.playClickSound((Player)event.getWhoClicked());
                  } catch (Exception var8) {
                     this.plugin.getLogger().severe("GUI edit error: " + var8.getMessage());
                     this.playErrorSound((Player)event.getWhoClicked());
                  }
               }

               return false;
            case 1:
               event.setCancelled(true);
               this.playDenySound((Player)event.getWhoClicked());
               return true;
            case 2:
               event.setCancelled(true);
               this.playErrorSound((Player)event.getWhoClicked());
               return true;
            case 3:
               event.setCancelled(true);
               Consumer<InventoryClickEvent> handler = (Consumer)this.clickHandlers.get(slot);
               if (handler != null) {
                  try {
                     handler.accept(event);
                     this.playClickSound((Player)event.getWhoClicked());
                  } catch (Exception var7) {
                     this.plugin.getLogger().severe("GUI click error: " + var7.getMessage());
                     this.playErrorSound((Player)event.getWhoClicked());
                  }
               }

               return true;
            case 4:
               event.setCancelled(true);
               this.playErrorSound((Player)event.getWhoClicked());
               return true;
            default:
               return false;
            }
         }
      } else {
         return event.isShiftClick() && event.getClickedInventory() != this.inventory ? this.handleShiftClickFromPlayer(event) : false;
      }
   }

   protected boolean handleShiftClick(InventoryClickEvent event, int slot, BaseGui.SlotPermission permission) {
      switch(permission.ordinal()) {
      case 0:
         return false;
      case 1:
      case 2:
      case 3:
      case 4:
         event.setCancelled(true);
         return true;
      default:
         return false;
      }
   }

   protected boolean handleKeyboardClick(InventoryClickEvent event, int slot, BaseGui.SlotPermission permission) {
      switch(permission.ordinal()) {
      case 0:
         return false;
      case 1:
      case 2:
      case 3:
      case 4:
         event.setCancelled(true);
         return true;
      default:
         return false;
      }
   }

   protected boolean handleShiftClickFromPlayer(InventoryClickEvent event) {
      for(int i = 0; i < this.size; ++i) {
         if (this.getSlotPermission(i) == BaseGui.SlotPermission.EDITABLE && this.inventory.getItem(i) == null) {
            return false;
         }
      }

      event.setCancelled(true);
      return true;
   }

   public boolean handleDrag(InventoryDragEvent event) {
      boolean hasProtectedSlot = false;
      Iterator var3 = event.getRawSlots().iterator();

      while(var3.hasNext()) {
         Integer rawSlot = (Integer)var3.next();
         if (rawSlot < this.size) {
            BaseGui.SlotPermission permission = this.getSlotPermission(rawSlot);
            if (permission != BaseGui.SlotPermission.EDITABLE) {
               hasProtectedSlot = true;
               break;
            }
         }
      }

      if (hasProtectedSlot) {
         event.setCancelled(true);
         return true;
      } else {
         return false;
      }
   }

   public void refresh() {
      this.inventory.clear();
      this.clickHandlers.clear();
      this.slotPermissions.clear();
      this.protectedSlots.clear();
      this.setupGui();
   }

   public void updateSlot(int slot, ItemStack item) {
      if (this.isValidSlot(slot)) {
         this.inventory.setItem(slot, item);
      }

   }

   protected void playSound(Player player, Sound sound, float volume, float pitch) {
      if (player != null && player.isOnline()) {
         player.playSound(player.getLocation(), sound, SoundCategory.MASTER, volume, pitch);
      }

   }

   protected void playClickSound(Player player) {
      this.playSound(player, Sound.UI_BUTTON_CLICK, 0.7F, 1.2F);
   }

   protected void playErrorSound(Player player) {
      this.playSound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.5F, 0.7F);
   }

   protected void playDenySound(Player player) {
      this.playSound(player, Sound.ENTITY_VILLAGER_NO, 0.3F, 1.2F);
   }

   protected void playSuccessSound(Player player) {
      this.playSound(player, Sound.ENTITY_PLAYER_LEVELUP, 0.8F, 1.5F);
   }

   public BaseGui setAllowClose(boolean allowClose) {
      this.allowClose = allowClose;
      return this;
   }

   public boolean canClose() {
      return this.allowClose;
   }

   public long getLastInteraction() {
      return this.lastInteraction;
   }

   public boolean isExpired(long timeoutMs) {
      return System.currentTimeMillis() - this.lastInteraction > timeoutMs;
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   public String getTitle() {
      return this.title;
   }

   public Player getViewer() {
      return this.viewer;
   }

   public boolean belongsTo(Player player) {
      return this.viewer != null && this.viewer.equals(player);
   }

   public boolean isOpen() {
      return this.isOpen;
   }

   public void cleanup() {
      this.components.clear();
      this.clickHandlers.clear();
      this.slotPermissions.clear();
      this.protectedSlots.clear();
      this.guiData.clear();
      this.viewer = null;
      this.isOpen = false;
      this.onClose = null;
      this.onOpen = null;
   }

   public void close() {
      if (this.viewer != null && this.viewer.getOpenInventory().getTopInventory().equals(this.inventory)) {
         this.isOpen = false;
         if (this.onClose != null) {
            this.onClose.accept(this.viewer);
         }

         this.playSound(this.viewer, Sound.BLOCK_CHEST_CLOSE, 1.0F, 1.0F);
         this.viewer.closeInventory();
      }

      this.cleanup();
   }

   public void forceClose() {
      if (this.viewer != null) {
         this.isOpen = false;
         this.viewer.closeInventory();
      }

      this.cleanup();
   }

   public static enum SlotPermission {
      EDITABLE,
      DISPLAY_ONLY,
      BACKGROUND,
      BUTTON,
      LOCKED;

      // $FF: synthetic method
      private static BaseGui.SlotPermission[] $values() {
         return new BaseGui.SlotPermission[]{EDITABLE, DISPLAY_ONLY, BACKGROUND, BUTTON, LOCKED};
      }
   }
}
