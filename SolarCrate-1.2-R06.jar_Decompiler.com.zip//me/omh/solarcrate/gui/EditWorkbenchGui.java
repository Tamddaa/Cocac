package me.omh.solarcrate.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class EditWorkbenchGui extends BaseGui {
   private final String crateName;
   private boolean isSaving = false;
   private GuiComponents.EditSession session;

   public EditWorkbenchGui(SolarCrate plugin, String crateName) {
      super(plugin, getEditTitle(plugin, crateName), 54);
      this.crateName = crateName;
      this.session = new GuiComponents.EditSession();
      this.setData("crateName", crateName);
      this.setData("openTime", System.currentTimeMillis());
   }

   private static String getEditTitle(SolarCrate plugin, String crateName) {
      String title = plugin.getConfigManager().getConfig().getString("crate_display.edit_title", "&a&l✏ &7Chỉnh sửa: &e{crate_name}");
      title = title.replace("{crate_name}", crateName != null ? crateName : "Unknown").replace("{crate}", crateName != null ? crateName : "Unknown");
      return SolarUtils.c(title);
   }

   protected void setupGui() {
      this.setupModernLayout();
      this.loadWorkingItems();
      this.updateDynamicElements();
   }

   private void setupModernLayout() {
      this.setupEditableWorkspace();
      this.setupModernSeparator();
      this.setupEnhancedControlPanel();
      this.setupStatusBar();
   }

   private void setupEditableWorkspace() {
      for(int i = 0; i < 27; ++i) {
         this.setSlotPermission(i, BaseGui.SlotPermission.EDITABLE);
      }

   }

   private void setupModernSeparator() {
      ItemStack separatorGlass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
      ItemMeta meta = separatorGlass.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-separator-title")));
         meta.setLore(Arrays.asList(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-separator-lore1")), SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-separator-lore2"))));
         separatorGlass.setItemMeta(meta);
      }

      for(int i = 27; i < 36; ++i) {
         this.setItem(i, separatorGlass, BaseGui.SlotPermission.DISPLAY_ONLY);
      }

   }

   private void setupEnhancedControlPanel() {
      this.setupModernSaveButton(38);
      this.setupModernDiscardButton(40);
      this.setupModernQuickActions(42);
      this.setupControlPanelFillers();
   }

   private void setupControlPanelFillers() {
      ItemStack fillerGlass = new ItemStack(Material.LIGHT_GRAY_STAINED_GLASS_PANE);
      ItemMeta meta = fillerGlass.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&7"));
         fillerGlass.setItemMeta(meta);
      }

      int[] fillerSlots = new int[]{36, 37, 39, 41, 43, 44};
      int[] var4 = fillerSlots;
      int var5 = fillerSlots.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         int slot = var4[var6];
         this.setItem(slot, fillerGlass, BaseGui.SlotPermission.DISPLAY_ONLY);
      }

   }

   private void setupStatusBar() {
      this.setupStatusButtons();
   }

   private void setupStatusButtons() {
      this.setupCloseButton(49);
      ItemStack fillerGlass = new ItemStack(Material.BLUE_STAINED_GLASS_PANE);
      ItemMeta meta = fillerGlass.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c("&7"));
         fillerGlass.setItemMeta(meta);
      }

      int[] statusFillers = new int[]{45, 46, 47, 48, 50, 51, 52, 53};
      int[] var4 = statusFillers;
      int var5 = statusFillers.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         int slot = var4[var6];
         this.setItem(slot, fillerGlass, BaseGui.SlotPermission.DISPLAY_ONLY);
      }

   }

   private void loadWorkingItems() {
      Crate crate = this.plugin.getCrateManager().getCrate(this.crateName);
      if (crate != null) {
         Map<Integer, ItemStack> crateItems = crate.getItems();
         Iterator var3 = crateItems.entrySet().iterator();

         while(var3.hasNext()) {
            Entry<Integer, ItemStack> entry = (Entry)var3.next();
            int slot = (Integer)entry.getKey();
            ItemStack item = (ItemStack)entry.getValue();
            if (slot >= 0 && slot < 27 && item != null) {
               this.inventory.setItem(slot, item.clone());
            }
         }
      }

   }

   private void updateDynamicElements() {
      this.updateSaveButton();
      this.updateWorkspaceInfo();
   }

   private void updateWorkspaceInfo() {
   }

   public boolean handleClick(InventoryClickEvent event) {
      int slot = event.getSlot();
      boolean isTopInventory = event.getClickedInventory() == this.inventory;
      if (!isTopInventory && (event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT)) {
         this.handleShiftClickFromPlayerInventory(event);
         return true;
      } else if (isTopInventory) {
         if (slot >= 0 && slot < 27) {
            this.handleEditableSlotClick(event);
            return false;
         } else {
            return super.handleClick(event);
         }
      } else {
         return false;
      }
   }

   private void handleShiftClickFromPlayerInventory(InventoryClickEvent event) {
      ItemStack item = event.getCurrentItem();
      if (item != null && item.getType() != Material.AIR) {
         for(int i = 0; i < 27; ++i) {
            if (this.inventory.getItem(i) == null) {
               this.inventory.setItem(i, item.clone());
               event.setCurrentItem((ItemStack)null);
               event.setCancelled(true);
               this.playClickSound(this.viewer);
               this.plugin.getFoliaLib().getImpl().runLater(() -> {
                  this.updateDynamicElements();
               }, 1L);
               return;
            }
         }

         event.setCancelled(true);
         this.viewer.sendMessage(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-workspace-full")));
         this.playErrorSound(this.viewer);
      } else {
         event.setCancelled(true);
      }
   }

   private void handleEditableSlotClick(InventoryClickEvent event) {
      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         this.updateDynamicElements();
      }, 1L);
   }

   private void saveCrateItems() {
      Map<Integer, ItemStack> itemsWithSlots = new HashMap();

      for(int i = 0; i < 27; ++i) {
         ItemStack item = this.inventory.getItem(i);
         if (item != null && item.getType() != Material.AIR) {
            itemsWithSlots.put(i, item);
         }
      }

      this.plugin.getCrateManager().setCrateItemsWithSlots(this.crateName, itemsWithSlots);
   }

   private void setupModernSaveButton(int slot) {
      ItemStack saveButton = new ItemStack(Material.EMERALD_BLOCK);
      ItemMeta meta = saveButton.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-title")));
         meta.setLore(this.createSaveButtonLore());
         saveButton.setItemMeta(meta);
      }

      this.setButton(slot, saveButton, (event) -> {
         this.handleEnhancedSave();
      });
   }

   private List<String> createSaveButtonLore() {
      List<String> lore = new ArrayList();
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore1")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore2")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore3")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore4")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore5")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore6")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-lore7")));
      return lore;
   }

   private void handleEnhancedSave() {
      if (this.isSaving) {
         this.playErrorSound(this.viewer);
      } else {
         this.isSaving = true;
         this.viewer.sendTitle(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-saving")), SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-wait")), 5, 60, 10);
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            this.saveCrateItems();
            this.playSuccessSound(this.viewer);
            this.viewer.sendTitle(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-success-title")), SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-save-success-sub")), 10, 40, 15);
            this.plugin.getFoliaLib().getImpl().runLater(() -> {
               this.viewer.closeInventory();
            }, 30L);
         }, 1L);
      }
   }

   private void setupModernDiscardButton(int slot) {
      ItemStack discardButton = new ItemStack(Material.REDSTONE_BLOCK);
      ItemMeta meta = discardButton.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-title")));
         meta.setLore(this.createDiscardButtonLore());
         discardButton.setItemMeta(meta);
      }

      this.setButton(slot, discardButton, (event) -> {
         this.handleDiscard();
      });
   }

   private List<String> createDiscardButtonLore() {
      List<String> lore = new ArrayList();
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-lore1")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-lore2")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-lore3")));
      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-lore4")));
      if (this.session.isDirty()) {
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-dirty")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-confirm")));
      } else {
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-clean")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-click")));
      }

      lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-lore5")));
      return lore;
   }

   private void handleDiscard() {
      if (this.session.isDirty()) {
         this.viewer.sendTitle(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-confirm-title")), SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-discard-confirm-sub")), 10, 60, 15);
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            this.playSound(this.viewer, Sound.BLOCK_NOTE_BLOCK_BASS, 0.5F, 0.8F);
            this.viewer.closeInventory();
         }, 30L);
      } else {
         this.session.close();
         this.playClickSound(this.viewer);
         this.viewer.closeInventory();
      }

   }

   private void setupModernQuickActions(int clearSlot) {
      this.setupClearAllButton(clearSlot);
   }

   private void setupClearAllButton(int slot) {
      ItemStack clearButton = new ItemStack(Material.BARRIER);
      ItemMeta meta = clearButton.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-title")));
         List<String> lore = new ArrayList();
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-lore1")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-lore2")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-lore3")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().formatMessage("edit-clear-items", Map.of("items", String.valueOf(this.session.getItemCount())))));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-lore4")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-lore5")));
         meta.setLore(lore);
         clearButton.setItemMeta(meta);
      }

      this.setButton(slot, clearButton, (event) -> {
         for(int i = 0; i < 27; ++i) {
            this.inventory.setItem(i, (ItemStack)null);
         }

         this.updateDynamicElements();
         this.playSound(this.viewer, Sound.ENTITY_ITEM_BREAK, 0.5F, 1.0F);
         this.viewer.sendMessage(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-clear-success")));
      });
   }

   private void setupCloseButton(int slot) {
      ItemStack closeButton = new ItemStack(Material.OAK_DOOR);
      ItemMeta meta = closeButton.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-title")));
         List<String> lore = new ArrayList();
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-lore1")));
         lore.add(this.session.isDirty() ? SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-dirty")) : SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-clean")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-lore2")));
         lore.add(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-lore3")));
         meta.setLore(lore);
         closeButton.setItemMeta(meta);
      }

      this.setButton(slot, closeButton, (event) -> {
         if (this.session.isDirty()) {
            this.viewer.sendTitle(SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-unsaved-title")), SolarUtils.c(this.plugin.getConfigManager().getMessage("edit-close-unsaved-sub")), 10, 60, 15);
            this.playErrorSound(this.viewer);
         } else {
            this.viewer.closeInventory();
            this.playClickSound(this.viewer);
         }

      });
   }

   private void updateSaveButton() {
      if (this.inventory.getItem(38) != null) {
         ItemStack saveBtn = this.inventory.getItem(38);
         ItemMeta meta = saveBtn.getItemMeta();
         if (meta != null) {
            meta.setLore(this.createSaveButtonLore());
            if (this.session.isDirty()) {
               meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
               meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
            } else {
               meta.removeEnchant(Enchantment.LUCK_OF_THE_SEA);
               meta.removeItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
            }

            saveBtn.setItemMeta(meta);
            this.inventory.setItem(38, saveBtn);
         }
      }

   }

   public void close() {
      if (!this.session.isClosed()) {
         this.session.close();
      }

      super.close();
   }
}
