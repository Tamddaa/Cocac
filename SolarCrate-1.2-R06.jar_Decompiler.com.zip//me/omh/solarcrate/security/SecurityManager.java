package me.omh.solarcrate.security;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import me.omh.solarcrate.SolarCrate;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SecurityManager {
   private final SolarCrate plugin;
   private final ConcurrentHashMap<UUID, Long> commandCooldowns = new ConcurrentHashMap();
   private final ConcurrentHashMap<UUID, Integer> rateLimitCounter = new ConcurrentHashMap();
   private final ConcurrentHashMap<String, Long> ipCooldowns = new ConcurrentHashMap();
   private static final Pattern CRATE_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_-]{1,32}$");
   private static final Pattern KEY_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_-]{1,64}$");
   private static final Pattern SAFE_STRING_PATTERN = Pattern.compile("^[\\w\\s\\-_.!@#$%^&*()+={}\\[\\]:;\"'<>,.?/|\\\\]{1,256}$");
   private final long COMMAND_COOLDOWN_MS;
   private final int MAX_COMMANDS_PER_MINUTE;
   private final boolean VALIDATE_PERMISSIONS;

   public SecurityManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.COMMAND_COOLDOWN_MS = (long)plugin.getConfigManager().getCachedInt("security.command_cooldown", 1000);
      this.MAX_COMMANDS_PER_MINUTE = plugin.getConfigManager().getCachedInt("security.max_commands_per_minute", 30);
      this.VALIDATE_PERMISSIONS = plugin.getConfigManager().getCachedBoolean("security.validate_permissions", true);
      plugin.getFoliaLib().getImpl().runTimer(() -> {
         this.cleanupRateLimiting();
      }, 1200L, 1200L);
   }

   public boolean hasPermission(CommandSender sender, String permission) {
      if (!this.VALIDATE_PERMISSIONS) {
         return true;
      } else if (sender != null && permission != null && !permission.trim().isEmpty()) {
         if (sender instanceof Player) {
            Player player = (Player)sender;
            String var10000 = String.valueOf(player.getUniqueId());
            String cacheKey = "permission_" + var10000 + "_" + permission;
            Object cached = this.plugin.getUtilityManagers().get(cacheKey);
            if (cached instanceof Boolean) {
               Boolean cachedBool = (Boolean)cached;
               return cachedBool;
            } else {
               boolean hasPermission = player.hasPermission(permission);
               this.plugin.getUtilityManagers().put(cacheKey, hasPermission);
               this.plugin.getFoliaLib().getImpl().runLater(() -> {
                  this.plugin.getUtilityManagers().invalidate(cacheKey);
               }, 600L);
               return hasPermission;
            }
         } else {
            return sender.hasPermission(permission);
         }
      } else {
         return false;
      }
   }

   public boolean checkCooldown(Player player, String command) {
      if (player != null && command != null) {
         UUID uuid = player.getUniqueId();
         long currentTime = System.currentTimeMillis();
         Long lastCommand = (Long)this.commandCooldowns.get(uuid);
         if (lastCommand != null && currentTime - lastCommand < this.COMMAND_COOLDOWN_MS) {
            return false;
         } else {
            int commandCount = (Integer)this.rateLimitCounter.getOrDefault(uuid, 0);
            if (commandCount >= this.MAX_COMMANDS_PER_MINUTE) {
               this.plugin.getLogger().warning("Player " + player.getName() + " exceeded command rate limit");
               return false;
            } else {
               this.commandCooldowns.put(uuid, currentTime);
               this.rateLimitCounter.put(uuid, commandCount + 1);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public SecurityManager.ValidationResult validateCrateName(String name) {
      if (name != null && !name.trim().isEmpty()) {
         String trimmed = name.trim();
         if (trimmed.length() > 32) {
            return SecurityManager.ValidationResult.invalid("Tên crate quá dài (tối đa 32 ký tự)");
         } else if (!CRATE_NAME_PATTERN.matcher(trimmed).matches()) {
            return SecurityManager.ValidationResult.invalid("Tên crate chỉ được chứa chữ cái, số, dấu gạch dưới và dấu gạch ngang");
         } else {
            return this.isReservedName(trimmed) ? SecurityManager.ValidationResult.invalid("Tên crate này đã được hệ thống sử dụng") : SecurityManager.ValidationResult.valid(trimmed);
         }
      } else {
         return SecurityManager.ValidationResult.invalid("Tên crate không được để trống");
      }
   }

   public SecurityManager.ValidationResult validateKeyName(String name) {
      if (name != null && !name.trim().isEmpty()) {
         String trimmed = name.trim();
         if (trimmed.length() > 64) {
            return SecurityManager.ValidationResult.invalid("Tên chìa khóa quá dài (tối đa 64 ký tự)");
         } else {
            return !KEY_NAME_PATTERN.matcher(trimmed).matches() ? SecurityManager.ValidationResult.invalid("Tên chìa khóa chứa ký tự không hợp lệ") : SecurityManager.ValidationResult.valid(trimmed);
         }
      } else {
         return SecurityManager.ValidationResult.invalid("Tên chìa khóa không được để trống");
      }
   }

   public SecurityManager.ValidationResult validateAmount(String input, int min, int max) {
      if (input != null && !input.trim().isEmpty()) {
         try {
            int amount = Integer.parseInt(input.trim());
            if (amount < min) {
               return SecurityManager.ValidationResult.invalid("Số lượng phải từ " + min + " trở lên");
            } else {
               return amount > max ? SecurityManager.ValidationResult.invalid("Số lượng không được vượt quá " + max) : SecurityManager.ValidationResult.valid(amount);
            }
         } catch (NumberFormatException var5) {
            return SecurityManager.ValidationResult.invalid("Số lượng phải là một số nguyên hợp lệ");
         }
      } else {
         return SecurityManager.ValidationResult.invalid("Số lượng không được để trống");
      }
   }

   public String sanitizeInput(String input) {
      return input == null ? "" : input.trim().replaceAll("[<>\"'&]", "").replaceAll("\\s+", " ").substring(0, Math.min(input.length(), 256));
   }

   public SecurityManager.ValidationResult validateCoordinates(String x, String y, String z) {
      try {
         double dx = Double.parseDouble(x);
         double dy = Double.parseDouble(y);
         double dz = Double.parseDouble(z);
         if (!(Math.abs(dx) > 3.0E7D) && !(Math.abs(dz) > 3.0E7D)) {
            return !(dy < -2048.0D) && !(dy > 2048.0D) ? SecurityManager.ValidationResult.valid(new double[]{dx, dy, dz}) : SecurityManager.ValidationResult.invalid("Tọa độ Y phải nằm trong khoảng -2048 đến 2048");
         } else {
            return SecurityManager.ValidationResult.invalid("Tọa độ X và Z phải nằm trong khoảng ±30,000,000");
         }
      } catch (NumberFormatException var10) {
         return SecurityManager.ValidationResult.invalid("Tọa độ phải là số hợp lệ");
      }
   }

   public boolean checkGuiLimit(Player player) {
      if (player == null) {
         return false;
      } else {
         int maxGuis = this.plugin.getConfigManager().getCachedInt("security.max_concurrent_guis", 5);
         return true;
      }
   }

   public void logSecurityEvent(Player player, String event, String details) {
      if (this.plugin.getConfigManager().getCachedBoolean("security.log_events", true)) {
         this.plugin.getLogger().info(String.format("SECURITY [%s] %s: %s", player != null ? player.getName() : "CONSOLE", event, details));
      }

   }

   private boolean isReservedName(String name) {
      String lowerName = name.toLowerCase();
      return lowerName.equals("admin") || lowerName.equals("system") || lowerName.equals("default") || lowerName.equals("config") || lowerName.equals("temp") || lowerName.equals("backup");
   }

   private void cleanupRateLimiting() {
      this.rateLimitCounter.clear();
      long cutoff = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(1L);
      this.commandCooldowns.entrySet().removeIf((entry) -> {
         return (Long)entry.getValue() < cutoff;
      });
      this.ipCooldowns.entrySet().removeIf((entry) -> {
         return (Long)entry.getValue() < cutoff;
      });
   }

   public void cleanup() {
      this.commandCooldowns.clear();
      this.rateLimitCounter.clear();
      this.ipCooldowns.clear();
   }

   public static class ValidationResult {
      private final boolean valid;
      private final String error;
      private final Object value;

      private ValidationResult(boolean valid, String error, Object value) {
         this.valid = valid;
         this.error = error;
         this.value = value;
      }

      public static SecurityManager.ValidationResult valid(Object value) {
         return new SecurityManager.ValidationResult(true, (String)null, value);
      }

      public static SecurityManager.ValidationResult invalid(String error) {
         return new SecurityManager.ValidationResult(false, error, (Object)null);
      }

      public boolean isValid() {
         return this.valid;
      }

      public String getError() {
         return this.error;
      }

      public <T> T getValue() {
         return this.value;
      }
   }
}
