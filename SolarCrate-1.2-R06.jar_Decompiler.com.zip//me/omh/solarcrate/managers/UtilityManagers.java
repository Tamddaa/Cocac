package me.omh.solarcrate.managers;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import org.bukkit.configuration.file.FileConfiguration;

public class UtilityManagers {
   private final Map<String, Object> cache = new ConcurrentHashMap();
   private final Map<String, Long> operationTimes = new ConcurrentHashMap();
   private final Map<String, Integer> operationCounts = new ConcurrentHashMap();
   private final Map<String, Long> totalTimes = new ConcurrentHashMap();

   public Object get(String key) {
      UtilityManagers.CacheEntry entry = (UtilityManagers.CacheEntry)this.cache.get(key);
      return entry != null ? entry.value : null;
   }

   public void put(String key, Object value) {
      this.cache.put(key, new UtilityManagers.CacheEntry(value, System.currentTimeMillis()));
   }

   public void invalidate(String key) {
      this.cache.remove(key);
   }

   public void clearCache() {
      this.cache.clear();
   }

   public <T> T getOrCompute(String key, Supplier<T> supplier, long ttl) {
      UtilityManagers.CacheEntry entry = (UtilityManagers.CacheEntry)this.cache.get(key);
      long currentTime = System.currentTimeMillis();
      if (entry != null && (ttl <= 0L || currentTime - entry.timestamp <= ttl)) {
         return entry.value;
      } else {
         T value = supplier.get();
         this.cache.put(key, new UtilityManagers.CacheEntry(value, currentTime));
         return value;
      }
   }

   public CompletableFuture<Boolean> saveConfigAsync(String name, FileConfiguration config, File file) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            config.save(file);
            return true;
         } catch (Exception var3) {
            var3.printStackTrace();
            return false;
         }
      });
   }

   public void startOperation(String operationName) {
      this.operationTimes.put(operationName, System.currentTimeMillis());
   }

   public long endOperation(String operationName) {
      Long startTime = (Long)this.operationTimes.remove(operationName);
      if (startTime == null) {
         return -1L;
      } else {
         long duration = System.currentTimeMillis() - startTime;
         this.operationCounts.merge(operationName, 1, Integer::sum);
         this.totalTimes.merge(operationName, duration, Long::sum);
         return duration;
      }
   }

   public <T> T timeOperation(String operationName, Supplier<T> operation) {
      this.startOperation(operationName);

      Object var3;
      try {
         var3 = operation.get();
      } finally {
         this.endOperation(operationName);
      }

      return var3;
   }

   public void timeOperation(String operationName, Runnable operation) {
      this.startOperation(operationName);

      try {
         operation.run();
      } finally {
         this.endOperation(operationName);
      }

   }

   public long getAverageTime(String operationName) {
      Integer count = (Integer)this.operationCounts.get(operationName);
      Long total = (Long)this.totalTimes.get(operationName);
      return count != null && total != null && count != 0 ? total / (long)count : 0L;
   }

   public int getOperationCount(String operationName) {
      return (Integer)this.operationCounts.getOrDefault(operationName, 0);
   }

   public long getTotalTime(String operationName) {
      return (Long)this.totalTimes.getOrDefault(operationName, 0L);
   }

   public Map<String, String> getPerformanceStats() {
      Map<String, String> stats = new HashMap();
      Iterator var2 = this.operationCounts.keySet().iterator();

      while(var2.hasNext()) {
         String operation = (String)var2.next();
         int count = this.getOperationCount(operation);
         long total = this.getTotalTime(operation);
         long average = this.getAverageTime(operation);
         stats.put(operation, String.format("Count: %d, Total: %dms, Avg: %dms", count, total, average));
      }

      return stats;
   }

   public void resetStats() {
      this.operationCounts.clear();
      this.totalTimes.clear();
      this.operationTimes.clear();
   }

   public void resetStats(String operationName) {
      this.operationCounts.remove(operationName);
      this.totalTimes.remove(operationName);
      this.operationTimes.remove(operationName);
   }

   public void cleanup() {
      this.clearCache();
      this.resetStats();
   }

   private static class CacheEntry {
      final Object value;
      final long timestamp;

      CacheEntry(Object value, long timestamp) {
         this.value = value;
         this.timestamp = timestamp;
      }
   }
}
