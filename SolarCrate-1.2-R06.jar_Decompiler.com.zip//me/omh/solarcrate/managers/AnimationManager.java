package me.omh.solarcrate.managers;

import java.util.Random;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class AnimationManager {
   private final SolarCrate plugin;
   private final Random random = new Random();

   public AnimationManager(SolarCrate plugin) {
      this.plugin = plugin;
   }

   public void playCrateOpeningAnimation(Player player, Crate crate) {
      if (crate == null || crate.isParticlesEnabled()) {
         if (this.plugin.getConfigManager().getCachedBoolean("animations.crate_opening.enabled", true)) {
            int duration = this.plugin.getConfigManager().getCachedInt("animations.crate_opening.duration_ticks", 80);
            int density = crate != null ? crate.getParticleDensity() : this.plugin.getConfigManager().getCachedInt("animations.crate_opening.particle_density", 10);
            Location playerLoc = player.getLocation().add(0.0D, 1.0D, 0.0D);
            this.playAnticipationPhase(player, playerLoc, density);
            this.plugin.getFoliaLib().getImpl().runLater(() -> {
               if (player.isOnline()) {
                  this.playOpeningExplosion(player, playerLoc, density, crate);
               }
            }, (long)(duration / 4));
            this.plugin.getFoliaLib().getImpl().runLater(() -> {
               if (player.isOnline()) {
                  this.playCelebrationPhase(player, playerLoc, duration / 2, density, crate);
               }
            }, (long)(duration / 2));
         }
      }
   }

   public void playRewardAnimation(Player player, String rarity) {
      if (this.plugin.getConfigManager().getCachedBoolean("animations.reward_receive.enabled", true)) {
         int spiralDuration = this.plugin.getConfigManager().getCachedInt("animations.reward_receive.spiral_duration", 40);
         Location loc = player.getLocation().add(0.0D, 2.0D, 0.0D);
         Color rarityColor = this.getRarityColor(rarity);

         for(int tick = 0; tick < spiralDuration; ++tick) {
            this.plugin.getFoliaLib().getImpl().runLater(() -> {
               if (player.isOnline()) {
                  double baseAngle = (double)tick * 0.3D;
                  double radius = 1.5D;

                  for(int spiral = 0; spiral < 3; ++spiral) {
                     double angle = baseAngle + (double)spiral * 3.141592653589793D * 2.0D / 3.0D;
                     double x = Math.cos(angle) * radius;
                     double z = Math.sin(angle) * radius;
                     double y = Math.sin(baseAngle * 2.0D) * 0.5D;
                     Location particleLoc = loc.clone().add(x, y, z);
                     if (rarityColor != null) {
                        player.spawnParticle(Particle.DUST, particleLoc, 1, new DustOptions(rarityColor, 1.5F));
                     } else {
                        player.spawnParticle(Particle.HAPPY_VILLAGER, particleLoc, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                     }
                  }

               }
            }, (long)tick * 2L);
         }

         if (player.isOnline()) {
            this.playRewardSounds(player, rarity);
         }

      }
   }

   public void playLocationParticles(Location location, Particle particle, int count, Color color) {
      if (this.plugin.getConfigManager().getCachedBoolean("animations.location_effects.enabled", true)) {
         if (color != null && particle == Particle.DUST) {
            location.getWorld().spawnParticle(particle, location, count, new DustOptions(color, 1.0F));
         } else {
            location.getWorld().spawnParticle(particle, location, count, 0.5D, 0.5D, 0.5D, 0.1D);
         }

      }
   }

   public void playEnhancedSuccessAnimation(Player player) {
      Location loc = player.getLocation().add(0.0D, 1.0D, 0.0D);
      int animationDuration = true;

      for(int tick = 0; tick < 30; ++tick) {
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            if (player.isOnline()) {
               double time = (double)tick * 0.1D;
               double radius = 2.0D;
               double height = 3.0D;

               for(int p = 0; p < 8; ++p) {
                  double angle = time + (double)p * 3.141592653589793D / 4.0D;
                  double x = Math.cos(angle) * radius;
                  double z = Math.sin(angle) * radius;
                  double y = Math.sin(time * 3.0D) * height * 0.3D;
                  Location particleLoc = loc.clone().add(x, y, z);
                  player.spawnParticle(Particle.DUST, particleLoc, 1, new DustOptions(Color.YELLOW, 2.0F));
                  if (this.random.nextFloat() < 0.3F) {
                     player.spawnParticle(Particle.ENCHANT, particleLoc, 1, 0.1D, 0.1D, 0.1D, 1.0D);
                  }
               }

            }
         }, (long)tick);
      }

      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         if (player.isOnline()) {
            Location currentLoc = player.getLocation().add(0.0D, 1.0D, 0.0D);
            player.spawnParticle(Particle.EXPLOSION, currentLoc, 3, 1.0D, 1.0D, 1.0D, 0.0D);
            player.spawnParticle(Particle.TOTEM_OF_UNDYING, currentLoc, 15, 1.5D, 1.5D, 1.5D, 0.1D);
         }
      }, 30L);
   }

   private void playAnticipationPhase(Player player, Location loc, int density) {
      int anticipationTicks = Math.max(10, density);

      for(int i = 0; i < anticipationTicks; ++i) {
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            if (player.isOnline()) {
               double angle = this.random.nextDouble() * 3.141592653589793D * 2.0D;
               double radius = 0.5D + this.random.nextDouble() * 0.5D;
               double x = Math.cos(angle) * radius;
               double z = Math.sin(angle) * radius;
               double y = this.random.nextDouble() * 0.5D;
               Location particleLoc = loc.clone().add(x, y, z);
               player.spawnParticle(Particle.ENCHANT, particleLoc, Math.max(1, density / 5), 0.1D, 0.1D, 0.1D, 0.5D);
               if (i % 5 == 0) {
                  player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.3F, 1.0F + (float)i * 0.1F);
               }

            }
         }, (long)i);
      }

   }

   private void playOpeningExplosion(Player player, Location loc, int density, Crate crate) {
      if (player.isOnline()) {
         player.spawnParticle(Particle.FLASH, loc, 1);
         player.spawnParticle(Particle.EXPLOSION, loc, Math.max(1, density / 2), 1.0D, 1.0D, 1.0D, 0.0D);

         try {
            Particle openingParticle = crate != null && crate.getOpeningParticle() != null ? Particle.valueOf(crate.getOpeningParticle().toUpperCase()) : Particle.FIREWORK;
            player.spawnParticle(openingParticle, loc, density * 2, 2.0D, 2.0D, 2.0D, 0.2D);
         } catch (IllegalArgumentException var12) {
            player.spawnParticle(Particle.FIREWORK, loc, density * 2, 2.0D, 2.0D, 2.0D, 0.2D);
         }

         Color[] colors = new Color[]{Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.PURPLE, Color.ORANGE};
         Color[] var6 = colors;
         int var7 = colors.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            Color color = var6[var8];
            Vector direction = (new Vector((this.random.nextDouble() - 0.5D) * 2.0D, this.random.nextDouble(), (this.random.nextDouble() - 0.5D) * 2.0D)).normalize().multiply(1.5D);
            Location particleLoc = loc.clone().add(direction);
            player.spawnParticle(Particle.DUST, particleLoc, Math.max(1, density / 3), new DustOptions(color, 2.0F));
         }

         player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.0F, 1.2F);
         player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.7F, 1.5F);
      }
   }

   private void playCelebrationPhase(Player player, Location loc, int duration, int density, Crate crate) {
      for(int i = 0; i < duration; ++i) {
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            if (player.isOnline()) {
               int fountainParticles = Math.max(1, density / 3);

               int j;
               Vector velocity;
               Location particleLoc;
               try {
                  Particle celebrationParticle = crate != null && crate.getCelebrationParticle() != null ? Particle.valueOf(crate.getCelebrationParticle().toUpperCase()) : Particle.HAPPY_VILLAGER;

                  for(j = 0; j < fountainParticles; ++j) {
                     velocity = new Vector((this.random.nextDouble() - 0.5D) * 0.5D, this.random.nextDouble() * 2.0D, (this.random.nextDouble() - 0.5D) * 0.5D);
                     particleLoc = loc.clone().add(0.0D, this.random.nextDouble(), 0.0D);
                     player.spawnParticle(celebrationParticle, particleLoc, 1, velocity.getX(), velocity.getY(), velocity.getZ(), 0.1D);
                  }
               } catch (IllegalArgumentException var10) {
                  for(j = 0; j < fountainParticles; ++j) {
                     velocity = new Vector((this.random.nextDouble() - 0.5D) * 0.5D, this.random.nextDouble() * 2.0D, (this.random.nextDouble() - 0.5D) * 0.5D);
                     particleLoc = loc.clone().add(0.0D, this.random.nextDouble(), 0.0D);
                     player.spawnParticle(Particle.HAPPY_VILLAGER, particleLoc, 1, velocity.getX(), velocity.getY(), velocity.getZ(), 0.1D);
                  }
               }

               if (this.random.nextFloat() < 0.2F + (float)density * 0.05F) {
                  Location sparkle = loc.clone().add((this.random.nextDouble() - 0.5D) * 3.0D, this.random.nextDouble() * 2.0D, (this.random.nextDouble() - 0.5D) * 3.0D);
                  player.spawnParticle(Particle.END_ROD, sparkle, 1, 0.0D, 0.0D, 0.0D, 0.1D);
               }

            }
         }, (long)i);
      }

   }

   private void playRewardSounds(Player player, String rarity) {
      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         if (player.isOnline()) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
         }
      }, 1L);
      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         if (player.isOnline()) {
            String var2 = rarity.toLowerCase();
            byte var3 = -1;
            switch(var2.hashCode()) {
            case -2081562821:
               if (var2.equals("legendary")) {
                  var3 = 0;
               }
               break;
            case 3119877:
               if (var2.equals("epic")) {
                  var3 = 1;
               }
               break;
            case 3493026:
               if (var2.equals("rare")) {
                  var3 = 2;
               }
            }

            switch(var3) {
            case 0:
               player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
               break;
            case 1:
               player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8F, 1.2F);
               break;
            case 2:
               player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.5F);
               break;
            default:
               player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
            }

         }
      }, 10L);
      this.plugin.getFoliaLib().getImpl().runLater(() -> {
         if (player.isOnline()) {
            player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 0.7F, 1.8F);
         }
      }, 20L);
   }

   private Color getRarityColor(String rarity) {
      String var2 = rarity.toLowerCase();
      byte var3 = -1;
      switch(var2.hashCode()) {
      case -2081562821:
         if (var2.equals("legendary")) {
            var3 = 0;
         }
         break;
      case -468311612:
         if (var2.equals("uncommon")) {
            var3 = 3;
         }
         break;
      case 3119877:
         if (var2.equals("epic")) {
            var3 = 1;
         }
         break;
      case 3493026:
         if (var2.equals("rare")) {
            var3 = 2;
         }
      }

      switch(var3) {
      case 0:
         return Color.ORANGE;
      case 1:
         return Color.PURPLE;
      case 2:
         return Color.BLUE;
      case 3:
         return Color.GREEN;
      default:
         return Color.WHITE;
      }
   }

   public void playAmbientCrateEffect(Location crateLocation, Crate crate) {
      if (crate == null || crate.isParticlesEnabled()) {
         if (this.plugin.getConfigManager().getCachedBoolean("animations.ambient_effects.enabled", true)) {
            int particleCount = crate != null ? Math.max(1, crate.getParticleDensity() / 3) : this.plugin.getConfigManager().getCachedInt("animations.ambient_effects.particle_count", 3);
            Location loc = crateLocation.clone().add(0.5D, 1.5D, 0.5D);

            for(int i = 0; i < particleCount; ++i) {
               double x = (this.random.nextDouble() - 0.5D) * 1.5D;
               double y = this.random.nextDouble() * 0.5D;
               double z = (this.random.nextDouble() - 0.5D) * 1.5D;
               Location particleLoc = loc.clone().add(x, y, z);
               if (crate != null && crate.getAmbientParticle() != null) {
                  try {
                     Particle particle = Particle.valueOf(crate.getAmbientParticle().toUpperCase());
                     if (particle == Particle.DUST) {
                        Color color = Color.fromRGB(crate.getAmbientColorRed(), crate.getAmbientColorGreen(), crate.getAmbientColorBlue());
                        crateLocation.getWorld().spawnParticle(particle, particleLoc, 1, new DustOptions(color, 0.8F));
                     } else {
                        crateLocation.getWorld().spawnParticle(particle, particleLoc, 1, 0.1D, 0.1D, 0.1D, 0.0D);
                     }
                  } catch (IllegalArgumentException var15) {
                     crateLocation.getWorld().spawnParticle(Particle.DUST, particleLoc, 1, new DustOptions(Color.AQUA, 0.8F));
                  }
               } else {
                  crateLocation.getWorld().spawnParticle(Particle.DUST, particleLoc, 1, new DustOptions(Color.AQUA, 0.8F));
               }
            }

         }
      }
   }

   public void playCountdownAnimation(Player player, Crate crate, int seconds) {
      String titleTemplate = crate != null && crate.getCountdownTitle() != null ? crate.getCountdownTitle() : "&e&l⏰ {count} ⏰";
      String subtitleTemplate = crate != null && crate.getCountdownSubtitle() != null ? crate.getCountdownSubtitle() : "&7Chuẩn bị nhận phần thưởng...";

      for(int i = seconds; i > 0; --i) {
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            Location loc = player.getLocation().add(0.0D, 2.0D, 0.0D);
            player.spawnParticle(Particle.HAPPY_VILLAGER, loc, i * 2, 0.5D, 0.5D, 0.5D, 0.1D);
            float pitch = 0.8F + 0.2F * (float)(seconds - i + 1);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8F, pitch);
            String title = SolarUtils.c(titleTemplate.replace("{count}", String.valueOf(i)));
            String subtitle = SolarUtils.c(subtitleTemplate);
            player.sendTitle(title, subtitle, 2, 18, 2);
         }, (long)(seconds - i) * 20L);
      }

   }
}
