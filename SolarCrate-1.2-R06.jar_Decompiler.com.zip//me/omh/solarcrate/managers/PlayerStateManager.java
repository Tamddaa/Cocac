package me.omh.solarcrate.managers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.gui.BaseGui;
import me.omh.solarcrate.libs.folialib.wrapper.task.WrappedTask;
import org.bukkit.Bukkit;

public class PlayerStateManager {
   private final SolarCrate plugin;
   private final Map<UUID, PlayerStateManager.PlayerState> playerStates = new ConcurrentHashMap();
   private final AtomicBoolean isShuttingDown = new AtomicBoolean(false);
   private WrappedTask cleanupTask;
   private static final long CLEANUP_INTERVAL_TICKS = 1200L;
   private static final long STATE_TIMEOUT_MS = 60000L;
   private static final int MAX_CACHED_STATES = 500;

   public PlayerStateManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.startCleanupTask();
   }

   private PlayerStateManager.PlayerState getPlayerState(UUID playerId) {
      return (PlayerStateManager.PlayerState)this.playerStates.computeIfAbsent(playerId, (k) -> {
         return new PlayerStateManager.PlayerState();
      });
   }

   public void onPlayerJoin(UUID playerId) {
      PlayerStateManager.PlayerState state = this.getPlayerState(playerId);
      state.setOnline(true);
      this.plugin.getSLF4JLogger().debug("Player state initialized for: {}", playerId);
   }

   public void onPlayerQuit(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      if (state != null) {
         state.setOnline(false);
         long sessionTime = System.currentTimeMillis() - state.getJoinTime();
         this.plugin.getSLF4JLogger().debug("Player {} session time: {} minutes", playerId, sessionTime / 60000L);
         state.clearAllState();
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            this.playerStates.remove(playerId);
         }, 200L);
      }

   }

   public String getSelectedCrate(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? state.getSelectedCrate() : null;
   }

   public void setSelectedCrate(UUID playerId, String crateName) {
      this.getPlayerState(playerId).setSelectedCrate(crateName);
   }

   public void clearSelectedCrate(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      if (state != null) {
         state.setSelectedCrate((String)null);
      }

   }

   public String getEditingCrate(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? state.getEditingCrate() : null;
   }

   public void setEditingCrate(UUID playerId, String crateName) {
      this.getPlayerState(playerId).setEditingCrate(crateName);
   }

   public void clearEditingCrate(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      if (state != null) {
         state.setEditingCrate((String)null);
      }

   }

   public boolean isEditingCrate(UUID playerId) {
      return this.getEditingCrate(playerId) != null;
   }

   public PlayerStateManager.PlayerMode getPlayerMode(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? state.getMode() : PlayerStateManager.PlayerMode.NORMAL;
   }

   public void setPlayerMode(UUID playerId, PlayerStateManager.PlayerMode mode) {
      this.getPlayerState(playerId).setMode(mode);
   }

   public boolean isInRemoveMode(UUID playerId) {
      return this.getPlayerMode(playerId) == PlayerStateManager.PlayerMode.REMOVE_MODE;
   }

   public void setRemoveMode(UUID playerId, boolean removeMode) {
      this.setPlayerMode(playerId, removeMode ? PlayerStateManager.PlayerMode.REMOVE_MODE : PlayerStateManager.PlayerMode.NORMAL);
   }

   public PlayerStateManager.GuiType getCurrentGuiType(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? state.getCurrentGuiType() : null;
   }

   public void setCurrentGuiType(UUID playerId, PlayerStateManager.GuiType guiType) {
      this.getPlayerState(playerId).setCurrentGuiType(guiType);
   }

   public BaseGui getCurrentGui(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? state.getCurrentGui() : null;
   }

   public void setCurrentGui(UUID playerId, BaseGui gui) {
      this.getPlayerState(playerId).setCurrentGui(gui);
   }

   public void clearGuiState(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      if (state != null) {
         state.clearGuiState();
      }

   }

   public void setEditingCrateAndMode(UUID playerId, String editingCrate, PlayerStateManager.PlayerMode mode) {
      PlayerStateManager.PlayerState state = this.getPlayerState(playerId);
      state.setEditingCrateAndMode(editingCrate, mode);
   }

   public void setGuiStateAtomic(UUID playerId, PlayerStateManager.GuiType guiType, BaseGui gui) {
      PlayerStateManager.PlayerState state = this.getPlayerState(playerId);
      state.setGuiStateAtomic(guiType, gui);
   }

   public void clearEditingState(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      if (state != null) {
         state.clearEditingState();
      }

   }

   public boolean isInGui(UUID playerId, PlayerStateManager.GuiType guiType) {
      return guiType != null && guiType.equals(this.getCurrentGuiType(playerId));
   }

   public long getSessionTime(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? System.currentTimeMillis() - state.getJoinTime() : 0L;
   }

   public long getLastGuiAccess(UUID playerId) {
      PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)this.playerStates.get(playerId);
      return state != null ? state.getLastGuiAccess() : 0L;
   }

   public Set<UUID> getAllOnlinePlayers() {
      return (Set)this.playerStates.entrySet().stream().filter((entry) -> {
         return ((PlayerStateManager.PlayerState)entry.getValue()).isOnline();
      }).map(Entry::getKey).collect(Collectors.toSet());
   }

   public Set<UUID> getPlayersEditingCrates() {
      return (Set)this.playerStates.entrySet().stream().filter((entry) -> {
         return ((PlayerStateManager.PlayerState)entry.getValue()).getEditingCrate() != null;
      }).map(Entry::getKey).collect(Collectors.toSet());
   }

   private void startCleanupTask() {
      if (!this.isShuttingDown.get()) {
         this.cleanupTask = this.plugin.getFoliaLib().getImpl().runTimer(() -> {
            if (!this.isShuttingDown.get()) {
               this.cleanupStaleStates();
            }

         }, 1200L, 1200L);
      }
   }

   private void cleanupStaleStates() {
      long currentTime = System.currentTimeMillis();
      int removedCount = 0;
      int removedCount = removedCount + (this.playerStates.entrySet().removeIf((entry) -> {
         UUID playerId = (UUID)entry.getKey();
         PlayerStateManager.PlayerState state = (PlayerStateManager.PlayerState)entry.getValue();
         if (!state.isOnline() && currentTime - state.getLastGuiAccess() > 60000L) {
            this.plugin.getSLF4JLogger().debug("Cleaned up stale state for offline player: {}", playerId);
            return true;
         } else if (state.isOnline() && Bukkit.getPlayer(playerId) == null) {
            this.plugin.getSLF4JLogger().debug("Cleaned up state for disconnected player: {}", playerId);
            return true;
         } else {
            return false;
         }
      }) ? 1 : 0);
      if (this.playerStates.size() > 500) {
         this.plugin.getLogger().warning("Player state cache exceeds maximum size (" + this.playerStates.size() + " > 500). Forcing cleanup of oldest states.");
         List<Entry<UUID, PlayerStateManager.PlayerState>> sortedEntries = new ArrayList(this.playerStates.entrySet());
         sortedEntries.sort((e1, e2) -> {
            return Long.compare(((PlayerStateManager.PlayerState)e1.getValue()).getLastGuiAccess(), ((PlayerStateManager.PlayerState)e2.getValue()).getLastGuiAccess());
         });
         int toRemove = this.playerStates.size() - 500;

         for(int i = 0; i < toRemove && i < sortedEntries.size(); ++i) {
            UUID playerToRemove = (UUID)((Entry)sortedEntries.get(i)).getKey();
            if (!((PlayerStateManager.PlayerState)((Entry)sortedEntries.get(i)).getValue()).isOnline()) {
               this.playerStates.remove(playerToRemove);
               ++removedCount;
            }
         }
      }

      if (removedCount > 0) {
         this.plugin.getSLF4JLogger().debug("Cleanup removed {} stale player states. Remaining: {}", removedCount, this.playerStates.size());
      }

   }

   public void shutdown() {
      this.isShuttingDown.set(true);
      if (this.cleanupTask != null && !this.cleanupTask.isCancelled()) {
         this.cleanupTask.cancel();
      }

      this.playerStates.clear();
      this.plugin.getSLF4JLogger().info("PlayerStateManager shutdown complete");
   }

   public int getActiveStateCount() {
      return this.playerStates.size();
   }

   public Map<String, Object> getDebugInfo() {
      Map<String, Object> debug = new ConcurrentHashMap();
      debug.put("total_states", this.playerStates.size());
      debug.put("online_players", this.getAllOnlinePlayers().size());
      debug.put("editing_players", this.getPlayersEditingCrates().size());
      debug.put("is_shutting_down", this.isShuttingDown.get());
      return debug;
   }

   private static class PlayerState {
      private String selectedCrate;
      private String editingCrate;
      private PlayerStateManager.PlayerMode mode;
      private PlayerStateManager.GuiType currentGuiType;
      private BaseGui currentGui;
      private long joinTime;
      private long lastGuiAccess;
      private volatile boolean isOnline;

      public PlayerState() {
         this.mode = PlayerStateManager.PlayerMode.NORMAL;
         this.isOnline = true;
         this.joinTime = System.currentTimeMillis();
         this.lastGuiAccess = System.currentTimeMillis();
      }

      public synchronized String getSelectedCrate() {
         return this.selectedCrate;
      }

      public synchronized void setSelectedCrate(String selectedCrate) {
         this.selectedCrate = selectedCrate;
         this.updateLastAccess();
      }

      public synchronized String getEditingCrate() {
         return this.editingCrate;
      }

      public synchronized void setEditingCrate(String editingCrate) {
         this.editingCrate = editingCrate;
         this.mode = editingCrate != null ? PlayerStateManager.PlayerMode.EDITING_CRATE : PlayerStateManager.PlayerMode.NORMAL;
         this.updateLastAccess();
      }

      public synchronized PlayerStateManager.PlayerMode getMode() {
         return this.mode;
      }

      public synchronized void setMode(PlayerStateManager.PlayerMode mode) {
         this.mode = mode;
         this.updateLastAccess();
      }

      public synchronized PlayerStateManager.GuiType getCurrentGuiType() {
         return this.currentGuiType;
      }

      public synchronized void setCurrentGuiType(PlayerStateManager.GuiType currentGuiType) {
         this.currentGuiType = currentGuiType;
         this.updateLastAccess();
      }

      public synchronized BaseGui getCurrentGui() {
         return this.currentGui;
      }

      public synchronized void setCurrentGui(BaseGui currentGui) {
         this.currentGui = currentGui;
         this.updateLastAccess();
      }

      public synchronized long getJoinTime() {
         return this.joinTime;
      }

      public synchronized long getLastGuiAccess() {
         return this.lastGuiAccess;
      }

      public synchronized boolean isOnline() {
         return this.isOnline;
      }

      public synchronized void setOnline(boolean online) {
         this.isOnline = online;
      }

      private void updateLastAccess() {
         this.lastGuiAccess = System.currentTimeMillis();
      }

      public synchronized void clearGuiState() {
         this.currentGui = null;
         this.currentGuiType = null;
         this.selectedCrate = null;
         this.updateLastAccess();
      }

      public synchronized void clearAllState() {
         this.selectedCrate = null;
         this.editingCrate = null;
         this.mode = PlayerStateManager.PlayerMode.NORMAL;
         this.currentGuiType = null;
         this.currentGui = null;
         this.isOnline = false;
      }

      public synchronized void setEditingCrateAndMode(String editingCrate, PlayerStateManager.PlayerMode mode) {
         this.editingCrate = editingCrate;
         this.mode = mode;
         this.updateLastAccess();
      }

      public synchronized void setGuiStateAtomic(PlayerStateManager.GuiType guiType, BaseGui gui) {
         this.currentGuiType = guiType;
         this.currentGui = gui;
         this.updateLastAccess();
      }

      public synchronized void clearEditingState() {
         this.editingCrate = null;
         this.mode = PlayerStateManager.PlayerMode.NORMAL;
         this.updateLastAccess();
      }
   }

   public static enum PlayerMode {
      NORMAL,
      EDITING_CRATE,
      REMOVE_MODE;

      // $FF: synthetic method
      private static PlayerStateManager.PlayerMode[] $values() {
         return new PlayerStateManager.PlayerMode[]{NORMAL, EDITING_CRATE, REMOVE_MODE};
      }
   }

   public static enum GuiType {
      CRATE_SELECTION,
      CONFIRMATION,
      EDIT_WORKBENCH;

      // $FF: synthetic method
      private static PlayerStateManager.GuiType[] $values() {
         return new PlayerStateManager.GuiType[]{CRATE_SELECTION, CONFIRMATION, EDIT_WORKBENCH};
      }
   }
}
