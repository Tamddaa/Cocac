package me.omh.solarcrate.managers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import me.omh.solarcrate.SolarCrate;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class KeyManager {
   private final SolarCrate plugin;
   private final Map<UUID, Map<String, Integer>> playerKeys = new ConcurrentHashMap();
   private File file;
   private volatile FileConfiguration data;
   private final Object saveLock = new Object();

   public KeyManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "keys.yml");
      if (!this.file.exists()) {
         try {
            this.file.getParentFile().mkdirs();
            this.file.createNewFile();
         } catch (IOException var3) {
            plugin.getLogger().severe("Could not create keys.yml file: " + var3.getMessage());
         }
      }

      this.data = YamlConfiguration.loadConfiguration(this.file);
   }

   public void loadKeys() {
      synchronized(this.saveLock) {
         try {
            Map<UUID, Map<String, Integer>> tempPlayerKeys = new ConcurrentHashMap();
            this.data = YamlConfiguration.loadConfiguration(this.file);
            Iterator var3 = this.data.getKeys(false).iterator();

            while(var3.hasNext()) {
               String uuidStr = (String)var3.next();

               try {
                  UUID uuid = UUID.fromString(uuidStr);
                  Map<String, Integer> keyMap = new ConcurrentHashMap();
                  ConfigurationSection section = this.data.getConfigurationSection(uuidStr);
                  if (section != null) {
                     Iterator var8 = section.getKeys(false).iterator();

                     while(var8.hasNext()) {
                        String key = (String)var8.next();

                        try {
                           int amount = this.data.getInt(uuidStr + "." + key, 0);
                           if (amount > 0) {
                              keyMap.put(key.toLowerCase(), amount);
                           }
                        } catch (ClassCastException var12) {
                           this.plugin.getLogger().warning("Invalid data type for key '" + key + "' for player " + uuidStr + ": " + var12.getMessage());
                        }
                     }
                  }

                  if (!keyMap.isEmpty()) {
                     tempPlayerKeys.put(uuid, keyMap);
                  }
               } catch (IllegalArgumentException var13) {
                  this.plugin.getLogger().warning("Invalid UUID format in keys.yml: " + uuidStr);
               } catch (RuntimeException var14) {
                  this.plugin.getLogger().severe("Runtime error processing player keys for " + uuidStr + ": " + var14.getMessage());
               }
            }

            this.playerKeys.clear();
            this.playerKeys.putAll(tempPlayerKeys);
         } catch (SecurityException var15) {
            this.plugin.getLogger().severe("Security error accessing keys.yml: " + var15.getMessage());
            var15.printStackTrace();
         } catch (RuntimeException var16) {
            this.plugin.getLogger().severe("Unexpected runtime error loading keys.yml: " + var16.getMessage());
            var16.printStackTrace();
         }

      }
   }

   public void saveKeys() {
      this.performKeySave();
   }

   private void performKeySave() {
      synchronized(this.saveLock) {
         try {
            File backupFile = new File(this.plugin.getDataFolder(), "keys.yml.backup");
            boolean backupCreated = false;
            if (this.file.exists()) {
               try {
                  Files.copy(this.file.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                  backupCreated = true;
               } catch (IOException var12) {
                  this.plugin.getLogger().severe("Critical error: Could not create backup of keys.yml - aborting save to prevent data loss: " + var12.getMessage());
                  return;
               }
            } else {
               backupCreated = true;
            }

            if (backupCreated) {
               FileConfiguration newData = new YamlConfiguration();
               Iterator var5 = this.playerKeys.entrySet().iterator();

               while(var5.hasNext()) {
                  Entry<UUID, Map<String, Integer>> entry = (Entry)var5.next();
                  String uuidStr = ((UUID)entry.getKey()).toString();
                  Iterator var8 = ((Map)entry.getValue()).entrySet().iterator();

                  while(var8.hasNext()) {
                     Entry<String, Integer> keyEntry = (Entry)var8.next();
                     int amount = (Integer)keyEntry.getValue();
                     if (amount > 0) {
                        newData.set(uuidStr + "." + ((String)keyEntry.getKey()).toLowerCase(), amount);
                     }
                  }
               }

               this.data = newData;
               this.saveKeysSync();
            }

         } catch (SecurityException var13) {
            this.plugin.getLogger().severe("Security error during key save preparation - file access denied: " + var13.getMessage());
            var13.printStackTrace();
         } catch (IllegalStateException var14) {
            this.plugin.getLogger().severe("Invalid state during key save preparation: " + var14.getMessage());
            var14.printStackTrace();
         } catch (OutOfMemoryError var15) {
            this.plugin.getLogger().severe("FATAL: Out of memory during key save preparation - disabling plugin: " + var15.getMessage());
            var15.printStackTrace();
            this.plugin.getServer().getPluginManager().disablePlugin(this.plugin);
            throw var15;
         } catch (Exception var16) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = var16.getClass().getSimpleName();
            var10000.severe("Unexpected error preparing key save: " + var10001 + " - " + var16.getMessage());
            var16.printStackTrace();
         }
      }
   }

   private void saveKeysSync() {
      synchronized(this.saveLock) {
         try {
            this.data.save(this.file);
            this.plugin.getLogger().info("Successfully saved keys for " + this.playerKeys.size() + " players");
         } catch (IOException var7) {
            this.plugin.getLogger().severe("Could not save keys.yml file: " + var7.getMessage());
            File backupFile = new File(this.plugin.getDataFolder(), "keys.yml.backup");
            if (backupFile.exists()) {
               try {
                  Files.copy(backupFile.toPath(), this.file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                  this.plugin.getLogger().info("Restored keys.yml from backup");
               } catch (IOException var6) {
                  this.plugin.getLogger().severe("Could not restore from backup: " + var6.getMessage());
                  this.plugin.getLogger().severe("CRITICAL: Both save and restore operations failed! Data may be corrupted.");
               }
            } else {
               this.plugin.getLogger().severe("No backup file available for restoration after save failure!");
            }
         }

      }
   }

   public int getKeys(UUID uuid, String key) {
      if (uuid != null && key != null && !key.trim().isEmpty()) {
         Map<String, Integer> keyMap = (Map)this.playerKeys.get(uuid);
         return keyMap == null ? 0 : (Integer)keyMap.getOrDefault(key.toLowerCase(), 0);
      } else {
         return 0;
      }
   }

   private int calculateTotalKeys(UUID uuid) {
      Map<String, Integer> keyMap = (Map)this.playerKeys.get(uuid);
      return keyMap == null ? 0 : keyMap.values().stream().mapToInt(Integer::intValue).sum();
   }

   public boolean restoreKey(UUID uuid, String key) {
      if (uuid != null && key != null && !key.trim().isEmpty()) {
         Logger var10000;
         String var10001;
         try {
            int maxKeysPerPlayer = this.plugin.getConfigManager().getCachedInt("max-keys-per-player", 100);
            Map<String, Integer> keyMap = (Map)this.playerKeys.computeIfAbsent(uuid, (u) -> {
               return new ConcurrentHashMap();
            });
            synchronized(keyMap) {
               int current = (Integer)keyMap.getOrDefault(key.toLowerCase(), 0);
               if (current >= Integer.MAX_VALUE) {
                  this.plugin.getLogger().severe("Cannot restore key for player " + String.valueOf(uuid) + ": current count is at maximum value");
                  return false;
               } else {
                  int totalKeys = keyMap.values().stream().mapToInt(Integer::intValue).sum();
                  if (totalKeys >= maxKeysPerPlayer) {
                     var10000 = this.plugin.getLogger();
                     var10001 = String.valueOf(uuid);
                     var10000.warning("Cannot restore key for player " + var10001 + ": would exceed max keys limit of " + maxKeysPerPlayer);
                     return false;
                  } else {
                     int newCount = current + 1;
                     keyMap.put(key.toLowerCase(), newCount);
                     this.plugin.getLogger().info("Restored 1 " + key + " key to player " + String.valueOf(uuid) + " (total keys: " + (totalKeys + 1) + "/" + maxKeysPerPlayer + ")");
                     this.markForSave();
                     return true;
                  }
               }
            }
         } catch (IllegalStateException var11) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Invalid state while restoring key for player " + var10001 + ": " + var11.getMessage());
            var11.printStackTrace();
            return false;
         } catch (Exception var12) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Unexpected error restoring key for player " + var10001 + ": " + var12.getClass().getSimpleName() + " - " + var12.getMessage());
            var12.printStackTrace();
            return false;
         }
      } else {
         this.plugin.getLogger().warning("Invalid parameters for key restoration");
         return false;
      }
   }

   public boolean addKeys(UUID uuid, String key, int amount) {
      if (uuid != null && key != null && !key.trim().isEmpty()) {
         if (amount <= 0) {
            this.plugin.getLogger().warning("Attempted to add non-positive amount of keys: " + amount);
            return false;
         } else {
            Logger var10000;
            String var10001;
            try {
               int maxKeysPerPlayer = this.plugin.getConfigManager().getCachedInt("max-keys-per-player", 100);
               Map<String, Integer> keyMap = (Map)this.playerKeys.computeIfAbsent(uuid, (u) -> {
                  return new ConcurrentHashMap();
               });
               synchronized(keyMap) {
                  int current = (Integer)keyMap.getOrDefault(key.toLowerCase(), 0);
                  long sum = (long)current + (long)amount;
                  if (sum > 2147483647L) {
                     this.plugin.getLogger().warning("Adding " + amount + " keys would cause overflow for player " + String.valueOf(uuid));
                     return false;
                  } else {
                     long totalKeys = keyMap.values().stream().mapToLong(Integer::longValue).sum();
                     if (totalKeys + (long)amount > (long)maxKeysPerPlayer) {
                        this.plugin.getLogger().info("Cannot add " + amount + " keys to player " + String.valueOf(uuid) + ": would exceed total limit of " + maxKeysPerPlayer + " (current: " + totalKeys + ")");
                        return false;
                     } else {
                        int newCount = (int)sum;
                        if (newCount == 0) {
                           keyMap.remove(key.toLowerCase());
                        } else {
                           keyMap.put(key.toLowerCase(), newCount);
                        }

                        this.plugin.getLogger().info("Added " + amount + " " + key + " keys to player " + String.valueOf(uuid) + " (total keys: " + (totalKeys + (long)amount) + "/" + maxKeysPerPlayer + ")");
                        this.markForSave();
                        return true;
                     }
                  }
               }
            } catch (ArithmeticException var15) {
               var10000 = this.plugin.getLogger();
               var10001 = String.valueOf(uuid);
               var10000.severe("Arithmetic overflow adding keys for player " + var10001 + ": " + var15.getMessage());
               var15.printStackTrace();
               return false;
            } catch (IllegalStateException var16) {
               var10000 = this.plugin.getLogger();
               var10001 = String.valueOf(uuid);
               var10000.severe("Invalid state while adding keys for player " + var10001 + ": " + var16.getMessage());
               var16.printStackTrace();
               return false;
            } catch (Exception var17) {
               var10000 = this.plugin.getLogger();
               var10001 = String.valueOf(uuid);
               var10000.severe("Unexpected error adding keys for player " + var10001 + ": " + var17.getClass().getSimpleName() + " - " + var17.getMessage());
               var17.printStackTrace();
               return false;
            }
         }
      } else {
         this.plugin.getLogger().warning("Invalid parameters for addKeys operation");
         return false;
      }
   }

   public boolean removeKey(UUID uuid, String key) {
      if (uuid != null && key != null && !key.trim().isEmpty()) {
         Logger var10000;
         String var10001;
         try {
            Map<String, Integer> keyMap = (Map)this.playerKeys.get(uuid);
            if (keyMap == null) {
               return false;
            } else {
               synchronized(keyMap) {
                  int existing = (Integer)keyMap.getOrDefault(key.toLowerCase(), 0);
                  if (existing > 0) {
                     int result = existing - 1;
                     if (result == 0) {
                        keyMap.remove(key.toLowerCase());
                     } else {
                        keyMap.put(key.toLowerCase(), result);
                     }

                     this.markForSave();
                     return true;
                  } else {
                     return false;
                  }
               }
            }
         } catch (IllegalStateException var9) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Invalid state while removing key for player " + var10001 + ": " + var9.getMessage());
            var9.printStackTrace();
            return false;
         } catch (Exception var10) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Unexpected error removing key for player " + var10001 + ": " + var10.getClass().getSimpleName() + " - " + var10.getMessage());
            var10.printStackTrace();
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean takeKeys(UUID uuid, String key, int amount) {
      if (uuid != null && key != null && !key.trim().isEmpty() && amount > 0) {
         Logger var10000;
         String var10001;
         try {
            Map<String, Integer> keyMap = (Map)this.playerKeys.get(uuid);
            if (keyMap == null) {
               return false;
            } else {
               synchronized(keyMap) {
                  int existing = (Integer)keyMap.getOrDefault(key.toLowerCase(), 0);
                  if (existing >= amount) {
                     int result = existing - amount;
                     if (result == 0) {
                        keyMap.remove(key.toLowerCase());
                     } else {
                        keyMap.put(key.toLowerCase(), result);
                     }

                     this.markForSave();
                     return true;
                  } else {
                     return false;
                  }
               }
            }
         } catch (IllegalStateException var10) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Invalid state while taking keys for player " + var10001 + ": " + var10.getMessage());
            var10.printStackTrace();
            return false;
         } catch (Exception var11) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Unexpected error taking keys for player " + var10001 + ": " + var11.getClass().getSimpleName() + " - " + var11.getMessage());
            var11.printStackTrace();
            return false;
         }
      } else {
         return false;
      }
   }

   public int removeKeys(UUID uuid, String key, int amount) {
      if (uuid != null && key != null && !key.trim().isEmpty() && amount > 0) {
         Logger var10000;
         String var10001;
         try {
            Map<String, Integer> keyMap = (Map)this.playerKeys.get(uuid);
            if (keyMap == null) {
               return 0;
            } else {
               synchronized(keyMap) {
                  int existing = (Integer)keyMap.getOrDefault(key.toLowerCase(), 0);
                  int removing = Math.min(existing, amount);
                  if (removing > 0) {
                     int result = existing - removing;
                     if (result == 0) {
                        keyMap.remove(key.toLowerCase());
                     } else {
                        keyMap.put(key.toLowerCase(), result);
                     }

                     this.markForSave();
                  }

                  return removing;
               }
            }
         } catch (IllegalStateException var11) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Invalid state while removing keys for player " + var10001 + ": " + var11.getMessage());
            var11.printStackTrace();
            return 0;
         } catch (Exception var12) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(uuid);
            var10000.severe("Unexpected error removing keys for player " + var10001 + ": " + var12.getClass().getSimpleName() + " - " + var12.getMessage());
            var12.printStackTrace();
            return 0;
         }
      } else {
         return 0;
      }
   }

   public Set<String> getAllKeyTypes() {
      Set<String> allTypes = new HashSet();
      Iterator var2 = this.playerKeys.values().iterator();

      while(var2.hasNext()) {
         Map<String, Integer> playerKeyMap = (Map)var2.next();
         if (playerKeyMap != null) {
            allTypes.addAll(playerKeyMap.keySet());
         }
      }

      return allTypes;
   }

   private void markForSave() {
      synchronized(this.saveLock) {
         try {
            this.plugin.getFoliaLib().getImpl().runAsync((task) -> {
               this.performScheduledSave();
            });
         } catch (Exception var4) {
            this.plugin.getLogger().warning("Failed to schedule async key save, performing sync save: " + var4.getMessage());
            this.performScheduledSave();
         }

      }
   }

   public void forceSave() {
      synchronized(this.saveLock) {
         try {
            this.saveKeys();
         } catch (Exception var4) {
            this.plugin.getLogger().severe("Error during force save: " + var4.getMessage());
            var4.printStackTrace();
         }

      }
   }

   private void performScheduledSave() {
      synchronized(this.saveLock) {
         FileConfiguration backupData = this.data;

         try {
            this.saveKeys();
            this.plugin.getLogger().fine("Scheduled key save completed successfully");
         } catch (Exception var5) {
            this.plugin.getLogger().severe("Error during scheduled key save: " + var5.getMessage());
            var5.printStackTrace();
            this.data = backupData;
         }

      }
   }

   public boolean setKeys(UUID playerUUID, String crateName, int amount) {
      if (playerUUID != null && crateName != null && !crateName.trim().isEmpty()) {
         Logger var10000;
         String var10001;
         try {
            String normalizedKey = crateName.toLowerCase();
            if (amount <= 0) {
               Map<String, Integer> keyMap = (Map)this.playerKeys.get(playerUUID);
               if (keyMap != null) {
                  synchronized(keyMap) {
                     Integer removed = (Integer)keyMap.remove(normalizedKey);
                     if (removed != null) {
                        this.markForSave();
                        this.plugin.getLogger().info("Removed " + crateName + " keys from player " + String.valueOf(playerUUID));
                        return true;
                     }
                  }
               }

               this.plugin.getLogger().fine("No keys to remove for " + crateName + " from player " + String.valueOf(playerUUID));
               return true;
            } else {
               int maxKeysPerPlayer = this.plugin.getConfigManager().getCachedInt("max-keys-per-player", 100);
               Map<String, Integer> keyMap = (Map)this.playerKeys.computeIfAbsent(playerUUID, (u) -> {
                  return new ConcurrentHashMap();
               });
               synchronized(keyMap) {
                  int currentAmount = (Integer)keyMap.getOrDefault(normalizedKey, 0);
                  long totalKeys = keyMap.values().stream().mapToLong(Integer::longValue).sum();
                  long adjustedTotal = totalKeys - (long)currentAmount + (long)amount;
                  if (adjustedTotal > (long)maxKeysPerPlayer) {
                     this.plugin.getLogger().warning("Cannot set " + amount + " " + crateName + " keys for player " + String.valueOf(playerUUID) + ": would exceed total limit of " + maxKeysPerPlayer + " (current total: " + totalKeys + ")");
                     return false;
                  } else {
                     keyMap.put(normalizedKey, amount);
                     this.plugin.getLogger().info("Set " + amount + " " + crateName + " keys for player " + String.valueOf(playerUUID) + " (total keys: " + adjustedTotal + "/" + maxKeysPerPlayer + ")");
                     this.markForSave();
                     return true;
                  }
               }
            }
         } catch (ArithmeticException var16) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(playerUUID);
            var10000.severe("Arithmetic overflow setting keys for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
            return false;
         } catch (IllegalStateException var17) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(playerUUID);
            var10000.severe("Invalid state while setting keys for player " + var10001 + ": " + var17.getMessage());
            var17.printStackTrace();
            return false;
         } catch (Exception var18) {
            var10000 = this.plugin.getLogger();
            var10001 = String.valueOf(playerUUID);
            var10000.severe("Unexpected error setting keys for player " + var10001 + ": " + var18.getClass().getSimpleName() + " - " + var18.getMessage());
            var18.printStackTrace();
            return false;
         }
      } else {
         this.plugin.getLogger().warning("Invalid parameters for setKeys operation");
         return false;
      }
   }

   public void shutdown() {
      this.plugin.getLogger().info("Shutting down KeyManager...");
      synchronized(this.saveLock) {
         try {
            this.forceSave();
            this.plugin.getLogger().info("Final key save completed successfully");
         } catch (Exception var4) {
            this.plugin.getLogger().severe("Error during final KeyManager save on shutdown: " + var4.getMessage());
            var4.printStackTrace();
         }

         this.playerKeys.clear();
         this.plugin.getLogger().info("KeyManager shutdown complete");
      }
   }
}
