package me.omh.solarcrate.managers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Supplier;
import me.omh.solarcrate.SolarCrate;

public class IntelligentCache {
   private final SolarCrate plugin;
   private final ConcurrentHashMap<String, IntelligentCache.CacheEntry> cache;
   private final ScheduledExecutorService cleanupExecutor;
   private final long defaultTtlMs;
   private final int maxSize;
   private final ReadWriteLock lruLock = new ReentrantReadWriteLock();
   private IntelligentCache.CacheEntry lruHead;
   private IntelligentCache.CacheEntry lruTail;

   public IntelligentCache(SolarCrate plugin) {
      this.plugin = plugin;
      this.cache = new ConcurrentHashMap();
      this.defaultTtlMs = (long)plugin.getConfigManager().getCachedInt("performance.cache_ttl_seconds", 300) * 1000L;
      this.maxSize = plugin.getConfigManager().getCachedInt("performance.cache_size", 1000);
      this.initializeLruList();
      this.cleanupExecutor = Executors.newSingleThreadScheduledExecutor((r) -> {
         Thread t = new Thread(r, "SolarCrate-CacheCleanup");
         t.setDaemon(true);
         return t;
      });
      this.cleanupExecutor.scheduleAtFixedRate(this::cleanup, 1L, 1L, TimeUnit.MINUTES);
   }

   private void initializeLruList() {
      this.lruHead = new IntelligentCache.CacheEntry("HEAD", (Object)null, Long.MAX_VALUE);
      this.lruTail = new IntelligentCache.CacheEntry("TAIL", (Object)null, Long.MAX_VALUE);
      this.lruHead.next = this.lruTail;
      this.lruTail.prev = this.lruHead;
   }

   public <T> T getOrCompute(String key, Supplier<T> supplier) {
      return this.getOrCompute(key, supplier, this.defaultTtlMs);
   }

   public <T> T getOrCompute(String key, Supplier<T> supplier, long ttlMs) {
      IntelligentCache.CacheEntry entry = (IntelligentCache.CacheEntry)this.cache.get(key);
      if (entry != null && !entry.isExpired()) {
         entry.accessed();
         this.moveToLruFront(entry);
         return entry.value;
      } else {
         T value = supplier.get();
         if (value != null) {
            this.put(key, value, ttlMs);
         }

         return value;
      }
   }

   public void put(String key, Object value) {
      this.put(key, value, this.defaultTtlMs);
   }

   public void put(String key, Object value, long ttlMs) {
      if (key != null && value != null) {
         if (this.cache.size() >= this.maxSize) {
            this.evictLRU();
         }

         IntelligentCache.CacheEntry entry = new IntelligentCache.CacheEntry(key, value, ttlMs);
         this.lruLock.writeLock().lock();

         try {
            IntelligentCache.CacheEntry existing = (IntelligentCache.CacheEntry)this.cache.put(key, entry);
            if (existing != null) {
               this.removeFromLruListInternal(existing);
            }

            this.addToLruFrontInternal(entry);
         } finally {
            this.lruLock.writeLock().unlock();
         }

      }
   }

   public <T> T get(String key) {
      IntelligentCache.CacheEntry entry = (IntelligentCache.CacheEntry)this.cache.get(key);
      if (entry != null && !entry.isExpired()) {
         entry.accessed();
         this.moveToLruFront(entry);
         return entry.value;
      } else {
         return null;
      }
   }

   public void invalidate(String key) {
      this.lruLock.writeLock().lock();

      try {
         IntelligentCache.CacheEntry removed = (IntelligentCache.CacheEntry)this.cache.remove(key);
         if (removed != null) {
            this.removeFromLruListInternal(removed);
         }
      } finally {
         this.lruLock.writeLock().unlock();
      }

   }

   public void invalidatePattern(String pattern) {
      String regex = pattern.replace("*", ".*");
      this.lruLock.writeLock().lock();

      try {
         List<String> matchingKeys = new ArrayList();
         Iterator var4 = this.cache.keySet().iterator();

         String key;
         while(var4.hasNext()) {
            key = (String)var4.next();
            if (key.matches(regex)) {
               matchingKeys.add(key);
            }
         }

         var4 = matchingKeys.iterator();

         while(var4.hasNext()) {
            key = (String)var4.next();
            IntelligentCache.CacheEntry removed = (IntelligentCache.CacheEntry)this.cache.remove(key);
            if (removed != null) {
               this.removeFromLruListInternal(removed);
            }
         }
      } finally {
         this.lruLock.writeLock().unlock();
      }

   }

   public void clearAll() {
      this.lruLock.writeLock().lock();

      try {
         this.cache.clear();
         this.initializeLruList();
      } finally {
         this.lruLock.writeLock().unlock();
      }

   }

   public IntelligentCache.CacheStats getStats() {
      int totalEntries = this.cache.size();
      int expiredEntries = 0;
      long totalAccessCount = 0L;

      IntelligentCache.CacheEntry entry;
      for(Iterator var5 = this.cache.values().iterator(); var5.hasNext(); totalAccessCount += (long)entry.accessCount) {
         entry = (IntelligentCache.CacheEntry)var5.next();
         if (entry.isExpired()) {
            ++expiredEntries;
         }
      }

      return new IntelligentCache.CacheStats(totalEntries, expiredEntries, totalAccessCount);
   }

   private void cleanup() {
      this.lruLock.writeLock().lock();

      try {
         List<String> expiredKeys = new ArrayList();
         Iterator var2 = this.cache.entrySet().iterator();

         while(var2.hasNext()) {
            Entry<String, IntelligentCache.CacheEntry> entry = (Entry)var2.next();
            if (((IntelligentCache.CacheEntry)entry.getValue()).isExpired()) {
               expiredKeys.add((String)entry.getKey());
            }
         }

         var2 = expiredKeys.iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            IntelligentCache.CacheEntry removed = (IntelligentCache.CacheEntry)this.cache.remove(key);
            if (removed != null) {
               this.removeFromLruListInternal(removed);
            }
         }
      } finally {
         this.lruLock.writeLock().unlock();
      }

   }

   private void evictLRU() {
      if (this.lruTail.prev != this.lruHead) {
         IntelligentCache.CacheEntry lruEntry = this.lruTail.prev;
         this.cache.remove(lruEntry.key);
         this.removeFromLruListInternal(lruEntry);
      }

   }

   private void moveToLruFront(IntelligentCache.CacheEntry entry) {
      this.lruLock.writeLock().lock();

      try {
         if (this.lruHead.next != entry) {
            this.removeFromLruListInternal(entry);
            this.addToLruFrontInternal(entry);
         }
      } finally {
         this.lruLock.writeLock().unlock();
      }

   }

   private void addToLruFrontInternal(IntelligentCache.CacheEntry entry) {
      entry.next = this.lruHead.next;
      entry.prev = this.lruHead;
      this.lruHead.next.prev = entry;
      this.lruHead.next = entry;
   }

   private void removeFromLruListInternal(IntelligentCache.CacheEntry entry) {
      if (entry.prev != null) {
         entry.prev.next = entry.next;
      }

      if (entry.next != null) {
         entry.next.prev = entry.prev;
      }

   }

   public void shutdown() {
      this.cleanupExecutor.shutdown();

      try {
         if (!this.cleanupExecutor.awaitTermination(2L, TimeUnit.SECONDS)) {
            this.cleanupExecutor.shutdownNow();
         }
      } catch (InterruptedException var2) {
         this.cleanupExecutor.shutdownNow();
         Thread.currentThread().interrupt();
      }

      this.clearAll();
   }

   private static class CacheEntry {
      final Object value;
      final String key;
      final long expiryTime;
      volatile long lastAccessed;
      volatile int accessCount;
      volatile IntelligentCache.CacheEntry prev;
      volatile IntelligentCache.CacheEntry next;

      CacheEntry(String key, Object value, long ttlMs) {
         this.key = key;
         this.value = value;
         this.expiryTime = System.currentTimeMillis() + ttlMs;
         this.lastAccessed = System.currentTimeMillis();
         this.accessCount = 1;
      }

      boolean isExpired() {
         return System.currentTimeMillis() > this.expiryTime;
      }

      void accessed() {
         this.lastAccessed = System.currentTimeMillis();
         ++this.accessCount;
      }
   }

   public static class CacheStats {
      public final int totalEntries;
      public final int expiredEntries;
      public final long totalAccessCount;

      CacheStats(int totalEntries, int expiredEntries, long totalAccessCount) {
         this.totalEntries = totalEntries;
         this.expiredEntries = expiredEntries;
         this.totalAccessCount = totalAccessCount;
      }

      public double getHitRate() {
         return this.totalEntries > 0 ? (double)(this.totalEntries - this.expiredEntries) / (double)this.totalEntries : 0.0D;
      }

      public double getAverageAccess() {
         return this.totalEntries > 0 ? (double)this.totalAccessCount / (double)this.totalEntries : 0.0D;
      }
   }
}
