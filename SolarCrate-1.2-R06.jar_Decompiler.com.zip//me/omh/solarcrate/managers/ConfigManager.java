package me.omh.solarcrate.managers;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Logger;
import me.omh.solarcrate.SolarCrate;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigManager {
   private final SolarCrate plugin;
   private volatile FileConfiguration config;
   private volatile FileConfiguration currentLanguageConfig;
   private volatile FileConfiguration crateConfig;
   private volatile String currentLanguage;
   private File configFile;
   private File crateConfigFile;
   private final Object reloadLock = new Object();

   public ConfigManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.currentLanguage = "en_us";
   }

   public void loadConfigs() throws IOException {
      this.createConfigFiles();
      this.loadConfigFiles();
   }

   private void createConfigFiles() throws IOException {
      this.configFile = new File(this.plugin.getDataFolder(), "config.yml");
      File langDir = new File(this.plugin.getDataFolder(), "lang");
      File cratesDir = new File(this.plugin.getDataFolder(), "crates");
      if (!langDir.exists() && !langDir.mkdirs()) {
         throw new IOException("Could not create lang directory: " + langDir.getAbsolutePath());
      } else if (!cratesDir.exists() && !cratesDir.mkdirs()) {
         throw new IOException("Could not create crates directory: " + cratesDir.getAbsolutePath());
      } else {
         this.migrateLegacyFiles();
         this.createFile(this.configFile, "config.yml");
         List<String> defaultLanguages = this.getAvailableLanguageResources();
         Iterator var4 = defaultLanguages.iterator();

         while(var4.hasNext()) {
            String language = (String)var4.next();
            this.createFile(new File(langDir, language + ".yml"), "lang/" + language + ".yml");
         }

         this.plugin.getLogger().info("Language files created. The system will now load ALL .yml files from the lang directory dynamically.");
         this.plugin.getLogger().info("To add new languages: Place .yml files in the 'lang' folder and restart the plugin.");
         String[] crateFiles = new String[]{"template.yml", "spawner.yml", "crimson.yml", "common.yml", "amethyst.yml"};
         String[] var11 = crateFiles;
         int var6 = crateFiles.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            String crateFileName = var11[var7];
            File crateFile = new File(cratesDir, crateFileName);
            this.createFile(crateFile, "crates/" + crateFileName);
         }

      }
   }

   private void migrateLegacyFiles() throws IOException {
      File rootDir = this.plugin.getDataFolder();
      File legacyMessageFile = new File(rootDir, "message.yml");
      File newLanguageFile = new File(rootDir, "lang/en_us.yml");
      File legacyCrateFile;
      if (legacyMessageFile.exists() && !newLanguageFile.exists()) {
         try {
            Files.copy(legacyMessageFile.toPath(), newLanguageFile.toPath());
            legacyCrateFile = new File(rootDir, "message.yml.backup");
            Files.move(legacyMessageFile.toPath(), legacyCrateFile.toPath());
         } catch (IOException var8) {
            this.plugin.getLogger().warning("Failed to migrate message.yml: " + var8.getMessage());
         }
      }

      legacyCrateFile = new File(rootDir, "crates.yml");
      File newCrateFile = new File(rootDir, "crates/common.yml");
      if (legacyCrateFile.exists() && !newCrateFile.exists()) {
         try {
            Files.copy(legacyCrateFile.toPath(), newCrateFile.toPath());
            File backupFile = new File(rootDir, "crates.yml.backup");
            Files.move(legacyCrateFile.toPath(), backupFile.toPath());
         } catch (IOException var7) {
            this.plugin.getLogger().warning("Failed to migrate crates.yml: " + var7.getMessage());
         }
      }

   }

   private void createFile(File file, String resourceName) throws IOException {
      if (!file.exists()) {
         if (!file.getParentFile().mkdirs() && !file.getParentFile().exists()) {
            throw new IOException("Could not create plugin data directory: " + file.getParentFile().getAbsolutePath());
         }

         try {
            InputStream inputStream = this.plugin.getResource(resourceName);

            try {
               if (inputStream == null) {
                  throw new IOException("Resource " + resourceName + " not found in plugin jar");
               }

               Files.copy(inputStream, file.toPath(), new CopyOption[0]);
            } catch (Throwable var7) {
               if (inputStream != null) {
                  try {
                     inputStream.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (inputStream != null) {
               inputStream.close();
            }
         } catch (IOException var8) {
            this.plugin.getLogger().severe("Critical error: Could not create " + resourceName + ": " + var8.getMessage());
            throw var8;
         }
      }

   }

   private void loadConfigFiles() {
      synchronized(this.reloadLock) {
         this.config = this.loadConfigWithRecovery(this.configFile, "main config");
         this.currentLanguage = this.config.getString("language", "en_us");
         this.currentLanguageConfig = this.loadLanguageFile(this.currentLanguage);
         if (this.currentLanguageConfig == null) {
            if (!this.currentLanguage.equals("en_us")) {
               this.plugin.getLogger().warning("Failed to load language: " + this.currentLanguage + ", using en_us as fallback");
               this.currentLanguage = "en_us";
               this.currentLanguageConfig = this.loadLanguageFile(this.currentLanguage);
            }

            if (this.currentLanguageConfig == null) {
               this.plugin.getLogger().severe("Failed to load en_us fallback language! Creating emergency default configuration");
               this.currentLanguageConfig = this.createEmergencyLanguageConfig();
            }
         }

         this.crateConfigFile = new File(this.plugin.getDataFolder(), "crates/common.yml");
         this.crateConfig = this.loadConfigWithRecovery(this.crateConfigFile, "crate config");
      }
   }

   private FileConfiguration loadConfigWithRecovery(File file, String configType) {
      if (file.exists() && this.isValidConfigFile(file)) {
         try {
            return YamlConfiguration.loadConfiguration(file);
         } catch (Exception var13) {
            this.plugin.getLogger().warning("Failed to load " + configType + " from main file: " + var13.getMessage());
         }
      } else if (file.exists()) {
         this.plugin.getLogger().warning("Main " + configType + " file is corrupted, trying backups");
      }

      String[] backupSuffixes = new String[]{".backup", ".backup.1", ".backup.2"};
      String[] var4 = backupSuffixes;
      int var5 = backupSuffixes.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String suffix = var4[var6];
         String var10002 = file.getParent();
         String var10003 = file.getName();
         File backup = new File(var10002, var10003 + suffix);
         if (backup.exists() && this.isValidConfigFile(backup)) {
            try {
               FileConfiguration recoveredConfig = YamlConfiguration.loadConfiguration(backup);
               this.plugin.getLogger().info("Recovered " + configType + " from " + backup.getName());

               try {
                  recoveredConfig.save(file);
                  this.plugin.getLogger().info("Restored " + configType + " to main file");
               } catch (IOException var11) {
                  this.plugin.getLogger().warning("Failed to restore " + configType + " to main file: " + var11.getMessage());
               }

               return recoveredConfig;
            } catch (Exception var12) {
               this.plugin.getLogger().warning("Failed to load " + configType + " from " + backup.getName() + ": " + var12.getMessage());
            }
         }
      }

      this.plugin.getLogger().warning("All recovery attempts failed for " + configType + ", creating new configuration");
      return new YamlConfiguration();
   }

   public void reloadConfigs() {
      synchronized(this.reloadLock) {
         this.loadConfigFiles();
      }
   }

   public int getCachedInt(String path, int defaultValue) {
      if (this.config == null) {
         this.plugin.getLogger().warning("Config is null, returning default value for: " + path);
         return defaultValue;
      } else {
         return this.config.getInt(path, defaultValue);
      }
   }

   public boolean getCachedBoolean(String path, boolean defaultValue) {
      if (this.config == null) {
         this.plugin.getLogger().warning("Config is null, returning default value for: " + path);
         return defaultValue;
      } else {
         return this.config.getBoolean(path, defaultValue);
      }
   }

   public String getCachedString(String path, String defaultValue) {
      if (this.config == null) {
         this.plugin.getLogger().warning("Config is null, returning default value for: " + path);
         return defaultValue;
      } else {
         return this.config.getString(path, defaultValue);
      }
   }

   public double getCachedDouble(String path, double defaultValue) {
      if (this.config == null) {
         this.plugin.getLogger().warning("Config is null, returning default value for: " + path);
         return defaultValue;
      } else {
         return this.config.getDouble(path, defaultValue);
      }
   }

   public void saveConfig(String configName) {
      try {
         String var2 = configName.toLowerCase();
         byte var3 = -1;
         switch(var2.hashCode()) {
         case -1613589672:
            if (var2.equals("language")) {
               var3 = 1;
            }
            break;
         case -1354792126:
            if (var2.equals("config")) {
               var3 = 0;
            }
            break;
         case -1352395504:
            if (var2.equals("crates")) {
               var3 = 2;
            }
         }

         switch(var3) {
         case 0:
            this.saveConfigWithBackup(this.config, this.configFile, "config");
            break;
         case 1:
            if (this.currentLanguageConfig != null) {
               File langFile = new File(this.plugin.getDataFolder(), "lang/" + this.currentLanguage + ".yml");
               this.saveConfigWithBackup(this.currentLanguageConfig, langFile, "language");
            }
            break;
         case 2:
            if (this.crateConfig != null && this.crateConfigFile != null) {
               this.saveConfigWithBackup(this.crateConfig, this.crateConfigFile, "crates");
            }
            break;
         default:
            this.plugin.getLogger().warning("Unknown config name: " + configName);
         }
      } catch (Exception var5) {
         this.plugin.getLogger().severe("Error saving " + configName + ".yml: " + var5.getMessage());
         var5.printStackTrace();
      }

   }

   private void saveConfigWithBackup(FileConfiguration config, File file, String configType) throws IOException {
      if (file.exists()) {
         try {
            this.createMultiGenerationBackups(file);
            File backup = new File(file.getParent(), file.getName() + ".backup");
            Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            if (!this.isValidConfigFile(backup)) {
               this.plugin.getLogger().warning("Backup verification failed for " + configType + " config");
            }
         } catch (IOException var5) {
            this.plugin.getLogger().warning("Failed to create backup for " + configType + " config: " + var5.getMessage());
         }
      }

      try {
         config.save(file);
      } catch (IOException var6) {
         this.plugin.getLogger().severe("Failed to save " + configType + " config: " + var6.getMessage());
         if (this.attemptConfigRestore(file, configType)) {
            this.plugin.getLogger().info("Restored " + configType + " config from backup after save failure");
         } else {
            this.plugin.getLogger().severe("All backup restore attempts failed for " + configType + " config");
         }

         throw var6;
      }
   }

   private void createMultiGenerationBackups(File file) throws IOException {
      File backup1 = new File(file.getParent(), file.getName() + ".backup");
      File backup2 = new File(file.getParent(), file.getName() + ".backup.1");
      File backup3 = new File(file.getParent(), file.getName() + ".backup.2");
      if (backup2.exists()) {
         Files.deleteIfExists(backup3.toPath());
         Files.move(backup2.toPath(), backup3.toPath());
      }

      if (backup1.exists()) {
         Files.move(backup1.toPath(), backup2.toPath());
      }

   }

   private boolean attemptConfigRestore(File file, String configType) {
      String[] backupSuffixes = new String[]{".backup", ".backup.1", ".backup.2"};
      String[] var4 = backupSuffixes;
      int var5 = backupSuffixes.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String suffix = var4[var6];
         String var10002 = file.getParent();
         String var10003 = file.getName();
         File backup = new File(var10002, var10003 + suffix);
         if (backup.exists()) {
            try {
               if (!this.isValidConfigFile(backup)) {
                  this.plugin.getLogger().warning("Backup " + backup.getName() + " is corrupted, trying next generation");
               } else {
                  Files.copy(backup.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                  if (this.isValidConfigFile(file)) {
                     this.plugin.getLogger().info("Successfully restored " + configType + " config from " + backup.getName());
                     return true;
                  }

                  this.plugin.getLogger().warning("Restored " + configType + " config is still invalid, trying next backup");
               }
            } catch (IOException var10) {
               this.plugin.getLogger().warning("Failed to restore " + configType + " config from " + backup.getName() + ": " + var10.getMessage());
            }
         }
      }

      return false;
   }

   private boolean isValidConfigFile(File file) {
      try {
         if (!file.exists()) {
            return false;
         } else {
            YamlConfiguration config = new YamlConfiguration();
            config.load(file);
            return true;
         }
      } catch (Exception var3) {
         return false;
      }
   }

   public void saveConfig() {
      this.saveConfig("config");
   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public FileConfiguration getMessageConfig() {
      return this.currentLanguageConfig;
   }

   public FileConfiguration getCrateConfig() {
      return this.crateConfig;
   }

   public String getMessage(String key) {
      if (this.currentLanguageConfig == null) {
         this.plugin.getLogger().severe("Language configuration is not loaded! Cannot get message: " + key);
         return "&cConfiguration error: " + key;
      } else {
         String message = this.currentLanguageConfig.getString("messages." + key, "&cMessage not found: " + key);
         if (message.equals("&cMessage not found: " + key)) {
            message = this.currentLanguageConfig.getString(key, "&cMessage not found: " + key);
         }

         return this.replacePlaceholders(message);
      }
   }

   public List<String> getMessageList(String key) {
      if (this.currentLanguageConfig == null) {
         this.plugin.getLogger().severe("Language configuration is not loaded! Cannot get message list: " + key);
         return Collections.singletonList("&cConfiguration error: " + key);
      } else {
         List<String> messages = this.currentLanguageConfig.getStringList("messages." + key);
         if (messages.isEmpty()) {
            messages = this.currentLanguageConfig.getStringList(key);
         }

         messages.replaceAll(this::replacePlaceholders);
         return messages;
      }
   }

   private String replacePlaceholders(String message) {
      if (message == null) {
         return null;
      } else if (this.currentLanguageConfig == null) {
         return message.replace("{prefix}", "&8[&eSolar&6Crate&8] ");
      } else {
         String prefix = this.currentLanguageConfig.getString("messages.prefix", "&8[&eSolar&6Crate&8] ");
         return message.replace("{prefix}", prefix);
      }
   }

   public long getTimerInterval() {
      return this.config.getLong("timer.interval", 3600L);
   }

   public List<String> getTimerCommands() {
      return this.config.getStringList("timer.commands");
   }

   public String getClickableCommand() {
      return this.config.getString("clickable.command", "/warp crates");
   }

   public String getClickableText() {
      return this.config.getString("clickable.text", "#00A4FB[CLICK TO TELEPORT] &for type /warp crates to open it");
   }

   public List<String> getBeforeMessages() {
      return this.config.getStringList("messages.before");
   }

   public List<String> getAfterMessages() {
      return this.config.getStringList("messages.after");
   }

   public long getKeySaveDelayTicks() {
      return this.config.getLong("performance.key-save-delay-ticks", 100L);
   }

   public long getKeySaveMinIntervalMs() {
      return this.config.getLong("performance.key-save-min-interval-ms", 1000L);
   }

   public long getPlayerCleanupIntervalTicks() {
      return this.config.getLong("performance.player-cleanup-interval-ticks", 6000L);
   }

   public String getGlassName(String permissionType) {
      if (this.config == null) {
         this.plugin.getLogger().warning("Config is not loaded! Cannot get glass name for: " + permissionType);
         return null;
      } else {
         String path = "glass_names." + permissionType.toLowerCase() + ".name";
         return this.config.getString(path);
      }
   }

   public List<String> getGlassLore(String permissionType) {
      if (this.config == null) {
         this.plugin.getLogger().warning("Config is not loaded! Cannot get glass lore for: " + permissionType);
         return Collections.emptyList();
      } else {
         String path = "glass_names." + permissionType.toLowerCase() + ".lore";
         return this.config.getStringList(path);
      }
   }

   public boolean hasGlassConfig(String permissionType) {
      if (this.config == null) {
         return false;
      } else {
         String path = "glass_names." + permissionType.toLowerCase();
         return this.config.contains(path);
      }
   }

   public boolean isGlassNamesEnabled() {
      return this.config == null ? false : this.config.contains("glass_names");
   }

   public String formatMessage(String key, Map<String, String> placeholders) {
      String message = this.getMessage(key);
      Entry entry;
      if (placeholders != null) {
         for(Iterator var4 = placeholders.entrySet().iterator(); var4.hasNext(); message = message.replace("{" + (String)entry.getKey() + "}", (CharSequence)entry.getValue())) {
            entry = (Entry)var4.next();
         }
      }

      return message;
   }

   public FileConfiguration loadLanguageFile(String language) {
      File langDir = new File(this.plugin.getDataFolder(), "lang");
      File langFile = new File(langDir, language + ".yml");
      if (!langFile.exists()) {
         this.plugin.getLogger().warning("Language file not found: " + language + ".yml");
         return null;
      } else {
         return YamlConfiguration.loadConfiguration(langFile);
      }
   }

   private FileConfiguration createEmergencyLanguageConfig() {
      YamlConfiguration emergencyConfig = new YamlConfiguration();
      emergencyConfig.set("messages.prefix", "&8[&eSolar&6Crate&8] ");
      emergencyConfig.set("messages.no-permission", "&cYou don't have permission to do this!");
      emergencyConfig.set("messages.reload-success", "&aConfiguration reloaded successfully!");
      emergencyConfig.set("messages.player-not-found", "&cPlayer not found!");
      emergencyConfig.set("messages.console-no-info", "&cConsole cannot view player info!");
      emergencyConfig.set("messages.time-remaining", "&eTime remaining: &b{time}");
      emergencyConfig.set("messages.version-info", "&eSolarCrate &7v{version} &7by {author}");
      emergencyConfig.set("messages.edit-usage", "&cUsage: /sc edit <crateName>");
      emergencyConfig.set("messages.sound-error", "&cSound error: {sound} for {context}");
      emergencyConfig.set("messages.crate-not-found", "&cCrate not found!");
      emergencyConfig.set("messages.invalid-key-amount", "&cInvalid key amount!");
      emergencyConfig.set("messages.amount-must-be-number", "&cAmount must be a number!");
      emergencyConfig.set("messages.keys-given", "&aGiven {amount} {crate} keys to {player}!");
      emergencyConfig.set("messages.keys-received", "&aYou received {amount} {crate} keys!");
      emergencyConfig.set("messages.not-enough-keys", "&cYou don't have enough keys!");
      emergencyConfig.set("messages.opening-crate", "&aOpening crate...");
      emergencyConfig.set("messages.config-error", "&cConfiguration error - please contact an administrator");
      this.plugin.getLogger().info("Emergency language configuration created with default messages");
      return emergencyConfig;
   }

   public List<String> getAvailableLanguages() {
      File langDir = new File(this.plugin.getDataFolder(), "lang");
      if (langDir.exists() && langDir.isDirectory()) {
         File[] langFiles = langDir.listFiles((dir, namex) -> {
            return namex.endsWith(".yml");
         });
         if (langFiles == null) {
            return Collections.emptyList();
         } else {
            List<String> languageNames = new ArrayList();
            File[] var4 = langFiles;
            int var5 = langFiles.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               File file = var4[var6];
               String name = file.getName();
               languageNames.add(name.substring(0, name.lastIndexOf(46)));
            }

            return languageNames;
         }
      } else {
         return Collections.emptyList();
      }
   }

   public List<String> getAvailableLanguageResources() {
      ArrayList availableLanguages = new ArrayList();

      int var6;
      String language;
      try {
         URL langDirUrl = this.plugin.getClass().getClassLoader().getResource("lang/");
         if (langDirUrl != null) {
            this.plugin.getLogger().info("Attempting to enumerate language resources from: " + String.valueOf(langDirUrl));
            if (langDirUrl.getProtocol().equals("jar")) {
               JarURLConnection connection = (JarURLConnection)langDirUrl.openConnection();
               JarFile jarFile = connection.getJarFile();
               Enumeration entries = jarFile.entries();

               while(entries.hasMoreElements()) {
                  JarEntry entry = (JarEntry)entries.nextElement();
                  language = entry.getName();
                  if (language.startsWith("lang/") && language.endsWith(".yml") && !entry.isDirectory()) {
                     String langName = language.substring("lang/".length(), language.length() - ".yml".length());
                     availableLanguages.add(langName);
                  }
               }
            } else {
               File langDir = new File(langDirUrl.toURI());
               if (langDir.exists() && langDir.isDirectory()) {
                  File[] files = langDir.listFiles((dir, name) -> {
                     return name.endsWith(".yml");
                  });
                  if (files != null) {
                     File[] var20 = files;
                     var6 = files.length;

                     for(int var22 = 0; var22 < var6; ++var22) {
                        File file = var20[var22];
                        String langName = file.getName().substring(0, file.getName().length() - ".yml".length());
                        availableLanguages.add(langName);
                     }
                  }
               }
            }
         }
      } catch (Exception var14) {
         this.plugin.getLogger().warning("Failed to enumerate language resources automatically: " + var14.getMessage());
         this.plugin.getLogger().info("Falling back to known language files");
         String[] knownLanguages = new String[]{"en_us", "vi_vn"};
         String[] var4 = knownLanguages;
         int var5 = knownLanguages.length;

         for(var6 = 0; var6 < var5; ++var6) {
            language = var4[var6];

            try {
               InputStream inputStream = this.plugin.getResource("lang/" + language + ".yml");

               try {
                  if (inputStream != null) {
                     availableLanguages.add(language);
                  }
               } catch (Throwable var12) {
                  if (inputStream != null) {
                     try {
                        inputStream.close();
                     } catch (Throwable var11) {
                        var12.addSuppressed(var11);
                     }
                  }

                  throw var12;
               }

               if (inputStream != null) {
                  inputStream.close();
               }
            } catch (IOException var13) {
               this.plugin.getLogger().warning("Failed to load language resource '" + language + "': " + var13.getMessage());
            }
         }
      }

      Logger var10000 = this.plugin.getLogger();
      int var10001 = availableLanguages.size();
      var10000.info("Found " + var10001 + " language resources to create: " + String.valueOf(availableLanguages));
      return availableLanguages;
   }

   public List<String> getAvailableCrates() {
      File cratesDir = new File(this.plugin.getDataFolder(), "crates");
      if (cratesDir.exists() && cratesDir.isDirectory()) {
         File[] crateFiles = cratesDir.listFiles((dir, namex) -> {
            return namex.endsWith(".yml");
         });
         if (crateFiles == null) {
            return Collections.emptyList();
         } else {
            List<String> crateNames = new ArrayList();
            File[] var4 = crateFiles;
            int var5 = crateFiles.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               File file = var4[var6];
               String name = file.getName();
               crateNames.add(name.substring(0, name.lastIndexOf(46)));
            }

            return crateNames;
         }
      } else {
         return Collections.emptyList();
      }
   }

   public FileConfiguration loadCrateConfig(String crateName) {
      File cratesDir = new File(this.plugin.getDataFolder(), "crates");
      File crateFile = new File(cratesDir, crateName + ".yml");
      if (!crateFile.exists()) {
         this.plugin.getLogger().warning("Crate configuration file not found: " + crateName + ".yml");
         return null;
      } else {
         return YamlConfiguration.loadConfiguration(crateFile);
      }
   }

   public boolean createCrateConfig(String crateName) {
      File cratesDir = new File(this.plugin.getDataFolder(), "crates");
      File crateFile = new File(cratesDir, crateName + ".yml");
      if (crateFile.exists()) {
         return false;
      } else {
         try {
            this.createFile(crateFile, "crates/template.yml");
            this.plugin.getLogger().info("Created new crate configuration: " + crateName + ".yml");
            return true;
         } catch (IOException var5) {
            this.plugin.getLogger().severe("Failed to create crate configuration: " + crateName + ".yml - " + var5.getMessage());
            return false;
         }
      }
   }

   public String getCurrentLanguage() {
      return this.currentLanguage;
   }

   public void setLanguage(String language) {
      this.currentLanguage = language;
      this.currentLanguageConfig = this.loadLanguageFile(language);
      if (this.currentLanguageConfig == null) {
         this.plugin.getLogger().warning("Failed to load language: " + language + ", keeping current language");
      } else {
         this.config.set("language", language);
         this.saveConfig();
      }
   }
}
