package me.omh.solarcrate.managers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public class CrateManager {
   private final SolarCrate plugin;
   private final Map<String, Crate> crates = new ConcurrentHashMap();
   private final Map<String, CrateManager.PendingCrateData> pendingCrates = new ConcurrentHashMap();
   private final Map<String, String> locationIndex = new ConcurrentHashMap();
   private final Object loadSaveLock = new Object();

   public CrateManager(SolarCrate plugin) {
      this.plugin = plugin;
   }

   public void loadCrates() {
      synchronized(this.loadSaveLock) {
         try {
            Map<String, Crate> tempCrates = new ConcurrentHashMap();
            this.migrateFromCommonFile();
            List<String> availableCrates = this.plugin.getConfigManager().getAvailableCrates();
            Iterator var4 = availableCrates.iterator();

            while(var4.hasNext()) {
               String crateName = (String)var4.next();

               try {
                  this.loadIndividualCrate(crateName, tempCrates);
               } catch (RuntimeException var8) {
                  this.plugin.getLogger().severe("Runtime error loading crate '" + crateName + "': " + var8.getClass().getSimpleName() + " - " + var8.getMessage());
                  var8.printStackTrace();
               }
            }

            this.crates.clear();
            this.crates.putAll(tempCrates);
            this.locationIndex.clear();
            var4 = this.crates.values().iterator();

            while(var4.hasNext()) {
               Crate crate = (Crate)var4.next();
               this.addToLocationIndex(crate);
            }

            this.plugin.getLogger().info("Loaded " + this.crates.size() + " crates from individual files");
            if (!this.pendingCrates.isEmpty()) {
               this.plugin.getLogger().warning("Found " + this.pendingCrates.size() + " crate(s) waiting for worlds to load. Will retry when worlds become available.");
            }
         } catch (SecurityException var9) {
            this.plugin.getLogger().severe("Security error loading crates - file access denied: " + var9.getMessage());
            var9.printStackTrace();
         } catch (IllegalStateException var10) {
            this.plugin.getLogger().severe("Invalid state during crate loading: " + var10.getMessage());
            var10.printStackTrace();
         } catch (OutOfMemoryError var11) {
            this.plugin.getLogger().severe("FATAL: Out of memory during crate loading - disabling plugin: " + var11.getMessage());
            var11.printStackTrace();
            this.plugin.getServer().getPluginManager().disablePlugin(this.plugin);
            throw var11;
         } catch (Exception var12) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = var12.getClass().getSimpleName();
            var10000.severe("Unexpected error loading crates: " + var10001 + " - " + var12.getMessage());
            var12.printStackTrace();
         }

      }
   }

   private void loadIndividualCrate(String crateName, Map<String, Crate> targetMap) {
      try {
         String sanitizedName = SolarUtils.sanitizeCrateName(crateName);
         if (sanitizedName == null) {
            this.plugin.getLogger().warning("Skipping crate with invalid name: " + crateName);
            return;
         }

         FileConfiguration crateConfig = this.plugin.getConfigManager().loadCrateConfig(sanitizedName);
         if (crateConfig == null) {
            this.plugin.getLogger().warning("Could not load configuration for crate: " + sanitizedName);
            return;
         }

         String worldName = crateConfig.getString("world");
         if (worldName == null || worldName.isEmpty()) {
            this.plugin.getLogger().warning("Crate '" + crateName + "' has no world specified, skipping");
            return;
         }

         double x = crateConfig.getDouble("x", 0.0D);
         double y = crateConfig.getDouble("y", 0.0D);
         double z = crateConfig.getDouble("z", 0.0D);
         ConfigurationSection itemsSection = crateConfig.getConfigurationSection("items");
         Map<Integer, ItemStack> items = new HashMap();
         int totalSlots = 0;
         int failedItems = 0;
         int loadedItems = 0;
         if (itemsSection != null) {
            totalSlots = itemsSection.getKeys(false).size();
            Iterator var17 = itemsSection.getKeys(false).iterator();

            while(var17.hasNext()) {
               String slotStr = (String)var17.next();

               try {
                  int slot = Integer.parseInt(slotStr);
                  if (slot >= 0 && slot < 54) {
                     ItemStack item = itemsSection.getItemStack(slotStr);
                     if (item != null) {
                        items.put(slot, item);
                        ++loadedItems;
                     } else {
                        ++failedItems;
                     }
                  } else {
                     this.plugin.getLogger().warning("Invalid slot number in crate '" + crateName + "': " + slot + " (must be 0-53)");
                     ++failedItems;
                  }
               } catch (NumberFormatException var22) {
                  this.plugin.getLogger().warning("Invalid slot number in crate '" + crateName + "': " + slotStr);
                  ++failedItems;
               } catch (ClassCastException var23) {
                  this.plugin.getLogger().warning("Invalid item data type in slot " + slotStr + " in crate '" + crateName + "': " + var23.getMessage());
                  ++failedItems;
               } catch (IllegalArgumentException var24) {
                  this.plugin.getLogger().warning("Invalid item configuration in slot " + slotStr + " in crate '" + crateName + "': " + var24.getMessage());
                  ++failedItems;
               }
            }
         }

         if (failedItems > 0) {
            if (loadedItems == 0 && totalSlots > 0) {
               this.plugin.getLogger().severe("CRITICAL: Crate '" + crateName + "' failed to load ALL items (" + failedItems + " failed). Crate will be empty!");
            } else {
               this.plugin.getLogger().warning("Crate '" + crateName + "' loaded with " + failedItems + " failed items out of " + totalSlots + " total (" + loadedItems + " loaded successfully)");
            }
         }

         World world = Bukkit.getWorld(worldName);
         if (world == null) {
            this.plugin.getLogger().warning("World '" + worldName + "' not loaded yet for crate '" + crateName + "'. Will retry when world loads.");
            this.pendingCrates.put(crateName.toLowerCase(), new CrateManager.PendingCrateData(crateName, worldName, x, y, z, items));
            return;
         }

         Location location = new Location(world, x, y, z);
         Crate crate = new Crate(crateName, location);
         Iterator var30 = items.entrySet().iterator();

         while(var30.hasNext()) {
            Entry<Integer, ItemStack> entry = (Entry)var30.next();
            crate.setItem((Integer)entry.getKey(), (ItemStack)entry.getValue());
         }

         crate.setCountdownTitle(crateConfig.getString("countdown-title", "&e&l⏰ {count} ⏰"));
         crate.setCountdownSubtitle(crateConfig.getString("countdown-subtitle", "&7Chuẩn bị nhận phần thưởng..."));
         crate.setSuccessTitle(crateConfig.getString("success-title", "&a&l✨ CHÚC MỪNG! ✨"));
         crate.setSuccessSubtitle(crateConfig.getString("success-subtitle", "&7Bạn đã nhận được: &e&l{item}"));
         if (crateConfig.contains("particles")) {
            crate.setParticlesEnabled(crateConfig.getBoolean("particles.enabled", true));
            crate.setAmbientParticle(crateConfig.getString("particles.ambient_particle", "DUST"));
            crate.setAmbientColorRed(crateConfig.getInt("particles.ambient_color_red", 0));
            crate.setAmbientColorGreen(crateConfig.getInt("particles.ambient_color_green", 252));
            crate.setAmbientColorBlue(crateConfig.getInt("particles.ambient_color_blue", 255));
            crate.setOpeningParticle(crateConfig.getString("particles.opening_particle", "FIREWORK"));
            crate.setCelebrationParticle(crateConfig.getString("particles.celebration_particle", "HAPPY_VILLAGER"));
            crate.setParticleDensity(crateConfig.getInt("particles.particle_density", 10));
         }

         targetMap.put(crateName.toLowerCase(), crate);
      } catch (ClassCastException var25) {
         this.plugin.getLogger().severe("Invalid data type in crate '" + crateName + "' configuration: " + var25.getMessage());
         var25.printStackTrace();
      } catch (IllegalArgumentException var26) {
         this.plugin.getLogger().severe("Invalid crate configuration for '" + crateName + "': " + var26.getMessage());
         var26.printStackTrace();
      }

   }

   private void migrateFromCommonFile() {
      try {
         File cratesDir = new File(this.plugin.getDataFolder(), "crates");
         File migrationFlag = new File(cratesDir, ".migration_completed");
         if (migrationFlag.exists()) {
            return;
         }

         FileConfiguration commonConfig = this.plugin.getConfigManager().getCrateConfig();
         ConfigurationSection section = commonConfig.getConfigurationSection("crates");
         if (section != null && !section.getKeys(false).isEmpty()) {
            this.plugin.getLogger().info("Found crates in common.yml, migrating to individual files...");
            if (!cratesDir.exists() && !cratesDir.mkdirs()) {
               this.plugin.getLogger().severe("Failed to create crates directory for migration");
               return;
            }

            try {
               File commonBackup = new File(cratesDir, "common_backup_" + System.currentTimeMillis() + ".yml");
               Files.copy((new File(this.plugin.getDataFolder(), "crates/common.yml")).toPath(), commonBackup.toPath());
               this.plugin.getLogger().info("Created backup: " + commonBackup.getName());
            } catch (IOException var18) {
               this.plugin.getLogger().warning("Failed to create backup before migration: " + var18.getMessage());
            }

            List<String> successfulMigrations = new ArrayList();
            Iterator var6 = section.getKeys(false).iterator();

            while(var6.hasNext()) {
               String name = (String)var6.next();

               try {
                  String sanitizedName = SolarUtils.sanitizeCrateName(name);
                  if (sanitizedName == null) {
                     this.plugin.getLogger().warning("Skipping migration of crate with invalid name: " + name);
                  } else {
                     ConfigurationSection crateSection = section.getConfigurationSection(name);
                     if (crateSection == null) {
                        this.plugin.getLogger().warning("Crate section '" + name + "' is null, skipping migration");
                     } else {
                        File crateFile = new File(cratesDir, sanitizedName + ".yml");
                        if (!crateFile.exists()) {
                           FileConfiguration newCrateConfig = new YamlConfiguration();
                           String worldName = crateSection.getString("world");
                           if (worldName != null) {
                              newCrateConfig.set("world", worldName);
                              newCrateConfig.set("x", crateSection.getDouble("x", 0.0D));
                              newCrateConfig.set("y", crateSection.getDouble("y", 0.0D));
                              newCrateConfig.set("z", crateSection.getDouble("z", 0.0D));
                              ConfigurationSection itemsSection = crateSection.getConfigurationSection("items");
                              if (itemsSection != null) {
                                 Iterator var14 = itemsSection.getKeys(false).iterator();

                                 while(var14.hasNext()) {
                                    String slotStr = (String)var14.next();
                                    ItemStack item = itemsSection.getItemStack(slotStr);
                                    if (item != null) {
                                       newCrateConfig.set("items." + slotStr, item);
                                    }
                                 }
                              }

                              newCrateConfig.save(crateFile);
                              successfulMigrations.add(name);
                              this.plugin.getLogger().info("Migrated crate '" + name + "' to individual file");
                           }
                        } else {
                           successfulMigrations.add(name);
                        }
                     }
                  }
               } catch (Exception var19) {
                  this.plugin.getLogger().severe("Error migrating crate '" + name + "': " + var19.getMessage());
               }
            }

            if (successfulMigrations.size() == section.getKeys(false).size()) {
               commonConfig.set("crates", (Object)null);
               this.plugin.getConfigManager().saveConfig("crates");

               try {
                  migrationFlag.createNewFile();
                  this.plugin.getLogger().info("Migration completed successfully. Cleared common.yml file.");
               } catch (IOException var17) {
                  this.plugin.getLogger().warning("Failed to create migration flag: " + var17.getMessage());
               }
            } else {
               Logger var10000 = this.plugin.getLogger();
               int var10001 = successfulMigrations.size();
               var10000.warning("Migration incomplete: " + var10001 + " of " + section.getKeys(false).size() + " crates migrated. Keeping common.yml intact.");
            }
         }
      } catch (Exception var20) {
         this.plugin.getLogger().severe("Critical error during migration from common file: " + var20.getMessage());
         var20.printStackTrace();
      }

   }

   public void saveCrates() {
      synchronized(this.loadSaveLock) {
         Logger var10000;
         String var10001;
         try {
            int savedCount = 0;
            Iterator var3 = this.crates.values().iterator();

            while(var3.hasNext()) {
               Crate crate = (Crate)var3.next();

               try {
                  this.saveIndividualCrate(crate);
                  ++savedCount;
               } catch (Exception var7) {
                  var10000 = this.plugin.getLogger();
                  var10001 = crate.getName();
                  var10000.severe("Error saving crate '" + var10001 + "': " + var7.getMessage());
                  var7.printStackTrace();
               }
            }

            this.plugin.getLogger().info("Saved " + savedCount + " crates to individual files");
         } catch (SecurityException var8) {
            this.plugin.getLogger().severe("Security error saving crates - file access denied: " + var8.getMessage());
            var8.printStackTrace();
         } catch (IllegalStateException var9) {
            this.plugin.getLogger().severe("Invalid state during crate saving: " + var9.getMessage());
            var9.printStackTrace();
         } catch (OutOfMemoryError var10) {
            this.plugin.getLogger().severe("FATAL: Out of memory during crate saving - disabling plugin: " + var10.getMessage());
            var10.printStackTrace();
            this.plugin.getServer().getPluginManager().disablePlugin(this.plugin);
            throw var10;
         } catch (Exception var11) {
            var10000 = this.plugin.getLogger();
            var10001 = var11.getClass().getSimpleName();
            var10000.severe("Unexpected error saving crates: " + var10001 + " - " + var11.getMessage());
            var11.printStackTrace();
         }

      }
   }

   private synchronized void saveIndividualCrate(Crate crate) throws IOException {
      if (crate == null) {
         this.plugin.getLogger().warning("Attempted to save null crate");
      } else {
         String sanitizedName = SolarUtils.sanitizeCrateName(crate.getName());
         if (sanitizedName == null) {
            throw new IOException("Invalid crate name: " + crate.getName());
         } else {
            Location location = crate.getLocation();
            if (location == null) {
               this.plugin.getLogger().warning("Crate '" + crate.getName() + "' has null location, skipping save");
            } else if (location.getWorld() == null) {
               this.plugin.getLogger().warning("Crate '" + crate.getName() + "' has null world, skipping save");
            } else {
               Logger var10000;
               String var10001;
               try {
                  File cratesDir = new File(this.plugin.getDataFolder(), "crates");
                  if (!cratesDir.exists()) {
                     cratesDir.mkdirs();
                  }

                  File crateFile = new File(cratesDir, sanitizedName + ".yml");
                  FileConfiguration crateConfig = new YamlConfiguration();
                  crateConfig.set("world", location.getWorld().getName());
                  crateConfig.set("x", location.getX());
                  crateConfig.set("y", location.getY());
                  crateConfig.set("z", location.getZ());
                  crateConfig.set("countdown-title", crate.getCountdownTitle());
                  crateConfig.set("countdown-subtitle", crate.getCountdownSubtitle());
                  crateConfig.set("success-title", crate.getSuccessTitle());
                  crateConfig.set("success-subtitle", crate.getSuccessSubtitle());
                  crateConfig.set("particles.enabled", crate.isParticlesEnabled());
                  crateConfig.set("particles.ambient_particle", crate.getAmbientParticle());
                  crateConfig.set("particles.ambient_color_red", crate.getAmbientColorRed());
                  crateConfig.set("particles.ambient_color_green", crate.getAmbientColorGreen());
                  crateConfig.set("particles.ambient_color_blue", crate.getAmbientColorBlue());
                  crateConfig.set("particles.opening_particle", crate.getOpeningParticle());
                  crateConfig.set("particles.celebration_particle", crate.getCelebrationParticle());
                  crateConfig.set("particles.particle_density", crate.getParticleDensity());
                  crateConfig.set("items", (Object)null);
                  Iterator var7 = crate.getItems().entrySet().iterator();

                  while(var7.hasNext()) {
                     Entry entry = (Entry)var7.next();

                     try {
                        crateConfig.set("items." + String.valueOf(entry.getKey()), entry.getValue());
                     } catch (Exception var10) {
                        var10000 = this.plugin.getLogger();
                        var10001 = String.valueOf(entry.getKey());
                        var10000.warning("Error saving item in slot " + var10001 + " for crate '" + crate.getName() + "': " + var10.getMessage());
                     }
                  }

                  crateConfig.save(crateFile);
               } catch (IOException var11) {
                  var10000 = this.plugin.getLogger();
                  var10001 = crate.getName();
                  var10000.severe("I/O error saving crate '" + var10001 + "': " + var11.getMessage());
                  throw var11;
               } catch (Exception var12) {
                  var10000 = this.plugin.getLogger();
                  var10001 = crate.getName();
                  var10000.severe("Unexpected error saving crate '" + var10001 + "': " + var12.getMessage());
                  throw new IOException("Failed to save crate: " + var12.getMessage(), var12);
               }
            }
         }
      }
   }

   public void createCrate(String name, Location location) {
      synchronized(this.loadSaveLock) {
         if (location == null) {
            this.plugin.getLogger().severe("Cannot create crate '" + name + "' with null location");
         } else if (location.getWorld() == null) {
            this.plugin.getLogger().severe("Cannot create crate '" + name + "' with null world");
         } else {
            Crate crate = new Crate(name, location);
            this.crates.put(name.toLowerCase(), crate);
            this.addToLocationIndex(crate);

            try {
               this.saveIndividualCrate(crate);
            } catch (IOException var7) {
               this.plugin.getLogger().severe("Error saving new crate '" + name + "': " + var7.getMessage());
               var7.printStackTrace();
            }

         }
      }
   }

   public boolean deleteCrate(String name) {
      synchronized(this.loadSaveLock) {
         Crate removed = (Crate)this.crates.remove(name.toLowerCase());
         if (removed != null) {
            this.removeCrate(name);
            return true;
         } else {
            return false;
         }
      }
   }

   public boolean crateExists(String name) {
      return this.crates.containsKey(name.toLowerCase());
   }

   public Crate getCrate(String name) {
      return (Crate)this.crates.get(name.toLowerCase());
   }

   public Set<String> getCrateNames() {
      return this.crates.keySet();
   }

   public Collection<Crate> getAllCrates() {
      return this.crates.values();
   }

   private String getLocationKey(Location loc) {
      if (loc != null && loc.getWorld() != null) {
         String var10000 = loc.getWorld().getName();
         return var10000 + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
      } else {
         return null;
      }
   }

   private void addToLocationIndex(Crate crate) {
      if (crate != null && crate.getLocation() != null) {
         Location loc = crate.getLocation();
         String crateName = crate.getName().toLowerCase();
         String mainKey = this.getLocationKey(loc);
         if (mainKey != null) {
            this.locationIndex.put(mainKey, crateName);
         }

         int[][] adjacentOffsets = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
         int[][] var6 = adjacentOffsets;
         int var7 = adjacentOffsets.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            int[] offset = var6[var8];
            Location adjacent = loc.clone().add((double)offset[0], 0.0D, (double)offset[1]);
            String adjacentKey = this.getLocationKey(adjacent);
            if (adjacentKey != null) {
               this.locationIndex.put(adjacentKey, crateName);
            }
         }

      }
   }

   private void removeFromLocationIndex(Crate crate) {
      if (crate != null && crate.getLocation() != null) {
         Location loc = crate.getLocation();
         String crateName = crate.getName().toLowerCase();
         String mainKey = this.getLocationKey(loc);
         if (mainKey != null) {
            this.locationIndex.remove(mainKey, crateName);
         }

         int[][] adjacentOffsets = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
         int[][] var6 = adjacentOffsets;
         int var7 = adjacentOffsets.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            int[] offset = var6[var8];
            Location adjacent = loc.clone().add((double)offset[0], 0.0D, (double)offset[1]);
            String adjacentKey = this.getLocationKey(adjacent);
            if (adjacentKey != null) {
               this.locationIndex.remove(adjacentKey, crateName);
            }
         }

      }
   }

   public Crate getCrateAtLocation(Location location) {
      if (location != null && location.getWorld() != null) {
         String locationKey = this.getLocationKey(location);
         if (locationKey == null) {
            return null;
         } else {
            String crateName = (String)this.locationIndex.get(locationKey);
            return crateName == null ? null : (Crate)this.crates.get(crateName);
         }
      } else {
         return null;
      }
   }

   public void saveCrate(Crate crate) {
      if (crate == null) {
         this.plugin.getLogger().warning("Attempted to save null crate");
      } else {
         synchronized(this.loadSaveLock) {
            try {
               String name = crate.getName();
               if (!this.crates.containsKey(name.toLowerCase())) {
                  this.plugin.getLogger().warning("Attempted to save crate '" + name + "' that doesn't exist in memory");
                  return;
               }

               this.crates.put(name.toLowerCase(), crate);
               this.saveIndividualCrate(crate);
            } catch (Exception var5) {
               Logger var10000 = this.plugin.getLogger();
               String var10001 = crate.getName();
               var10000.severe("Error saving crate '" + var10001 + "': " + var5.getMessage());
               var5.printStackTrace();
            }

         }
      }
   }

   public Map<String, Crate> getCrates() {
      return new HashMap(this.crates);
   }

   public void addCrate(Crate crate) {
      this.crates.put(crate.getName().toLowerCase(), crate);
      this.addToLocationIndex(crate);
   }

   public void updateCrateLocation(String crateName, Location newLocation) throws IOException {
      if (crateName != null && newLocation != null) {
         if (newLocation.getWorld() == null) {
            throw new IllegalArgumentException("Cannot update crate to location with null world");
         } else {
            synchronized(this.loadSaveLock) {
               Crate crate = (Crate)this.crates.get(crateName.toLowerCase());
               if (crate == null) {
                  throw new IllegalArgumentException("Cannot update location for non-existent crate: " + crateName);
               } else {
                  String currentLocationKey = this.getLocationKey(crate.getLocation());
                  if (currentLocationKey != null && !crateName.equalsIgnoreCase((String)this.locationIndex.get(currentLocationKey))) {
                     this.plugin.getLogger().warning("Location index inconsistency detected for crate '" + crateName + "', attempting to fix");
                  }

                  this.removeFromLocationIndex(crate);
                  crate.setLocation(newLocation);
                  this.addToLocationIndex(crate);
                  this.crates.put(crateName.toLowerCase(), crate);
                  this.saveIndividualCrate(crate);
               }
            }
         }
      } else {
         throw new IllegalArgumentException("Cannot update crate location: null parameters");
      }
   }

   public void removeCrate(String name) {
      Crate removed = (Crate)this.crates.remove(name.toLowerCase());
      if (removed != null) {
         this.removeFromLocationIndex(removed);
      }

      try {
         String sanitizedName = SolarUtils.sanitizeCrateName(name);
         if (sanitizedName == null) {
            this.plugin.getLogger().warning("Cannot delete crate file with invalid name: " + name);
            return;
         }

         File cratesDir = new File(this.plugin.getDataFolder(), "crates");
         File crateFile = new File(cratesDir, sanitizedName + ".yml");
         if (crateFile.exists()) {
            if (!crateFile.delete()) {
               this.plugin.getLogger().warning("Failed to delete crate file: " + sanitizedName + ".yml");
            }
         } else {
            this.plugin.getLogger().warning("Crate file not found: " + sanitizedName + ".yml");
         }
      } catch (Exception var6) {
         this.plugin.getLogger().severe("Error deleting crate file: " + var6.getMessage());
         var6.printStackTrace();
      }

   }

   public List<ItemStack> getCrateItems(String crateName) {
      Crate crate = this.getCrate(crateName);
      if (crate != null) {
         Map<Integer, ItemStack> itemMap = crate.getItems();
         return new ArrayList(itemMap.values());
      } else {
         return new ArrayList();
      }
   }

   public void setCrateItems(String crateName, List<ItemStack> items) {
      Crate crate = this.getCrate(crateName);
      if (crate != null) {
         crate.getItems().clear();

         for(int i = 0; i < items.size(); ++i) {
            if (items.get(i) != null) {
               crate.setItem(i, (ItemStack)items.get(i));
            }
         }

         this.saveCrate(crate);
      }

   }

   public void setCrateItemsWithSlots(String crateName, Map<Integer, ItemStack> itemsWithSlots) {
      Crate crate = this.getCrate(crateName);
      if (crate != null) {
         crate.getItems().clear();
         Iterator var4 = itemsWithSlots.entrySet().iterator();

         while(var4.hasNext()) {
            Entry<Integer, ItemStack> entry = (Entry)var4.next();
            if (entry.getValue() != null) {
               crate.setItem((Integer)entry.getKey(), (ItemStack)entry.getValue());
            }
         }

         this.saveCrate(crate);
      }

   }

   public void retryPendingCratesForWorld(String worldName) {
      if (worldName != null && !worldName.isEmpty()) {
         synchronized(this.loadSaveLock) {
            List<String> retried = new ArrayList();
            Iterator var4 = this.pendingCrates.entrySet().iterator();

            while(true) {
               CrateManager.PendingCrateData data;
               World world;
               Logger var10000;
               do {
                  do {
                     if (!var4.hasNext()) {
                        var4 = retried.iterator();

                        while(var4.hasNext()) {
                           String crateName = (String)var4.next();
                           this.pendingCrates.remove(crateName.toLowerCase());
                        }

                        if (!retried.isEmpty()) {
                           var10000 = this.plugin.getLogger();
                           int var16 = retried.size();
                           var10000.info("Loaded " + var16 + " pending crate(s) for world '" + worldName + "'");
                        }

                        return;
                     }

                     Entry<String, CrateManager.PendingCrateData> entry = (Entry)var4.next();
                     data = (CrateManager.PendingCrateData)entry.getValue();
                  } while(!data.worldName.equalsIgnoreCase(worldName));

                  world = Bukkit.getWorld(worldName);
               } while(world == null);

               try {
                  Location location = new Location(world, data.x, data.y, data.z);
                  Crate crate = new Crate(data.crateName, location);
                  Iterator var10 = data.items.entrySet().iterator();

                  while(var10.hasNext()) {
                     Entry<Integer, ItemStack> itemEntry = (Entry)var10.next();
                     crate.setItem((Integer)itemEntry.getKey(), (ItemStack)itemEntry.getValue());
                  }

                  this.crates.put(data.crateName.toLowerCase(), crate);
                  this.addToLocationIndex(crate);
                  retried.add(data.crateName);
                  this.plugin.getLogger().info("Successfully loaded pending crate '" + data.crateName + "' for world '" + worldName + "'");
               } catch (Exception var13) {
                  var10000 = this.plugin.getLogger();
                  String var10001 = data.crateName;
                  var10000.severe("Failed to load pending crate '" + var10001 + "': " + var13.getMessage());
                  var13.printStackTrace();
               }
            }
         }
      }
   }

   public void retryAllPendingCrates() {
      synchronized(this.loadSaveLock) {
         if (!this.pendingCrates.isEmpty()) {
            this.plugin.getLogger().info("Retrying to load " + this.pendingCrates.size() + " pending crate(s)...");
            Set<String> worldsToRetry = new HashSet();
            Iterator var3 = this.pendingCrates.values().iterator();

            while(var3.hasNext()) {
               CrateManager.PendingCrateData data = (CrateManager.PendingCrateData)var3.next();
               worldsToRetry.add(data.worldName);
            }

            var3 = worldsToRetry.iterator();

            label87:
            while(true) {
               Logger var10000;
               String worldName;
               int var19;
               do {
                  do {
                     if (!var3.hasNext()) {
                        if (!this.pendingCrates.isEmpty()) {
                           var10000 = this.plugin.getLogger();
                           var19 = this.pendingCrates.size();
                           var10000.warning("Still have " + var19 + " pending crate(s) waiting for worlds to load: " + String.join(", ", (CharSequence[])this.pendingCrates.values().stream().map((d) -> {
                              return d.crateName + " (" + d.worldName + ")";
                           }).toArray((x$0) -> {
                              return new String[x$0];
                           })));
                        }

                        return;
                     }

                     worldName = (String)var3.next();
                  } while(worldName == null);
               } while(worldName.isEmpty());

               List<String> retried = new ArrayList();
               Iterator var6 = this.pendingCrates.entrySet().iterator();

               while(true) {
                  CrateManager.PendingCrateData data;
                  World world;
                  do {
                     do {
                        if (!var6.hasNext()) {
                           var6 = retried.iterator();

                           while(var6.hasNext()) {
                              String crateName = (String)var6.next();
                              this.pendingCrates.remove(crateName.toLowerCase());
                           }

                           if (!retried.isEmpty()) {
                              var10000 = this.plugin.getLogger();
                              var19 = retried.size();
                              var10000.info("Loaded " + var19 + " pending crate(s) for world '" + worldName + "'");
                           }
                           continue label87;
                        }

                        Entry<String, CrateManager.PendingCrateData> entry = (Entry)var6.next();
                        data = (CrateManager.PendingCrateData)entry.getValue();
                     } while(!data.worldName.equalsIgnoreCase(worldName));

                     world = Bukkit.getWorld(worldName);
                  } while(world == null);

                  try {
                     Location location = new Location(world, data.x, data.y, data.z);
                     Crate crate = new Crate(data.crateName, location);
                     Iterator var12 = data.items.entrySet().iterator();

                     while(var12.hasNext()) {
                        Entry<Integer, ItemStack> itemEntry = (Entry)var12.next();
                        crate.setItem((Integer)itemEntry.getKey(), (ItemStack)itemEntry.getValue());
                     }

                     this.crates.put(data.crateName.toLowerCase(), crate);
                     retried.add(data.crateName);
                     this.plugin.getLogger().info("Successfully loaded pending crate '" + data.crateName + "' for world '" + worldName + "'");
                  } catch (Exception var15) {
                     var10000 = this.plugin.getLogger();
                     String var10001 = data.crateName;
                     var10000.severe("Failed to load pending crate '" + var10001 + "': " + var15.getMessage());
                     var15.printStackTrace();
                  }
               }
            }
         }
      }
   }

   public int getPendingCratesCount() {
      return this.pendingCrates.size();
   }

   private static class PendingCrateData {
      final String crateName;
      final String worldName;
      final double x;
      final double y;
      final double z;
      final Map<Integer, ItemStack> items;

      PendingCrateData(String crateName, String worldName, double x, double y, double z, Map<Integer, ItemStack> items) {
         this.crateName = crateName;
         this.worldName = worldName;
         this.x = x;
         this.y = y;
         this.z = z;
         this.items = items;
      }
   }
}
