package me.omh.solarcrate.managers;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.libs.folialib.wrapper.task.WrappedTask;
import me.omh.solarcrate.utils.SolarUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class TimerManager {
   private final SolarCrate plugin;
   private volatile WrappedTask timerTask;
   private volatile long nextExecutionTime;
   private volatile boolean running = false;

   public TimerManager(SolarCrate plugin) {
      this.plugin = plugin;
   }

   public synchronized void startTimer() {
      if (!this.running) {
         long interval = this.plugin.getConfigManager().getTimerInterval();
         if (interval <= 0L) {
            this.plugin.getLogger().severe("Invalid timer interval: " + interval + " seconds. Must be positive. Using default of 3600 seconds (1 hour).");
            interval = 3600L;
         } else if (interval < 60L) {
            this.plugin.getLogger().warning("Timer interval is very short: " + interval + " seconds. This may cause performance issues.");
         } else if (interval > 86400L) {
            this.plugin.getLogger().warning("Timer interval is very long: " + interval + " seconds (" + interval / 3600L + " hours).");
         }

         try {
            this.timerTask = this.plugin.getFoliaLib().getImpl().runTimer(() -> {
               this.executeTimer();
            }, interval * 20L, interval * 20L);
            this.running = true;
            this.nextExecutionTime = System.currentTimeMillis() + interval * 1000L;
         } catch (Exception var4) {
            this.plugin.getLogger().severe("Failed to start timer: " + var4.getMessage());
            var4.printStackTrace();
            this.running = false;
            this.timerTask = null;
         }
      }
   }

   public synchronized void stopTimer() {
      this.running = false;
      this.nextExecutionTime = 0L;
      if (this.timerTask != null) {
         try {
            this.timerTask.cancel();
         } catch (Exception var5) {
            this.plugin.getLogger().warning("Error canceling timer task: " + var5.getMessage());
         } finally {
            this.timerTask = null;
         }
      }

   }

   public synchronized void restartTimer() {
      this.stopTimer();
      this.startTimer();
   }

   private void executeTimer() {
      this.performTimerExecution();
   }

   private void performTimerExecution() {
      List beforeMessages;
      List commands;
      String clickableCommand;
      String clickableText;
      List afterMessages;
      boolean soundEnabled;
      String soundName;
      float volume;
      float pitch;
      synchronized(this) {
         if (!this.running) {
            return;
         }

         long interval = (long)this.plugin.getConfigManager().getCachedInt("timer.interval", 3600);
         this.nextExecutionTime = System.currentTimeMillis() + interval * 1000L;
         beforeMessages = this.plugin.getConfigManager().getBeforeMessages();
         commands = this.plugin.getConfigManager().getTimerCommands();
         clickableCommand = this.plugin.getConfigManager().getClickableCommand();
         clickableText = this.plugin.getConfigManager().getClickableText();
         afterMessages = this.plugin.getConfigManager().getAfterMessages();
         soundEnabled = this.plugin.getConfigManager().getCachedBoolean("sounds.timer-execute.enabled", true);
         soundName = this.plugin.getConfigManager().getCachedString("sounds.timer-execute.sound", "BLOCK_NOTE_BLOCK_PLING");
         volume = (float)this.plugin.getConfigManager().getCachedDouble("sounds.timer-execute.volume", 1.0D);
         pitch = (float)this.plugin.getConfigManager().getCachedDouble("sounds.timer-execute.pitch", 1.0D);
      }

      Collection<? extends Player> onlinePlayers = Bukkit.getOnlinePlayers();
      int playerCount = onlinePlayers.size();
      Iterator var14 = beforeMessages.iterator();

      while(true) {
         String message;
         String message;
         do {
            if (!var14.hasNext()) {
               StringBuilder executedCommands = new StringBuilder();
               this.executeCommandsForPlayers(onlinePlayers, commands, executedCommands);
               if (!clickableText.trim().isEmpty()) {
                  Component message = ((TextComponent)Component.text(SolarUtils.translateColors(clickableText)).color(NamedTextColor.GREEN)).clickEvent(ClickEvent.runCommand(clickableCommand));
                  Iterator var24 = onlinePlayers.iterator();

                  while(var24.hasNext()) {
                     Player player = (Player)var24.next();
                     player.sendMessage(message);
                  }
               }

               Iterator var23 = afterMessages.iterator();

               while(true) {
                  do {
                     if (!var23.hasNext()) {
                        if (soundEnabled) {
                           this.plugin.getSoundManager().playSound(soundName, volume, pitch);
                        }

                        this.plugin.getLogger().info("Timer executed commands: " + executedCommands.toString());
                        this.plugin.getLogger().info("Timer executed for " + playerCount + " players");
                        return;
                     }

                     message = (String)var23.next();
                  } while(message.trim().isEmpty());

                  String coloredMessage = SolarUtils.c(message);
                  Iterator var27 = onlinePlayers.iterator();

                  while(var27.hasNext()) {
                     Player player = (Player)var27.next();
                     player.sendMessage(coloredMessage);
                  }
               }
            }

            message = (String)var14.next();
         } while(message.trim().isEmpty());

         message = SolarUtils.c(message);
         Iterator var17 = onlinePlayers.iterator();

         while(var17.hasNext()) {
            Player player = (Player)var17.next();
            player.sendMessage(message);
         }
      }
   }

   public synchronized long getTimeUntilNext() {
      return this.running && this.nextExecutionTime != 0L ? Math.max(0L, (this.nextExecutionTime - System.currentTimeMillis()) / 1000L) : 0L;
   }

   public String getFormattedTimeUntilNext() {
      long seconds = this.getTimeUntilNext();
      if (seconds <= 0L) {
         return "0s";
      } else {
         long hours = seconds / 3600L;
         long minutes = seconds % 3600L / 60L;
         long secs = seconds % 60L;
         StringBuilder result = new StringBuilder();
         if (hours > 0L) {
            result.append(hours).append("h");
         }

         if (minutes > 0L) {
            if (result.length() > 0) {
               result.append(" ");
            }

            result.append(minutes).append("m");
         }

         if (secs > 0L || result.length() == 0) {
            if (result.length() > 0) {
               result.append(" ");
            }

            result.append(secs).append("s");
         }

         return result.toString();
      }
   }

   public synchronized boolean isRunning() {
      return this.running;
   }

   public void forceExecute() {
      this.executeTimer();
   }

   private void executeCommandsForPlayers(Collection<? extends Player> players, List<String> commands, StringBuilder executedCommands) {
      Iterator var4 = players.iterator();

      while(true) {
         while(true) {
            Player player;
            do {
               do {
                  if (!var4.hasNext()) {
                     return;
                  }

                  player = (Player)var4.next();
               } while(player == null);
            } while(!player.isOnline());

            String sanitizedPlayerName = this.sanitizePlayerName(player.getName());
            if (sanitizedPlayerName == null) {
               this.plugin.getLogger().warning("Skipping timer commands for player with invalid name: " + player.getName());
            } else {
               Iterator var7 = commands.iterator();

               while(var7.hasNext()) {
                  String command = (String)var7.next();

                  try {
                     String processedCommand = command.replace("{player}", sanitizedPlayerName);
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
                     executedCommands.append(processedCommand).append(";");
                  } catch (Exception var10) {
                     this.plugin.getLogger().warning("Failed to execute timer command '" + command + "' for player " + player.getName() + ": " + var10.getMessage());
                  }
               }
            }
         }
      }
   }

   private String sanitizePlayerName(String playerName) {
      if (playerName != null && !playerName.trim().isEmpty()) {
         return !playerName.matches("^[A-Za-z0-9_]{3,16}$") ? null : playerName;
      } else {
         return null;
      }
   }
}
