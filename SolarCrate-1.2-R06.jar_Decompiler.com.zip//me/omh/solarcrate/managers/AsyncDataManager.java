package me.omh.solarcrate.managers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.logging.Logger;
import me.omh.solarcrate.SolarCrate;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class AsyncDataManager {
   private final SolarCrate plugin;
   private final ExecutorService executor;
   private final ScheduledExecutorService scheduler;
   private final ConcurrentHashMap<String, CompletableFuture<Void>> pendingOperations;
   private final ConcurrentHashMap<String, Long> lastSaveTime;
   private final ConcurrentHashMap<String, Long> lastAttemptTime;
   private final long MIN_SAVE_INTERVAL_MS = 1000L;
   private static final CompletableFuture<Boolean> TRUE_FUTURE = CompletableFuture.completedFuture(true);
   private static final CompletableFuture<Boolean> FALSE_FUTURE = CompletableFuture.completedFuture(false);
   private static final CompletableFuture<Void> COMPLETED_VOID_FUTURE = CompletableFuture.completedFuture((Object)null);

   public AsyncDataManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.executor = Executors.newFixedThreadPool(plugin.getConfigManager().getCachedInt("settings.thread_pool_size", 4), (r) -> {
         Thread t = new Thread(r, "SolarCrate-AsyncIO");
         t.setDaemon(true);
         t.setPriority(4);
         return t;
      });
      this.scheduler = Executors.newScheduledThreadPool(2, (r) -> {
         Thread t = new Thread(r, "SolarCrate-Scheduler");
         t.setDaemon(true);
         return t;
      });
      this.pendingOperations = new ConcurrentHashMap();
      this.lastSaveTime = new ConcurrentHashMap();
      this.lastAttemptTime = new ConcurrentHashMap();
   }

   public CompletableFuture<Boolean> saveConfigAsync(String name, FileConfiguration config, File file) {
      return this.saveConfigAsync(name, config, file, (Consumer)null, (Consumer)null);
   }

   public CompletableFuture<Boolean> saveConfigAsync(String name, FileConfiguration config, File file, Consumer<Boolean> callback, Consumer<Exception> errorHandler) {
      long currentTime = System.currentTimeMillis();
      Long lastAttempt = (Long)this.lastAttemptTime.get(name);
      if (lastAttempt != null && currentTime - lastAttempt < 1000L) {
         long remainingDelay = 1000L - (currentTime - lastAttempt);
         CompletableFuture<Boolean> delayedFuture = new CompletableFuture();
         this.scheduler.schedule(() -> {
            this.saveConfigNow(name, config, file, callback, errorHandler).whenComplete((result, ex) -> {
               if (ex != null) {
                  delayedFuture.completeExceptionally(ex);
               } else {
                  delayedFuture.complete(result);
               }

            });
         }, remainingDelay, TimeUnit.MILLISECONDS);
         return delayedFuture;
      } else {
         return this.saveConfigNow(name, config, file, callback, errorHandler);
      }
   }

   private CompletableFuture<Boolean> saveConfigNow(String name, FileConfiguration config, File file, Consumer<Boolean> callback, Consumer<Exception> errorHandler) {
      CompletableFuture<Void> chainedFuture = (CompletableFuture)this.pendingOperations.compute(name, (key, prev) -> {
         CompletableFuture<Void> base = prev == null ? COMPLETED_VOID_FUTURE : prev;
         CompletableFuture<Void> next = base.thenComposeAsync((unused) -> {
            return this.performSaveOperation(name, config, file, callback, errorHandler);
         }, this.executor);
         next.whenComplete((v, t) -> {
            this.pendingOperations.remove(name, next);
         });
         return next;
      });
      return chainedFuture.handle((unused, ex) -> {
         if (ex == null) {
            return true;
         } else {
            this.plugin.getLogger().severe("Chained save operation failed for " + name + ": " + ex.getMessage());
            if (errorHandler != null) {
               errorHandler.accept(ex instanceof Exception ? (Exception)ex : new RuntimeException(ex));
            }

            return false;
         }
      });
   }

   private CompletableFuture<Void> performSaveOperation(String name, FileConfiguration config, File file, Consumer<Boolean> callback, Consumer<Exception> errorHandler) {
      return CompletableFuture.runAsync(() -> {
         this.plugin.getUtilityManagers().startOperation("save_config_" + name);
         long attemptTime = System.currentTimeMillis();
         this.lastAttemptTime.put(name, attemptTime);

         try {
            boolean backupSuccess = this.createBackup(file);
            if (!backupSuccess) {
               this.plugin.getLogger().warning("Failed to create backup for " + name + " - proceeding with save");
            }

            config.save(file);
            this.lastSaveTime.put(name, attemptTime);
            if (callback != null) {
               this.plugin.getFoliaLib().getImpl().runLater(() -> {
                  callback.accept(true);
               }, 1L);
            }
         } catch (IOException var12) {
            this.plugin.getLogger().severe("Failed to save " + name + ": " + var12.getMessage());
            if (this.attemptRestore(file)) {
               this.plugin.getLogger().info("Restored " + name + " from backup after save failure");
            }

            if (callback != null) {
               this.plugin.getFoliaLib().getImpl().runLater(() -> {
                  callback.accept(false);
               }, 1L);
            }

            throw new RuntimeException("Save failed: " + var12.getMessage(), var12);
         } catch (Exception var13) {
            this.plugin.getLogger().severe("Unexpected error saving " + name + ": " + var13.getClass().getSimpleName() + " - " + var13.getMessage());
            if (callback != null) {
               this.plugin.getFoliaLib().getImpl().runLater(() -> {
                  callback.accept(false);
               }, 1L);
            }

            throw new RuntimeException("Unexpected save error: " + var13.getMessage(), var13);
         } finally {
            this.plugin.getUtilityManagers().endOperation("save_config_" + name);
         }

      }, this.executor);
   }

   public CompletableFuture<FileConfiguration> loadConfigAsync(File file) {
      return CompletableFuture.supplyAsync(() -> {
         this.plugin.getUtilityManagers().startOperation("load_config_" + file.getName());

         try {
            YamlConfiguration var3;
            Logger var10000;
            String var10001;
            try {
               YamlConfiguration var19;
               if (!file.exists()) {
                  var19 = new YamlConfiguration();
                  return var19;
               } else if (this.isValidConfigFile(file)) {
                  var19 = YamlConfiguration.loadConfiguration(file);
                  return var19;
               } else {
                  this.plugin.getLogger().warning("Main config file " + file.getName() + " is invalid, trying backups");
                  String[] backupSuffixes = new String[]{".backup", ".backup.1", ".backup.2"};
                  String[] var20 = backupSuffixes;
                  int var4 = backupSuffixes.length;

                  for(int var5 = 0; var5 < var4; ++var5) {
                     String suffix = var20[var5];
                     String var10002 = file.getParent();
                     String var10003 = file.getName();
                     File backup = new File(var10002, var10003 + suffix);
                     if (backup.exists() && this.isValidConfigFile(backup)) {
                        try {
                           this.plugin.getLogger().info("Loading from backup: " + backup.getName());
                           YamlConfiguration recoveredConfig = YamlConfiguration.loadConfiguration(backup);

                           try {
                              recoveredConfig.save(file);
                              var10000 = this.plugin.getLogger();
                              var10001 = file.getName();
                              var10000.info("Healed main config file " + var10001 + " from " + backup.getName());
                           } catch (IOException var15) {
                              var10000 = this.plugin.getLogger();
                              var10001 = file.getName();
                              var10000.warning("Failed to heal main config file " + var10001 + ": " + var15.getMessage());
                           }

                           YamlConfiguration var9 = recoveredConfig;
                           return var9;
                        } catch (Exception var16) {
                           var10000 = this.plugin.getLogger();
                           var10001 = backup.getName();
                           var10000.warning("Failed to load from " + var10001 + ": " + var16.getMessage());
                        }
                     }
                  }

                  this.plugin.getLogger().severe("All backup restore attempts failed for " + file.getName() + ", returning empty config");
                  var3 = new YamlConfiguration();
                  return var3;
               }
            } catch (Exception var17) {
               var10000 = this.plugin.getLogger();
               var10001 = file.getName();
               var10000.severe("Failed to load config from " + var10001 + ": " + var17.getMessage());
               var3 = new YamlConfiguration();
               return var3;
            }
         } finally {
            this.plugin.getUtilityManagers().endOperation("load_config_" + file.getName());
         }
      }, this.executor);
   }

   public CompletableFuture<Boolean> batchSave(Map<String, Entry<FileConfiguration, File>> configs) {
      if (configs.isEmpty()) {
         return CompletableFuture.completedFuture(true);
      } else {
         this.plugin.getUtilityManagers().startOperation("batch_save");
         CompletableFuture<Boolean>[] futures = (CompletableFuture[])configs.entrySet().stream().map((entry) -> {
            String name = (String)entry.getKey();
            FileConfiguration config = (FileConfiguration)((Entry)entry.getValue()).getKey();
            File file = (File)((Entry)entry.getValue()).getValue();
            return this.saveConfigAsync(name, config, file);
         }).toArray((x$0) -> {
            return new CompletableFuture[x$0];
         });
         return CompletableFuture.allOf(futures).thenApply((v) -> {
            this.plugin.getUtilityManagers().endOperation("batch_save");
            CompletableFuture[] var3 = futures;
            int var4 = futures.length;

            for(int var5 = 0; var5 < var4; ++var5) {
               CompletableFuture future = var3[var5];

               try {
                  if (!(Boolean)future.get()) {
                     return false;
                  }
               } catch (Exception var8) {
                  this.plugin.getLogger().warning("Batch save operation failed: " + var8.getMessage());
                  return false;
               }
            }

            return true;
         });
      }
   }

   private boolean createBackup(File file) {
      if (!file.exists()) {
         return true;
      } else {
         try {
            this.createMultiGenerationBackups(file);
            File backup = new File(file.getParent(), file.getName() + ".backup");
            Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            if (this.verifyBackupIntegrity(file, backup)) {
               return true;
            } else {
               this.plugin.getLogger().warning("Backup verification failed for " + file.getName());
               return false;
            }
         } catch (IOException var3) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = file.getName();
            var10000.warning("Failed to create backup for " + var10001 + ": " + var3.getMessage());
            return false;
         }
      }
   }

   private void createMultiGenerationBackups(File file) throws IOException {
      File backup1 = new File(file.getParent(), file.getName() + ".backup");
      File backup2 = new File(file.getParent(), file.getName() + ".backup.1");
      File backup3 = new File(file.getParent(), file.getName() + ".backup.2");
      if (backup2.exists()) {
         Files.deleteIfExists(backup3.toPath());
         Files.move(backup2.toPath(), backup3.toPath());
      }

      if (backup1.exists()) {
         Files.move(backup1.toPath(), backup2.toPath());
      }

   }

   private boolean verifyBackupIntegrity(File original, File backup) {
      try {
         if (original.length() != backup.length()) {
            return false;
         } else {
            YamlConfiguration.loadConfiguration(backup);
            return true;
         }
      } catch (Exception var4) {
         this.plugin.getLogger().warning("Backup integrity verification failed: " + var4.getMessage());
         return false;
      }
   }

   private boolean attemptRestore(File file) {
      String[] backupSuffixes = new String[]{".backup", ".backup.1", ".backup.2"};
      String[] var3 = backupSuffixes;
      int var4 = backupSuffixes.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String suffix = var3[var5];
         String var10002 = file.getParent();
         String var10003 = file.getName();
         File backup = new File(var10002, var10003 + suffix);
         if (backup.exists()) {
            Logger var10000;
            String var10001;
            try {
               if (!this.isValidConfigFile(backup)) {
                  this.plugin.getLogger().warning("Backup " + backup.getName() + " is corrupted, trying next generation");
               } else {
                  var10002 = file.getParent();
                  var10003 = file.getName();
                  File corruptedCopy = new File(var10002, var10003 + ".corrupted." + System.currentTimeMillis());
                  if (file.exists()) {
                     Files.copy(file.toPath(), corruptedCopy.toPath(), StandardCopyOption.REPLACE_EXISTING);
                     this.plugin.getLogger().info("Saved corrupted file as " + corruptedCopy.getName() + " for analysis");
                  }

                  Files.copy(backup.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                  if (this.isValidConfigFile(file)) {
                     var10000 = this.plugin.getLogger();
                     var10001 = file.getName();
                     var10000.info("Successfully restored " + var10001 + " from " + backup.getName());
                     return true;
                  }

                  this.plugin.getLogger().warning("Restored file " + file.getName() + " is still invalid, trying next backup");
               }
            } catch (IOException var9) {
               var10000 = this.plugin.getLogger();
               var10001 = backup.getName();
               var10000.warning("Failed to restore from " + var10001 + ": " + var9.getMessage());
            }
         }
      }

      this.plugin.getLogger().severe("All backup restore attempts failed for " + file.getName());
      return false;
   }

   private boolean isValidConfigFile(File file) {
      try {
         if (!file.exists()) {
            return false;
         } else {
            YamlConfiguration config = new YamlConfiguration();
            config.load(file);
            return true;
         }
      } catch (Exception var3) {
         return false;
      }
   }

   public void shutdown() {
      this.plugin.getLogger().info("Shutting down async data manager...");

      try {
         try {
            int cancelledCount = 0;
            Iterator var2 = this.pendingOperations.values().iterator();

            while(var2.hasNext()) {
               CompletableFuture<Void> future = (CompletableFuture)var2.next();
               if (future.cancel(false)) {
                  ++cancelledCount;
               }
            }

            if (cancelledCount > 0) {
               this.plugin.getLogger().info("Cancelled " + cancelledCount + " pending operations");
            }

            this.executor.shutdown();
            this.scheduler.shutdown();
            boolean executorTerminated = false;
            boolean schedulerTerminated = false;

            try {
               executorTerminated = this.executor.awaitTermination(5L, TimeUnit.SECONDS);
               if (!executorTerminated) {
                  this.plugin.getLogger().warning("Async executor did not terminate gracefully within 5 seconds, forcing shutdown");
                  this.executor.shutdownNow();
                  executorTerminated = this.executor.awaitTermination(2L, TimeUnit.SECONDS);
               }

               schedulerTerminated = this.scheduler.awaitTermination(2L, TimeUnit.SECONDS);
               if (!schedulerTerminated) {
                  this.plugin.getLogger().warning("Scheduler did not terminate gracefully, forcing shutdown");
                  this.scheduler.shutdownNow();
                  schedulerTerminated = this.scheduler.awaitTermination(1L, TimeUnit.SECONDS);
               }
            } catch (InterruptedException var11) {
               this.plugin.getLogger().warning("Interrupted during async shutdown, forcing immediate termination");
               this.executor.shutdownNow();
               this.scheduler.shutdownNow();
               Thread.currentThread().interrupt();
               return;
            }

            if (executorTerminated && schedulerTerminated) {
               this.plugin.getLogger().info("Async data manager shutdown completed successfully");
               return;
            }

            this.plugin.getLogger().warning("Async data manager shutdown completed with warnings - some tasks may not have terminated cleanly");
         } catch (Exception var12) {
            this.plugin.getLogger().severe("Error during async data manager shutdown: " + var12.getMessage());
            var12.printStackTrace();

            try {
               this.executor.shutdownNow();
               this.scheduler.shutdownNow();
            } catch (Exception var10) {
               this.plugin.getLogger().severe("Error during forced shutdown: " + var10.getMessage());
            }

            return;
         }

      } finally {
         this.pendingOperations.clear();
         this.lastSaveTime.clear();
         this.lastAttemptTime.clear();
      }
   }

   public Map<String, Object> getStats() {
      Map<String, Object> stats = new HashMap();
      stats.put("pending_operations", this.pendingOperations.size());
      stats.put("executor_active_count", ((ThreadPoolExecutor)this.executor).getActiveCount());
      stats.put("executor_queue_size", ((ThreadPoolExecutor)this.executor).getQueue().size());
      stats.put("last_save_times", new HashMap(this.lastSaveTime));
      return stats;
   }
}
