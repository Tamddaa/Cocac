package me.omh.solarcrate.managers;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import me.omh.solarcrate.SolarCrate;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

public class SoundManager {
   private final SolarCrate plugin;
   private final Set<String> invalidSounds = ConcurrentHashMap.newKeySet();

   public SoundManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.validateAllConfiguredSounds();
   }

   private void validateAllConfiguredSounds() {
      String[] soundConfigs = new String[]{"sounds.key-receive.sound", "sounds.command.sound", "sounds.error.sound", "sounds.crate-open.sound", "sounds.crate-close.sound", "sounds.item-select.sound", "sounds.confirm.sound", "sounds.cancel.sound", "sounds.success.sound", "sounds.warning.sound", "sounds.info.sound", "sounds.edit-gui.sound", "sounds.reload.sound", "sounds.timer-execute.sound"};
      String[] var2 = soundConfigs;
      int var3 = soundConfigs.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String soundConfig = var2[var4];
         String soundName = this.plugin.getConfigManager().getConfig().getString(soundConfig);
         if (soundName != null) {
            this.isValidSound(soundName);
         }
      }

   }

   private boolean isValidSound(String soundName) {
      if (soundName != null && !soundName.trim().isEmpty()) {
         if (this.invalidSounds.contains(soundName.toUpperCase())) {
            return false;
         } else {
            try {
               Sound.valueOf(soundName.toUpperCase());
               return true;
            } catch (IllegalArgumentException var3) {
               this.invalidSounds.add(soundName.toUpperCase());
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private boolean playSoundSafely(Player player, Location location, String soundName, float volume, float pitch, String context) {
      if (!this.isValidSound(soundName)) {
         return false;
      } else {
         try {
            Sound sound = Sound.valueOf(soundName.toUpperCase());
            if (player != null && location != null) {
               player.playSound(location, sound, SoundCategory.MASTER, volume, pitch);
            } else if (player != null) {
               player.playSound(player.getLocation(), sound, SoundCategory.MASTER, volume, pitch);
            } else if (location != null) {
               location.getWorld().playSound(location, sound, SoundCategory.MASTER, volume, pitch);
            }

            return true;
         } catch (Exception var8) {
            return false;
         }
      }
   }

   public void playSound(String soundName, float volume, float pitch) {
      Iterator var4 = Bukkit.getOnlinePlayers().iterator();

      while(var4.hasNext()) {
         Player player = (Player)var4.next();
         this.playSoundSafely(player, (Location)null, soundName, volume, pitch, "global sound");
      }

   }

   public void playSound(Player player, String soundName, float volume, float pitch) {
      this.playSoundSafely(player, (Location)null, soundName, volume, pitch, "player sound");
   }

   public void playSound(Location location, String soundName, float volume, float pitch) {
      this.playSoundSafely((Player)null, location, soundName, volume, pitch, "location sound");
   }

   public void playKeyReceiveSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.key-receive.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.key-receive.sound", "ENTITY_PLAYER_LEVELUP");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.key-receive.volume", 1.0D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.key-receive.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playCommandSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.command.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.command.sound", "UI_BUTTON_CLICK");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.command.volume", 0.5D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.command.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playErrorSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.error.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.error.sound", "BLOCK_NOTE_BLOCK_BASS");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.error.volume", 1.0D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.error.pitch", 0.5D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playCrateOpenSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.crate-open.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.crate-open.sound", "BLOCK_CHEST_OPEN");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.crate-open.volume", 1.0D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.crate-open.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playCrateCloseSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.crate-close.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.crate-close.sound", "BLOCK_CHEST_CLOSE");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.crate-close.volume", 1.0D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.crate-close.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playItemSelectSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.item-select.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.item-select.sound", "UI_BUTTON_CLICK");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.item-select.volume", 0.7D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.item-select.pitch", 1.2D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playConfirmSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.confirm.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.confirm.sound", "ENTITY_PLAYER_LEVELUP");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.confirm.volume", 0.8D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.confirm.pitch", 1.5D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playCancelSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.cancel.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.cancel.sound", "BLOCK_NOTE_BLOCK_BASS");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.cancel.volume", 0.6D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.cancel.pitch", 0.8D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playSuccessSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.success.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.success.sound", "ENTITY_PLAYER_LEVELUP");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.success.volume", 1.0D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.success.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playWarningSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.warning.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.warning.sound", "BLOCK_NOTE_BLOCK_BELL");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.warning.volume", 0.8D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.warning.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playInfoSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.info.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.info.sound", "BLOCK_NOTE_BLOCK_PLING");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.info.volume", 0.6D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.info.pitch", 1.2D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playEditGuiSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.edit-gui.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.edit-gui.sound", "BLOCK_ENCHANTMENT_TABLE_USE");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.edit-gui.volume", 0.7D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.edit-gui.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }

   public void playReloadSound(Player player) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("sounds.reload.enabled", true)) {
         String soundName = this.plugin.getConfigManager().getConfig().getString("sounds.reload.sound", "BLOCK_ANVIL_USE");
         float volume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.reload.volume", 0.8D);
         float pitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.reload.pitch", 1.0D);
         this.playSound(player, soundName, volume, pitch);
      }

   }
}
