package me.omh.solarcrate;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import me.omh.solarcrate.backup.BackupManager;
import me.omh.solarcrate.commands.SolarCrateCommand;
import me.omh.solarcrate.gui.GuiEventHandler;
import me.omh.solarcrate.gui.GuiManager;
import me.omh.solarcrate.libs.folialib.FoliaLib;
import me.omh.solarcrate.listeners.SolarCrateListeners;
import me.omh.solarcrate.managers.AnimationManager;
import me.omh.solarcrate.managers.ConfigManager;
import me.omh.solarcrate.managers.CrateManager;
import me.omh.solarcrate.managers.KeyManager;
import me.omh.solarcrate.managers.PlayerStateManager;
import me.omh.solarcrate.managers.SoundManager;
import me.omh.solarcrate.managers.TimerManager;
import me.omh.solarcrate.managers.UtilityManagers;
import me.omh.solarcrate.placeholders.SolarCratePlaceholder;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

public class SolarCrate extends JavaPlugin {
   private static volatile SolarCrate instance;
   private FoliaLib foliaLib;
   private ConfigManager configManager;
   private TimerManager timerManager;
   private SoundManager soundManager;
   private CrateManager crateManager;
   private KeyManager keyManager;
   private AnimationManager animationManager;
   private SolarCratePlaceholder placeholder;
   private GuiManager guiManager;
   private PlayerStateManager playerStateManager;
   private SolarCrateListeners solarCrateListeners;
   private GuiEventHandler guiEventHandler;
   private UtilityManagers utilityManagers;
   private BackupManager backupManager;

   public void onEnable() {
      instance = this;

      try {
         try {
            this.foliaLib = new FoliaLib(this);
         } catch (NoClassDefFoundError var15) {
            this.getLogger().severe("Critical error: FoliaLib class not found - ensure dependency is available: " + var15.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (RuntimeException var16) {
            this.getLogger().severe("Critical error: Failed to initialize FoliaLib due to runtime error: " + var16.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         }

         Logger var10000;
         String var10001;
         try {
            this.configManager = new ConfigManager(this);
            this.configManager.loadConfigs();
         } catch (IOException var11) {
            this.getLogger().severe("Critical error: Failed to create or load configuration files: " + var11.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (IllegalArgumentException var12) {
            this.getLogger().severe("Critical error: Invalid configuration values: " + var12.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (SecurityException var13) {
            this.getLogger().severe("Critical error: Security restrictions prevent configuration access: " + var13.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (Exception var14) {
            var10000 = this.getLogger();
            var10001 = var14.getClass().getSimpleName();
            var10000.severe("Critical error: Unexpected configuration failure: " + var10001 + " - " + var14.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         }

         try {
            this.utilityManagers = new UtilityManagers();
            this.playerStateManager = new PlayerStateManager(this);
            this.soundManager = new SoundManager(this);
            this.animationManager = new AnimationManager(this);
            this.crateManager = new CrateManager(this);
            this.keyManager = new KeyManager(this);
            this.timerManager = new TimerManager(this);
            this.backupManager = new BackupManager(this);
         } catch (IllegalStateException var9) {
            this.getLogger().severe("Critical error: Invalid state during core managers initialization: " + var9.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (RuntimeException var10) {
            this.getLogger().severe("Critical error: Failed to initialize core managers due to runtime error: " + var10.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         }

         try {
            this.guiManager = new GuiManager(this);
         } catch (IllegalArgumentException var6) {
            this.getLogger().severe("Critical error: Invalid arguments for GUI system initialization: " + var6.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (NullPointerException var7) {
            this.getLogger().severe("Critical error: Null pointer during GUI system initialization: " + var7.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (RuntimeException var8) {
            var10000 = this.getLogger();
            var10001 = var8.getClass().getSimpleName();
            var10000.severe("Critical error: Runtime error initializing GUI system: " + var10001 + " - " + var8.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         }

         try {
            if (this.getCommand("solarcrate") != null) {
               this.getCommand("solarcrate").setExecutor(new SolarCrateCommand(this));
            }

            this.solarCrateListeners = new SolarCrateListeners(this);
            this.getServer().getPluginManager().registerEvents(this.solarCrateListeners, this);
            this.guiEventHandler = new GuiEventHandler(this, this.guiManager);
            this.getServer().getPluginManager().registerEvents(this.guiEventHandler, this);
         } catch (IllegalArgumentException var17) {
            this.getLogger().severe("Critical error: Invalid command or listener configuration: " + var17.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (IllegalStateException var18) {
            this.getLogger().severe("Critical error: Server in invalid state for command/listener registration: " + var18.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (SecurityException var19) {
            this.getLogger().severe("Critical error: Security restrictions prevent command/listener registration: " + var19.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         } catch (Exception var20) {
            var10000 = this.getLogger();
            var10001 = var20.getClass().getSimpleName();
            var10000.severe("Critical error: Unexpected command/listener registration failure: " + var10001 + " - " + var20.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         }

         if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null && this.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
               this.placeholder = new SolarCratePlaceholder(this);
               this.placeholder.register();
            } catch (Exception var5) {
               this.placeholder = null;
            }
         }

         try {
            if (this.crateManager != null) {
               this.crateManager.loadCrates();
            }
         } catch (Exception var4) {
            this.getLogger().severe("Failed to load crates: " + var4.getMessage());
            var4.printStackTrace();
         }

         try {
            if (this.keyManager != null) {
               this.keyManager.loadKeys();
            }
         } catch (Exception var3) {
            this.getLogger().severe("Failed to load keys: " + var3.getMessage());
            var3.printStackTrace();
         }

         try {
            if (this.timerManager != null) {
               this.timerManager.startTimer();
            }
         } catch (Exception var2) {
         }

         if (this.crateManager != null && this.crateManager.getPendingCratesCount() > 0) {
            this.foliaLib.getImpl().runLater(() -> {
               try {
                  this.crateManager.retryAllPendingCrates();
               } catch (Exception var2) {
               }

            }, 100L);
         }
      } catch (Exception var21) {
         this.getLogger().severe("Unexpected error during plugin initialization: " + var21.getMessage());
         this.getServer().getPluginManager().disablePlugin(this);
      }

   }

   public void onDisable() {
      if (this.timerManager != null) {
         this.timerManager.stopTimer();
      }

      if (this.crateManager != null) {
         this.crateManager.saveCrates();
      }

      if (this.keyManager != null) {
         this.keyManager.shutdown();
      }

      if (this.placeholder != null) {
         this.placeholder.unregister();
      }

      if (this.guiManager != null) {
         this.guiManager.cleanup();
      }

      if (this.guiEventHandler != null) {
         this.guiEventHandler.shutdown();

         try {
            HandlerList.unregisterAll(this.guiEventHandler);
         } catch (Exception var3) {
         }
      }

      if (this.playerStateManager != null) {
         this.playerStateManager.shutdown();
      }

      if (this.utilityManagers != null) {
         this.utilityManagers.cleanup();
      }

      if (this.solarCrateListeners != null) {
         this.solarCrateListeners.cleanup();

         try {
            HandlerList.unregisterAll(this.solarCrateListeners);
         } catch (Exception var2) {
         }
      }

      instance = null;
   }

   public static SolarCrate getInstance() {
      if (instance == null) {
         throw new IllegalStateException("SolarCrate plugin is not properly initialized");
      } else if (!instance.isEnabled()) {
         throw new IllegalStateException("SolarCrate plugin has been disabled");
      } else {
         return instance;
      }
   }

   public FoliaLib getFoliaLib() {
      return this.foliaLib;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public TimerManager getTimerManager() {
      return this.timerManager;
   }

   public SoundManager getSoundManager() {
      return this.soundManager;
   }

   public CrateManager getCrateManager() {
      return this.crateManager;
   }

   public KeyManager getKeyManager() {
      return this.keyManager;
   }

   public AnimationManager getAnimationManager() {
      return this.animationManager;
   }

   public PlayerStateManager getPlayerStateManager() {
      return this.playerStateManager;
   }

   /** @deprecated */
   @Deprecated
   public Map<UUID, String> getEditingPlayers() {
      return (Map)(this.playerStateManager == null ? new HashMap() : new SolarCrate.AbstractPlayerStateMap<String>() {
         protected String getValue(UUID uuid) {
            return SolarCrate.this.playerStateManager.getEditingCrate(uuid);
         }

         protected void setValue(UUID uuid, String value) {
            SolarCrate.this.playerStateManager.setEditingCrate(uuid, value);
         }

         protected void clearValue(UUID uuid) {
            SolarCrate.this.playerStateManager.clearEditingCrate(uuid);
         }

         protected Set<UUID> getKeys() {
            return SolarCrate.this.playerStateManager.getPlayersEditingCrates();
         }
      });
   }

   /** @deprecated */
   @Deprecated
   public Map<UUID, String> getSelectingCrate() {
      return (Map)(this.playerStateManager == null ? new HashMap() : new SolarCrate.AbstractPlayerStateMap<String>() {
         protected String getValue(UUID uuid) {
            return SolarCrate.this.playerStateManager.getSelectedCrate(uuid);
         }

         protected void setValue(UUID uuid, String value) {
            SolarCrate.this.playerStateManager.setSelectedCrate(uuid, value);
         }

         protected void clearValue(UUID uuid) {
            SolarCrate.this.playerStateManager.clearSelectedCrate(uuid);
         }

         protected Set<UUID> getKeys() {
            return (Set)SolarCrate.this.playerStateManager.getAllOnlinePlayers().stream().filter((uuid) -> {
               return SolarCrate.this.playerStateManager.getSelectedCrate(uuid) != null;
            }).collect(Collectors.toSet());
         }
      });
   }

   /** @deprecated */
   @Deprecated
   public Map<UUID, Boolean> getRemoveMode() {
      return (Map)(this.playerStateManager == null ? new HashMap() : new SolarCrate.AbstractPlayerStateMap<Boolean>() {
         protected Boolean getValue(UUID uuid) {
            return SolarCrate.this.playerStateManager.isInRemoveMode(uuid) ? true : null;
         }

         protected void setValue(UUID uuid, Boolean value) {
            SolarCrate.this.playerStateManager.setRemoveMode(uuid, value != null && value);
         }

         protected void clearValue(UUID uuid) {
            SolarCrate.this.playerStateManager.setRemoveMode(uuid, false);
         }

         protected Set<UUID> getKeys() {
            Stream var10000 = SolarCrate.this.playerStateManager.getAllOnlinePlayers().stream();
            PlayerStateManager var10001 = SolarCrate.this.playerStateManager;
            Objects.requireNonNull(var10001);
            return (Set)var10000.filter(var10001::isInRemoveMode).collect(Collectors.toSet());
         }
      });
   }

   public SolarCrateListeners getSolarCrateListeners() {
      return this.solarCrateListeners;
   }

   public UtilityManagers getUtilityManagers() {
      return this.utilityManagers;
   }

   public GuiManager getGuiManager() {
      return this.guiManager;
   }

   public BackupManager getBackupManager() {
      return this.backupManager;
   }

   private abstract static class AbstractPlayerStateMap<V> extends AbstractMap<UUID, V> {
      protected abstract V getValue(UUID var1);

      protected abstract void setValue(UUID var1, V var2);

      protected abstract void clearValue(UUID var1);

      protected abstract Set<UUID> getKeys();

      public V get(Object key) {
         return key instanceof UUID ? this.getValue((UUID)key) : null;
      }

      public V put(UUID key, V value) {
         V old = this.getValue(key);
         this.setValue(key, value);
         return old;
      }

      public V remove(Object key) {
         if (key instanceof UUID) {
            V old = this.getValue((UUID)key);
            this.clearValue((UUID)key);
            return old;
         } else {
            return null;
         }
      }

      public boolean containsKey(Object key) {
         return key instanceof UUID && this.getValue((UUID)key) != null;
      }

      public int size() {
         return this.getKeys().size();
      }

      public boolean isEmpty() {
         return this.getKeys().isEmpty();
      }

      public void clear() {
         (new HashSet(this.getKeys())).forEach(this::clearValue);
      }

      public Set<UUID> keySet() {
         return this.getKeys();
      }

      public Set<Entry<UUID, V>> entrySet() {
         return new AbstractSet<Entry<UUID, V>>() {
            // $FF: synthetic field
            final SolarCrate.AbstractPlayerStateMap this$0;

            {
               this.this$0 = this$0;
            }

            public int size() {
               return this.this$0.getKeys().size();
            }

            public Iterator<Entry<UUID, V>> iterator() {
               Iterator<UUID> keyIterator = (new HashSet(this.this$0.getKeys())).iterator();
               return new Iterator<Entry<UUID, V>>(keyIterator) {
                  private UUID currentKey;
                  // $FF: synthetic field
                  final Iterator val$keyIterator;
                  // $FF: synthetic field
                  final <undefinedtype> this$1;

                  {
                     this.this$1 = this$1;
                     this.val$keyIterator = var2;
                     this.currentKey = null;
                  }

                  public boolean hasNext() {
                     return this.val$keyIterator.hasNext();
                  }

                  public Entry<UUID, V> next() {
                     this.currentKey = (UUID)this.val$keyIterator.next();
                     return new Entry<UUID, V>() {
                        private final UUID key;
                        // $FF: synthetic field
                        final <undefinedtype> this$2;

                        {
                           this.this$2 = this$2;
                           this.key = this.this$2.currentKey;
                        }

                        public UUID getKey() {
                           return this.key;
                        }

                        public V getValue() {
                           return this.this$2.this$1.this$0.getValue(this.key);
                        }

                        public V setValue(V value) {
                           V old = this.this$2.this$1.this$0.getValue(this.key);
                           this.this$2.this$1.this$0.setValue(this.key, value);
                           return old;
                        }

                        public boolean equals(Object o) {
                           if (!(o instanceof Entry)) {
                              return false;
                           } else {
                              Entry<?, ?> e = (Entry)o;
                              return Objects.equals(this.key, e.getKey()) && Objects.equals(this.getValue(), e.getValue());
                           }
                        }

                        public int hashCode() {
                           return Objects.hashCode(this.key) ^ Objects.hashCode(this.getValue());
                        }
                     };
                  }

                  public void remove() {
                     if (this.currentKey == null) {
                        throw new IllegalStateException();
                     } else {
                        this.this$1.this$0.clearValue(this.currentKey);
                        this.currentKey = null;
                     }
                  }
               };
            }
         };
      }
   }
}
