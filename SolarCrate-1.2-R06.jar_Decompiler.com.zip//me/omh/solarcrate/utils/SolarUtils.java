package me.omh.solarcrate.utils;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.CommandSender;

public class SolarUtils {
   private static final Pattern HEX_PATTERN = Pattern.compile("#([a-fA-F0-9]{6})");
   private static final Pattern GRADIENT_PATTERN = Pattern.compile("\\[gradient=#([a-fA-F0-9]{6}):#([a-fA-F0-9]{6})\\](.+?)\\[/gradient\\]");
   private static final MiniMessage miniMessage = MiniMessage.miniMessage();
   public static final String SUCCESS = "&a";
   public static final String ERROR = "&c";
   public static final String WARNING = "&e";
   public static final String INFO = "&b";
   public static final String SECONDARY = "&7";
   public static final String PRIMARY = "&f";
   public static final String ACCENT = "&6";
   private static final Pattern VALID_CRATE_NAME = Pattern.compile("^[a-zA-Z0-9_-]{1,32}$");
   private static final int MIN_KEY_AMOUNT = 1;
   private static final int MAX_KEY_AMOUNT = 10000;
   private static final int MIN_COORDINATE = -30000000;
   private static final int MAX_COORDINATE = 30000000;
   private static final int MIN_Y_COORDINATE = -64;
   private static final int MAX_Y_COORDINATE = 320;

   public static String translateColors(String text) {
      if (text != null && !text.isEmpty()) {
         boolean hasGradients = GRADIENT_PATTERN.matcher(text).find();
         boolean hasHex = HEX_PATTERN.matcher(text).find();
         boolean hasLegacy = text.contains("&");
         if (hasGradients) {
            text = processGradients(text);
            text = processStandaloneHexColors(text);
            return ChatColor.translateAlternateColorCodes('&', text);
         } else {
            if (hasHex) {
               text = processStandaloneHexColors(text);
            }

            if (hasLegacy) {
               text = ChatColor.translateAlternateColorCodes('&', text);
            }

            return text;
         }
      } else {
         return text;
      }
   }

   private static String processStandaloneHexColors(String text) {
      Matcher matcher = HEX_PATTERN.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while(matcher.find()) {
         matcher.appendReplacement(buffer, ChatColor.of("#" + matcher.group(1)).toString());
      }

      matcher.appendTail(buffer);
      return buffer.toString();
   }

   private static String processGradients(String text) {
      Matcher matcher = GRADIENT_PATTERN.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while(matcher.find()) {
         String startColor = matcher.group(1);
         String endColor = matcher.group(2);
         String content = matcher.group(3);
         String gradient = createGradient(content, startColor, endColor);
         matcher.appendReplacement(buffer, gradient);
      }

      matcher.appendTail(buffer);
      return buffer.toString();
   }

   private static String createGradient(String text, String startHex, String endHex) {
      if (text.length() <= 1) {
         String var10000 = String.valueOf(ChatColor.of("#" + startHex));
         return var10000 + text;
      } else {
         StringBuilder result = new StringBuilder();
         int[] startRGB = hexToRGB(startHex);
         int[] endRGB = hexToRGB(endHex);

         for(int i = 0; i < text.length(); ++i) {
            float ratio = (float)i / (float)(text.length() - 1);
            int r = (int)((float)startRGB[0] + ratio * (float)(endRGB[0] - startRGB[0]));
            int g = (int)((float)startRGB[1] + ratio * (float)(endRGB[1] - startRGB[1]));
            int b = (int)((float)startRGB[2] + ratio * (float)(endRGB[2] - startRGB[2]));
            String hex = String.format("%02x%02x%02x", r, g, b);
            result.append(ChatColor.of("#" + hex)).append(text.charAt(i));
         }

         return result.toString();
      }
   }

   private static int[] hexToRGB(String hex) {
      int r = Integer.parseInt(hex.substring(0, 2), 16);
      int g = Integer.parseInt(hex.substring(2, 4), 16);
      int b = Integer.parseInt(hex.substring(4, 6), 16);
      return new int[]{r, g, b};
   }

   private static boolean hasColorCodes(String text) {
      if (text != null && !text.isEmpty()) {
         if (GRADIENT_PATTERN.matcher(text).find()) {
            return true;
         } else {
            return HEX_PATTERN.matcher(text).find() ? true : text.contains("&");
         }
      } else {
         return false;
      }
   }

   public static void success(CommandSender sender, String message) {
      if (!hasColorCodes(message)) {
         message = "&a" + message;
      }

      sender.sendMessage(translateColors(message));
   }

   public static void error(CommandSender sender, String message) {
      if (!hasColorCodes(message)) {
         message = "&c" + message;
      }

      sender.sendMessage(translateColors(message));
   }

   public static void info(CommandSender sender, String message) {
      if (!hasColorCodes(message)) {
         message = "&b" + message;
      }

      sender.sendMessage(translateColors(message));
   }

   public static void warn(CommandSender sender, String message) {
      if (!hasColorCodes(message)) {
         message = "&e" + message;
      }

      sender.sendMessage(translateColors(message));
   }

   public static Component createComponent(String message, NamedTextColor color) {
      return (Component)(hasColorCodes(message) ? LegacyComponentSerializer.legacySection().deserialize(translateColors(message)) : Component.text(message).color(color));
   }

   public static void sendComponent(CommandSender sender, Component component) {
      sender.sendMessage(component);
   }

   public static void send(CommandSender sender, List<String> messages) {
      Iterator var2 = messages.iterator();

      while(var2.hasNext()) {
         String message = (String)var2.next();
         sender.sendMessage(translateColors(message));
      }

   }

   public static String f(String text, Object... args) {
      String formatted = String.format(text, args);
      return translateColors(formatted);
   }

   public static String formatFileSize(long bytes) {
      if (bytes < 1024L) {
         return bytes + " B";
      } else {
         int exp = (int)(Math.log((double)bytes) / Math.log(1024.0D));
         String pre = "KMGTPE".charAt(exp - 1).makeConcatWithConstants<invokedynamic>("KMGTPE".charAt(exp - 1));
         return String.format("%.1f %sB", (double)bytes / Math.pow(1024.0D, (double)exp), pre);
      }
   }

   public static String c(String text) {
      return translateColors(text);
   }

   public static String sanitizeCrateName(String input) {
      if (input != null && !input.trim().isEmpty()) {
         String sanitized = input.trim().toLowerCase();
         if (!VALID_CRATE_NAME.matcher(sanitized).matches()) {
            return null;
         } else {
            return !sanitized.equals("default") && !sanitized.equals("admin") && !sanitized.equals("system") ? sanitized : null;
         }
      } else {
         return null;
      }
   }

   public static Integer validateKeyAmount(String input) {
      if (input != null && !input.trim().isEmpty()) {
         try {
            int amount = Integer.parseInt(input.trim());
            return amount >= 1 && amount <= 10000 ? amount : null;
         } catch (NumberFormatException var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static Integer validateInteger(String input) {
      if (input != null && !input.trim().isEmpty()) {
         try {
            return Integer.parseInt(input.trim());
         } catch (NumberFormatException var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static Integer validatePositiveInteger(String input) {
      Integer value = validateInteger(input);
      return value != null && value > 0 ? value : null;
   }

   public static Integer validateCoordinate(String input) {
      Integer coord = validateInteger(input);
      if (coord == null) {
         return null;
      } else {
         return coord >= -30000000 && coord <= 30000000 ? coord : null;
      }
   }

   public static Integer validateYCoordinate(String input) {
      Integer y = validateInteger(input);
      if (y == null) {
         return null;
      } else {
         return y >= -64 && y <= 320 ? y : null;
      }
   }

   public static Double validateDouble(String input) {
      if (input != null && !input.trim().isEmpty()) {
         try {
            return Double.parseDouble(input.trim());
         } catch (NumberFormatException var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static Double validatePositiveDouble(String input) {
      Double value = validateDouble(input);
      return value != null && value > 0.0D ? value : null;
   }

   public static Boolean validateBoolean(String input) {
      if (input != null && !input.trim().isEmpty()) {
         String trimmed = input.trim().toLowerCase();
         if (!trimmed.equals("true") && !trimmed.equals("yes") && !trimmed.equals("1") && !trimmed.equals("on")) {
            return !trimmed.equals("false") && !trimmed.equals("no") && !trimmed.equals("0") && !trimmed.equals("off") ? null : false;
         } else {
            return true;
         }
      } else {
         return null;
      }
   }

   public static String validateString(String input, int minLength, int maxLength) {
      if (input == null) {
         return null;
      } else {
         String trimmed = input.trim();
         return trimmed.length() >= minLength && trimmed.length() <= maxLength ? trimmed : null;
      }
   }

   public static String sanitizeInput(String input) {
      return input == null ? null : input.trim().replaceAll("[\\r\\n\\t]", " ").replaceAll("\\s+", " ").trim();
   }

   public static boolean isValidSlot(int slot) {
      return slot >= 0 && slot <= 53;
   }

   public static boolean isValidInventorySize(int size) {
      return size > 0 && size <= 54 && size % 9 == 0;
   }

   public static boolean isInteger(String input) {
      return validateInteger(input) != null;
   }

   public static boolean isPositiveInteger(String input) {
      return validatePositiveInteger(input) != null;
   }

   public static boolean isValidCrateName(String input) {
      return sanitizeCrateName(input) != null;
   }
}
