package me.omh.solarcrate.commands;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.backup.BackupManager;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.utils.SolarUtils;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Statistic;
import org.bukkit.block.Block;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class SolarCrateCommand implements CommandExecutor, TabCompleter {
   private final SolarCrate plugin;

   public SolarCrateCommand(SolarCrate plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         this.sendHelp(sender);
         return true;
      } else {
         String var5 = args[0].toLowerCase();
         byte var6 = -1;
         switch(var5.hashCode()) {
         case -1613589672:
            if (var5.equals("language")) {
               var6 = 14;
            }
            break;
         case -1396673086:
            if (var5.equals("backup")) {
               var6 = 19;
            }
            break;
         case -1352294148:
            if (var5.equals("create")) {
               var6 = 5;
            }
            break;
         case -1335458389:
            if (var5.equals("delete")) {
               var6 = 6;
            }
            break;
         case -1319569547:
            if (var5.equals("execute")) {
               var6 = 4;
            }
            break;
         case -1270221375:
            if (var5.equals("clearkeys")) {
               var6 = 18;
            }
            break;
         case -1134671134:
            if (var5.equals("keyall")) {
               var6 = 10;
            }
            break;
         case -934641255:
            if (var5.equals("reload")) {
               var6 = 1;
            }
            break;
         case -905776226:
            if (var5.equals("setloc")) {
               var6 = 22;
            }
            break;
         case -469247465:
            if (var5.equals("setlocation")) {
               var6 = 21;
            }
            break;
         case -103826623:
            if (var5.equals("movehere")) {
               var6 = 13;
            }
            break;
         case 3108362:
            if (var5.equals("edit")) {
               var6 = 7;
            }
            break;
         case 3173137:
            if (var5.equals("give")) {
               var6 = 8;
            }
            break;
         case 3198785:
            if (var5.equals("help")) {
               var6 = 0;
            }
            break;
         case 3237038:
            if (var5.equals("info")) {
               var6 = 3;
            }
            break;
         case 3314158:
            if (var5.equals("lang")) {
               var6 = 15;
            }
            break;
         case 3322014:
            if (var5.equals("list")) {
               var6 = 16;
            }
            break;
         case 3357649:
            if (var5.equals("move")) {
               var6 = 12;
            }
            break;
         case 3417674:
            if (var5.equals("open")) {
               var6 = 23;
            }
            break;
         case 3552391:
            if (var5.equals("take")) {
               var6 = 9;
            }
            break;
         case 3560141:
            if (var5.equals("time")) {
               var6 = 2;
            }
            break;
         case 109757599:
            if (var5.equals("stats")) {
               var6 = 17;
            }
            break;
         case 351608024:
            if (var5.equals("version")) {
               var6 = 11;
            }
            break;
         case 1097519758:
            if (var5.equals("restore")) {
               var6 = 20;
            }
         }

         switch(var6) {
         case 0:
            this.sendHelp(sender);
            break;
         case 1:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager() != null ? this.plugin.getConfigManager().getMessage("no-permission") : "&cNo permission");
               return true;
            }

            try {
               if (this.plugin.getConfigManager() != null) {
                  this.plugin.getConfigManager().reloadConfigs();
               }

               if (this.plugin.getCrateManager() != null) {
                  this.plugin.getCrateManager().loadCrates();
               }

               if (this.plugin.getKeyManager() != null) {
                  this.plugin.getKeyManager().loadKeys();
               }

               if (this.plugin.getTimerManager() != null) {
                  this.plugin.getTimerManager().restartTimer();
               }

               if (sender instanceof Player && this.plugin.getSoundManager() != null) {
                  this.plugin.getSoundManager().playReloadSound((Player)sender);
               }

               SolarUtils.success(sender, this.plugin.getConfigManager() != null ? this.plugin.getConfigManager().getMessage("reload-success") : "&aReload completed");
            } catch (Exception var10) {
               SolarUtils.error(sender, "&cReload failed: " + var10.getMessage());
               this.plugin.getLogger().severe("Reload command failed: " + var10.getMessage());
               var10.printStackTrace();
            }
            break;
         case 2:
            if (!sender.hasPermission("sc.user")) {
               SolarUtils.error(sender, this.plugin.getConfigManager() != null ? this.plugin.getConfigManager().getMessage("no-permission") : "&cNo permission");
               return true;
            }

            if (this.plugin.getTimerManager() == null || this.plugin.getConfigManager() == null) {
               SolarUtils.error(sender, "&cTimer system not initialized");
               return true;
            }

            String timeLeft = this.plugin.getTimerManager().getFormattedTimeUntilNext();
            String message = this.plugin.getConfigManager().getMessage("time-remaining").replace("{time}", timeLeft);
            SolarUtils.info(sender, message);
            break;
         case 3:
            if (args.length > 1) {
               if (!sender.hasPermission("sc.admin")) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
                  return true;
               }

               Player target = Bukkit.getPlayer(args[1]);
               if (target == null) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("player-not-found"));
                  return true;
               }

               this.showPlayerInfo(sender, target);
            } else {
               if (!(sender instanceof Player)) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-no-info"));
                  return true;
               }

               if (!sender.hasPermission("sc.user")) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
                  return true;
               }

               this.showPlayerInfo(sender, (Player)sender);
            }
            break;
         case 4:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager() != null ? this.plugin.getConfigManager().getMessage("no-permission") : "&cNo permission");
               return true;
            }

            if (this.plugin.getTimerManager() == null) {
               SolarUtils.error(sender, "&cTimer manager not initialized");
               return true;
            }

            this.plugin.getTimerManager().forceExecute();
            SolarUtils.success(sender, this.plugin.getConfigManager() != null ? this.plugin.getConfigManager().getMessage("timer-executed") : "&aTimer executed");
            break;
         case 5:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (!(sender instanceof Player)) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-cannot-create"));
               return true;
            }

            if (args.length < 2) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-create-usage"));
               return true;
            }

            this.handleCreateCrate(sender, args);
            break;
         case 6:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (args.length < 2) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("delete-usage"));
               return true;
            }

            this.handleDeleteCrate(sender, args[1]);
            break;
         case 7:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (!(sender instanceof Player)) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-cannot-edit"));
               return true;
            }

            if (args.length < 2) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("edit-usage"));
               return true;
            }

            this.handleEditCrate(sender, args[1]);
            break;
         case 8:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleGiveKeys(sender, args);
            break;
         case 9:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleTakeKeys(sender, args);
            break;
         case 10:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleKeyAll(sender, args);
            break;
         case 11:
            String author = this.plugin.getDescription().getAuthors().isEmpty() ? "Unknown" : (String)this.plugin.getDescription().getAuthors().get(0);
            SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("version-info").replace("{version}", this.plugin.getDescription().getVersion()).replace("{author}", author));
            break;
         case 12:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (!(sender instanceof Player)) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-cannot-move"));
               return true;
            }

            if (args.length < 5) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("move-usage"));
               return true;
            }

            this.handleMoveCrate(sender, args);
            break;
         case 13:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (!(sender instanceof Player)) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-cannot-move"));
               return true;
            }

            if (args.length < 2) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("movehere-usage"));
               return true;
            }

            this.handleMoveCrateHere(sender, args[1]);
            break;
         case 14:
         case 15:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleLanguageCommand(sender, args);
            break;
         case 16:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleListCrates(sender);
            break;
         case 17:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleStats(sender);
            break;
         case 18:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleClearKeys(sender, args);
            break;
         case 19:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleBackup(sender);
            break;
         case 20:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            this.handleRestore(sender, args);
            break;
         case 21:
         case 22:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (!(sender instanceof Player)) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-cannot-setlocation"));
               return true;
            }

            if (args.length < 2) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("setlocation-usage"));
               return true;
            }

            this.handleSetLocation(sender, args[1]);
            break;
         case 23:
            if (!sender.hasPermission("sc.admin")) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-permission"));
               return true;
            }

            if (args.length < 2) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("open-usage"));
               return true;
            }

            this.handleOpenCrate(sender, args);
            break;
         default:
            this.sendHelp(sender);
         }

         return true;
      }
   }

   private void sendHelp(CommandSender sender) {
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("help-header"));
      List<String> userHelp = this.plugin.getConfigManager().getMessageList("help-user");
      Iterator var3 = userHelp.iterator();

      while(var3.hasNext()) {
         String line = (String)var3.next();
         SolarUtils.info(sender, line);
      }

      if (sender.hasPermission("sc.admin")) {
         List<String> adminHelp = this.plugin.getConfigManager().getMessageList("help-admin");
         Iterator var7 = adminHelp.iterator();

         while(var7.hasNext()) {
            String line = (String)var7.next();
            SolarUtils.info(sender, line);
         }
      }

   }

   private void showPlayerInfo(CommandSender sender, Player target) {
      List<String> info = this.plugin.getConfigManager().getMessageList("player-info");
      Iterator var4 = info.iterator();

      while(var4.hasNext()) {
         String line = (String)var4.next();
         String formatted = line.replace("{player}", target.getName()).replace("{keys_received}", String.valueOf(this.getTotalKeysForPlayer(target.getUniqueId()))).replace("{last_key_time}", "N/A").replace("{total_playtime}", this.formatPlaytime(target.getStatistic(Statistic.PLAY_ONE_MINUTE)));
         SolarUtils.info(sender, formatted);
      }

   }

   private String formatPlaytime(int ticks) {
      long seconds = (long)(ticks / 20);
      long hours = seconds / 3600L;
      long minutes = seconds % 3600L / 60L;
      return String.format("%dh %dm", hours, minutes);
   }

   private void handleCreateCrate(CommandSender sender, String[] args) {
      Player player = (Player)sender;
      String rawCrateName = args[1];
      String crateName = SolarUtils.sanitizeCrateName(rawCrateName);
      if (crateName == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-crate-name").replace("{name}", rawCrateName));
      } else if (this.plugin.getCrateManager().getCrate(crateName) != null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-already-exists").replace("{name}", crateName));
      } else {
         Block targetBlock = player.getTargetBlockExact(15);
         if (targetBlock == null) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("must-look-at-block"));
         } else {
            Location fluidLocation;
            if (targetBlock.isLiquid() || targetBlock.getType().name().contains("WATER") || targetBlock.getType().name().contains("LAVA")) {
               fluidLocation = targetBlock.getLocation();
               Block solidBlock = null;

               for(int y = 0; y < 5; ++y) {
                  Block belowBlock = fluidLocation.clone().subtract(0.0D, (double)y, 0.0D).getBlock();
                  if (belowBlock.getType().isSolid() && belowBlock.getType() != Material.BEDROCK) {
                     solidBlock = belowBlock;
                     break;
                  }
               }

               if (solidBlock == null) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-solid-ground"));
                  return;
               }

               targetBlock = solidBlock;
            }

            if (targetBlock.getType().isSolid() && targetBlock.getType() != Material.BEDROCK) {
               fluidLocation = targetBlock.getLocation();
               Crate crate = new Crate(crateName, fluidLocation);
               this.plugin.getCrateManager().addCrate(crate);
               this.plugin.getCrateManager().saveCrates();
               SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("crate-created").replace("{name}", crateName).replace("{x}", String.valueOf(fluidLocation.getBlockX())).replace("{y}", String.valueOf(fluidLocation.getBlockY())).replace("{z}", String.valueOf(fluidLocation.getBlockZ())));
            } else {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-block-type").replace("{block}", targetBlock.getType().name()));
            }
         }
      }
   }

   private void handleDeleteCrate(CommandSender sender, String crateName) {
      if (this.plugin.getCrateManager().getCrate(crateName) == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-not-exists").replace("{name}", crateName));
      } else {
         this.plugin.getCrateManager().removeCrate(crateName);
         this.plugin.getCrateManager().saveCrates();
         SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("crate-deleted").replace("{name}", crateName));
      }
   }

   private void handleEditCrate(CommandSender sender, String crateName) {
      Player player = (Player)sender;
      Crate crate = this.plugin.getCrateManager().getCrate(crateName);
      if (crate == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-not-exists").replace("{name}", crateName));
      } else {
         this.plugin.getGuiManager().openCrateEditGui(player, crateName);
      }
   }

   private void handleGiveKeys(CommandSender sender, String[] args) {
      if (args.length < 3) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("give-key-usage"));
      } else {
         String rawCrateName = args[1];
         String crateName = SolarUtils.sanitizeCrateName(rawCrateName);
         if (crateName == null) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-crate-name").replace("{name}", rawCrateName));
         } else {
            Integer amount = SolarUtils.validateKeyAmount(args[2]);
            if (amount == null) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-key-amount"));
            } else {
               Player target;
               boolean success;
               if (args.length >= 4) {
                  target = Bukkit.getPlayer(args[3]);
                  if (target == null) {
                     SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("player-not-found"));
                     return;
                  }

                  success = this.plugin.getKeyManager().addKeys(target.getUniqueId(), crateName, amount);
                  if (success) {
                     SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("gave-keys").replace("{amount}", String.valueOf(amount)).replace("{crate}", crateName).replace("{player}", target.getName()));
                  } else {
                     SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("keys-add-failed"));
                  }
               } else {
                  if (!(sender instanceof Player)) {
                     SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-specify-player"));
                     return;
                  }

                  target = (Player)sender;
                  success = this.plugin.getKeyManager().addKeys(target.getUniqueId(), crateName, amount);
                  if (success) {
                     SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("gave-keys").replace("{amount}", String.valueOf(amount)).replace("{crate}", crateName).replace("{player}", target.getName()));
                  } else {
                     SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("keys-add-failed-self"));
                  }
               }

            }
         }
      }
   }

   private void handleTakeKeys(CommandSender sender, String[] args) {
      if (args.length < 4) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("take-key-usage"));
      } else {
         String rawCrateName = args[1];
         String crateName = SolarUtils.sanitizeCrateName(rawCrateName);
         if (crateName == null) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-crate-name").replace("{name}", rawCrateName));
         } else {
            Player target = Bukkit.getPlayer(args[2]);
            if (target == null) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("player-not-found"));
            } else {
               int amount;
               try {
                  amount = Integer.parseInt(args[3]);
               } catch (NumberFormatException var8) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("amount-must-be-number"));
                  return;
               }

               int currentKeys = this.plugin.getKeyManager().getKeys(target.getUniqueId(), crateName);
               if (currentKeys < amount) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("not-enough-keys"));
               } else {
                  this.plugin.getKeyManager().removeKeys(target.getUniqueId(), crateName, amount);
                  SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("took-keys").replace("{amount}", String.valueOf(amount)).replace("{crate}", crateName).replace("{player}", target.getName()));
               }
            }
         }
      }
   }

   private void handleKeyAll(CommandSender sender, String[] args) {
      if (args.length < 3) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("keyall-usage"));
      } else {
         String rawCrateName = args[1];
         String crateName = SolarUtils.sanitizeCrateName(rawCrateName);
         if (crateName != null && !crateName.isEmpty()) {
            int amount;
            try {
               amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException var15) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("amount-must-be-number"));
               return;
            }

            if (amount <= 0) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("amount-must-be-number"));
            } else {
               int count = 0;
               int failed = 0;
               String niceName = crateName.length() > 0 ? crateName.substring(0, 1).toUpperCase() + (crateName.length() > 1 ? crateName.substring(1).toLowerCase() : "") + " Key" : "Key";
               Iterator var9 = Bukkit.getOnlinePlayers().iterator();

               while(var9.hasNext()) {
                  Player player = (Player)var9.next();
                  boolean success = this.plugin.getKeyManager().addKeys(player.getUniqueId(), crateName, amount);
                  if (success) {
                     player.sendMessage(SolarUtils.translateColors(this.plugin.getConfigManager().getMessage("keyall-success-header")));
                     player.sendMessage(SolarUtils.translateColors(this.plugin.getConfigManager().getMessage("keyall-success-message").replace("{amount}", String.valueOf(amount)).replace("{keyname}", niceName + (amount > 1 ? "s" : ""))));
                     String title = SolarUtils.translateColors(this.plugin.getConfigManager().getMessage("keyall-success-title"));
                     String subtitle = SolarUtils.translateColors(this.plugin.getConfigManager().getMessage("keyall-success-subtitle").replace("{amount}", String.valueOf(amount)).replace("{keyname}", niceName));
                     player.sendTitle(title, subtitle, 10, 60, 20);
                     String actionBar = SolarUtils.translateColors(this.plugin.getConfigManager().getMessage("keyall-success-actionbar").replace("{amount}", String.valueOf(amount)).replace("{keyname}", niceName));
                     player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(actionBar));
                     player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
                     player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
                     ++count;
                  } else {
                     player.sendMessage(SolarUtils.translateColors(this.plugin.getConfigManager().getMessage("keyall-player-limit")));
                     ++failed;
                  }
               }

               String resultMessage = this.plugin.getConfigManager().getMessage("gave-keys-to-all").replace("{amount}", String.valueOf(amount)).replace("{crate}", crateName).replace("{count}", String.valueOf(count));
               if (failed > 0) {
                  resultMessage = resultMessage + this.plugin.getConfigManager().getMessage("keyall-some-failed").replace("{failed}", String.valueOf(failed));
               }

               SolarUtils.success(sender, resultMessage);
            }
         } else {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-crate-name").replace("{name}", rawCrateName));
         }
      }
   }

   private void handleMoveCrate(CommandSender sender, String[] args) {
      Player player = (Player)sender;
      String crateName = args[1];
      Crate crate = this.plugin.getCrateManager().getCrate(crateName);
      if (crate == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-not-exists").replace("{name}", crateName));
      } else {
         Integer x = SolarUtils.validateCoordinate(args[2]);
         Integer y = SolarUtils.validateYCoordinate(args[3]);
         Integer z = SolarUtils.validateCoordinate(args[4]);
         if (x != null && y != null && z != null) {
            if (player.getWorld() == null) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("world-invalid"));
            } else {
               Location newLocation = new Location(player.getWorld(), (double)x, (double)y, (double)z);
               if (!newLocation.getWorld().isChunkLoaded(newLocation.getBlockX() >> 4, newLocation.getBlockZ() >> 4)) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("chunk-not-loaded"));
               } else {
                  Location oldLocation = crate.getLocation().clone();

                  try {
                     this.plugin.getCrateManager().updateCrateLocation(crateName, newLocation);
                     SolarUtils.success(sender, "Crate '" + crateName + "' moved from " + oldLocation.getBlockX() + "," + oldLocation.getBlockY() + "," + oldLocation.getBlockZ() + " to " + newLocation.getBlockX() + "," + newLocation.getBlockY() + "," + newLocation.getBlockZ());
                  } catch (IOException | IllegalArgumentException var14) {
                     try {
                        this.plugin.getCrateManager().updateCrateLocation(crateName, oldLocation);
                     } catch (Exception var13) {
                        this.plugin.getLogger().severe("Failed to rollback crate location: " + var13.getMessage());
                     }

                     SolarUtils.error(sender, "Failed to move crate: " + var14.getMessage());
                     this.plugin.getLogger().warning("Failed to move crate '" + crateName + "': " + var14.getMessage());
                  }

               }
            }
         } else {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-coordinates"));
         }
      }
   }

   private void handleMoveCrateHere(CommandSender sender, String crateName) {
      Player player = (Player)sender;
      Crate crate = this.plugin.getCrateManager().getCrate(crateName);
      if (crate == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-not-exists").replace("{name}", crateName));
      } else {
         Block targetBlock = null;
         Block initialTarget = player.getTargetBlockExact(15);
         if (initialTarget == null) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("must-look-at-block"));
         } else {
            Location newLocation;
            if (!initialTarget.isLiquid() && !initialTarget.getType().name().contains("WATER") && !initialTarget.getType().name().contains("LAVA")) {
               targetBlock = initialTarget;
            } else {
               newLocation = initialTarget.getLocation();

               for(int y = 0; y < 5; ++y) {
                  Block belowBlock = newLocation.clone().subtract(0.0D, (double)y, 0.0D).getBlock();
                  if (belowBlock.getType().isSolid() && belowBlock.getType() != Material.BEDROCK) {
                     targetBlock = belowBlock;
                     break;
                  }
               }

               if (targetBlock == null) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-solid-ground"));
                  return;
               }
            }

            if (targetBlock.getType().isSolid() && targetBlock.getType() != Material.BEDROCK) {
               try {
                  if (targetBlock.getBlockData() instanceof Waterlogged && ((Waterlogged)targetBlock.getBlockData()).isWaterlogged()) {
                     SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-waterlogged-blocks"));
                     return;
                  }
               } catch (Exception var14) {
               }

               newLocation = targetBlock.getLocation().add(0.0D, 1.0D, 0.0D);
               Block placementBlock = newLocation.getBlock();
               if (!placementBlock.isPassable() && !placementBlock.getType().isAir()) {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("space-occupied").replace("{block}", placementBlock.getType().name()));
               } else if (!(newLocation.getY() < -64.0D) && !(newLocation.getY() > 320.0D)) {
                  if (!newLocation.getWorld().isChunkLoaded(newLocation.getBlockX() >> 4, newLocation.getBlockZ() >> 4)) {
                     SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("chunk-not-loaded"));
                  } else {
                     Location oldLocation = crate.getLocation().clone();

                     try {
                        this.plugin.getCrateManager().updateCrateLocation(crateName, newLocation);
                        SolarUtils.success(sender, "Crate '" + crateName + "' moved from " + oldLocation.getBlockX() + "," + oldLocation.getBlockY() + "," + oldLocation.getBlockZ() + " to " + newLocation.getBlockX() + "," + newLocation.getBlockY() + "," + newLocation.getBlockZ());
                     } catch (IOException | IllegalArgumentException var13) {
                        try {
                           this.plugin.getCrateManager().updateCrateLocation(crateName, oldLocation);
                        } catch (Exception var12) {
                           this.plugin.getLogger().severe("Failed to rollback crate location: " + var12.getMessage());
                        }

                        SolarUtils.error(sender, "Failed to move crate: " + var13.getMessage());
                        this.plugin.getLogger().warning("Failed to move crate '" + crateName + "': " + var13.getMessage());
                     }

                  }
               } else {
                  SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("y-out-of-bounds").replace("{y}", String.valueOf((int)newLocation.getY())));
               }
            } else {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("invalid-block-type").replace("{block}", targetBlock.getType().name()));
            }
         }
      }
   }

   private void handleLanguageCommand(CommandSender sender, String[] args) {
      String newLanguage;
      List availableLanguages;
      if (args.length == 1) {
         newLanguage = this.plugin.getConfigManager().getCurrentLanguage();
         availableLanguages = this.plugin.getConfigManager().getAvailableLanguages();
         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("language-current").replace("{language}", newLanguage));
         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("language-available").replace("{languages}", String.join(", ", availableLanguages)));
         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("language-usage"));
      } else {
         newLanguage = args[1].toLowerCase();
         availableLanguages = this.plugin.getConfigManager().getAvailableLanguages();
         if (!availableLanguages.contains(newLanguage)) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("language-not-found").replace("{language}", newLanguage).replace("{languages}", String.join(", ", availableLanguages)));
         } else {
            String oldLanguage = this.plugin.getConfigManager().getCurrentLanguage();
            this.plugin.getConfigManager().setLanguage(newLanguage);
            SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("language-changed").replace("{old}", oldLanguage).replace("{new}", newLanguage));
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1) {
         String[] commands = new String[]{"help", "time", "info", "version", "list"};
         String[] adminCommands;
         if (sender.hasPermission("sc.admin")) {
            adminCommands = new String[]{"reload", "execute", "create", "delete", "edit", "give", "take", "keyall", "move", "movehere", "language", "lang", "stats", "clearkeys", "backup", "restore", "setlocation", "setloc", "open"};
            List<String> allCommands = new ArrayList(Arrays.asList(commands));
            allCommands.addAll(Arrays.asList(adminCommands));
            commands = (String[])allCommands.toArray(new String[0]);
         }

         adminCommands = commands;
         int var14 = commands.length;

         for(int var9 = 0; var9 < var14; ++var9) {
            String cmd = adminCommands[var9];
            if (cmd.toLowerCase().startsWith(args[0].toLowerCase())) {
               completions.add(cmd);
            }
         }
      } else if (args.length == 2) {
         if (!args[0].equalsIgnoreCase("edit") && !args[0].equalsIgnoreCase("delete") && !args[0].equalsIgnoreCase("give") && !args[0].equalsIgnoreCase("take") && !args[0].equalsIgnoreCase("keyall") && !args[0].equalsIgnoreCase("move") && !args[0].equalsIgnoreCase("movehere") && !args[0].equalsIgnoreCase("setlocation") && !args[0].equalsIgnoreCase("setloc") && !args[0].equalsIgnoreCase("open")) {
            if (args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("clearkeys")) {
               return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
                  return name.toLowerCase().startsWith(args[1].toLowerCase());
               }).collect(Collectors.toList());
            }

            if (args[0].equalsIgnoreCase("language") || args[0].equalsIgnoreCase("lang")) {
               return (List)this.plugin.getConfigManager().getAvailableLanguages().stream().filter((lang) -> {
                  return lang.toLowerCase().startsWith(args[1].toLowerCase());
               }).collect(Collectors.toList());
            }

            if (args[0].equalsIgnoreCase("restore")) {
               try {
                  if (this.plugin.getBackupManager() != null) {
                     return (List)this.plugin.getBackupManager().getAvailableBackups().stream().map((backup) -> {
                        return backup.getName();
                     }).filter((name) -> {
                        return name.toLowerCase().startsWith(args[1].toLowerCase());
                     }).collect(Collectors.toList());
                  }
               } catch (Exception var11) {
                  return new ArrayList();
               }
            }
         } else {
            Iterator var6 = this.plugin.getCrateManager().getCrates().keySet().iterator();

            while(var6.hasNext()) {
               String crateName = (String)var6.next();
               if (crateName.toLowerCase().startsWith(args[1].toLowerCase())) {
                  completions.add(crateName);
               }
            }
         }
      } else if (args.length == 3) {
         if (args[0].equalsIgnoreCase("open")) {
            return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
               return name.toLowerCase().startsWith(args[2].toLowerCase());
            }).collect(Collectors.toList());
         }
      } else if (args.length == 4 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("take"))) {
         return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
            return name.toLowerCase().startsWith(args[3].toLowerCase());
         }).collect(Collectors.toList());
      }

      return completions;
   }

   private int getTotalKeysForPlayer(UUID uuid) {
      int total = 0;

      String crateName;
      for(Iterator var3 = this.plugin.getCrateManager().getCrates().keySet().iterator(); var3.hasNext(); total += this.plugin.getKeyManager().getKeys(uuid, crateName)) {
         crateName = (String)var3.next();
      }

      return total;
   }

   private void handleListCrates(CommandSender sender) {
      if (this.plugin.getCrateManager().getCrates().isEmpty()) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-crates-found"));
      } else {
         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("list-header"));
         Iterator var2 = this.plugin.getCrateManager().getCrates().values().iterator();

         while(var2.hasNext()) {
            Crate crate = (Crate)var2.next();
            Location loc = crate.getLocation();
            int itemCount = crate.getItems() != null ? crate.getItems().size() : 0;
            String crateLine = this.plugin.getConfigManager().getMessage("list-crate-line").replace("{name}", crate.getName()).replace("{items}", String.valueOf(itemCount)).replace("{x}", String.valueOf(loc.getBlockX())).replace("{y}", String.valueOf(loc.getBlockY())).replace("{z}", String.valueOf(loc.getBlockZ())).replace("{world}", loc.getWorld() != null ? loc.getWorld().getName() : "unknown");
            SolarUtils.info(sender, crateLine);
         }

         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("list-footer").replace("{total}", String.valueOf(this.plugin.getCrateManager().getCrates().size())));
      }
   }

   private void handleStats(CommandSender sender) {
      int totalCrates = this.plugin.getCrateManager().getCrates().size();
      int totalOnlinePlayers = Bukkit.getOnlinePlayers().size();
      int totalKeysInCirculation = 0;

      Player player;
      for(Iterator var5 = Bukkit.getOnlinePlayers().iterator(); var5.hasNext(); totalKeysInCirculation += this.getTotalKeysForPlayer(player.getUniqueId())) {
         player = (Player)var5.next();
      }

      int totalItems = 0;
      Iterator var9 = this.plugin.getCrateManager().getCrates().values().iterator();

      while(var9.hasNext()) {
         Crate crate = (Crate)var9.next();
         if (crate.getItems() != null) {
            totalItems += crate.getItems().size();
         }
      }

      String uptime = this.plugin.getTimerManager() != null ? this.plugin.getTimerManager().getFormattedTimeUntilNext() : "N/A";
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-header"));
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-crates").replace("{count}", String.valueOf(totalCrates)));
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-items").replace("{count}", String.valueOf(totalItems)));
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-online-players").replace("{count}", String.valueOf(totalOnlinePlayers)));
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-keys-online").replace("{count}", String.valueOf(totalKeysInCirculation)));
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-next-timer").replace("{time}", uptime));
      SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("stats-footer"));
   }

   private void handleClearKeys(CommandSender sender, String[] args) {
      if (args.length < 2) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("clearkeys-usage"));
      } else {
         Player target = Bukkit.getPlayer(args[1]);
         if (target == null) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("player-not-found"));
         } else {
            int totalRemoved = 0;
            Iterator var5 = this.plugin.getCrateManager().getCrates().keySet().iterator();

            while(var5.hasNext()) {
               String crateName = (String)var5.next();
               int keys = this.plugin.getKeyManager().getKeys(target.getUniqueId(), crateName);
               if (keys > 0) {
                  this.plugin.getKeyManager().removeKeys(target.getUniqueId(), crateName, keys);
                  totalRemoved += keys;
               }
            }

            SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("clearkeys-success").replace("{player}", target.getName()).replace("{count}", String.valueOf(totalRemoved)));
         }
      }
   }

   private void handleBackup(CommandSender sender) {
      try {
         if (this.plugin.getBackupManager() == null) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("backup-not-available"));
            return;
         }

         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("backup-creating"));
         BackupManager.BackupResult result = (BackupManager.BackupResult)this.plugin.getBackupManager().createBackup("Manual backup from command", BackupManager.BackupType.MANUAL).join();
         if (result.isSuccess()) {
            SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("backup-success").replace("{file}", result.getBackupInfo().getName()));
         } else {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("backup-failed").replace("{error}", result.getMessage() != null ? result.getMessage() : "Unknown error"));
         }
      } catch (Exception var3) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("backup-failed").replace("{error}", var3.getMessage()));
         this.plugin.getLogger().severe("Backup failed: " + var3.getMessage());
         var3.printStackTrace();
      }

   }

   private void handleRestore(CommandSender sender, String[] args) {
      if (this.plugin.getBackupManager() == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("backup-not-available"));
      } else if (args.length < 2) {
         try {
            List<BackupManager.BackupInfo> backups = this.plugin.getBackupManager().getAvailableBackups();
            if (backups.isEmpty()) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-backups-found"));
               return;
            }

            SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("restore-usage"));
            SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("restore-available-backups"));

            for(int i = 0; i < Math.min(backups.size(), 10); ++i) {
               BackupManager.BackupInfo backup = (BackupManager.BackupInfo)backups.get(i);
               SolarUtils.info(sender, "  &7" + (i + 1) + ". &e" + backup.getName());
            }
         } catch (Exception var7) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("no-backups-found"));
         }

      } else {
         String backupName = args[1];
         SolarUtils.info(sender, this.plugin.getConfigManager().getMessage("restore-restoring").replace("{file}", backupName));

         try {
            BackupManager.BackupResult result = (BackupManager.BackupResult)this.plugin.getBackupManager().restoreBackup(backupName, true).join();
            if (result.isSuccess()) {
               this.plugin.getCrateManager().loadCrates();
               this.plugin.getKeyManager().loadKeys();
               SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("restore-success").replace("{file}", backupName));
            } else {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("restore-failed").replace("{error}", result.getMessage() != null ? result.getMessage() : "Unknown error"));
            }
         } catch (Exception var6) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("restore-failed").replace("{error}", var6.getMessage()));
            this.plugin.getLogger().severe("Restore failed: " + var6.getMessage());
            var6.printStackTrace();
         }

      }
   }

   private void handleSetLocation(CommandSender sender, String crateName) {
      Player player = (Player)sender;
      Crate crate = this.plugin.getCrateManager().getCrate(crateName);
      if (crate == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-not-exists").replace("{name}", crateName));
      } else {
         Location newLocation = player.getLocation();
         Location oldLocation = crate.getLocation().clone();

         try {
            this.plugin.getCrateManager().updateCrateLocation(crateName, newLocation);
            SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("setlocation-success").replace("{name}", crateName).replace("{x}", String.valueOf(newLocation.getBlockX())).replace("{y}", String.valueOf(newLocation.getBlockY())).replace("{z}", String.valueOf(newLocation.getBlockZ())));
         } catch (IOException | IllegalArgumentException var10) {
            try {
               this.plugin.getCrateManager().updateCrateLocation(crateName, oldLocation);
            } catch (Exception var9) {
               this.plugin.getLogger().severe("Failed to rollback crate location: " + var9.getMessage());
            }

            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("setlocation-failed").replace("{error}", var10.getMessage()));
            this.plugin.getLogger().warning("Failed to set location for crate '" + crateName + "': " + var10.getMessage());
         }

      }
   }

   private void handleOpenCrate(CommandSender sender, String[] args) {
      String crateName = args[1];
      Crate crate = this.plugin.getCrateManager().getCrate(crateName);
      if (crate == null) {
         SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("crate-not-exists").replace("{name}", crateName));
      } else {
         Player target;
         if (args.length >= 3) {
            target = Bukkit.getPlayer(args[2]);
            if (target == null) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("player-not-found"));
               return;
            }
         } else {
            if (!(sender instanceof Player)) {
               SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("console-cannot-open"));
               return;
            }

            target = (Player)sender;
         }

         try {
            this.plugin.getGuiManager().openCrateSelectionGui(target, crateName);
            if (target != sender) {
               SolarUtils.success(sender, this.plugin.getConfigManager().getMessage("open-success").replace("{crate}", crateName).replace("{player}", target.getName()));
            }
         } catch (Exception var7) {
            SolarUtils.error(sender, this.plugin.getConfigManager().getMessage("open-failed").replace("{error}", var7.getMessage()));
            this.plugin.getLogger().warning("Failed to open crate '" + crateName + "' for " + target.getName() + ": " + var7.getMessage());
         }

      }
   }
}
