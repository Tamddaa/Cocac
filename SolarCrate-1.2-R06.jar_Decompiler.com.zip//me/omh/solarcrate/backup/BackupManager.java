package me.omh.solarcrate.backup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.utils.SolarUtils;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class BackupManager {
   private final SolarCrate plugin;
   private final File backupDirectory;
   private final Map<String, BackupManager.BackupInfo> backupHistory = new ConcurrentHashMap();
   private final Object backupOperationLock = new Object();
   private final boolean AUTO_BACKUP_ENABLED;
   private final int BACKUP_INTERVAL_HOURS;
   private final int MAX_BACKUPS_PER_TYPE;
   private final boolean COMPRESS_BACKUPS;
   private final Set<String> BACKUP_PATHS;
   private final DateTimeFormatter BACKUP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

   public BackupManager(SolarCrate plugin) {
      this.plugin = plugin;
      this.backupDirectory = new File(plugin.getDataFolder(), "backups");
      FileConfiguration config = plugin.getConfig();
      this.AUTO_BACKUP_ENABLED = config.getBoolean("backup.auto_enabled", true);
      this.BACKUP_INTERVAL_HOURS = config.getInt("backup.interval_hours", 6);
      this.MAX_BACKUPS_PER_TYPE = config.getInt("backup.max_backups", 10);
      this.COMPRESS_BACKUPS = config.getBoolean("backup.compress", true);
      this.BACKUP_PATHS = new HashSet(config.getStringList("backup.paths"));
      if (this.BACKUP_PATHS.isEmpty()) {
         this.BACKUP_PATHS.addAll(Arrays.asList("crates.yml", "keys.yml", "playerdata", "locations.yml"));
      }

      this.initialize();
   }

   private void initialize() {
      if (!this.backupDirectory.exists()) {
         this.backupDirectory.mkdirs();
      }

      this.loadBackupHistory();
      if (this.AUTO_BACKUP_ENABLED) {
         this.scheduleAutoBackups();
      }

      this.plugin.getLogger().info("BackupManager initialized with " + this.BACKUP_PATHS.size() + " monitored paths");
   }

   public CompletableFuture<BackupManager.BackupResult> createBackup(String description, BackupManager.BackupType type) {
      return CompletableFuture.supplyAsync(() -> {
         synchronized(this.backupOperationLock) {
            try {
               String timestamp = LocalDateTime.now().format(this.BACKUP_DATE_FORMAT);
               String var10000 = type.name().toLowerCase();
               String backupName = var10000 + "_" + timestamp;
               Logger var22 = this.plugin.getLogger();
               String var10001 = String.valueOf(type);
               var22.info("Creating " + var10001 + " backup: " + backupName);
               File backupFolder = new File(this.backupDirectory, backupName);
               backupFolder.mkdirs();
               long totalSize = 0L;
               int fileCount = 0;
               List<String> backedUpFiles = new ArrayList();
               Iterator var11 = this.BACKUP_PATHS.iterator();

               while(var11.hasNext()) {
                  String path = (String)var11.next();
                  File sourceFile = new File(this.plugin.getDataFolder(), path);
                  if (sourceFile.exists()) {
                     File destFile = new File(backupFolder, path);
                     if (sourceFile.isDirectory()) {
                        long size = this.copyDirectory(sourceFile, destFile);
                        totalSize += size;
                        fileCount += this.countFiles(destFile);
                     } else {
                        Files.copy(sourceFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                        totalSize += sourceFile.length();
                        ++fileCount;
                     }

                     backedUpFiles.add(path);
                  }
               }

               File finalBackup = backupFolder;
               if (this.COMPRESS_BACKUPS) {
                  finalBackup = new File(this.backupDirectory, backupName + ".zip");
                  this.compressDirectory(backupFolder, finalBackup);
                  this.deleteDirectory(backupFolder);
               }

               BackupManager.BackupInfo info = new BackupManager.BackupInfo(backupName, type, description, LocalDateTime.now(), finalBackup.length(), fileCount, backedUpFiles, finalBackup.getAbsolutePath());
               this.backupHistory.put(backupName, info);
               this.saveBackupHistory();
               this.cleanOldBackups(type);
               var22 = this.plugin.getLogger();
               var10001 = finalBackup.getName();
               var22.info("Backup completed: " + var10001 + " (" + SolarUtils.formatFileSize(info.getSize()) + ", " + info.getFileCount() + " files)");
               BackupManager.BackupResult var23 = new BackupManager.BackupResult(true, "Backup created successfully", info);
               return var23;
            } catch (Exception var18) {
               this.plugin.getLogger().severe("Failed to create backup: " + var18.getMessage());
               var18.printStackTrace();
               return new BackupManager.BackupResult(false, "Backup failed: " + var18.getMessage(), (BackupManager.BackupInfo)null);
            }
         }
      });
   }

   public CompletableFuture<BackupManager.BackupResult> restoreBackup(String backupName, boolean confirmOverwrite) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            BackupManager.BackupInfo info = (BackupManager.BackupInfo)this.backupHistory.get(backupName);
            if (info == null) {
               return new BackupManager.BackupResult(false, "Backup not found: " + backupName, (BackupManager.BackupInfo)null);
            } else if (!confirmOverwrite) {
               return new BackupManager.BackupResult(false, "Restore requires confirmation to overwrite current data", info);
            } else {
               this.plugin.getLogger().warning("Restoring from backup: " + backupName);
               File backupFile = new File(info.getFilePath());
               if (!backupFile.exists()) {
                  return new BackupManager.BackupResult(false, "Backup file not found: " + backupFile.getName(), info);
               } else {
                  this.createBackup("Pre-restore emergency backup", BackupManager.BackupType.EMERGENCY).join();
                  synchronized(this.backupOperationLock) {
                     File restoreSource;
                     if (backupFile.getName().endsWith(".zip")) {
                        restoreSource = new File(this.backupDirectory, "temp_restore_" + System.currentTimeMillis());
                        this.extractZip(backupFile, restoreSource);
                     } else {
                        restoreSource = backupFile;
                     }

                     int restoredCount = 0;
                     Iterator var8 = info.getBackedUpFiles().iterator();

                     while(true) {
                        while(true) {
                           File sourceFile;
                           File destFile;
                           do {
                              if (!var8.hasNext()) {
                                 if (restoreSource != backupFile) {
                                    this.deleteDirectory(restoreSource);
                                 }

                                 this.plugin.getLogger().info("Restore completed: " + restoredCount + " items restored from " + backupName);
                                 return new BackupManager.BackupResult(true, "Backup restored successfully (" + restoredCount + " items)", info);
                              }

                              String path = (String)var8.next();
                              sourceFile = new File(restoreSource, path);
                              destFile = new File(this.plugin.getDataFolder(), path);
                           } while(!sourceFile.exists());

                           if (destFile.exists()) {
                              if (destFile.isDirectory()) {
                                 this.deleteDirectory(destFile);
                              } else {
                                 destFile.delete();
                              }
                           }

                           File parentDir = destFile.getParentFile();
                           if (parentDir != null && !parentDir.exists() && !parentDir.mkdirs()) {
                              this.plugin.getLogger().warning("Failed to create parent directory for: " + destFile.getPath());
                           } else {
                              if (sourceFile.isDirectory()) {
                                 this.copyDirectory(sourceFile, destFile);
                              } else {
                                 Files.copy(sourceFile.toPath(), destFile.toPath());
                              }

                              ++restoredCount;
                           }
                        }
                     }
                  }
               }
            }
         } catch (Exception var15) {
            this.plugin.getLogger().severe("Failed to restore backup: " + var15.getMessage());
            var15.printStackTrace();
            return new BackupManager.BackupResult(false, "Restore failed: " + var15.getMessage(), (BackupManager.BackupInfo)null);
         }
      });
   }

   public List<BackupManager.BackupInfo> getAvailableBackups() {
      return new ArrayList(this.backupHistory.values());
   }

   public BackupManager.BackupInfo getBackupInfo(String backupName) {
      return (BackupManager.BackupInfo)this.backupHistory.get(backupName);
   }

   public boolean deleteBackup(String backupName) {
      BackupManager.BackupInfo info = (BackupManager.BackupInfo)this.backupHistory.get(backupName);
      if (info == null) {
         return false;
      } else {
         File backupFile = new File(info.getFilePath());
         if (backupFile.exists()) {
            if (backupFile.isDirectory()) {
               this.deleteDirectory(backupFile);
            } else {
               backupFile.delete();
            }
         }

         this.backupHistory.remove(backupName);
         this.saveBackupHistory();
         this.plugin.getLogger().info("Deleted backup: " + backupName);
         return true;
      }
   }

   private void scheduleAutoBackups() {
      long interval = (long)(this.BACKUP_INTERVAL_HOURS * 20 * 60 * 60);
      this.plugin.getFoliaLib().getImpl().runTimer(() -> {
         this.createBackup("Automatic backup", BackupManager.BackupType.AUTOMATIC);
      }, interval, interval);
      this.plugin.getLogger().info("Automatic backups scheduled every " + this.BACKUP_INTERVAL_HOURS + " hours");
   }

   private void cleanOldBackups(BackupManager.BackupType type) {
      List<BackupManager.BackupInfo> typeBackups = this.backupHistory.values().stream().filter((info) -> {
         return info.getType() == type;
      }).sorted((a, b) -> {
         return b.getCreatedAt().compareTo(a.getCreatedAt());
      }).toList();
      if (typeBackups.size() > this.MAX_BACKUPS_PER_TYPE) {
         for(int i = this.MAX_BACKUPS_PER_TYPE; i < typeBackups.size(); ++i) {
            this.deleteBackup(((BackupManager.BackupInfo)typeBackups.get(i)).getName());
         }
      }

   }

   private long copyDirectory(File source, File dest) throws IOException {
      if (!dest.exists()) {
         dest.mkdirs();
      }

      long totalSize = 0L;
      File[] files = source.listFiles();
      if (files == null) {
         this.plugin.getLogger().warning("Unable to list files in directory: " + source.getAbsolutePath());
         return 0L;
      } else {
         File[] var6 = files;
         int var7 = files.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            File file = var6[var8];
            File destFile = new File(dest, file.getName());
            if (file.isDirectory()) {
               totalSize += this.copyDirectory(file, destFile);
            } else {
               Files.copy(file.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
               totalSize += file.length();
            }
         }

         return totalSize;
      }
   }

   private int countFiles(File directory) {
      if (!directory.isDirectory()) {
         return 1;
      } else {
         File[] files = directory.listFiles();
         if (files == null) {
            this.plugin.getLogger().warning("Unable to list files in directory: " + directory.getAbsolutePath());
            return 0;
         } else {
            int count = 0;
            File[] var4 = files;
            int var5 = files.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               File file = var4[var6];
               if (file.isDirectory()) {
                  count += this.countFiles(file);
               } else {
                  ++count;
               }
            }

            return count;
         }
      }
   }

   private void deleteDirectory(File directory) {
      if (directory.isDirectory()) {
         File[] files = directory.listFiles();
         if (files != null) {
            File[] var3 = files;
            int var4 = files.length;

            for(int var5 = 0; var5 < var4; ++var5) {
               File file = var3[var5];
               this.deleteDirectory(file);
            }
         }
      }

      directory.delete();
   }

   private void compressDirectory(File source, File zipFile) throws IOException {
      ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zipFile.toPath()));

      try {
         this.compressDirectoryRecursive(source, source, zos);
      } catch (Throwable var7) {
         try {
            zos.close();
         } catch (Throwable var6) {
            var7.addSuppressed(var6);
         }

         throw var7;
      }

      zos.close();
   }

   private void compressDirectoryRecursive(File fileToZip, File rootDir, ZipOutputStream zos) throws IOException {
      if (fileToZip.isDirectory()) {
         File[] children = fileToZip.listFiles();
         if (children != null) {
            File[] var5 = children;
            int var6 = children.length;

            for(int var7 = 0; var7 < var6; ++var7) {
               File child = var5[var7];
               this.compressDirectoryRecursive(child, rootDir, zos);
            }
         }
      } else {
         String relativePath = rootDir.toPath().relativize(fileToZip.toPath()).toString();
         ZipEntry entry = new ZipEntry(relativePath);
         zos.putNextEntry(entry);
         Files.copy(fileToZip.toPath(), zos);
         zos.closeEntry();
      }

   }

   private void extractZip(File zipFile, File destDir) throws IOException {
      destDir.mkdirs();
      ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));

      ZipEntry entry;
      try {
         for(byte[] buffer = new byte[8192]; (entry = zis.getNextEntry()) != null; zis.closeEntry()) {
            File newFile = new File(destDir, entry.getName());
            if (entry.isDirectory()) {
               newFile.mkdirs();
            } else {
               newFile.getParentFile().mkdirs();
               FileOutputStream fos = new FileOutputStream(newFile);

               int len;
               try {
                  while((len = zis.read(buffer)) > 0) {
                     fos.write(buffer, 0, len);
                  }
               } catch (Throwable var12) {
                  try {
                     fos.close();
                  } catch (Throwable var11) {
                     var12.addSuppressed(var11);
                  }

                  throw var12;
               }

               fos.close();
            }
         }
      } catch (Throwable var13) {
         try {
            zis.close();
         } catch (Throwable var10) {
            var13.addSuppressed(var10);
         }

         throw var13;
      }

      zis.close();
      this.plugin.getLogger().info("Successfully extracted backup from: " + zipFile.getName());
   }

   private void loadBackupHistory() {
      File historyFile = new File(this.backupDirectory, "backup_history.yml");
      if (historyFile.exists()) {
         try {
            FileConfiguration config = YamlConfiguration.loadConfiguration(historyFile);
            Iterator var3 = config.getKeys(false).iterator();

            while(var3.hasNext()) {
               String key = (String)var3.next();

               try {
                  String name = config.getString(key + ".name");
                  BackupManager.BackupType type = BackupManager.BackupType.valueOf(config.getString(key + ".type", "MANUAL"));
                  String description = config.getString(key + ".description", "");
                  String dateStr = config.getString(key + ".created_at");
                  LocalDateTime createdAt = LocalDateTime.parse(dateStr, this.BACKUP_DATE_FORMAT);
                  long size = config.getLong(key + ".size");
                  int fileCount = config.getInt(key + ".file_count");
                  List<String> backedUpFiles = config.getStringList(key + ".backed_up_files");
                  String filePath = config.getString(key + ".file_path");
                  BackupManager.BackupInfo info = new BackupManager.BackupInfo(name, type, description, createdAt, size, fileCount, backedUpFiles, filePath);
                  this.backupHistory.put(key, info);
               } catch (Exception var16) {
                  this.plugin.getLogger().warning("Failed to load backup entry '" + key + "': " + var16.getMessage());
               }
            }

            this.plugin.getLogger().info("Loaded " + this.backupHistory.size() + " backup history entries");
         } catch (Exception var17) {
            this.plugin.getLogger().warning("Failed to load backup history: " + var17.getMessage());
         }

      }
   }

   private void saveBackupHistory() {
      File historyFile = new File(this.backupDirectory, "backup_history.yml");

      try {
         FileConfiguration config = new YamlConfiguration();
         Iterator var3 = this.backupHistory.values().iterator();

         while(var3.hasNext()) {
            BackupManager.BackupInfo info = (BackupManager.BackupInfo)var3.next();
            String key = info.getName();
            config.set(key + ".name", info.getName());
            config.set(key + ".type", info.getType().name());
            config.set(key + ".description", info.getDescription());
            config.set(key + ".created_at", info.getCreatedAt().format(this.BACKUP_DATE_FORMAT));
            config.set(key + ".size", info.getSize());
            config.set(key + ".file_count", info.getFileCount());
            config.set(key + ".backed_up_files", info.getBackedUpFiles());
            config.set(key + ".file_path", info.getFilePath());
         }

         config.save(historyFile);
         this.plugin.getLogger().fine("Saved backup history with " + this.backupHistory.size() + " entries");
      } catch (Exception var6) {
         this.plugin.getLogger().warning("Failed to save backup history: " + var6.getMessage());
      }

   }

   public void shutdown() {
      this.backupHistory.clear();
      this.plugin.getLogger().info("BackupManager shutdown completed");
   }

   public static enum BackupType {
      MANUAL,
      AUTOMATIC,
      EMERGENCY,
      SCHEDULED;

      // $FF: synthetic method
      private static BackupManager.BackupType[] $values() {
         return new BackupManager.BackupType[]{MANUAL, AUTOMATIC, EMERGENCY, SCHEDULED};
      }
   }

   public static class BackupInfo {
      private final String name;
      private final BackupManager.BackupType type;
      private final String description;
      private final LocalDateTime createdAt;
      private final long size;
      private final int fileCount;
      private final List<String> backedUpFiles;
      private final String filePath;

      public BackupInfo(String name, BackupManager.BackupType type, String description, LocalDateTime createdAt, long size, int fileCount, List<String> backedUpFiles, String filePath) {
         this.name = name;
         this.type = type;
         this.description = description;
         this.createdAt = createdAt;
         this.size = size;
         this.fileCount = fileCount;
         this.backedUpFiles = backedUpFiles;
         this.filePath = filePath;
      }

      public String getName() {
         return this.name;
      }

      public BackupManager.BackupType getType() {
         return this.type;
      }

      public String getDescription() {
         return this.description;
      }

      public LocalDateTime getCreatedAt() {
         return this.createdAt;
      }

      public long getSize() {
         return this.size;
      }

      public int getFileCount() {
         return this.fileCount;
      }

      public List<String> getBackedUpFiles() {
         return this.backedUpFiles;
      }

      public String getFilePath() {
         return this.filePath;
      }
   }

   public static class BackupResult {
      private final boolean success;
      private final String message;
      private final BackupManager.BackupInfo backupInfo;

      public BackupResult(boolean success, String message, BackupManager.BackupInfo backupInfo) {
         this.success = success;
         this.message = message;
         this.backupInfo = backupInfo;
      }

      public boolean isSuccess() {
         return this.success;
      }

      public String getMessage() {
         return this.message;
      }

      public BackupManager.BackupInfo getBackupInfo() {
         return this.backupInfo;
      }
   }
}
