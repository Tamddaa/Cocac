package me.omh.solarcrate.listeners;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import me.omh.solarcrate.SolarCrate;
import me.omh.solarcrate.crate.Crate;
import me.omh.solarcrate.libs.folialib.wrapper.task.WrappedTask;
import me.omh.solarcrate.managers.PlayerStateManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.WorldLoadEvent;

public class SolarCrateListeners implements Listener {
   private final SolarCrate plugin;
   private final Map<UUID, Long> joinTimes = new ConcurrentHashMap();
   private WrappedTask cleanupTask;
   private final AtomicBoolean isCleaningUp = new AtomicBoolean(false);
   private volatile boolean isShuttingDown = false;

   public SolarCrateListeners(SolarCrate plugin) {
      if (plugin == null) {
         throw new IllegalArgumentException("Plugin cannot be null");
      } else {
         this.plugin = plugin;
         this.startCleanupTasks();
      }
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      if (!this.isShuttingDown) {
         Player player = event.getPlayer();
         if (player == null) {
            this.plugin.getLogger().warning("PlayerJoinEvent received with null player");
         } else {
            UUID uuid = player.getUniqueId();
            if (uuid == null) {
               this.plugin.getLogger().warning("Player " + player.getName() + " has null UUID");
            } else {
               this.plugin.getPlayerStateManager().onPlayerJoin(uuid);
               this.joinTimes.put(uuid, System.currentTimeMillis());
               this.plugin.getLogger().info("Player " + player.getName() + " joined the server");
            }
         }
      }
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.handlePlayerDisconnect(event.getPlayer(), "quit");
   }

   @EventHandler
   public void onPlayerKick(PlayerKickEvent event) {
      this.handlePlayerDisconnect(event.getPlayer(), "kick");
   }

   @EventHandler
   public void onWorldLoad(WorldLoadEvent event) {
      if (!this.isShuttingDown && this.plugin.getCrateManager() != null) {
         String worldName = event.getWorld().getName();
         this.plugin.getLogger().info("World '" + worldName + "' loaded, checking for pending crates...");
         this.plugin.getFoliaLib().getImpl().runLater(() -> {
            try {
               this.plugin.getCrateManager().retryPendingCratesForWorld(worldName);
            } catch (Exception var3) {
               this.plugin.getLogger().severe("Error retrying pending crates for world '" + worldName + "': " + var3.getMessage());
               var3.printStackTrace();
            }

         }, 20L);
      }
   }

   private void handlePlayerDisconnect(Player player, String reason) {
      if (player == null) {
         this.plugin.getLogger().warning("Player disconnect event received with null player");
      } else {
         UUID uuid = player.getUniqueId();
         Logger var10000;
         String var10001;
         if (uuid == null) {
            var10000 = this.plugin.getLogger();
            var10001 = player.getName();
            var10000.warning("Player " + var10001 + " has null UUID on " + reason);
         } else {
            if (this.plugin.getPlayerStateManager() != null) {
               long sessionTime = this.plugin.getPlayerStateManager().getSessionTime(uuid);
               if (sessionTime > 0L) {
                  long minutes = sessionTime / 60000L;
                  var10000 = this.plugin.getLogger();
                  var10001 = player.getName();
                  var10000.info("Player " + var10001 + " played for " + minutes + " minutes this session");
               }

               this.plugin.getPlayerStateManager().onPlayerQuit(uuid);
            }

            this.joinTimes.remove(uuid);
            if (!this.isShuttingDown && this.plugin.isEnabled()) {
               this.plugin.getFoliaLib().getImpl().runAsync((task) -> {
                  try {
                     if (this.plugin.getKeyManager() != null) {
                        this.plugin.getKeyManager().saveKeys();
                     }
                  } catch (Exception var4) {
                     this.plugin.getLogger().severe("Error saving keys on player " + reason + ": " + var4.getMessage());
                     var4.printStackTrace();
                  }

               });
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onCrateInteract(PlayerInteractEvent event) {
      if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_BLOCK) {
         if (event.getClickedBlock() != null) {
            if (this.plugin.getCrateManager() == null) {
               this.plugin.getLogger().severe("CrateManager is null in interact listener");
            } else {
               Player player = event.getPlayer();
               Location clickedLoc = event.getClickedBlock().getLocation();
               Crate crate = this.plugin.getCrateManager().getCrateAtLocation(clickedLoc);
               if (crate != null) {
                  event.setCancelled(true);
                  this.plugin.getPlayerStateManager().setSelectedCrate(player.getUniqueId(), crate.getName());
                  this.plugin.getPlayerStateManager().setCurrentGuiType(player.getUniqueId(), PlayerStateManager.GuiType.CRATE_SELECTION);
                  this.plugin.getGuiManager().openCrateSelectionGui(player, crate.getName());
               }

            }
         }
      }
   }

   private boolean isSameOrAdjacentBlock(Location a, Location b) {
      if (a != null && b != null) {
         if (a.getWorld() != null && b.getWorld() != null) {
            if (!a.getWorld().equals(b.getWorld())) {
               return false;
            } else if (a.getBlockY() != b.getBlockY()) {
               return false;
            } else {
               int dx = Math.abs(a.getBlockX() - b.getBlockX());
               int dz = Math.abs(a.getBlockZ() - b.getBlockZ());
               return dx + dz == 0 || dx + dz == 1;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void startCleanupTasks() {
      long cleanupInterval = 12000L;
      this.cleanupTask = this.plugin.getFoliaLib().getImpl().runTimer(() -> {
         if (this.isCleaningUp.compareAndSet(false, true)) {
            try {
               this.cleanupStaleEntries();
            } finally {
               this.isCleaningUp.set(false);
            }

         }
      }, cleanupInterval, cleanupInterval);
   }

   private void cleanupStaleEntries() {
      int cleanedPlayerStates = 0;
      int cleanedJoinTimes = 0;
      Set<UUID> onlinePlayerIds = this.plugin.getPlayerStateManager().getAllOnlinePlayers();
      Iterator onlineIterator = onlinePlayerIds.iterator();

      while(true) {
         UUID playerUUID;
         Player player;
         do {
            do {
               if (!onlineIterator.hasNext()) {
                  Iterator joinTimesIterator = this.joinTimes.keySet().iterator();

                  while(true) {
                     while(joinTimesIterator.hasNext()) {
                        UUID playerUUID = (UUID)joinTimesIterator.next();
                        if (playerUUID == null) {
                           joinTimesIterator.remove();
                        } else {
                           Player player = Bukkit.getPlayer(playerUUID);
                           if (player == null || !player.isOnline()) {
                              joinTimesIterator.remove();
                              ++cleanedJoinTimes;
                           }
                        }
                     }

                     if (cleanedPlayerStates > 0 || cleanedJoinTimes > 0) {
                        this.plugin.getLogger().fine("Cleanup cycle: " + cleanedPlayerStates + " player states, " + cleanedJoinTimes + " join times cleaned");
                     }

                     return;
                  }
               }

               playerUUID = (UUID)onlineIterator.next();
            } while(playerUUID == null);

            player = Bukkit.getPlayer(playerUUID);
         } while(player != null && player.isOnline());

         this.plugin.getPlayerStateManager().onPlayerQuit(playerUUID);
         ++cleanedPlayerStates;
      }
   }

   public void cleanup() {
      this.plugin.getLogger().info("Shutting down SolarCrateListeners...");
      this.isShuttingDown = true;
      if (this.cleanupTask != null && !this.cleanupTask.isCancelled()) {
         this.cleanupTask.cancel();
         this.cleanupTask = null;
      }

      int joinTimesSize = this.joinTimes.size();
      this.joinTimes.clear();
      this.plugin.getLogger().info("SolarCrateListeners cleanup complete. Cleared " + joinTimesSize + " join times");
   }
}
