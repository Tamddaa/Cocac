package com.autocracker.engine;

import com.autocracker.crypto.CipherBypassModule;
import com.autocracker.crypto.CryptoDetector;
import com.autocracker.crypto.MessageDigestBypassModule;
import com.autocracker.crypto.ObfuscatedStringDecoder;
import com.autocracker.crypto.RSAKeyOverrideModule;
import com.autocracker.engine.bypass.BypassStrategy;
import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Main engine for license bypass processing.
 * Coordinates multiple bypass strategies to detect and remove various types of license protection.
 */
public class LicenseBypassEngine {
    private static final Logger logger = LoggerManager.getLogger(LicenseBypassEngine.class);
    
    private final List<BypassStrategy> strategies;
    private final Map<String, Object> metadata;
    
    /**
     * Constructor initializes an empty list of strategies.
     */
    public LicenseBypassEngine() {
        this.strategies = new ArrayList<>();
        this.metadata = new HashMap<>();
    }
    
    /**
     * Registers a bypass strategy with this engine.
     *
     * @param strategy The strategy to register
     */
    public void registerStrategy(BypassStrategy strategy) {
        strategies.add(strategy);
        logger.debug("Registered strategy: {}", strategy.getName());
    }
    
    /**
     * Adds metadata that will be passed to all strategies.
     *
     * @param key Metadata key
     * @param value Metadata value
     */
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
        logger.debug("Added metadata: {}={}", key, value);
    }
    
    /**
     * Process a directory of decompiled source files.
     *
     * @param decompileDir Directory containing decompiled source files
     * @return true if any bypasses were applied, false otherwise
     */
    public boolean process(Path decompileDir) {
        if (!Files.isDirectory(decompileDir)) {
            logger.error("Not a directory: {}", decompileDir);
            return false;
        }
        
        logger.info("Processing decompiled source in: {}", decompileDir);
        AtomicBoolean anyBypassed = new AtomicBoolean(false);
        
        try {
            // 1. First pass - process class files for strategies that support it
            processClassFiles(decompileDir, anyBypassed);
            
            // 2. Second pass - process Java source files
            processJavaFiles(decompileDir, anyBypassed);
            
        } catch (IOException e) {
            logger.error("Error processing directory: {}", decompileDir, e);
            return false;
        }
        
        return anyBypassed.get();
    }
    
    /**
     * Processes class files for strategies that support direct bytecode manipulation.
     *
     * @param decompileDir Directory containing class files
     * @param anyBypassed Flag to track if any bypasses were applied
     * @throws IOException If file operations fail
     */
    private void processClassFiles(Path decompileDir, AtomicBoolean anyBypassed) throws IOException {
        // Get all strategies that support class files
        List<BypassStrategy> classFileStrategies = strategies.stream()
                .filter(BypassStrategy::supportsClassFiles)
                .collect(Collectors.toList());
        
        // Process all class files
        try (Stream<Path> pathStream = Files.walk(decompileDir)) {
            List<Path> classFiles = pathStream
                .filter(path -> path.toString().endsWith(".class"))
                .collect(Collectors.toList());
                
            if (classFiles.isEmpty()) {
                logger.debug("No class files found in directory");
                return;
            }
            
            // First process with standard strategies
            if (!classFileStrategies.isEmpty()) {
                logger.debug("Processing with {} bytecode strategies", classFileStrategies.size());
                
                for (Path classFile : classFiles) {
                    for (BypassStrategy strategy : classFileStrategies) {
                        if (strategy.shouldApplyToClass(classFile, metadata)) {
                            logger.info("Applying {} to class file: {}", 
                                      strategy.getName(), classFile.getFileName());
                            
                            if (strategy.processClass(classFile, metadata)) {
                                anyBypassed.set(true);
                                logger.debug("Successfully applied {} to {}", 
                                           strategy.getName(), classFile.getFileName());
                            }
                        }
                    }
                }
            }
            
            // Process with crypto bypassing modules directly
            logger.debug("Processing with specialized crypto bypassing modules");
            
            // Apply cipher bypassing
            for (Path classFile : classFiles) {
                try {
                    if (CipherBypassModule.detectsCipherUsage(classFile)) {
                        logger.info("Applying cipher bypass to: {}", classFile.getFileName());
                        if (CipherBypassModule.patchClassFile(classFile)) {
                            anyBypassed.set(true);
                            logger.info("Successfully bypassed cipher operations in: {}", 
                                       classFile.getFileName());
                        }
                    }
                } catch (Exception e) {
                    logger.error("Error in cipher bypass: {}", e.getMessage());
                }
            }
            
            // Apply message digest bypassing
            for (Path classFile : classFiles) {
                try {
                    if (MessageDigestBypassModule.detectsHashUsage(classFile)) {
                        logger.info("Applying hash bypass to: {}", classFile.getFileName());
                        if (MessageDigestBypassModule.patchClassFile(classFile)) {
                            anyBypassed.set(true);
                            logger.info("Successfully bypassed hash operations in: {}", 
                                       classFile.getFileName());
                        }
                    }
                } catch (Exception e) {
                    logger.error("Error in message digest bypass: {}", e.getMessage());
                }
            }
            
            // Apply RSA key/signature bypassing if class exists
            for (Path classFile : classFiles) {
                try {
                    Class<?> rsaClass = Class.forName("com.autocracker.crypto.RSAKeyOverrideModule");
                    if (rsaClass != null) {
                        java.lang.reflect.Method detectsMethod = 
                            rsaClass.getMethod("detectsRSAUsage", Path.class);
                        java.lang.reflect.Method patchMethod = 
                            rsaClass.getMethod("patchClassFile", Path.class);
                        
                        if ((Boolean)detectsMethod.invoke(null, classFile)) {
                            logger.info("Applying RSA bypass to: {}", classFile.getFileName());
                            if ((Boolean)patchMethod.invoke(null, classFile)) {
                                anyBypassed.set(true);
                                logger.info("Successfully bypassed RSA operations in: {}", 
                                          classFile.getFileName());
                            }
                        }
                    }
                } catch (Exception e) {
                    // RSA module might not be available, which is fine
                    logger.debug("RSA module not available or error: {}", e.getMessage());
                }
            }
            
            // Process with the ObfuscatedStringDecoder for class files
            // Direct implementation instead of using reflection
            try {
                logger.debug("Checking for string decoders in class files");
                
                for (Path classFile : classFiles) {
                    try {
                        byte[] classData = Files.readAllBytes(classFile);
                        
                        // Just detect strings for now - in actual implementation we would
                        // have specialized bytecode manipulation for decoding strings
                        logger.debug("Checking for encoded strings in: {}", classFile.getFileName());
                        
                        // Add more direct bytecode manipulation logic here for future versions
                        
                    } catch (Exception e) {
                        logger.error("Error in string decoder bypass: {}", e.getMessage());
                    }
                }
            } catch (Exception e) {
                logger.debug("Error in string decoder processing: {}", e.getMessage());
            }
        }
        
        // Add statistics to metadata
        metadata.put("bypassStats", "Applied specialized bypassing modules: " + 
                   "CipherBypass, MessageDigestBypass and string decoder modules");
    }
    
    /**
     * Processes Java source files for all strategies.
     *
     * @param decompileDir Directory containing Java source files
     * @param anyBypassed Flag to track if any bypasses were applied
     * @throws IOException If file operations fail
     */
    private void processJavaFiles(Path decompileDir, AtomicBoolean anyBypassed) throws IOException {
        // Process all Java files
        try (Stream<Path> pathStream = Files.walk(decompileDir)) {
            List<Path> javaFiles = pathStream
                .filter(path -> path.toString().endsWith(".java"))
                .collect(Collectors.toList());
                
            if (javaFiles.isEmpty()) {
                logger.debug("No Java files found in directory");
                return;
            }
            
            // First detect obfuscated strings and analyze crypto usage
            logger.debug("Analyzing crypto usage and string obfuscation in Java files");
            Map<String, ObfuscatedStringDecoder.DecodingResult> stringDecoderMap = new HashMap<>();
            Map<String, CryptoDetector.CryptoInfo> cryptoInfoMap = new HashMap<>();
            
            for (Path javaFile : javaFiles) {
                try {
                    // Analyze string obfuscation
                    String fileContent = Files.readString(javaFile);
                    ObfuscatedStringDecoder.DecodingResult decodingResult = 
                        ObfuscatedStringDecoder.decodeObfuscatedStrings(fileContent);
                    
                    if (decodingResult.hasResults()) {
                        stringDecoderMap.put(javaFile.getFileName().toString(), decodingResult);
                        logger.debug("Detected string obfuscation in: {}", javaFile.getFileName());
                    }
                
                    // Analyze crypto usage
                    CryptoDetector.CryptoInfo cryptoInfo = CryptoDetector.analyzeJavaSource(javaFile);
                    if (!cryptoInfo.getDetectedAlgorithms().isEmpty()) {
                        cryptoInfoMap.put(javaFile.getFileName().toString(), cryptoInfo);
                        logger.debug("Detected crypto usage in: {} - algorithms: {}", 
                                   javaFile.getFileName(), 
                                   String.join(", ", cryptoInfo.getDetectedAlgorithmsList()));
                    }
                } catch (Exception e) {
                    logger.error("Error analyzing file {}: {}", javaFile.getFileName(), e.getMessage());
                }
            }
            
            // Apply string deobfuscation knowledge to metadata
            if (!stringDecoderMap.isEmpty()) {
                metadata.put("stringDecoders", stringDecoderMap);
                logger.info("Added string decoder information to metadata for {} files", 
                           stringDecoderMap.size());
            }
            
            // Apply crypto knowledge to metadata
            if (!cryptoInfoMap.isEmpty()) {
                metadata.put("cryptoInfo", cryptoInfoMap);
                logger.info("Added crypto information to metadata for {} files", 
                           cryptoInfoMap.size());
            }
            
            // Now apply all strategies with enhanced metadata
            for (Path javaFile : javaFiles) {
                try {
                    String content = Files.readString(javaFile);
                    boolean fileModified = false;
                    
                    for (BypassStrategy strategy : strategies) {
                        if (strategy.shouldApply(javaFile, content, metadata)) {
                            logger.info("Applying {} to: {}", 
                                      strategy.getName(), javaFile.getFileName());
                            
                            String modifiedContent = strategy.process(javaFile, content, metadata);
                            if (!modifiedContent.equals(content)) {
                                content = modifiedContent;
                                fileModified = true;
                                anyBypassed.set(true);
                                logger.debug("File modified by {}", strategy.getName());
                            }
                        }
                    }
                    
                    if (fileModified) {
                        Files.writeString(javaFile, content);
                        logger.debug("Wrote modified file: {}", javaFile);
                    }
                    
                } catch (IOException e) {
                    logger.error("Error processing file: {}", javaFile, e);
                }
            }
        }
    }
}