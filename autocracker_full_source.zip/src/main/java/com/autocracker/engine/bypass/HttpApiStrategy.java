package com.autocracker.engine.bypass;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bypass strategy for license checks that use HTTP/HTTPS API verification.
 * Detects and bypasses license validation that requires server communication.
 */
public class HttpApiStrategy implements BypassStrategy {
    private static final Logger logger = LoggerManager.getLogger(HttpApiStrategy.class);
    
    // HTTP request patterns
    private static final Pattern HTTP_PATTERN = Pattern.compile(
            "(?:https?://[^\"'\\s]+)|" +
            "(?:new\\s+URL\\s*\\([^)]+\\))|" +
            "(?:HttpURLConnection|HttpClient|OkHttp|URLConnection)|" +
            "(?:openConnection\\(\\))|" +
            "(?:\\.connect\\(\\))|" +
            "(?:getInputStream\\(\\))|" +
            "(?:getResponseCode\\(\\))",
            Pattern.CASE_INSENSITIVE
    );
    
    // License verification context patterns
    private static final Pattern LICENSE_CONTEXT_PATTERN = Pattern.compile(
            "(?:license|auth|verify|validate|check|premium|token|key)",
            Pattern.CASE_INSENSITIVE
    );
    
    @Override
    public String getName() {
        return "HTTP API Bypass";
    }
    
    @Override
    public boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata) {
        // Check if content contains HTTP patterns
        Matcher httpMatcher = HTTP_PATTERN.matcher(content);
        
        if (!httpMatcher.find()) {
            return false;
        }
        
        // Check if HTTP patterns are used in a license context
        Matcher licenseContextMatcher = LICENSE_CONTEXT_PATTERN.matcher(content);
        return licenseContextMatcher.find();
    }
    
    @Override
    public String process(Path javaFile, String content, Map<String, Object> metadata) {
        logger.debug("Applying HTTP API bypass to: {}", javaFile);
        String modifiedContent = content;
        
        // 1. Process URL creation
        modifiedContent = processUrlCreation(modifiedContent);
        
        // 2. Process HTTP connection setup
        modifiedContent = processHttpConnections(modifiedContent);
        
        // 3. Process response handling
        modifiedContent = processResponseHandling(modifiedContent);
        
        return modifiedContent;
    }
    
    /**
     * Processes URL creation code.
     *
     * @param content Source code content
     * @return Modified content with bypassed URL creation
     */
    private String processUrlCreation(String content) {
        // Replace URL constructors that contain license verification endpoints
        Pattern urlPattern = Pattern.compile(
                "(new\\s+URL\\s*\\(\\s*\")(https?://[^\"]+)(\")([^)]*\\))",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher urlMatcher = urlPattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (urlMatcher.find()) {
            String urlPrefix = urlMatcher.group(1);
            String url = urlMatcher.group(2);
            String urlSuffix = urlMatcher.group(3);
            String rest = urlMatcher.group(4);
            
            // Check if URL is likely for license verification
            if (isLicenseVerificationUrl(url)) {
                logger.debug("Bypassing license verification URL: {}", url);
                
                // Create a replacement that comments out the original URL but provides a dummy local URL
                String replacement = "/* Bypassed: " + urlPrefix + url + urlSuffix + rest + " */ " +
                                     urlPrefix + "http://localhost/dummy-license" + urlSuffix + rest;
                
                urlMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
            } else {
                urlMatcher.appendReplacement(sb, urlMatcher.group());
            }
        }
        urlMatcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Processes HTTP connection setup code.
     *
     * @param content Source code content
     * @return Modified content with bypassed connection setup
     */
    private String processHttpConnections(String content) {
        // Find HTTP connection setup patterns
        Pattern connectionPattern = Pattern.compile(
                "(\\w+)\\s*=\\s*(?:\\(HttpURLConnection\\)\\s*)?(\\w+)\\.openConnection\\(\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher connectionMatcher = connectionPattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (connectionMatcher.find()) {
            String connectionVar = connectionMatcher.group(1);
            
            // Check if this connection is for license verification
            int pos = content.indexOf(connectionMatcher.group());
            String surroundingCode = getSurroundingCode(content, pos, 500);
            
            if (isLicenseVerificationContext(surroundingCode)) {
                logger.debug("Bypassing HTTP connection for license verification");
                
                // Disable connection-related operations after this point
                content = disableConnectionOperations(content, connectionVar);
                
                // Keep the original line to avoid breaking compilation
                connectionMatcher.appendReplacement(sb, Matcher.quoteReplacement(connectionMatcher.group()));
            } else {
                connectionMatcher.appendReplacement(sb, Matcher.quoteReplacement(connectionMatcher.group()));
            }
        }
        connectionMatcher.appendTail(sb);
        
        return content;
    }
    
    /**
     * Processes response handling code.
     *
     * @param content Source code content
     * @return Modified content with bypassed response handling
     */
    private String processResponseHandling(String content) {
        // Find response code checking patterns
        Pattern responseCodePattern = Pattern.compile(
                "(\\w+)\\.getResponseCode\\(\\)\\s*([!=]=)\\s*(\\d+)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher responseCodeMatcher = responseCodePattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (responseCodeMatcher.find()) {
            String operator = responseCodeMatcher.group(2);
            String statusCode = responseCodeMatcher.group(3);
            
            // Check if checking for success status code
            boolean expectingSuccess = (operator.equals("==") && (statusCode.equals("200") || statusCode.equals("201"))) ||
                                      (operator.equals("!=") && !(statusCode.equals("200") || statusCode.equals("201")));
            
            // Bypass the check by returning the expected result
            String replacement = expectingSuccess ? 
                                "true /* Bypassed HTTP status check */" :
                                "false /* Bypassed HTTP status check */";
            
            responseCodeMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        responseCodeMatcher.appendTail(sb);
        String processedContent = sb.toString();
        
        // Handle response input stream reading
        Pattern inputStreamPattern = Pattern.compile(
                "(\\w+)\\s*=\\s*(\\w+)\\.getInputStream\\(\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher inputStreamMatcher = inputStreamPattern.matcher(processedContent);
        sb = new StringBuffer();
        
        while (inputStreamMatcher.find()) {
            String streamVar = inputStreamMatcher.group(1);
            String connectionVar = inputStreamMatcher.group(2);
            
            // Check if this is part of license verification
            int pos = processedContent.indexOf(inputStreamMatcher.group());
            String surroundingCode = getSurroundingCode(processedContent, pos, 500);
            
            if (isLicenseVerificationContext(surroundingCode)) {
                // Replace with a dummy stream containing a valid response
                String replacement = "/* Bypassed: " + inputStreamMatcher.group() + " */ " +
                                    streamVar + " = new java.io.ByteArrayInputStream(\"{\\\"status\\\":\\\"valid\\\",\\\"message\\\":\\\"License is valid\\\",\\\"expiryDate\\\":\\\"2099-12-31\\\"}\".getBytes())";
                
                inputStreamMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
            } else {
                inputStreamMatcher.appendReplacement(sb, inputStreamMatcher.group());
            }
        }
        inputStreamMatcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Checks if a URL is likely for license verification.
     *
     * @param url URL to check
     * @return true if the URL is likely used for license verification, false otherwise
     */
    private boolean isLicenseVerificationUrl(String url) {
        String lowerUrl = url.toLowerCase();
        return lowerUrl.contains("license") ||
               lowerUrl.contains("auth") ||
               lowerUrl.contains("verify") ||
               lowerUrl.contains("validate") ||
               lowerUrl.contains("check") ||
               lowerUrl.contains("premium") ||
               lowerUrl.contains("api.") && (lowerUrl.contains("key") || lowerUrl.contains("token"));
    }
    
    /**
     * Checks if code is in a license verification context.
     *
     * @param code Code to check
     * @return true if the code appears to be related to license verification, false otherwise
     */
    private boolean isLicenseVerificationContext(String code) {
        String lowerCode = code.toLowerCase();
        return lowerCode.contains("license") ||
               lowerCode.contains("auth") ||
               (lowerCode.contains("verify") && !lowerCode.contains("verify ssl")) ||
               lowerCode.contains("validate") ||
               (lowerCode.contains("check") && !lowerCode.contains("check update")) ||
               lowerCode.contains("premium") ||
               lowerCode.contains("hwid");
    }
    
    /**
     * Gets the surrounding code context around a position.
     *
     * @param content Full source code content
     * @param position Center position
     * @param range Number of characters to include in each direction
     * @return Surrounding code snippet
     */
    private String getSurroundingCode(String content, int position, int range) {
        int start = Math.max(0, position - range);
        int end = Math.min(content.length(), position + range);
        return content.substring(start, end);
    }
    
    /**
     * Disables connection operations for a specific connection variable.
     *
     * @param content Source code content
     * @param connectionVar Connection variable name
     * @return Modified content with disabled connection operations
     */
    private String disableConnectionOperations(String content, String connectionVar) {
        // Modify setRequestMethod
        content = content.replaceAll(
                Pattern.quote(connectionVar) + "\\.setRequestMethod\\(([^)]+)\\)",
                "/* Bypassed */ " + connectionVar + ".setRequestMethod($1)"
        );
        
        // Modify setRequestProperty
        content = content.replaceAll(
                Pattern.quote(connectionVar) + "\\.setRequestProperty\\(([^)]+)\\)",
                "/* Bypassed */ " + connectionVar + ".setRequestProperty($1)"
        );
        
        // Modify connect()
        content = content.replaceAll(
                Pattern.quote(connectionVar) + "\\.connect\\(\\)",
                "/* Bypassed connection */ " + connectionVar + ".connect()"
        );
        
        // Mock successful response code (HTTP 200 OK)
        content = content.replaceAll(
                Pattern.quote(connectionVar) + "\\.getResponseCode\\(\\)",
                "/* Bypassed: " + connectionVar + ".getResponseCode() */ 200"
        );
        
        // Ensure any error handling for unsuccessful connections is bypassed
        Pattern errorCheckPattern = Pattern.compile(
                "if\\s*\\(\\s*" + Pattern.quote(connectionVar) + "\\.getResponseCode\\(\\)\\s*!=\\s*200\\s*\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher errorCheckMatcher = errorCheckPattern.matcher(content);
        if (errorCheckMatcher.find()) {
            String errorCheck = errorCheckMatcher.group();
            content = content.replace(errorCheck, "if (false /* Bypassed error check */)");
        }
        
        return content;
    }
}