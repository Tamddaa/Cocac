package com.autocracker.engine.bypass;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bypass strategy for license checks that use hardcoded keys.
 * Detects and bypasses hardcoded license keys and validation logic.
 */
public class HardcodedKeyStrategy implements BypassStrategy {
    private static final Logger logger = LoggerManager.getLogger(HardcodedKeyStrategy.class);
    
    // Patterns for license keys
    private static final Pattern KEY_PATTERN = Pattern.compile(
            "(?:licen[sc]e|premium|auth)(?:_|\\s*)?(?:key|token|code|string)\\s*=\\s*\"([^\"]+)\"|" +
            "(?:key|token|licenseKey)\\s*=\\s*\"([a-zA-Z0-9\\-_]{10,})\"|" +
            "(?:verify|check|validate)(?:License|Key|Token)\\(\\s*\"([^\"]+)\"\\s*\\)",
            Pattern.CASE_INSENSITIVE
    );
    
    // Patterns for key equality checks
    private static final Pattern KEY_CHECK_PATTERN = Pattern.compile(
            "((?:key|token|code|license|input)(?:\\.equals\\(|\\.equalsIgnoreCase\\(|\\.contains\\(|\\.startsWith\\(|\\.endsWith\\(|\\.compareTo\\(|\\.matches\\()\"([^\"]+)\"\\))|" +
            "(\"([^\"]+)\"(?:\\.equals\\(|\\.equalsIgnoreCase\\(|\\.contains\\(|\\.startsWith\\(|\\.endsWith\\(|\\.compareTo\\(|\\.matches\\()(?:key|token|code|license|input)\\))",
            Pattern.CASE_INSENSITIVE
    );
    
    @Override
    public String getName() {
        return "Hardcoded Key Bypass";
    }
    
    @Override
    public boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata) {
        // Check if content contains hardcoded keys or equality checks
        return KEY_PATTERN.matcher(content).find() || KEY_CHECK_PATTERN.matcher(content).find();
    }
    
    @Override
    public String process(Path javaFile, String content, Map<String, Object> metadata) {
        logger.debug("Applying hardcoded key bypass to: {}", javaFile);
        String modifiedContent = content;
        
        // 1. Process hardcoded license key declarations
        modifiedContent = processKeyDeclarations(modifiedContent);
        
        // 2. Process key equality checks
        modifiedContent = processKeyEqualityChecks(modifiedContent);
        
        // 3. Process key validation methods
        modifiedContent = processKeyValidationMethods(modifiedContent);
        
        return modifiedContent;
    }
    
    /**
     * Processes hardcoded license key declarations.
     *
     * @param content Source code content
     * @return Modified content with patched key declarations
     */
    private String processKeyDeclarations(String content) {
        Matcher keyMatcher = KEY_PATTERN.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (keyMatcher.find()) {
            String key = null;
            // Try to extract key from any of the capturing groups
            for (int i = 1; i <= keyMatcher.groupCount(); i++) {
                if (keyMatcher.group(i) != null) {
                    key = keyMatcher.group(i);
                    break;
                }
            }
            
            if (key != null) {
                logger.debug("Found hardcoded key: {}", key);
                
                // Replace with our own key
                String fullMatch = keyMatcher.group();
                String replacement = fullMatch.replace(key, "AUTOCRACKER-PREMIUM-KEY-" + System.currentTimeMillis());
                
                keyMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
            } else {
                keyMatcher.appendReplacement(sb, keyMatcher.group());
            }
        }
        keyMatcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Processes key equality checks in the code.
     *
     * @param content Source code content
     * @return Modified content with patched equality checks
     */
    private String processKeyEqualityChecks(String content) {
        Matcher checkMatcher = KEY_CHECK_PATTERN.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (checkMatcher.find()) {
            String fullMatch = checkMatcher.group();
            String mainGroup = null;
            String key = null;
            
            // Try to determine which pattern matched
            if (checkMatcher.group(1) != null) {
                mainGroup = checkMatcher.group(1);
                key = checkMatcher.group(2);
            } else if (checkMatcher.group(3) != null) {
                mainGroup = checkMatcher.group(3);
                key = checkMatcher.group(4);
            }
            
            if (key != null) {
                logger.debug("Found key equality check: {}", key);
                
                // Check if it's in a condition
                boolean inCondition = false;
                int pos = content.indexOf(fullMatch);
                String before = content.substring(Math.max(0, pos - 20), pos);
                if (before.contains("if") || before.contains("while") || before.contains("return")) {
                    inCondition = true;
                }
                
                // Replace with true if in condition, otherwise keep original but comment
                if (inCondition) {
                    checkMatcher.appendReplacement(sb, "true /* Bypassed: " + fullMatch + " */");
                } else {
                    // Keep original to not break flow, but add comment
                    checkMatcher.appendReplacement(sb, fullMatch + " /* Bypassed key check */");
                }
            } else {
                checkMatcher.appendReplacement(sb, fullMatch);
            }
        }
        checkMatcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Processes key validation methods.
     *
     * @param content Source code content
     * @return Modified content with patched validation methods
     */
    private String processKeyValidationMethods(String content) {
        // Find boolean methods for key validation
        Pattern validationMethodPattern = Pattern.compile(
                "(public|private|protected)\\s+(static\\s+)?boolean\\s+([a-zA-Z0-9_]+)\\s*\\(\\s*String\\s+([a-zA-Z0-9_]+)\\s*\\)\\s*\\{",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher methodMatcher = validationMethodPattern.matcher(content);
        while (methodMatcher.find()) {
            String methodSignature = methodMatcher.group();
            String methodName = methodMatcher.group(3);
            String paramName = methodMatcher.group(4);
            
            // Check if this method is likely for key validation
            boolean isValidationMethod = methodName.toLowerCase().contains("valid") ||
                                       methodName.toLowerCase().contains("check") ||
                                       methodName.toLowerCase().contains("verify") ||
                                       methodName.toLowerCase().contains("license") ||
                                       methodName.toLowerCase().contains("key");
            
            if (isValidationMethod) {
                // Find method body
                int methodStart = content.indexOf(methodSignature);
                int openBrace = content.indexOf("{", methodStart);
                if (openBrace != -1) {
                    int closeBrace = findMatchingBrace(content, openBrace);
                    if (closeBrace != -1) {
                        // Replace method body with simple 'return true'
                        String replacement = methodSignature +
                                          "\n        // Bypassed license key validation\n" +
                                          "        return true;\n    }";
                        
                        content = content.substring(0, methodStart) + 
                                  replacement + 
                                  content.substring(closeBrace + 1);
                    }
                }
            }
        }
        
        // Process if/else conditions with key comparisons
        Pattern ifKeyPattern = Pattern.compile(
                "if\\s*\\(\\s*(?:!)?([a-zA-Z0-9_]+)\\.(?:equals|equalsIgnoreCase|contains|startsWith|endsWith|matches)\\(([^)]+)\\)\\s*\\)\\s*\\{([^}]+)\\}\\s*(?:else\\s*\\{([^}]+)\\})?",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher ifKeyMatcher = ifKeyPattern.matcher(content);
        while (ifKeyMatcher.find()) {
            String var = ifKeyMatcher.group(1);
            String arg = ifKeyMatcher.group(2);
            String ifBlock = ifKeyMatcher.group(3);
            String elseBlock = ifKeyMatcher.group(4);
            
            boolean isKeyCheck = var.toLowerCase().contains("key") ||
                              var.toLowerCase().contains("license") ||
                              var.toLowerCase().contains("token") ||
                              var.toLowerCase().contains("auth") ||
                              arg.toLowerCase().contains("key") ||
                              arg.toLowerCase().contains("license") ||
                              arg.toLowerCase().contains("token") ||
                              arg.toLowerCase().contains("auth");
            
            if (isKeyCheck) {
                // Determine which block is the "success" block
                boolean successInIf = ifBlock.contains("valid") || 
                                   ifBlock.contains("success") ||
                                   ifBlock.contains("premium") ||
                                   !ifBlock.contains("invalid") && !ifBlock.contains("failed");
                
                if (successInIf) {
                    // Always execute the if block
                    content = content.replace(ifKeyMatcher.group(), "// Bypassed key check - always succeed\n    {" + ifBlock + "}");
                } else if (elseBlock != null) {
                    // Always execute the else block
                    content = content.replace(ifKeyMatcher.group(), "// Bypassed key check - always succeed\n    {" + elseBlock + "}");
                }
            }
        }
        
        return content;
    }
    
    /**
     * Finds the matching closing brace for an opening brace.
     *
     * @param content Source code content
     * @param openBraceIndex Index of the opening brace
     * @return Index of the matching closing brace, or -1 if not found
     */
    private int findMatchingBrace(String content, int openBraceIndex) {
        int braceCount = 1;
        for (int i = openBraceIndex + 1; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '{') {
                braceCount++;
            } else if (c == '}') {
                braceCount--;
                if (braceCount == 0) {
                    return i;
                }
            }
        }
        return -1;
    }
}