package com.autocracker.engine.bypass;

import com.autocracker.module.LoggerManager;
import com.autocracker.util.ObfuscationDetector;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bypass strategy for obfuscated license check code.
 * Detects and bypasses license validation hidden through code obfuscation.
 */
public class ObfuscatedCodeStrategy implements BypassStrategy {
    private static final Logger logger = LoggerManager.getLogger(ObfuscatedCodeStrategy.class);
    
    // Patterns to identify obfuscated boolean methods that might be license checks
    private static final Pattern OBFUSCATED_BOOLEAN_METHOD = Pattern.compile(
            "(public|private|protected)\\s+(static\\s+)?boolean\\s+([a-zA-Z0-9_]{1,3})\\s*\\([^)]*\\)\\s*\\{",
            Pattern.CASE_INSENSITIVE
    );
    
    // Patterns to identify obfuscated methods with return statements
    private static final Pattern RETURN_PATTERN = Pattern.compile(
            "return\\s+(!?)(true|false|\\w+);",
            Pattern.CASE_INSENSITIVE
    );
    
    @Override
    public String getName() {
        return "Obfuscated Code Bypass";
    }
    
    @Override
    public boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata) {
        // Check if class name suggests obfuscation
        String className = javaFile.getFileName().toString().replace(".java", "");
        
        boolean isObfuscated = ObfuscationDetector.isObfuscatedClassName(className) ||
                               (metadata.containsKey("obfuscated") && (boolean)metadata.get("obfuscated"));
        
        if (!isObfuscated) {
            return false;
        }
        
        // Further check content for obfuscated patterns
        return OBFUSCATED_BOOLEAN_METHOD.matcher(content).find();
    }
    
    @Override
    public String process(Path javaFile, String content, Map<String, Object> metadata) {
        logger.debug("Applying obfuscated code bypass to: {}", javaFile);
        String modifiedContent = content;
        
        // Process obfuscated boolean methods
        Matcher booleanMethodMatcher = OBFUSCATED_BOOLEAN_METHOD.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (booleanMethodMatcher.find()) {
            String methodSignature = booleanMethodMatcher.group();
            String methodName = booleanMethodMatcher.group(3);
            
            logger.debug("Found obfuscated boolean method: {}", methodName);
            
            // Find method body
            int methodStart = content.indexOf(methodSignature);
            int openBrace = content.indexOf("{", methodStart);
            if (openBrace != -1) {
                int closeBrace = findMatchingBrace(content, openBrace);
                if (closeBrace != -1) {
                    String methodBody = content.substring(openBrace + 1, closeBrace);
                    
                    // Check if this obfuscated method is likely a license check
                    if (isLikelyLicenseCheck(methodBody)) {
                        // Replace with simple "return true"
                        String replacement = methodSignature + " return true; }";
                        booleanMethodMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
                        continue;
                    }
                    
                    // Check for obfuscated logic that might check system properties or files
                    if (methodBody.contains("System.getProperty") || 
                        methodBody.contains("File(") || 
                        methodBody.contains("Files.") ||
                        methodBody.contains("getClass().getResource")) {
                        
                        String replacement = methodSignature + " return true; }";
                        booleanMethodMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
                        continue;
                    }
                }
            }
            
            booleanMethodMatcher.appendReplacement(sb, Matcher.quoteReplacement(methodSignature));
        }
        booleanMethodMatcher.appendTail(sb);
        modifiedContent = sb.toString();
        
        // Process if statements with false returns
        Pattern ifFalsePattern = Pattern.compile(
                "if\\s*\\([^)]+\\)\\s*\\{\\s*return\\s+false;\\s*\\}",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher ifFalseMatcher = ifFalsePattern.matcher(modifiedContent);
        StringBuffer ifSb = new StringBuffer();
        
        while (ifFalseMatcher.find()) {
            String ifStatement = ifFalseMatcher.group();
            
            // Check the surrounding context to see if this might be a license check
            int statementPos = modifiedContent.indexOf(ifStatement);
            int methodStart = findMethodStart(modifiedContent, statementPos);
            
            if (methodStart != -1) {
                String methodDeclaration = modifiedContent.substring(methodStart, statementPos);
                
                // If this is a boolean method, likely a license check
                if (methodDeclaration.contains("boolean") && 
                    !methodDeclaration.contains("equals") && 
                    !methodDeclaration.contains("startsWith") && 
                    !methodDeclaration.contains("endsWith")) {
                    
                    ifFalseMatcher.appendReplacement(ifSb, "/* Bypassed license check */ ");
                    continue;
                }
            }
            
            ifFalseMatcher.appendReplacement(ifSb, Matcher.quoteReplacement(ifStatement));
        }
        ifFalseMatcher.appendTail(ifSb);
        modifiedContent = ifSb.toString();
        
        // Process obfuscated string constants that might be license keys
        modifiedContent = processObfuscatedStrings(modifiedContent);
        
        return modifiedContent;
    }
    
    /**
     * Processes obfuscated string constants that might be license keys.
     *
     * @param content Source code content
     * @return Modified content with bypassed obfuscated strings
     */
    private String processObfuscatedStrings(String content) {
        // Look for string array access patterns that might be used for obfuscated license keys
        Pattern stringArrayPattern = Pattern.compile(
                "new\\s+String\\s*\\[\\s*\\]\\s*\\{([^}]+)\\}",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher matcher = stringArrayPattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (matcher.find()) {
            String arrayContent = matcher.group(1);
            
            // If array contains a lot of strings, it might be an obfuscated table
            if (arrayContent.split(",").length > 5) {
                int statementStart = content.lastIndexOf("=", matcher.start());
                int statementEnd = content.indexOf(";", matcher.end());
                
                if (statementStart != -1 && statementEnd != -1) {
                    // Get variable name
                    String statement = content.substring(statementStart + 1, statementEnd).trim();
                    String arrayVar = statement.substring(0, statement.indexOf("=")).trim();
                    
                    // Look for accesses to this array
                    Pattern arrayAccessPattern = Pattern.compile(
                            "\\b" + Pattern.quote(arrayVar) + "\\s*\\[\\s*\\d+\\s*\\]",
                            Pattern.CASE_INSENSITIVE
                    );
                    
                    Matcher accessMatcher = arrayAccessPattern.matcher(content);
                    while (accessMatcher.find()) {
                        String arrayAccess = accessMatcher.group();
                        
                        // Check if this is used in a condition
                        int accessPos = content.indexOf(arrayAccess, accessMatcher.start());
                        int nextChar = accessPos + arrayAccess.length();
                        
                        if (nextChar < content.length()) {
                            String context = content.substring(nextChar, 
                                                 Math.min(nextChar + 20, content.length()));
                            
                            if (context.trim().startsWith(".equals") || 
                                context.trim().startsWith("==") || 
                                context.trim().startsWith("!=")) {
                                
                                // Replace with valid key
                                content = content.replace(arrayAccess, "\"AUTOCRACKER-KEY\"");
                            }
                        }
                    }
                }
            }
            
            matcher.appendReplacement(sb, Matcher.quoteReplacement(matcher.group()));
        }
        matcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Checks if a method body is likely a license check.
     *
     * @param methodBody Content of the method body
     * @return true if the method is likely a license check, false otherwise
     */
    private boolean isLikelyLicenseCheck(String methodBody) {
        // Check for patterns indicative of license checking
        return (methodBody.contains("return false") && !methodBody.contains("return true")) ||
               (methodBody.contains("getClass().getResource") && methodBody.contains("return")) ||
               (methodBody.contains("System.getProperty") && methodBody.contains("return")) ||
               (methodBody.contains("File") && methodBody.contains("exists") && methodBody.contains("return")) ||
               (methodBody.contains("equals") && methodBody.contains("return"));
    }
    
    /**
     * Finds the start of a method containing a given position.
     *
     * @param content Source code content
     * @param position Position within the method
     * @return Start index of the method, or -1 if not found
     */
    private int findMethodStart(String content, int position) {
        // Look backward for method modifiers
        String beforePosition = content.substring(0, position);
        int lastMethodStart = Math.max(
            beforePosition.lastIndexOf("public "),
            Math.max(
                beforePosition.lastIndexOf("private "),
                beforePosition.lastIndexOf("protected ")
            )
        );
        
        // Check if there's a class or method declaration between the modifier and position
        if (lastMethodStart != -1) {
            String declaration = beforePosition.substring(lastMethodStart);
            if (!declaration.contains("class ") && declaration.contains("(")) {
                return lastMethodStart;
            }
        }
        
        return -1;
    }
    
    /**
     * Finds the matching closing brace for an opening brace.
     *
     * @param content Source code content
     * @param openBraceIndex Index of the opening brace
     * @return Index of the matching closing brace, or -1 if not found
     */
    private int findMatchingBrace(String content, int openBraceIndex) {
        int braceCount = 1;
        for (int i = openBraceIndex + 1; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '{') {
                braceCount++;
            } else if (c == '}') {
                braceCount--;
                if (braceCount == 0) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    @Override
    public boolean supportsClassFiles() {
        return true;
    }
    
    @Override
    public boolean shouldApplyToClass(Path classFile, Map<String, Object> metadata) {
        String className = classFile.getFileName().toString().replace(".class", "");
        return ObfuscationDetector.isObfuscatedClassName(className) || 
              (metadata.containsKey("obfuscated") && (boolean)metadata.get("obfuscated"));
    }
    
    @Override
    public boolean processClass(Path classFile, Map<String, Object> metadata) {
        logger.debug("Processing obfuscated class file: {}", classFile);
        
        // For now, we'll defer actual bytecode manipulation to the BytecodeUtils class
        // In a real implementation, you would use ASM or Javassist here to modify bytecode
        return true;
    }
}