package com.autocracker.engine.bypass;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bypass strategy for license checks that use encryption or token-based verification.
 * Detects and bypasses encryption algorithms and token validation.
 */
public class EncryptionTokenStrategy implements BypassStrategy {
    private static final Logger logger = LoggerManager.getLogger(EncryptionTokenStrategy.class);
    
    // Common encryption patterns
    private static final Pattern ENCRYPTION_PATTERN = Pattern.compile(
            "(?:encrypt|decrypt|AES|RSA|DES|cipher|token|hash|MD5|SHA|sign)\\s*\\([^)]*\\)|" +
            "(?:Cipher\\.getInstance|KeyGenerator\\.getInstance|MessageDigest\\.getInstance)",
            Pattern.CASE_INSENSITIVE
    );
    
    // Token validation patterns
    private static final Pattern TOKEN_VALIDATION_PATTERN = Pattern.compile(
            "(?:validate|verify|check)\\s*(?:Token|Key|License|Auth)\\s*\\([^)]*\\)|" +
            "(?:isValid|isAuthenticated|isAuthorized|isLicensed)\\s*\\([^)]*\\)",
            Pattern.CASE_INSENSITIVE
    );
    
    @Override
    public String getName() {
        return "Encryption/Token Bypass";
    }
    
    @Override
    public boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata) {
        // Check if content contains encryption or token validation patterns
        Matcher encryptionMatcher = ENCRYPTION_PATTERN.matcher(content);
        Matcher tokenMatcher = TOKEN_VALIDATION_PATTERN.matcher(content);
        
        return encryptionMatcher.find() || tokenMatcher.find();
    }
    
    @Override
    public String process(Path javaFile, String content, Map<String, Object> metadata) {
        logger.debug("Applying encryption/token bypass to: {}", javaFile);
        String modifiedContent = content;
        
        // 1. Handle encryption/decryption methods
        modifiedContent = processEncryptionMethods(modifiedContent);
        
        // 2. Handle token validation
        modifiedContent = processTokenValidation(modifiedContent);
        
        // 3. Handle hashing and signatures
        modifiedContent = processHashingAndSignatures(modifiedContent);
        
        return modifiedContent;
    }
    
    /**
     * Processes encryption/decryption methods.
     * 
     * @param content Source code content
     * @return Modified content with bypassed encryption/decryption
     */
    private String processEncryptionMethods(String content) {
        // Replace encryption initialization
        Pattern cipherPattern = Pattern.compile(
                "(\\w+)\\s*=\\s*Cipher\\.getInstance\\(([^)]+)\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher cipherMatcher = cipherPattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (cipherMatcher.find()) {
            String cipherVar = cipherMatcher.group(1);
            
            // Comment the original line but keep it for reference
            String replacement = "/* Bypassed: " + cipherMatcher.group() + " */ " + cipherVar + " = null";
            cipherMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
            
            // Find and modify encryption/decryption calls
            Pattern encryptPattern = Pattern.compile(
                    cipherVar + "\\.(?:init|update|doFinal)\\s*\\([^)]*\\)",
                    Pattern.CASE_INSENSITIVE
            );
            
            Matcher encryptMatcher = encryptPattern.matcher(content);
            while (encryptMatcher.find()) {
                // Replace encryption calls with empty operations
                content = content.replace(
                        encryptMatcher.group(),
                        "/* Bypassed: " + encryptMatcher.group() + " */"
                );
            }
        }
        cipherMatcher.appendTail(sb);
        content = sb.toString();
        
        // Handle custom encrypt/decrypt methods
        Pattern customEncryptPattern = Pattern.compile(
                "(public|private|protected)\\s+(static\\s+)?(?:byte\\[\\]|String)\\s+(encrypt|decrypt)\\s*\\([^)]*\\)\\s*\\{",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher customEncryptMatcher = customEncryptPattern.matcher(content);
        while (customEncryptMatcher.find()) {
            String methodSignature = customEncryptMatcher.group();
            String methodName = customEncryptMatcher.group(3);
            
            // Find method body
            int methodStart = content.indexOf(methodSignature);
            int openBrace = content.indexOf("{", methodStart);
            if (openBrace != -1) {
                int closeBrace = findMatchingBrace(content, openBrace);
                if (closeBrace != -1) {
                    // Replace method implementation
                    String replacement;
                    if (methodName.equalsIgnoreCase("decrypt")) {
                        replacement = methodSignature + 
                                      "\n        // Bypass decryption\n" +
                                      "        return \"AUTOCRACKER-KEY\";\n    }";
                    } else {
                        replacement = methodSignature + 
                                      "\n        // Bypass encryption\n" +
                                      "        return \"AUTOCRACKER-ENCRYPTED\";\n    }";
                    }
                    
                    content = content.substring(0, methodStart) + 
                              replacement + 
                              content.substring(closeBrace + 1);
                }
            }
        }
        
        return content;
    }
    
    /**
     * Processes token validation methods.
     * 
     * @param content Source code content
     * @return Modified content with bypassed token validation
     */
    private String processTokenValidation(String content) {
        // Find and bypass token validation methods
        Pattern tokenMethodPattern = Pattern.compile(
                "(public|private|protected)\\s+(static\\s+)?boolean\\s+((?:validate|verify|check)(?:Token|Key|License|Auth)|is(?:Valid|Authenticated|Authorized|Licensed))\\s*\\([^)]*\\)\\s*\\{",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher tokenMethodMatcher = tokenMethodPattern.matcher(content);
        while (tokenMethodMatcher.find()) {
            String methodSignature = tokenMethodMatcher.group();
            
            // Find method body
            int methodStart = content.indexOf(methodSignature);
            int openBrace = content.indexOf("{", methodStart);
            if (openBrace != -1) {
                int closeBrace = findMatchingBrace(content, openBrace);
                if (closeBrace != -1) {
                    // Replace method implementation to always return true
                    String replacement = methodSignature + 
                                      "\n        // Bypass validation\n" +
                                      "        return true;\n    }";
                    
                    content = content.substring(0, methodStart) + 
                              replacement + 
                              content.substring(closeBrace + 1);
                }
            }
        }
        
        // Find and bypass token validation calls
        Pattern validateCallPattern = Pattern.compile(
                "(\\w+)\\.((?:validate|verify|check)(?:Token|Key|License|Auth)|is(?:Valid|Authenticated|Authorized|Licensed))\\s*\\([^)]*\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher validateCallMatcher = validateCallPattern.matcher(content);
        while (validateCallMatcher.find()) {
            String fullCall = validateCallMatcher.group();
            
            // Check if in a conditional
            boolean inConditional = false;
            int callPos = content.indexOf(fullCall);
            int ifStmtBefore = content.lastIndexOf("if", callPos);
            int closeParen = content.lastIndexOf(")", callPos);
            
            if (ifStmtBefore > -1 && closeParen > ifStmtBefore) {
                inConditional = true;
            }
            
            // Replace based on context
            if (inConditional) {
                content = content.replace(fullCall, "true /* Bypassed: " + fullCall + " */");
            } else {
                content = content.replace(fullCall, fullCall + " /* Result ignored, validation bypassed */");
            }
        }
        
        return content;
    }
    
    /**
     * Processes hashing and signature methods.
     * 
     * @param content Source code content
     * @return Modified content with bypassed hashing and signatures
     */
    private String processHashingAndSignatures(String content) {
        // Replace MessageDigest
        Pattern digestPattern = Pattern.compile(
                "(\\w+)\\s*=\\s*MessageDigest\\.getInstance\\(([^)]+)\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher digestMatcher = digestPattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (digestMatcher.find()) {
            String digestVar = digestMatcher.group(1);
            
            // Comment the original line but keep it for reference
            String replacement = "/* Bypassed: " + digestMatcher.group() + " */ " + digestVar + " = null";
            digestMatcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
            
            // Find and modify digest calls
            Pattern updatePattern = Pattern.compile(
                    digestVar + "\\.(?:update|digest)\\s*\\([^)]*\\)",
                    Pattern.CASE_INSENSITIVE
            );
            
            Matcher updateMatcher = updatePattern.matcher(content);
            while (updateMatcher.find()) {
                // Replace digest calls with empty operations
                content = content.replace(
                        updateMatcher.group(),
                        "/* Bypassed: " + updateMatcher.group() + " */ new byte[]{1, 2, 3, 4}"
                );
            }
        }
        digestMatcher.appendTail(sb);
        content = sb.toString();
        
        // Handle custom hash methods
        Pattern hashMethodPattern = Pattern.compile(
                "(public|private|protected)\\s+(static\\s+)?(?:byte\\[\\]|String)\\s+((?:generate|create)?(?:Hash|MD5|SHA|Signature|Sign))\\s*\\([^)]*\\)\\s*\\{",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher hashMethodMatcher = hashMethodPattern.matcher(content);
        while (hashMethodMatcher.find()) {
            String methodSignature = hashMethodMatcher.group();
            
            // Find method body
            int methodStart = content.indexOf(methodSignature);
            int openBrace = content.indexOf("{", methodStart);
            if (openBrace != -1) {
                int closeBrace = findMatchingBrace(content, openBrace);
                if (closeBrace != -1) {
                    // Replace method implementation
                    String returnType = methodSignature.contains("byte[]") ? "byte[]" : "String";
                    String returnValue = returnType.equals("byte[]") 
                        ? "new byte[]{0x01, 0x02, 0x03, 0x04, 0x05}" 
                        : "\"0102030405\"";
                    
                    String replacement = methodSignature + 
                                      "\n        // Bypass hash/signature\n" +
                                      "        return " + returnValue + ";\n    }";
                    
                    content = content.substring(0, methodStart) + 
                              replacement + 
                              content.substring(closeBrace + 1);
                }
            }
        }
        
        return content;
    }
    
    /**
     * Finds the matching closing brace for an opening brace.
     *
     * @param content Source code content
     * @param openBraceIndex Index of the opening brace
     * @return Index of the matching closing brace, or -1 if not found
     */
    private int findMatchingBrace(String content, int openBraceIndex) {
        int braceCount = 1;
        for (int i = openBraceIndex + 1; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '{') {
                braceCount++;
            } else if (c == '}') {
                braceCount--;
                if (braceCount == 0) {
                    return i;
                }
            }
        }
        return -1;
    }
}