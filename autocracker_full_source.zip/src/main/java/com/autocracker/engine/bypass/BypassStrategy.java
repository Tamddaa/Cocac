package com.autocracker.engine.bypass;

import java.nio.file.Path;
import java.util.Map;

/**
 * Interface defining a strategy for bypassing license protection.
 * Each implementation represents a different approach to detecting and bypassing
 * a specific type of license protection mechanism.
 */
public interface BypassStrategy {
    
    /**
     * Gets the name of this bypass strategy.
     * 
     * @return The strategy name
     */
    String getName();
    
    /**
     * Determines if this strategy should be applied to the given Java source file.
     * 
     * @param javaFile Path to the Java source file
     * @param content Content of the Java source file
     * @param metadata Additional metadata about the file or codebase
     * @return true if this strategy should be applied, false otherwise
     */
    boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata);
    
    /**
     * Processes the Java source file to bypass license protection.
     * 
     * @param javaFile Path to the Java source file
     * @param content Content of the Java source file
     * @param metadata Additional metadata about the file or codebase
     * @return Modified content with bypassed protection
     */
    String process(Path javaFile, String content, Map<String, Object> metadata);
    
    /**
     * Determines if this strategy supports direct class file processing.
     * Most strategies operate on decompiled Java source, but some may also
     * directly manipulate bytecode.
     * 
     * @return true if this strategy can process class files, false otherwise
     */
    default boolean supportsClassFiles() {
        return false;
    }
    
    /**
     * Determines if this strategy should be applied to the given class file.
     * Only called if {@link #supportsClassFiles()} returns true.
     * 
     * @param classFile Path to the class file
     * @param metadata Additional metadata about the file or codebase
     * @return true if this strategy should be applied, false otherwise
     */
    default boolean shouldApplyToClass(Path classFile, Map<String, Object> metadata) {
        return false;
    }
    
    /**
     * Processes the class file to bypass license protection.
     * Only called if {@link #supportsClassFiles()} returns true and
     * {@link #shouldApplyToClass(Path, Map)} returns true.
     * 
     * @param classFile Path to the class file
     * @param metadata Additional metadata about the file or codebase
     * @return true if the class was successfully modified, false otherwise
     */
    default boolean processClass(Path classFile, Map<String, Object> metadata) {
        return false;
    }
}