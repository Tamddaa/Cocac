package com.autocracker.engine.bypass;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bypass strategy for known license protection systems.
 * Contains specialized handlers for common protection systems like LicenseManager, XProtect, etc.
 */
public class KnownSystemStrategy implements BypassStrategy {
    private static final Logger logger = LoggerManager.getLogger(KnownSystemStrategy.class);
    
    // List of known protection system class names
    private static final List<String> KNOWN_SYSTEMS = Arrays.asList(
            "LicenseManager", 
            "LicenseVerifier",
            "XProtect", 
            "SpigotGuard", 
            "AuthlibHandler",
            "LicenseValidator",
            "AdvancedLicense",
            "AuthPlugin",
            "Authentication",
            "ServerAuth",
            "PremiumValidator"
    );
    
    @Override
    public String getName() {
        return "Known System Bypass";
    }
    
    @Override
    public boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata) {
        // Check if content references any of the known protection systems
        for (String system : KNOWN_SYSTEMS) {
            if (content.contains(system)) {
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public String process(Path javaFile, String content, Map<String, Object> metadata) {
        logger.debug("Applying known system bypass to: {}", javaFile);
        String modifiedContent = content;
        
        // Check which protection system is used and apply appropriate bypass
        if (content.contains("LicenseManager")) {
            modifiedContent = bypassLicenseManager(modifiedContent);
        }
        
        if (content.contains("XProtect")) {
            modifiedContent = bypassXProtect(modifiedContent);
        }
        
        if (content.contains("SpigotGuard")) {
            modifiedContent = bypassSpigotGuard(modifiedContent);
        }
        
        if (content.contains("AuthlibHandler")) {
            modifiedContent = bypassAuthlibHandler(modifiedContent);
        }
        
        if (content.contains("AdvancedLicense")) {
            modifiedContent = bypassAdvancedLicense(modifiedContent);
        }
        
        if (content.contains("ServerAuth")) {
            modifiedContent = bypassServerAuth(modifiedContent);
        }
        
        return modifiedContent;
    }
    
    /**
     * Bypasses the LicenseManager protection system.
     * 
     * @param content Source code content
     * @return Modified content with bypassed protection
     */
    private String bypassLicenseManager(String content) {
        logger.debug("Bypassing LicenseManager system");
        
        // Replace license verification calls
        content = replaceMethodCalls(content, "LicenseManager.verify", "true");
        content = replaceMethodCalls(content, "LicenseManager.isValidLicense", "true");
        content = replaceMethodCalls(content, "LicenseManager.checkLicense", "true");
        content = replaceMethodCalls(content, "LicenseManager.isValid", "true");
        
        // Disable license initialization
        content = replaceMethodCalls(content, "LicenseManager.initialize", "/* Bypassed initialization */");
        content = replaceMethodCalls(content, "LicenseManager.setup", "/* Bypassed setup */");
        
        // Disable license checking
        content = replaceMethodCalls(content, "LicenseManager.startChecking", "/* Bypassed checking */");
        
        return content;
    }
    
    /**
     * Bypasses the XProtect protection system.
     * 
     * @param content Source code content
     * @return Modified content with bypassed protection
     */
    private String bypassXProtect(String content) {
        logger.debug("Bypassing XProtect system");
        
        // Replace verification calls
        content = replaceMethodCalls(content, "XProtect.verify", "true");
        content = replaceMethodCalls(content, "XProtect.check", "true");
        content = replaceMethodCalls(content, "XProtect.isVerified", "true");
        content = replaceMethodCalls(content, "XProtect.isValid", "true");
        content = replaceMethodCalls(content, "XProtect.isLicensed", "true");
        
        // Disable initialization
        content = replaceMethodCalls(content, "XProtect.initialize", "/* Bypassed initialization */");
        content = replaceMethodCalls(content, "XProtect.start", "/* Bypassed start */");
        
        // Disable shutdown hooks
        content = replaceMethodCalls(content, "XProtect.addShutdownHook", "/* Bypassed shutdown hook */");
        
        return content;
    }
    
    /**
     * Bypasses the SpigotGuard protection system.
     * 
     * @param content Source code content
     * @return Modified content with bypassed protection
     */
    private String bypassSpigotGuard(String content) {
        logger.debug("Bypassing SpigotGuard system");
        
        // Replace verification calls
        content = replaceMethodCalls(content, "SpigotGuard.isValid", "true");
        content = replaceMethodCalls(content, "SpigotGuard.verify", "true");
        content = replaceMethodCalls(content, "SpigotGuard.check", "true");
        content = replaceMethodCalls(content, "SpigotGuard.isLicensed", "true");
        
        // Disable tracking and reporting
        content = replaceMethodCalls(content, "SpigotGuard.track", "/* Bypassed tracking */");
        content = replaceMethodCalls(content, "SpigotGuard.report", "/* Bypassed reporting */");
        content = replaceMethodCalls(content, "SpigotGuard.collectInfo", "/* Bypassed info collection */");
        
        // Disable initialization
        content = replaceMethodCalls(content, "SpigotGuard.initialize", "/* Bypassed initialization */");
        content = replaceMethodCalls(content, "SpigotGuard.setup", "/* Bypassed setup */");
        
        return content;
    }
    
    /**
     * Bypasses the AuthlibHandler protection system.
     * 
     * @param content Source code content
     * @return Modified content with bypassed protection
     */
    private String bypassAuthlibHandler(String content) {
        logger.debug("Bypassing AuthlibHandler system");
        
        // Replace verification calls
        content = replaceMethodCalls(content, "AuthlibHandler.authenticate", "true");
        content = replaceMethodCalls(content, "AuthlibHandler.verify", "true");
        content = replaceMethodCalls(content, "AuthlibHandler.checkLicense", "true");
        content = replaceMethodCalls(content, "AuthlibHandler.isAuthenticated", "true");
        content = replaceMethodCalls(content, "AuthlibHandler.isValid", "true");
        
        // Replace token generation/validation
        content = replaceMethodCalls(content, "AuthlibHandler.generateToken", "\"AUTOCRACKER-TOKEN\"");
        content = replaceMethodCalls(content, "AuthlibHandler.validateToken", "true");
        
        // Disable initialization
        content = replaceMethodCalls(content, "AuthlibHandler.initialize", "/* Bypassed initialization */");
        content = replaceMethodCalls(content, "AuthlibHandler.setup", "/* Bypassed setup */");
        
        return content;
    }
    
    /**
     * Bypasses the AdvancedLicense protection system.
     * 
     * @param content Source code content
     * @return Modified content with bypassed protection
     */
    private String bypassAdvancedLicense(String content) {
        logger.debug("Bypassing AdvancedLicense system");
        
        // Replace instance method calls
        Pattern instancePattern = Pattern.compile("(\\w+)\\s*=\\s*new\\s+AdvancedLicense\\(([^)]+)\\)");
        Matcher matcher = instancePattern.matcher(content);
        
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String varName = matcher.group(1);
            
            // Look for method calls on this instance
            content = content.replaceAll(
                Pattern.quote(varName) + "\\.isValid\\(\\)", 
                "true"
            );
            
            content = content.replaceAll(
                Pattern.quote(varName) + "\\.verify\\(\\)", 
                "true"
            );
            
            matcher.appendReplacement(sb, matcher.group());
        }
        matcher.appendTail(sb);
        content = sb.toString();
        
        // Also modify constructor to prevent actual API calls
        content = content.replaceAll(
            "new\\s+AdvancedLicense\\(([^)]+)\\)",
            "/* Bypassed */ new AdvancedLicense($1)"
        );
        
        return content;
    }
    
    /**
     * Bypasses the ServerAuth protection system.
     * 
     * @param content Source code content
     * @return Modified content with bypassed protection
     */
    private String bypassServerAuth(String content) {
        logger.debug("Bypassing ServerAuth system");
        
        // Replace verification calls
        content = replaceMethodCalls(content, "ServerAuth.verify", "true");
        content = replaceMethodCalls(content, "ServerAuth.checkKey", "true");
        content = replaceMethodCalls(content, "ServerAuth.isVerified", "true");
        content = replaceMethodCalls(content, "ServerAuth.isAuthorized", "true");
        
        // Replace IP verification
        content = replaceMethodCalls(content, "ServerAuth.isIpAuthorized", "true");
        
        // Disable initialization
        content = replaceMethodCalls(content, "ServerAuth.initialize", "/* Bypassed initialization */");
        content = replaceMethodCalls(content, "ServerAuth.register", "/* Bypassed registration */");
        
        return content;
    }
    
    /**
     * Replaces method calls with a replacement value.
     * 
     * @param content Source code content
     * @param methodCall Method call to replace
     * @param replacement Replacement value
     * @return Modified content
     */
    private String replaceMethodCalls(String content, String methodCall, String replacement) {
        // Replace simple method calls
        Pattern simpleCallPattern = Pattern.compile(
                Pattern.quote(methodCall) + "\\s*\\([^)]*\\)"
        );
        
        Matcher matcher = simpleCallPattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (matcher.find()) {
            String call = matcher.group();
            
            // Check if it's in a condition
            boolean inCondition = false;
            int pos = content.indexOf(call);
            int ifStatementPos = content.lastIndexOf("if", pos);
            int whileStatementPos = content.lastIndexOf("while", pos);
            
            if (ifStatementPos != -1 && content.substring(ifStatementPos, pos).contains("(")) {
                inCondition = true;
            }
            
            if (whileStatementPos != -1 && content.substring(whileStatementPos, pos).contains("(")) {
                inCondition = true;
            }
            
            // Check if it's used in an assignment
            boolean inAssignment = false;
            int semicolonBefore = content.lastIndexOf(";", pos);
            int equalSignPos = content.lastIndexOf("=", pos);
            
            if (semicolonBefore != -1 && equalSignPos != -1 && equalSignPos > semicolonBefore) {
                inAssignment = true;
            }
            
            // Handle different contexts
            if (inCondition) {
                matcher.appendReplacement(sb, replacement);
            } else if (inAssignment) {
                matcher.appendReplacement(sb, replacement);
            } else {
                // Just a statement, replace with appropriate code
                if (replacement.startsWith("/*")) {
                    // Comment replacement
                    matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
                } else {
                    // Value replacement, keep the statement form
                    matcher.appendReplacement(sb, Matcher.quoteReplacement(call + "; /* Bypassed */"));
                }
            }
        }
        matcher.appendTail(sb);
        
        return sb.toString();
    }
}