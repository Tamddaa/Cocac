package com.autocracker.engine.bypass;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bypass strategy for license checks that use Java reflection.
 * Detects and bypasses license validation that's hidden through reflection or obfuscation.
 */
public class ReflectionStrategy implements BypassStrategy {
    private static final Logger logger = LoggerManager.getLogger(ReflectionStrategy.class);
    
    private static final Pattern REFLECTION_PATTERN = Pattern.compile(
            "(?:Class\\.forName|getMethod|invoke|getField|getDeclaredMethod|getDeclaredField)\\s*\\([^)]*\\)",
            Pattern.CASE_INSENSITIVE
    );
    
    private static final Pattern METHOD_INVOKE_PATTERN = Pattern.compile(
            "(\\w+)\\s*\\.\\s*invoke\\s*\\(([^)]+)\\)",
            Pattern.CASE_INSENSITIVE
    );
    
    @Override
    public String getName() {
        return "Reflection Bypass";
    }
    
    @Override
    public boolean shouldApply(Path javaFile, String content, Map<String, Object> metadata) {
        // Check if content contains reflection patterns
        Matcher reflectionMatcher = REFLECTION_PATTERN.matcher(content);
        
        // Check if reflection is used in a context that suggests license verification
        return reflectionMatcher.find() && (
               content.toLowerCase().contains("license") ||
               content.toLowerCase().contains("auth") ||
               content.toLowerCase().contains("valid") ||
               content.toLowerCase().contains("check") ||
               content.toLowerCase().contains("verify"));
    }
    
    @Override
    public String process(Path javaFile, String content, Map<String, Object> metadata) {
        logger.debug("Applying reflection bypass to: {}", javaFile);
        String modifiedContent = content;
        
        // 1. Handle Class.forName calls that might load license checker classes
        modifiedContent = processClassForName(modifiedContent);
        
        // 2. Handle getMethod and invoke calls
        modifiedContent = processMethodInvocation(modifiedContent);
        
        // 3. Handle field reflection that might store license state
        modifiedContent = processFieldReflection(modifiedContent);
        
        return modifiedContent;
    }
    
    /**
     * Processes Class.forName calls that might load license checker classes.
     *
     * @param content Source code content
     * @return Modified content with bypassed Class.forName calls
     */
    private String processClassForName(String content) {
        Pattern classForNamePattern = Pattern.compile(
                "Class\\.forName\\s*\\(\\s*\"([^\"]+)\"\\s*\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher matcher = classForNamePattern.matcher(content);
        StringBuffer sb = new StringBuffer();
        
        while (matcher.find()) {
            String fullMatch = matcher.group();
            String className = matcher.group(1);
            
            // Check if this is likely loading a license-related class
            if (className.toLowerCase().contains("license") ||
                className.toLowerCase().contains("auth") ||
                className.toLowerCase().contains("valid") ||
                className.toLowerCase().contains("protect")) {
                
                logger.debug("Found reflection loading license class: {}", className);
                
                // Replace with null or dummy class depending on context
                String replacement = "/* Bypassed Class.forName */ null";
                
                // Check if the result is used in a null check
                int pos = content.indexOf(fullMatch);
                int semicolon = content.indexOf(";", pos);
                if (semicolon != -1) {
                    String nextChars = content.substring(pos + fullMatch.length(), semicolon).trim();
                    if (nextChars.isEmpty()) {
                        // If this is standalone, just comment it out
                        replacement = "/* Bypassed: " + fullMatch + " */ null";
                    } else {
                        // If it's used in an expression, use Object.class to avoid NullPointerException
                        replacement = "/* Bypassed: " + fullMatch + " */ Object.class";
                    }
                }
                
                matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
            } else {
                matcher.appendReplacement(sb, Matcher.quoteReplacement(fullMatch));
            }
        }
        matcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Processes method invocation through reflection.
     *
     * @param content Source code content
     * @return Modified content with bypassed method invocation
     */
    private String processMethodInvocation(String content) {
        // Find method retrieval
        Pattern getMethodPattern = Pattern.compile(
                "(\\w+)\\s*=\\s*(\\w+)\\.getMethod\\(\\s*\"([^\"]+)\"[^)]*\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher methodMatcher = getMethodPattern.matcher(content);
        StringBuffer methodSb = new StringBuffer();
        
        while (methodMatcher.find()) {
            String methodVarName = methodMatcher.group(1);
            String methodName = methodMatcher.group(3);
            
            // Check if method name suggests license verification
            if (methodName.toLowerCase().contains("check") ||
                methodName.toLowerCase().contains("valid") ||
                methodName.toLowerCase().contains("verify") ||
                methodName.toLowerCase().contains("license") ||
                methodName.toLowerCase().contains("auth")) {
                
                logger.debug("Found reflection method for license check: {}", methodName);
                
                // Look for invoke call with this method variable
                Pattern invokePattern = Pattern.compile(
                        methodVarName + "\\s*\\.\\s*invoke\\s*\\([^)]+\\)",
                        Pattern.CASE_INSENSITIVE
                );
                
                Matcher invokeMatcher = invokePattern.matcher(content);
                if (invokeMatcher.find()) {
                    String invokeCall = invokeMatcher.group();
                    int invokePos = content.indexOf(invokeCall);
                    
                    // Determine context - is it used in a boolean condition?
                    boolean usedInCondition = false;
                    int semicolonAfter = content.indexOf(";", invokePos);
                    if (semicolonAfter != -1) {
                        String line = content.substring(invokePos, semicolonAfter).trim();
                        if (line.equals(invokeCall)) {
                            // Standalone invocation - likely void method
                            content = content.replace(invokeCall, "/* Bypassed method invocation */ null");
                        } else {
                            // Used in an expression
                            int ifBefore = content.lastIndexOf("if", invokePos);
                            int whileBefore = content.lastIndexOf("while", invokePos);
                            int closeBracketBefore = content.lastIndexOf(")", invokePos);
                            
                            if ((ifBefore > -1 && closeBracketBefore > ifBefore) ||
                                (whileBefore > -1 && closeBracketBefore > whileBefore)) {
                                usedInCondition = true;
                            }
                            
                            if (usedInCondition) {
                                content = content.replace(invokeCall, "/* Bypassed condition */ true");
                            } else {
                                // General replacement - might need adjustment based on context
                                content = content.replace(invokeCall, "/* Bypassed method invocation */ null");
                            }
                        }
                    }
                }
                
                // Replace the getMethod call too
                methodMatcher.appendReplacement(methodSb, Matcher.quoteReplacement("/* Bypassed getMethod */ null"));
            } else {
                methodMatcher.appendReplacement(methodSb, Matcher.quoteReplacement(methodMatcher.group()));
            }
        }
        methodMatcher.appendTail(methodSb);
        
        return methodSb.toString();
    }
    
    /**
     * Processes field reflection that might store license state.
     *
     * @param content Source code content
     * @return Modified content with bypassed field reflection
     */
    private String processFieldReflection(String content) {
        // Find field retrieval for license state
        Pattern getFieldPattern = Pattern.compile(
                "(\\w+)\\s*=\\s*(\\w+)\\.getField\\(\\s*\"([^\"]+)\"\\s*\\)",
                Pattern.CASE_INSENSITIVE
        );
        
        Matcher fieldMatcher = getFieldPattern.matcher(content);
        StringBuffer fieldSb = new StringBuffer();
        
        while (fieldMatcher.find()) {
            String fieldVarName = fieldMatcher.group(1);
            String fieldName = fieldMatcher.group(3);
            
            // Check if field name suggests license state
            if (fieldName.toLowerCase().contains("license") ||
                fieldName.toLowerCase().contains("valid") ||
                fieldName.toLowerCase().contains("auth") ||
                fieldName.toLowerCase().contains("activated") ||
                fieldName.toLowerCase().contains("premium")) {
                
                logger.debug("Found reflection field for license state: {}", fieldName);
                
                // Look for setting license state to true
                Pattern setPattern = Pattern.compile(
                        fieldVarName + "\\.set\\w*\\([^,]+,\\s*(true|false)\\s*\\)",
                        Pattern.CASE_INSENSITIVE
                );
                
                Matcher setMatcher = setPattern.matcher(content);
                if (setMatcher.find()) {
                    String setCall = setMatcher.group();
                    String booleanValue = setMatcher.group(1);
                    
                    // Force license state to be true
                    if (booleanValue.equals("false")) {
                        content = content.replace(setCall, setCall.replace("false", "true"));
                    }
                }
                
                // Leave the getField call intact to avoid breaking the code
                fieldMatcher.appendReplacement(fieldSb, Matcher.quoteReplacement(fieldMatcher.group()));
            } else {
                fieldMatcher.appendReplacement(fieldSb, Matcher.quoteReplacement(fieldMatcher.group()));
            }
        }
        fieldMatcher.appendTail(fieldSb);
        
        return fieldSb.toString();
    }
}