package com.autocracker.crypto;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Advanced crypto detection module for analyzing Java source and bytecode.
 * Identifies various encryption algorithms, keys, and license verification patterns.
 */
public class CryptoDetector {
    private static final Logger logger = LoggerManager.getLogger(CryptoDetector.class);
    
    // Patterns for detecting various cryptographic usages
    private static final Map<String, Pattern> CRYPTO_PATTERNS = new HashMap<>();
    
    static {
        // Cipher initialization patterns
        CRYPTO_PATTERNS.put("AES", Pattern.compile("(?i)Cipher\\.getInstance\\([\"']AES[^\"']*[\"']\\)|new SecretKeySpec\\([^,]+,\\s*[\"']AES[\"']\\)"));
        CRYPTO_PATTERNS.put("DES", Pattern.compile("(?i)Cipher\\.getInstance\\([\"']DES[^\"']*[\"']\\)|new SecretKeySpec\\([^,]+,\\s*[\"']DES[\"']\\)"));
        CRYPTO_PATTERNS.put("DESede", Pattern.compile("(?i)Cipher\\.getInstance\\([\"']DESede[^\"']*[\"']\\)|new SecretKeySpec\\([^,]+,\\s*[\"']DESede[\"']\\)"));
        CRYPTO_PATTERNS.put("Blowfish", Pattern.compile("(?i)Cipher\\.getInstance\\([\"']Blowfish[^\"']*[\"']\\)|new SecretKeySpec\\([^,]+,\\s*[\"']Blowfish[\"']\\)"));
        
        // RSA patterns
        CRYPTO_PATTERNS.put("RSA", Pattern.compile("(?i)Cipher\\.getInstance\\([\"']RSA[^\"']*[\"']\\)|KeyPairGenerator\\.getInstance\\([\"']RSA[\"']\\)|KeyFactory\\.getInstance\\([\"']RSA[\"']\\)"));
        
        // Signature verification patterns
        CRYPTO_PATTERNS.put("Signature", Pattern.compile("(?i)Signature\\.getInstance\\([^)]+\\)|signature\\.initVerify\\(|signature\\.verify\\("));
        
        // MessageDigest patterns (hash functions)
        CRYPTO_PATTERNS.put("MD5", Pattern.compile("(?i)MessageDigest\\.getInstance\\([\"']MD5[\"']\\)"));
        CRYPTO_PATTERNS.put("SHA-1", Pattern.compile("(?i)MessageDigest\\.getInstance\\([\"']SHA-?1[\"']\\)"));
        CRYPTO_PATTERNS.put("SHA-256", Pattern.compile("(?i)MessageDigest\\.getInstance\\([\"']SHA-?256[\"']\\)"));
        
        // MAC (Message Authentication Code) patterns
        CRYPTO_PATTERNS.put("HMAC", Pattern.compile("(?i)Mac\\.getInstance\\([\"']HmacSHA[0-9]+[\"']\\)"));
        
        // Key-related patterns
        CRYPTO_PATTERNS.put("KeyStore", Pattern.compile("(?i)KeyStore\\.getInstance\\(|keyStore\\.load\\("));
        
        // License verification patterns
        CRYPTO_PATTERNS.put("License", Pattern.compile("(?i)license|verify|validate|check|activation|register|premium"));
    }
    
    /**
     * Class representing detailed crypto usage information
     */
    public static class CryptoInfo {
        private Map<String, List<String>> detectedAlgorithms = new HashMap<>();
        private List<String> potentialKeys = new ArrayList<>();
        private boolean hasLicenseVerification = false;
        private Set<String> licensePatterns = new HashSet<>();
        
        /**
         * Get all detected cryptographic algorithms
         * 
         * @return Map of algorithm types to specific instances
         */
        public Map<String, List<String>> getDetectedAlgorithms() {
            return Collections.unmodifiableMap(detectedAlgorithms);
        }
        
        /**
         * Get a flattened list of all detected algorithms
         * 
         * @return List of all algorithm names
         */
        public List<String> getDetectedAlgorithmsList() {
            List<String> result = new ArrayList<>();
            for (List<String> algorithms : detectedAlgorithms.values()) {
                result.addAll(algorithms);
            }
            return result;
        }
        
        /**
         * Get potential encryption keys or passwords
         * 
         * @return List of potential key strings
         */
        public List<String> getPotentialKeys() {
            return Collections.unmodifiableList(potentialKeys);
        }
        
        /**
         * Check if license verification was detected
         * 
         * @return true if license verification was detected
         */
        public boolean hasLicenseVerification() {
            return hasLicenseVerification;
        }
        
        /**
         * Get detected license verification patterns
         * 
         * @return Set of license verification pattern names
         */
        public Set<String> getLicensePatterns() {
            return Collections.unmodifiableSet(licensePatterns);
        }
        
        /**
         * Add a detected algorithm
         * 
         * @param type Algorithm type (e.g., "Cipher", "Hash")
         * @param algorithm Specific algorithm (e.g., "AES", "SHA-256")
         */
        void addAlgorithm(String type, String algorithm) {
            detectedAlgorithms.computeIfAbsent(type, k -> new ArrayList<>()).add(algorithm);
        }
        
        /**
         * Add a potential key
         * 
         * @param key Potential encryption key or password
         */
        void addPotentialKey(String key) {
            if (key != null && !key.isEmpty() && !potentialKeys.contains(key)) {
                potentialKeys.add(key);
            }
        }
        
        /**
         * Set license verification flag
         * 
         * @param hasLicenseVerification true if license verification was detected
         */
        void setHasLicenseVerification(boolean hasLicenseVerification) {
            this.hasLicenseVerification = hasLicenseVerification;
        }
        
        /**
         * Add a license pattern
         * 
         * @param pattern Name of the detected license pattern
         */
        void addLicensePattern(String pattern) {
            if (pattern != null && !pattern.isEmpty()) {
                licensePatterns.add(pattern);
                setHasLicenseVerification(true);
            }
        }
    }
    
    /**
     * Analyze a Java source file for cryptographic usage
     * 
     * @param sourceFile Path to the Java source file
     * @return CryptoInfo object with detailed analysis
     */
    public static CryptoInfo analyzeJavaSource(Path sourceFile) {
        try {
            String content = Files.readString(sourceFile, StandardCharsets.UTF_8);
            return analyzeJavaContent(content, sourceFile.getFileName().toString());
        } catch (IOException e) {
            logger.error("Error reading source file {}: {}", sourceFile, e.getMessage());
            return new CryptoInfo();
        }
    }
    
    /**
     * Analyze Java source content for cryptographic usage
     * 
     * @param content Java source code content
     * @param fileName Source file name for logging
     * @return CryptoInfo object with detailed analysis
     */
    public static CryptoInfo analyzeJavaContent(String content, String fileName) {
        CryptoInfo info = new CryptoInfo();
        
        try {
            // Check for various crypto patterns
            for (Map.Entry<String, Pattern> entry : CRYPTO_PATTERNS.entrySet()) {
                String patternName = entry.getKey();
                Pattern pattern = entry.getValue();
                
                Matcher matcher = pattern.matcher(content);
                if (matcher.find()) {
                    if (patternName.equals("License")) {
                        info.addLicensePattern(patternName);
                        logger.debug("Detected license verification pattern in {}", fileName);
                    } else {
                        // Categorize the algorithm
                        String type = categorizeAlgorithm(patternName);
                        info.addAlgorithm(type, patternName);
                        logger.debug("Detected {} ({}) in {}", type, patternName, fileName);
                    }
                }
            }
            
            // Look for potential keys (string literals, byte arrays, etc.)
            detectPotentialKeys(content, info);
            
            return info;
        } catch (Exception e) {
            logger.error("Error analyzing Java content in {}: {}", fileName, e.getMessage());
            return info;
        }
    }
    
    /**
     * Categorize an algorithm into a type
     * 
     * @param algorithm Algorithm name
     * @return Type category (Cipher, Hash, Signature, etc.)
     */
    private static String categorizeAlgorithm(String algorithm) {
        if (algorithm.equals("AES") || algorithm.equals("DES") || algorithm.equals("DESede") || algorithm.equals("Blowfish")) {
            return "Cipher";
        } else if (algorithm.equals("RSA")) {
            return "AsymmetricCipher";
        } else if (algorithm.equals("Signature")) {
            return "Signature";
        } else if (algorithm.equals("MD5") || algorithm.equals("SHA-1") || algorithm.equals("SHA-256")) {
            return "Hash";
        } else if (algorithm.equals("HMAC")) {
            return "MAC";
        } else if (algorithm.equals("KeyStore")) {
            return "KeyStorage";
        } else {
            return "Other";
        }
    }
    
    /**
     * Detect potential encryption keys in Java source
     * 
     * @param content Java source content
     * @param info CryptoInfo object to update
     */
    private static void detectPotentialKeys(String content, CryptoInfo info) {
        try {
            // Pattern for string literals that might be keys
            Pattern stringLiteralPattern = Pattern.compile("\"([^\"]*)\"");
            Matcher stringMatcher = stringLiteralPattern.matcher(content);
            
            while (stringMatcher.find()) {
                String literal = stringMatcher.group(1);
                
                // Check if this string looks like a key
                if (ObfuscatedStringDecoder.isPotentialLicenseKey(literal)) {
                    info.addPotentialKey(literal);
                    logger.debug("Detected potential key: {}", literal);
                }
            }
            
            // Pattern for byte arrays that might be keys
            Pattern byteArrayPattern = Pattern.compile("new\\s+byte\\s*\\[\\s*\\]\\s*\\{\\s*([^}]+)\\s*\\}");
            Matcher byteMatcher = byteArrayPattern.matcher(content);
            
            while (byteMatcher.find()) {
                String byteArrayStr = byteMatcher.group(1);
                info.addPotentialKey("BYTE_ARRAY: " + byteArrayStr.trim());
                logger.debug("Detected potential byte array key");
            }
            
            // Pattern for Base64 encoded data
            Pattern base64Pattern = Pattern.compile("(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})");
            Matcher base64Matcher = base64Pattern.matcher(content);
            
            while (base64Matcher.find()) {
                String base64Str = base64Matcher.group();
                
                // Only consider base64 strings of a certain length (likely to be keys)
                if (base64Str.length() >= 16 && base64Str.length() <= 128) {
                    info.addPotentialKey("BASE64: " + base64Str);
                    logger.debug("Detected potential Base64 encoded key");
                }
            }
            
        } catch (Exception e) {
            logger.error("Error detecting potential keys: {}", e.getMessage());
        }
    }
    
    /**
     * Checks if a byte array is likely to be a cryptographic key
     * 
     * @param bytes Byte array to check
     * @return true if likely a key, false otherwise
     */
    public static boolean isPotentialKey(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return false;
        }
        
        // Common key sizes
        int[] commonKeySizes = {16, 24, 32, 64, 128, 256};
        
        // Check if length matches common key sizes
        boolean isCommonSize = false;
        for (int size : commonKeySizes) {
            if (bytes.length == size || bytes.length == size / 8) {
                isCommonSize = true;
                break;
            }
        }
        
        if (!isCommonSize) {
            return false;
        }
        
        // Check distribution of byte values
        int zeros = 0;
        int nonzeros = 0;
        
        for (byte b : bytes) {
            if (b == 0) {
                zeros++;
            } else {
                nonzeros++;
            }
        }
        
        // A key likely has a good mix of zero and non-zero bytes
        double zeroRatio = (double) zeros / bytes.length;
        
        // Most keys aren't all zeros or all non-zeros
        return zeroRatio < 0.8 && zeroRatio > 0.1;
    }
    
    /**
     * Check if a Java class contains hard-coded license checks
     * 
     * @param classContent Class file content
     * @return true if license checks detected, false otherwise
     */
    public static boolean detectsLicenseChecks(byte[] classContent) {
        if (classContent == null || classContent.length == 0) {
            return false;
        }
        
        try {
            // Convert to string for text-based analysis
            String content = new String(classContent, StandardCharsets.UTF_8);
            
            // Common strings found in license verification
            String[] licensePatterns = {
                "license", "verify", "valid", "check", "premium", "auth", "activation",
                "register", "getHWID", "hwid", "hardware", "expir", "trial"
            };
            
            for (String pattern : licensePatterns) {
                if (content.toLowerCase().contains(pattern.toLowerCase())) {
                    return true;
                }
            }
            
            return false;
        } catch (Exception e) {
            logger.error("Error detecting license checks: {}", e.getMessage());
            return false;
        }
    }
}