package com.autocracker.crypto;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Factory class for managing and coordinating all crypto-related bypass modules.
 * This factory provides a unified interface for detecting and bypassing various
 * encryption and obfuscation techniques used in license protection systems.
 */
public class CryptoBypassModuleFactory {
    private static final Logger logger = LoggerManager.getLogger(CryptoBypassModuleFactory.class);
    
    /**
     * Analyzes a class file for various cryptographic usage and applies appropriate bypasses.
     *
     * @param classFile Path to the class file to analyze and patch
     * @return true if any crypto-related patches were applied, false otherwise
     */
    public static boolean processCryptoProtections(Path classFile) {
        boolean modified = false;
        
        try {
            // Step 1: Detect and bypass Cipher operations (AES, DES, Blowfish)
            if (CipherBypassModule.detectsCipherUsage(classFile)) {
                logger.debug("Detected Cipher operations in {}", classFile.getFileName());
                if (CipherBypassModule.patchClassFile(classFile)) {
                    logger.info("Successfully bypassed Cipher operations in {}", classFile.getFileName());
                    modified = true;
                }
            }
            
            // Step 2: Detect and bypass RSA operations
            if (RSAKeyOverrideModule.detectsRSAUsage(classFile)) {
                logger.debug("Detected RSA operations in {}", classFile.getFileName());
                if (RSAKeyOverrideModule.patchClassFile(classFile)) {
                    logger.info("Successfully bypassed RSA operations in {}", classFile.getFileName());
                    modified = true;
                }
            }
            
            // Step 3: Apply additional crypto bypasses as needed 
            // (e.g., MessageDigest for hashing, Mac for HMAC, etc.)
            // Implementation for other modules would go here
            
            return modified;
        } catch (Exception e) {
            logger.error("Error processing crypto protections for {}: {}", 
                       classFile.getFileName(), e.getMessage());
            return false;
        }
    }
    
    /**
     * Analyzes a Java source file for cryptographic usage and returns detailed information.
     *
     * @param sourceFile Path to the Java source file
     * @return CryptoDetector.CryptoInfo object with detailed analysis
     */
    public static CryptoDetector.CryptoInfo analyzeCryptoUsage(Path sourceFile) {
        return CryptoDetector.analyzeJavaSource(sourceFile);
    }
    
    /**
     * Attempts to decode obfuscated strings in a Java source file.
     *
     * @param sourceContent Content of the Java source file
     * @return Map of encoded strings to their decoded values
     */
    public static Map<String, String> decodeObfuscatedStrings(String sourceContent) {
        Map<String, String> result = new HashMap<>();
        
        try {
            // Find potential obfuscated strings
            Pattern stringPattern = Pattern.compile("\"([^\"]*)\"");
            Matcher matcher = stringPattern.matcher(sourceContent);
            
            while (matcher.find()) {
                String encoded = matcher.group(1);
                String decoded = ObfuscatedStringDecoder.tryDecode(encoded);
                
                if (!encoded.equals(decoded)) {
                    result.put(encoded, decoded);
                }
            }
            
        } catch (Exception e) {
            logger.error("Error decoding obfuscated strings: {}", e.getMessage());
        }
        
        return result;
    }
}