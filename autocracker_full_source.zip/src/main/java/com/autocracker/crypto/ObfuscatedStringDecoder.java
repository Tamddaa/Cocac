package com.autocracker.crypto;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Specialized module for detecting and decoding obfuscated strings in plugin code.
 * Handles various string obfuscation techniques including Base64, byte arrays, and Unicode escapes.
 */
public class ObfuscatedStringDecoder {
    private static final Logger logger = LoggerManager.getLogger(ObfuscatedStringDecoder.class);
    
    /**
     * Class to store decoded string results
     */
    public static class DecodingResult {
        private final Map<String, List<String>> decodedStrings;
        private final List<String> potentialLicenseKeys;
        
        public DecodingResult() {
            this.decodedStrings = new HashMap<>();
            this.potentialLicenseKeys = new ArrayList<>();
        }
        
        public void addDecoded(String type, String value) {
            decodedStrings.computeIfAbsent(type, k -> new ArrayList<>()).add(value);
            
            // Check if this could be a license key
            if (isPotentialLicenseKey(value)) {
                potentialLicenseKeys.add(value);
            }
        }
        
        public Map<String, List<String>> getDecodedStrings() {
            return decodedStrings;
        }
        
        public List<String> getPotentialLicenseKeys() {
            return potentialLicenseKeys;
        }
        
        public boolean hasResults() {
            return !decodedStrings.isEmpty();
        }
        
        public int getTotalDecodedCount() {
            int count = 0;
            for (List<String> list : decodedStrings.values()) {
                count += list.size();
            }
            return count;
        }
        
        @Override
        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append("Decoded strings by type:\n");
            
            for (Map.Entry<String, List<String>> entry : decodedStrings.entrySet()) {
                builder.append(entry.getKey()).append(": ").append(entry.getValue().size()).append(" items\n");
                for (String value : entry.getValue()) {
                    builder.append("  - ").append(value).append("\n");
                }
            }
            
            if (!potentialLicenseKeys.isEmpty()) {
                builder.append("\nPotential license keys/secrets:\n");
                for (String key : potentialLicenseKeys) {
                    builder.append("  - ").append(key).append("\n");
                }
            }
            
            return builder.toString();
        }
    }
    
    /**
     * Process a Java source file to find and decode obfuscated strings
     * 
     * @param sourceCode Content of the Java source file
     * @return DecodingResult containing all decoded strings
     */
    public static DecodingResult decodeObfuscatedStrings(String sourceCode) {
        DecodingResult result = new DecodingResult();
        
        if (sourceCode == null || sourceCode.isEmpty()) {
            return result;
        }
        
        // Scan for potential Base64 encoded strings
        scanForBase64Strings(sourceCode, result);
        
        // Scan for byte array encoded strings
        scanForByteArrayStrings(sourceCode, result);
        
        // Scan for Unicode encoded strings
        scanForUnicodeStrings(sourceCode, result);
        
        logger.debug("Found {} total decoded strings", result.getTotalDecodedCount());
        return result;
    }
    
    /**
     * Scan source code for potential Base64 encoded strings
     */
    private static void scanForBase64Strings(String sourceCode, DecodingResult result) {
        // Look for string literals containing potential Base64 content
        Pattern stringPattern = Pattern.compile("\"([A-Za-z0-9+/=]{8,})\"");
        Matcher matcher = stringPattern.matcher(sourceCode);
        
        while (matcher.find()) {
            String encoded = matcher.group(1);
            String decoded = tryDecodeBase64(encoded);
            
            if (!decoded.equals(encoded) && isPrintableAscii(decoded)) {
                result.addDecoded("Base64", decoded);
                logger.debug("Decoded Base64 string: {}", decoded);
            }
        }
    }
    
    /**
     * Scan source code for byte array encoded strings
     */
    private static void scanForByteArrayStrings(String sourceCode, DecodingResult result) {
        Matcher matcher = BYTE_ARRAY_PATTERN.matcher(sourceCode);
        
        while (matcher.find()) {
            String bytesStr = matcher.group(1);
            String decoded = tryDecodeByteArray("new byte[] {" + bytesStr + "}");
            
            if (!decoded.equals("new byte[] {" + bytesStr + "}") && isPrintableAscii(decoded)) {
                result.addDecoded("ByteArray", decoded);
                logger.debug("Decoded byte array: {}", decoded);
            }
        }
    }
    
    /**
     * Scan source code for Unicode encoded strings
     */
    private static void scanForUnicodeStrings(String sourceCode, DecodingResult result) {
        // Look for strings with multiple Unicode escapes
        Pattern stringWithUnicodePattern = Pattern.compile("\"((?:\\\\u[0-9a-fA-F]{4}){2,})\"");
        Matcher matcher = stringWithUnicodePattern.matcher(sourceCode);
        
        while (matcher.find()) {
            String encoded = matcher.group(1);
            String decoded = tryDecodeUnicode(encoded);
            
            if (!decoded.equals(encoded)) {
                result.addDecoded("Unicode", decoded);
                logger.debug("Decoded Unicode string: {}", decoded);
            }
        }
    }
    
    // Patterns for various obfuscated string formats
    private static final Pattern BASE64_PATTERN = Pattern.compile(
            "(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?");
    
    private static final Pattern BYTE_ARRAY_PATTERN = Pattern.compile(
            "new\\s+byte\\s*\\[\\s*\\]\\s*\\{\\s*([^}]+)\\s*\\}");
    
    private static final Pattern UNICODE_PATTERN = Pattern.compile(
            "\\\\u[0-9a-fA-F]{4}");
    
    /**
     * Attempts to detect if a string is obfuscated and if so, decode it.
     * 
     * @param input Potentially obfuscated string
     * @return Decoded string if obfuscated, or original string otherwise
     */
    public static String tryDecode(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        
        // Try different decoding methods
        String decoded = tryDecodeBase64(input);
        if (!decoded.equals(input)) {
            logger.debug("Successfully decoded Base64 string");
            return decoded;
        }
        
        decoded = tryDecodeByteArray(input);
        if (!decoded.equals(input)) {
            logger.debug("Successfully decoded byte array");
            return decoded;
        }
        
        decoded = tryDecodeUnicode(input);
        if (!decoded.equals(input)) {
            logger.debug("Successfully decoded Unicode escapes");
            return decoded;
        }
        
        return input;
    }
    
    /**
     * Attempts to decode a Base64 encoded string.
     * 
     * @param input Potential Base64 string
     * @return Decoded string if valid Base64, or original string otherwise
     */
    public static String tryDecodeBase64(String input) {
        try {
            // Check if the string matches Base64 pattern
            if (!BASE64_PATTERN.matcher(input).matches()) {
                return input;
            }
            
            // Try to decode
            byte[] decoded = Base64.getDecoder().decode(input);
            String result = new String(decoded, StandardCharsets.UTF_8);
            
            // Validate result contains printable ASCII
            if (isPrintableAscii(result)) {
                return result;
            }
            
            return input;
        } catch (Exception e) {
            logger.debug("Failed to decode Base64: {}", e.getMessage());
            return input;
        }
    }
    
    /**
     * Attempts to decode a byte array representation of a string.
     * For example: new byte[] { 72, 101, 108, 108, 111 } -> "Hello"
     * 
     * @param input String containing byte array representation
     * @return Decoded string if valid byte array, or original string otherwise
     */
    public static String tryDecodeByteArray(String input) {
        try {
            Matcher matcher = BYTE_ARRAY_PATTERN.matcher(input);
            if (!matcher.find()) {
                return input;
            }
            
            // Extract byte values
            String bytesStr = matcher.group(1);
            String[] byteStrs = bytesStr.split(",");
            byte[] bytes = new byte[byteStrs.length];
            
            for (int i = 0; i < byteStrs.length; i++) {
                bytes[i] = (byte) Integer.parseInt(byteStrs[i].trim());
            }
            
            // Convert to string
            String result = new String(bytes, StandardCharsets.UTF_8);
            
            // Validate result
            if (isPrintableAscii(result)) {
                return result;
            }
            
            return input;
        } catch (Exception e) {
            logger.debug("Failed to decode byte array: {}", e.getMessage());
            return input;
        }
    }
    
    /**
     * Attempts to decode Unicode escape sequences in a string.
     * For example: "\u0048\u0065\u006c\u006c\u006f" -> "Hello"
     * 
     * @param input String with potential Unicode escapes
     * @return Decoded string if contains Unicode escapes, or original string otherwise
     */
    public static String tryDecodeUnicode(String input) {
        try {
            Matcher matcher = UNICODE_PATTERN.matcher(input);
            if (!matcher.find()) {
                return input;
            }
            
            // Replace all Unicode escapes
            StringBuffer result = new StringBuffer();
            matcher.reset();
            
            while (matcher.find()) {
                String unicodeEscape = matcher.group();
                int codePoint = Integer.parseInt(unicodeEscape.substring(2), 16);
                matcher.appendReplacement(result, String.valueOf((char) codePoint));
            }
            matcher.appendTail(result);
            
            return result.toString();
        } catch (Exception e) {
            logger.debug("Failed to decode Unicode escapes: {}", e.getMessage());
            return input;
        }
    }
    
    /**
     * Checks if a string contains only printable ASCII characters.
     * 
     * @param str String to check
     * @return true if string is printable ASCII, false otherwise
     */
    private static boolean isPrintableAscii(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            // Check if character is printable ASCII (32-126) or common control chars
            if ((c < 32 || c > 126) && c != '\n' && c != '\r' && c != '\t') {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Analyzes a string to determine if it's likely to be an encoded license key or secret.
     * 
     * @param str String to analyze
     * @return true if likely a license key or secret, false otherwise
     */
    public static boolean isPotentialLicenseKey(String str) {
        if (str == null || str.length() < 8) {
            return false;
        }
        
        // Check for patterns common in license keys
        boolean hasPattern = str.contains("-") || 
                            str.contains(".") || 
                            str.contains("_") ||
                            str.matches(".*[A-Z0-9]{8,}.*");
        
        // Check for entropy (mix of characters)
        boolean hasHighEntropy = hasHighEntropy(str);
        
        // Check for keyword indicators
        boolean hasKeyword = str.toLowerCase().contains("license") ||
                            str.toLowerCase().contains("key") ||
                            str.toLowerCase().contains("token") ||
                            str.toLowerCase().contains("secret") ||
                            str.toLowerCase().contains("auth");
        
        return (hasPattern && hasHighEntropy) || (hasHighEntropy && hasKeyword);
    }
    
    /**
     * Checks if a string has high character entropy (mix of different character types).
     * 
     * @param str String to check
     * @return true if string has high entropy, false otherwise
     */
    private static boolean hasHighEntropy(String str) {
        boolean hasLower = false;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        
        for (char c : str.toCharArray()) {
            if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else hasSpecial = true;
        }
        
        // Count how many character types are present
        int typeCount = 0;
        if (hasLower) typeCount++;
        if (hasUpper) typeCount++;
        if (hasDigit) typeCount++;
        if (hasSpecial) typeCount++;
        
        // High entropy means at least 3 different types of characters
        return typeCount >= 3;
    }
}