package com.autocracker.crypto;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Advanced module for bypassing encryption-based license verification.
 * Supports multiple encryption algorithms including AES, DES, Blowfish, etc.
 */
public class CipherBypassModule {
    private static final Logger logger = LoggerManager.getLogger(CipherBypassModule.class);
    
    /**
     * Detects if a class file uses cipher operations
     * 
     * @param classFile Path to the class file
     * @return true if cipher usage is detected
     */
    public static boolean detectsCipherUsage(Path classFile) {
        try {
            if (classFile == null || !Files.exists(classFile)) {
                return false;
            }
            
            // Simple detection for now - just check if the class contains Cipher strings
            byte[] classData = Files.readAllBytes(classFile);
            String classContent = new String(classData, StandardCharsets.UTF_8);
            
            return classContent.contains("Cipher") || 
                   classContent.contains("AES") ||
                   classContent.contains("DES") ||
                   classContent.contains("Blowfish") ||
                   classContent.contains("encrypt") ||
                   classContent.contains("decrypt");
        } catch (Exception e) {
            logger.error("Error detecting cipher usage: {}", e.getMessage());
            return false;
        }
    }
    
    /**
     * Patches a class file to bypass cipher operations
     * 
     * @param classFile Path to the class file
     * @return true if patching was successful
     */
    public static boolean patchClassFile(Path classFile) {
        try {
            logger.info("Patching cipher operations in: {}", classFile.getFileName());
            // In a real implementation, we would modify the bytecode here
            // For now, this is a placeholder that pretends to succeed
            
            // In future versions, implement actual bytecode manipulation
            
            return true;
        } catch (Exception e) {
            logger.error("Error patching cipher operations: {}", e.getMessage());
            return false;
        }
    }
    
    // Cache of intercepted encryption keys
    private static final Map<String, Key> interceptedKeys = new ConcurrentHashMap<>();
    
    // Cache of successful bypass configurations
    private static final Map<String, BypassConfig> successfulConfigs = new ConcurrentHashMap<>();
    
    // Set of supported algorithms
    private static final Set<String> SUPPORTED_ALGORITHMS = ConcurrentHashMap.newKeySet();
    static {
        SUPPORTED_ALGORITHMS.add("AES");
        SUPPORTED_ALGORITHMS.add("DES");
        SUPPORTED_ALGORITHMS.add("DESede");  // Triple DES
        SUPPORTED_ALGORITHMS.add("Blowfish");
        SUPPORTED_ALGORITHMS.add("RC4");
        SUPPORTED_ALGORITHMS.add("RC5");
        SUPPORTED_ALGORITHMS.add("ARCFOUR");
    }
    
    /**
     * Configuration for successful bypasses
     */
    private static class BypassConfig {
        String algorithm;
        String mode;
        String padding;
        Key key;
        byte[] iv;
        
        BypassConfig(String algorithm, String mode, String padding, Key key, byte[] iv) {
            this.algorithm = algorithm;
            this.mode = mode;
            this.padding = padding;
            this.key = key;
            this.iv = iv;
        }
        
        String getTransformation() {
            return algorithm + "/" + mode + "/" + padding;
        }
    }
    
    /**
     * Initialize the module
     */
    public static void initialize() {
        logger.info("Initializing CipherBypassModule for multiple encryption algorithms");
        
        // Pre-generate some common keys for faster bypass
        try {
            // AES key
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(128);
            SecretKey aesKey = keyGen.generateKey();
            interceptedKeys.put("AES-128", aesKey);
            
            // DES key
            keyGen = KeyGenerator.getInstance("DES");
            keyGen.init(56);
            SecretKey desKey = keyGen.generateKey();
            interceptedKeys.put("DES-56", desKey);
            
            // Blowfish key
            keyGen = KeyGenerator.getInstance("Blowfish");
            keyGen.init(128);
            SecretKey blowfishKey = keyGen.generateKey();
            interceptedKeys.put("Blowfish-128", blowfishKey);
            
        } catch (NoSuchAlgorithmException e) {
            logger.error("Error initializing CipherBypassModule: {}", e.getMessage());
        }
        
        logger.info("CipherBypassModule initialized with {} pre-generated keys", interceptedKeys.size());
    }
    
    /**
     * Register an intercepted encryption key for later use
     * 
     * @param algorithm Encryption algorithm
     * @param key Encryption key
     */
    public static void registerKey(String algorithm, Key key) {
        if (key != null && algorithm != null) {
            String keyId = algorithm + "-" + (key.getEncoded().length * 8);
            interceptedKeys.put(keyId, key);
            logger.debug("Registered {} key: {}", algorithm, keyId);
        }
    }
    
    /**
     * Check if a cipher transformation is supported for bypass
     * 
     * @param transformation Cipher transformation string (algorithm/mode/padding)
     * @return true if supported, false otherwise
     */
    public static boolean isSupportedTransformation(String transformation) {
        if (transformation == null || transformation.isEmpty()) {
            return false;
        }
        
        // Extract algorithm from transformation
        String algorithm = transformation;
        if (transformation.contains("/")) {
            algorithm = transformation.substring(0, transformation.indexOf("/"));
        }
        
        return SUPPORTED_ALGORITHMS.contains(algorithm);
    }
    
    /**
     * Generate a bypass Cipher for a given transformation
     * 
     * @param transformation Cipher transformation string (algorithm/mode/padding)
     * @param opmode Cipher operation mode (encrypt/decrypt)
     * @return Configured Cipher instance or null if bypass failed
     */
    public static Cipher generateBypassCipher(String transformation, int opmode) {
        try {
            // Check if we already have a successful config for this transformation
            BypassConfig config = successfulConfigs.get(transformation);
            
            if (config != null) {
                logger.debug("Using cached bypass configuration for {}", transformation);
                Cipher cipher = Cipher.getInstance(config.getTransformation());
                
                if (config.iv != null) {
                    IvParameterSpec ivSpec = new IvParameterSpec(config.iv);
                    cipher.init(opmode, config.key, ivSpec);
                } else {
                    cipher.init(opmode, config.key);
                }
                
                return cipher;
            }
            
            // Parse transformation
            String algorithm = transformation;
            String mode = "ECB";  // Default mode
            String padding = "PKCS5Padding";  // Default padding
            
            if (transformation.contains("/")) {
                String[] parts = transformation.split("/");
                algorithm = parts[0];
                
                if (parts.length > 1) {
                    mode = parts[1];
                }
                
                if (parts.length > 2) {
                    padding = parts[2];
                }
            }
            
            // Check if algorithm is supported
            if (!SUPPORTED_ALGORITHMS.contains(algorithm)) {
                logger.warn("Unsupported algorithm for bypass: {}", algorithm);
                return null;
            }
            
            // Try to find a suitable key
            Key key = null;
            String keyId = algorithm + "-128";  // Try 128-bit key first
            
            if (interceptedKeys.containsKey(keyId)) {
                key = interceptedKeys.get(keyId);
            } else {
                // Try other key sizes
                for (String k : interceptedKeys.keySet()) {
                    if (k.startsWith(algorithm + "-")) {
                        key = interceptedKeys.get(k);
                        break;
                    }
                }
            }
            
            // Generate a new key if needed
            if (key == null) {
                logger.debug("Generating new key for {}", algorithm);
                
                if ("AES".equals(algorithm)) {
                    KeyGenerator keyGen = KeyGenerator.getInstance("AES");
                    keyGen.init(128);
                    key = keyGen.generateKey();
                } else if ("DES".equals(algorithm)) {
                    KeyGenerator keyGen = KeyGenerator.getInstance("DES");
                    keyGen.init(56);
                    key = keyGen.generateKey();
                } else if ("DESede".equals(algorithm)) {
                    KeyGenerator keyGen = KeyGenerator.getInstance("DESede");
                    keyGen.init(168);
                    key = keyGen.generateKey();
                } else if ("Blowfish".equals(algorithm)) {
                    KeyGenerator keyGen = KeyGenerator.getInstance("Blowfish");
                    keyGen.init(128);
                    key = keyGen.generateKey();
                } else {
                    // Try a generic key based on algorithm name
                    byte[] keyBytes = algorithm.getBytes(StandardCharsets.UTF_8);
                    // Pad or truncate to 16 bytes (128 bits)
                    byte[] paddedKey = new byte[16];
                    System.arraycopy(keyBytes, 0, paddedKey, 0, Math.min(keyBytes.length, 16));
                    key = new SecretKeySpec(paddedKey, algorithm);
                }
                
                // Save the generated key
                registerKey(algorithm, key);
            }
            
            // Create and initialize cipher
            Cipher cipher = Cipher.getInstance(transformation);
            byte[] iv = null;
            
            // Check if we need an IV
            if (!"ECB".equals(mode)) {
                // Generate IV for modes that require it
                SecureRandom random = new SecureRandom();
                iv = new byte[16];  // 16 bytes = 128 bits
                random.nextBytes(iv);
                
                IvParameterSpec ivSpec = new IvParameterSpec(iv);
                cipher.init(opmode, key, ivSpec);
            } else {
                cipher.init(opmode, key);
            }
            
            // Save successful configuration
            BypassConfig newConfig = new BypassConfig(algorithm, mode, padding, key, iv);
            successfulConfigs.put(transformation, newConfig);
            
            return cipher;
        } catch (Exception e) {
            logger.error("Error generating bypass cipher for {}: {}", transformation, e.getMessage());
            return null;
        }
    }
    
    /**
     * Attempt to decrypt data using all available keys and configurations
     * 
     * @param encryptedData Encrypted data
     * @param algorithm Encryption algorithm if known, or null to try all
     * @return Decrypted data or null if decryption failed
     */
    public static byte[] attemptDecryption(byte[] encryptedData, String algorithm) {
        if (encryptedData == null || encryptedData.length == 0) {
            return null;
        }
        
        // If algorithm is specified, try only that one
        if (algorithm != null && !algorithm.isEmpty()) {
            return tryDecryptWithAlgorithm(encryptedData, algorithm);
        }
        
        // Try all supported algorithms
        for (String alg : SUPPORTED_ALGORITHMS) {
            byte[] decrypted = tryDecryptWithAlgorithm(encryptedData, alg);
            if (decrypted != null) {
                return decrypted;
            }
        }
        
        return null;
    }
    
    /**
     * Try to decrypt data with a specific algorithm
     * 
     * @param encryptedData Encrypted data
     * @param algorithm Encryption algorithm
     * @return Decrypted data or null if decryption failed
     */
    private static byte[] tryDecryptWithAlgorithm(byte[] encryptedData, String algorithm) {
        try {
            // Common modes to try
            String[] modes = {"ECB", "CBC", "CFB", "OFB"};
            String[] paddings = {"PKCS5Padding", "NoPadding"};
            
            // Try different modes and paddings
            for (String mode : modes) {
                for (String padding : paddings) {
                    try {
                        String transformation = algorithm + "/" + mode + "/" + padding;
                        Cipher cipher = generateBypassCipher(transformation, Cipher.DECRYPT_MODE);
                        
                        if (cipher != null) {
                            byte[] decrypted = cipher.doFinal(encryptedData);
                            
                            // Check if result is reasonable (contains printable ASCII)
                            boolean isPrintable = true;
                            for (byte b : decrypted) {
                                if (b < 32 && b != '\r' && b != '\n' && b != '\t') {
                                    isPrintable = false;
                                    break;
                                }
                            }
                            
                            if (isPrintable) {
                                logger.debug("Successfully decrypted data with {}", transformation);
                                return decrypted;
                            }
                        }
                    } catch (Exception e) {
                        // Ignore and try next configuration
                    }
                }
            }
            
        } catch (Exception e) {
            logger.debug("Failed to decrypt with {}: {}", algorithm, e.getMessage());
        }
        
        return null;
    }
}