package com.autocracker.crypto;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;
import org.objectweb.asm.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Advanced license key finder module that uses multiple techniques to locate and extract
 * license keys from both bytecode and source code.
 */
public class AdvancedKeyFinderModule {
    private static final Logger logger = LoggerManager.getLogger(AdvancedKeyFinderModule.class);
    
    /**
     * Result of key finding operation with detected keys and their context.
     */
    public static class KeyFinderResult {
        private final List<DetectedKey> detectedKeys = new ArrayList<>();
        private final String sourceFile;
        
        public KeyFinderResult(String sourceFile) {
            this.sourceFile = sourceFile;
        }
        
        public void addKey(String key, String type, String context) {
            detectedKeys.add(new DetectedKey(key, type, context));
        }
        
        public List<DetectedKey> getDetectedKeys() {
            return detectedKeys;
        }
        
        public String getSourceFile() {
            return sourceFile;
        }
        
        public boolean hasKeys() {
            return !detectedKeys.isEmpty();
        }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Key Finder Results for: ").append(sourceFile).append("\n");
            
            if (detectedKeys.isEmpty()) {
                sb.append("No keys detected\n");
            } else {
                sb.append("Detected ").append(detectedKeys.size()).append(" potential keys:\n");
                for (DetectedKey key : detectedKeys) {
                    sb.append("  - Type: ").append(key.getType()).append("\n");
                    sb.append("    Key: ").append(key.getKey()).append("\n");
                    sb.append("    Context: ").append(key.getContext()).append("\n");
                }
            }
            
            return sb.toString();
        }
        
        /**
         * Inner class representing a detected key.
         */
        public static class DetectedKey {
            private final String key;
            private final String type;
            private final String context;
            
            public DetectedKey(String key, String type, String context) {
                this.key = key;
                this.type = type;
                this.context = context;
            }
            
            public String getKey() {
                return key;
            }
            
            public String getType() {
                return type;
            }
            
            public String getContext() {
                return context;
            }
        }
    }
    
    /**
     * Analyzes Java source code to find potential license keys.
     *
     * @param javaFile Path to the Java source file
     * @return KeyFinderResult containing detected keys
     */
    public static KeyFinderResult findKeysInSource(Path javaFile) {
        String fileName = javaFile.getFileName().toString();
        KeyFinderResult result = new KeyFinderResult(fileName);
        
        try {
            String content = Files.readString(javaFile);
            
            // Find hardcoded string literals that look like keys
            findHardcodedKeys(content, result);
            
            // Find Base64 encoded strings
            findBase64EncodedKeys(content, result);
            
            // Find key-related variable declarations
            findKeyVariables(content, result);
            
            return result;
            
        } catch (IOException e) {
            logger.error("Error reading file: {}", javaFile, e);
            return result;
        }
    }
    
    /**
     * Analyzes class file bytecode to find potential license keys.
     *
     * @param classFile Path to the class file
     * @return KeyFinderResult containing detected keys
     */
    public static KeyFinderResult findKeysInBytecode(Path classFile) {
        String fileName = classFile.getFileName().toString();
        KeyFinderResult result = new KeyFinderResult(fileName);
        
        try {
            byte[] classBytes = Files.readAllBytes(classFile);
            
            ClassReader reader = new ClassReader(classBytes);
            KeyFinderClassVisitor visitor = new KeyFinderClassVisitor(result);
            reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
            
            return result;
            
        } catch (IOException e) {
            logger.error("Error reading class file: {}", classFile, e);
            return result;
        }
    }
    
    /**
     * Finds hardcoded keys in source code.
     *
     * @param content Source code content
     * @param result KeyFinderResult to update
     */
    private static void findHardcodedKeys(String content, KeyFinderResult result) {
        // Look for strings that match license key patterns (alphanumeric with possible separators)
        Pattern keyPattern = Pattern.compile(
                "\"([A-Za-z0-9\\-_]{10,})\"",
                Pattern.MULTILINE
        );
        
        Matcher matcher = keyPattern.matcher(content);
        while (matcher.find()) {
            String key = matcher.group(1);
            
            // Check if this is in a context that suggests it's a license key
            int pos = content.indexOf(matcher.group(), matcher.start());
            int contextStart = Math.max(0, pos - 100);
            int contextEnd = Math.min(content.length(), pos + 100);
            String context = content.substring(contextStart, contextEnd);
            
            if (isLicenseKeyContext(context)) {
                result.addKey(key, "Hardcoded String", context);
            }
        }
        
        // Look for strings explicitly labeled as keys
        Pattern labeledKeyPattern = Pattern.compile(
                "(?:key|license|token|apiKey|secret)\\s*=\\s*\"([^\"]+)\"",
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
        );
        
        Matcher labeledMatcher = labeledKeyPattern.matcher(content);
        while (labeledMatcher.find()) {
            String key = labeledMatcher.group(1);
            
            // Get context
            int pos = content.indexOf(labeledMatcher.group(), labeledMatcher.start());
            int contextStart = Math.max(0, pos - 50);
            int contextEnd = Math.min(content.length(), pos + 50);
            String context = content.substring(contextStart, contextEnd);
            
            result.addKey(key, "Labeled Key", context);
        }
    }
    
    /**
     * Finds Base64 encoded strings that might be keys.
     *
     * @param content Source code content
     * @param result KeyFinderResult to update
     */
    private static void findBase64EncodedKeys(String content, KeyFinderResult result) {
        // Look for Base64 encoded strings
        Pattern base64Pattern = Pattern.compile(
                "\"([A-Za-z0-9+/=]{16,})\"",
                Pattern.MULTILINE
        );
        
        Matcher matcher = base64Pattern.matcher(content);
        while (matcher.find()) {
            String encodedValue = matcher.group(1);
            
            // Check if it's likely Base64
            if (isLikelyBase64(encodedValue)) {
                // Check if this is in a context that suggests it's a license key
                int pos = content.indexOf(matcher.group(), matcher.start());
                int contextStart = Math.max(0, pos - 100);
                int contextEnd = Math.min(content.length(), pos + 100);
                String context = content.substring(contextStart, contextEnd);
                
                if (context.contains("Base64") || 
                    context.contains("decode") || 
                    context.contains("encode") || 
                    isLicenseKeyContext(context)) {
                    result.addKey(encodedValue, "Base64 Encoded", context);
                }
            }
        }
    }
    
    /**
     * Finds key-related variable declarations.
     *
     * @param content Source code content
     * @param result KeyFinderResult to update
     */
    private static void findKeyVariables(String content, KeyFinderResult result) {
        // Look for byte array declarations that might be keys
        Pattern byteArrayPattern = Pattern.compile(
                "(?:byte\\[\\]|Byte\\[\\])\\s+\\w+\\s*=\\s*(?:new\\s+byte\\[\\])?\\s*\\{([^}]+)\\}",
                Pattern.MULTILINE
        );
        
        Matcher matcher = byteArrayPattern.matcher(content);
        while (matcher.find()) {
            String byteArrayContent = matcher.group(1);
            
            // Check if this is in a context that suggests it's a key
            int pos = content.indexOf(matcher.group(), matcher.start());
            int contextStart = Math.max(0, pos - 100);
            int contextEnd = Math.min(content.length(), pos + 100);
            String context = content.substring(contextStart, contextEnd);
            
            if (isLicenseKeyContext(context)) {
                result.addKey(byteArrayContent, "Byte Array", context);
            }
        }
    }
    
    /**
     * Checks if a string is likely Base64 encoded.
     *
     * @param str String to check
     * @return true if likely Base64, false otherwise
     */
    private static boolean isLikelyBase64(String str) {
        // Base64 strings consist of a-z, A-Z, 0-9, +, /, and = for padding
        return str.matches("^[A-Za-z0-9+/]+={0,2}$") && 
               (str.length() % 4 == 0);
    }
    
    /**
     * Checks if a code context is related to license keys.
     *
     * @param context Code context
     * @return true if context is related to license keys, false otherwise
     */
    private static boolean isLicenseKeyContext(String context) {
        String lowerContext = context.toLowerCase();
        return lowerContext.contains("license") || 
               lowerContext.contains("key") || 
               lowerContext.contains("auth") || 
               lowerContext.contains("valid") || 
               lowerContext.contains("verify") || 
               lowerContext.contains("token") || 
               lowerContext.contains("secret") || 
               lowerContext.contains("premium") || 
               lowerContext.contains("activation");
    }
    
    /**
     * ASM ClassVisitor for finding keys in bytecode.
     */
    private static class KeyFinderClassVisitor extends ClassVisitor {
        private final KeyFinderResult result;
        private String className;
        
        public KeyFinderClassVisitor(KeyFinderResult result) {
            super(Opcodes.ASM9);
            this.result = result;
        }
        
        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            this.className = name.replace('/', '.');
        }
        
        @Override
        public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
            // Check field values for string constants
            if (value instanceof String) {
                String stringValue = (String) value;
                if (stringValue.length() >= 10 && isLicenseKeyFieldName(name)) {
                    result.addKey(stringValue, "Field Value", 
                                 "Class: " + className + ", Field: " + name);
                } else if (stringValue.length() >= 16 && isLikelyBase64(stringValue)) {
                    result.addKey(stringValue, "Base64 Field Value", 
                                 "Class: " + className + ", Field: " + name);
                }
            }
            
            return super.visitField(access, name, descriptor, signature, value);
        }
        
        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            return new KeyFinderMethodVisitor(result, className, name);
        }
        
        /**
         * Checks if a field name is related to license keys.
         *
         * @param fieldName Field name
         * @return true if field name is related to license keys, false otherwise
         */
        private boolean isLicenseKeyFieldName(String fieldName) {
            String lowerName = fieldName.toLowerCase();
            return lowerName.contains("key") || 
                   lowerName.contains("license") || 
                   lowerName.contains("token") || 
                   lowerName.contains("auth") || 
                   lowerName.contains("secret") || 
                   lowerName.contains("api") || 
                   lowerName.contains("valid");
        }
    }
    
    /**
     * ASM MethodVisitor for finding keys in bytecode.
     */
    private static class KeyFinderMethodVisitor extends MethodVisitor {
        private final KeyFinderResult result;
        private final String className;
        private final String methodName;
        
        public KeyFinderMethodVisitor(KeyFinderResult result, String className, String methodName) {
            super(Opcodes.ASM9);
            this.result = result;
            this.className = className;
            this.methodName = methodName;
        }
        
        @Override
        public void visitLdcInsn(Object value) {
            // Check for string constants
            if (value instanceof String) {
                String stringValue = (String) value;
                
                // Check if it might be a key
                if (stringValue.length() >= 10 && 
                    (isLicenseKeyMethodName(methodName) || 
                     stringValue.matches("[A-Za-z0-9\\-_]{10,}"))) {
                    
                    result.addKey(stringValue, "Method String Constant", 
                                 "Class: " + className + ", Method: " + methodName);
                } 
                // Check for Base64
                else if (stringValue.length() >= 16 && isLikelyBase64(stringValue)) {
                    result.addKey(stringValue, "Method Base64 Constant",
                                 "Class: " + className + ", Method: " + methodName);
                }
            }
            
            super.visitLdcInsn(value);
        }
        
        /**
         * Checks if a method name is related to license keys.
         *
         * @param methodName Method name
         * @return true if method name is related to license keys, false otherwise
         */
        private boolean isLicenseKeyMethodName(String methodName) {
            String lowerName = methodName.toLowerCase();
            return lowerName.contains("key") || 
                   lowerName.contains("license") || 
                   lowerName.contains("verify") || 
                   lowerName.contains("validate") || 
                   lowerName.contains("check") || 
                   lowerName.contains("auth");
        }
    }
}