package com.autocracker.config;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Manages configuration settings for the AutoCracker application.
 * Supports loading and saving settings from/to a properties file.
 */
public class Configuration {
    private static final Logger logger = LoggerManager.getLogger(Configuration.class);
    
    private static final String CONFIG_FILE = "autocracker.properties";
    private final Properties properties;
    private final Path configPath;
    
    // Default configuration values
    private static final String DEFAULT_INPUT_DIR = "./input";
    private static final String DEFAULT_OUTPUT_DIR = "./output";
    private static final String DEFAULT_TEMP_DIR = "./temp";
    private static final boolean DEFAULT_VERBOSE_MODE = false;
    private static final int DEFAULT_THREAD_COUNT = Runtime.getRuntime().availableProcessors();
    private static final boolean DEFAULT_CLEANUP_TEMP = true;
    private static final boolean DEFAULT_HANDLE_OBFUSCATION = true;
    
    // Configuration keys
    public static final String KEY_INPUT_DIR = "input.directory";
    public static final String KEY_OUTPUT_DIR = "output.directory";
    public static final String KEY_TEMP_DIR = "temp.directory";
    public static final String KEY_VERBOSE_MODE = "verbose.mode";
    public static final String KEY_THREAD_COUNT = "thread.count";
    public static final String KEY_CLEANUP_TEMP = "cleanup.temp";
    public static final String KEY_HANDLE_OBFUSCATION = "handle.obfuscation";
    public static final String KEY_DECOMPILER_TYPE = "decompiler.type";
    
    /**
     * Creates a new Configuration instance.
     * Loads existing configuration if available, otherwise creates a default configuration.
     */
    public Configuration() {
        properties = new Properties();
        configPath = Paths.get(CONFIG_FILE);
        
        // Load existing config or create default
        if (Files.exists(configPath)) {
            loadConfiguration();
        } else {
            setDefaults();
            saveConfiguration();
        }
    }
    
    /**
     * Sets default configuration values
     */
    private void setDefaults() {
        properties.setProperty(KEY_INPUT_DIR, DEFAULT_INPUT_DIR);
        properties.setProperty(KEY_OUTPUT_DIR, DEFAULT_OUTPUT_DIR);
        properties.setProperty(KEY_TEMP_DIR, DEFAULT_TEMP_DIR);
        properties.setProperty(KEY_VERBOSE_MODE, String.valueOf(DEFAULT_VERBOSE_MODE));
        properties.setProperty(KEY_THREAD_COUNT, String.valueOf(DEFAULT_THREAD_COUNT));
        properties.setProperty(KEY_CLEANUP_TEMP, String.valueOf(DEFAULT_CLEANUP_TEMP));
        properties.setProperty(KEY_HANDLE_OBFUSCATION, String.valueOf(DEFAULT_HANDLE_OBFUSCATION));
        properties.setProperty(KEY_DECOMPILER_TYPE, "CFR"); // Default decompiler
    }
    
    /**
     * Loads configuration from the properties file
     */
    private void loadConfiguration() {
        try (FileInputStream fis = new FileInputStream(configPath.toFile())) {
            properties.load(fis);
            logger.debug("Loaded configuration from {}", configPath);
        } catch (IOException e) {
            logger.error("Failed to load configuration from {}", configPath, e);
            // Set defaults if loading fails
            setDefaults();
        }
    }
    
    /**
     * Saves the current configuration to the properties file
     */
    public void saveConfiguration() {
        try (FileOutputStream fos = new FileOutputStream(configPath.toFile())) {
            properties.store(fos, "AutoCracker Configuration");
            logger.debug("Saved configuration to {}", configPath);
        } catch (IOException e) {
            logger.error("Failed to save configuration to {}", configPath, e);
        }
    }
    
    /**
     * Gets a string property value
     *
     * @param key The property key
     * @param defaultValue The default value to return if the key is not found
     * @return The property value
     */
    public String getString(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
    
    /**
     * Gets a boolean property value
     *
     * @param key The property key
     * @param defaultValue The default value to return if the key is not found
     * @return The property value
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        String value = properties.getProperty(key);
        return (value != null) ? Boolean.parseBoolean(value) : defaultValue;
    }
    
    /**
     * Gets an integer property value
     *
     * @param key The property key
     * @param defaultValue The default value to return if the key is not found
     * @return The property value
     */
    public int getInt(String key, int defaultValue) {
        String value = properties.getProperty(key);
        if (value != null) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                logger.warn("Invalid integer value for key {}: {}", key, value);
            }
        }
        return defaultValue;
    }
    
    /**
     * Sets a property value
     *
     * @param key The property key
     * @param value The property value
     */
    public void setProperty(String key, String value) {
        properties.setProperty(key, value);
    }
    
    /**
     * Gets the input directory
     *
     * @return The input directory path
     */
    public Path getInputDir() {
        return Paths.get(getString(KEY_INPUT_DIR, DEFAULT_INPUT_DIR));
    }
    
    /**
     * Sets the input directory
     *
     * @param inputDir The input directory path
     */
    public void setInputDir(Path inputDir) {
        setProperty(KEY_INPUT_DIR, inputDir.toString());
    }
    
    /**
     * Gets the output directory
     *
     * @return The output directory path
     */
    public Path getOutputDir() {
        return Paths.get(getString(KEY_OUTPUT_DIR, DEFAULT_OUTPUT_DIR));
    }
    
    /**
     * Sets the output directory
     *
     * @param outputDir The output directory path
     */
    public void setOutputDir(Path outputDir) {
        setProperty(KEY_OUTPUT_DIR, outputDir.toString());
    }
    
    /**
     * Gets the temporary directory
     *
     * @return The temporary directory path
     */
    public Path getTempDir() {
        return Paths.get(getString(KEY_TEMP_DIR, DEFAULT_TEMP_DIR));
    }
    
    /**
     * Sets the temporary directory
     *
     * @param tempDir The temporary directory path
     */
    public void setTempDir(Path tempDir) {
        setProperty(KEY_TEMP_DIR, tempDir.toString());
    }
    
    /**
     * Checks if verbose mode is enabled
     *
     * @return true if verbose mode is enabled, false otherwise
     */
    public boolean isVerboseMode() {
        return getBoolean(KEY_VERBOSE_MODE, DEFAULT_VERBOSE_MODE);
    }
    
    /**
     * Sets verbose mode
     *
     * @param verboseMode true to enable verbose mode, false to disable
     */
    public void setVerboseMode(boolean verboseMode) {
        setProperty(KEY_VERBOSE_MODE, String.valueOf(verboseMode));
    }
    
    /**
     * Gets the thread count
     *
     * @return The thread count
     */
    public int getThreadCount() {
        return getInt(KEY_THREAD_COUNT, DEFAULT_THREAD_COUNT);
    }
    
    /**
     * Sets the thread count
     *
     * @param threadCount The thread count
     */
    public void setThreadCount(int threadCount) {
        if (threadCount < 1) {
            threadCount = 1;
        }
        setProperty(KEY_THREAD_COUNT, String.valueOf(threadCount));
    }
    
    /**
     * Checks if temporary files should be cleaned up
     *
     * @return true if temporary files should be cleaned up, false otherwise
     */
    public boolean isCleanupTemp() {
        return getBoolean(KEY_CLEANUP_TEMP, DEFAULT_CLEANUP_TEMP);
    }
    
    /**
     * Sets whether temporary files should be cleaned up
     *
     * @param cleanupTemp true to clean up temporary files, false to keep them
     */
    public void setCleanupTemp(boolean cleanupTemp) {
        setProperty(KEY_CLEANUP_TEMP, String.valueOf(cleanupTemp));
    }
    
    /**
     * Checks if obfuscation handling is enabled
     *
     * @return true if obfuscation handling is enabled, false otherwise
     */
    public boolean isHandleObfuscation() {
        return getBoolean(KEY_HANDLE_OBFUSCATION, DEFAULT_HANDLE_OBFUSCATION);
    }
    
    /**
     * Sets whether obfuscation handling is enabled
     *
     * @param handleObfuscation true to enable obfuscation handling, false to disable
     */
    public void setHandleObfuscation(boolean handleObfuscation) {
        setProperty(KEY_HANDLE_OBFUSCATION, String.valueOf(handleObfuscation));
    }
    
    /**
     * Gets the decompiler type
     *
     * @return The decompiler type (e.g., "CFR", "Procyon")
     */
    public String getDecompilerType() {
        return getString(KEY_DECOMPILER_TYPE, "CFR");
    }
    
    /**
     * Sets the decompiler type
     *
     * @param decompilerType The decompiler type
     */
    public void setDecompilerType(String decompilerType) {
        setProperty(KEY_DECOMPILER_TYPE, decompilerType);
    }
}