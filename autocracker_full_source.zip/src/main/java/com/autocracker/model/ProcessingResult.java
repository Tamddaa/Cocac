package com.autocracker.model;

import java.nio.file.Path;

/**
 * Represents the result of processing a JAR file.
 * Contains information about success/failure and the output location.
 */
public class ProcessingResult {
    private final JarTask jarTask;
    private final boolean success;
    private final Path outputPath;
    private final String errorMessage;
    
    /**
     * Constructor.
     *
     * @param jarTask The task that was processed
     * @param success Whether processing was successful
     * @param outputPath Path to the output file (if successful)
     * @param errorMessage Error message (if not successful)
     */
    public ProcessingResult(JarTask jarTask, boolean success, Path outputPath, String errorMessage) {
        this.jarTask = jarTask;
        this.success = success;
        this.outputPath = outputPath;
        this.errorMessage = errorMessage;
    }
    
    /**
     * Gets the task that was processed.
     *
     * @return The JAR task
     */
    public JarTask getJarTask() {
        return jarTask;
    }
    
    /**
     * Gets whether processing was successful.
     *
     * @return true if successful, false otherwise
     */
    public boolean isSuccess() {
        return success;
    }
    
    /**
     * Gets the path to the output file.
     *
     * @return Path to the output file, or null if processing failed
     */
    public Path getOutputPath() {
        return outputPath;
    }
    
    /**
     * Gets the error message.
     *
     * @return Error message, or null if processing was successful
     */
    public String getErrorMessage() {
        return errorMessage;
    }
}