package com.autocracker.model;

import java.nio.file.Path;

/**
 * Represents a task for processing a JAR file.
 * Contains information about the JAR file to process and the output location.
 */
public class JarTask {
    private final Path jarPath;
    private final Path outputDir;
    
    /**
     * Constructor.
     *
     * @param jarPath Path to the JAR file
     * @param outputDir Directory to output the processed JAR to
     */
    public JarTask(Path jarPath, Path outputDir) {
        this.jarPath = jarPath;
        this.outputDir = outputDir;
    }
    
    /**
     * Gets the path to the JAR file.
     *
     * @return Path to the JAR file
     */
    public Path getJarPath() {
        return jarPath;
    }
    
    /**
     * Gets the output directory.
     *
     * @return Output directory path
     */
    public Path getOutputDir() {
        return outputDir;
    }
}