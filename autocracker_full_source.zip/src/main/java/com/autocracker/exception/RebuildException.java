package com.autocracker.exception;

/**
 * Exception thrown when rebuilding a JAR file fails.
 */
public class RebuildException extends Exception {

    /**
     * Constructor with message.
     *
     * @param message The error message
     */
    public RebuildException(String message) {
        super(message);
    }

    /**
     * Constructor with message and cause.
     *
     * @param message The error message
     * @param cause The cause of the exception
     */
    public RebuildException(String message, Throwable cause) {
        super(message, cause);
    }
}