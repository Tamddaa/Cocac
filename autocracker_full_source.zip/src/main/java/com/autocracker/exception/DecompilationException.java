package com.autocracker.exception;

/**
 * Exception thrown when decompilation of a JAR file fails.
 */
public class DecompilationException extends Exception {

    /**
     * Constructor with message.
     *
     * @param message The error message
     */
    public DecompilationException(String message) {
        super(message);
    }

    /**
     * Constructor with message and cause.
     *
     * @param message The error message
     * @param cause The cause of the exception
     */
    public DecompilationException(String message, Throwable cause) {
        super(message, cause);
    }
}