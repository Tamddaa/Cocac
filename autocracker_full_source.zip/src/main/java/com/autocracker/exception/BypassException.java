package com.autocracker.exception;

/**
 * Exception thrown when license bypassing fails.
 */
public class BypassException extends Exception {

    /**
     * Constructor with message.
     *
     * @param message The error message
     */
    public BypassException(String message) {
        super(message);
    }

    /**
     * Constructor with message and cause.
     *
     * @param message The error message
     * @param cause The cause of the exception
     */
    public BypassException(String message, Throwable cause) {
        super(message, cause);
    }
}