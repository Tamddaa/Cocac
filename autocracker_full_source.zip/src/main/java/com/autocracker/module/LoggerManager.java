package com.autocracker.module;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;

/**
 * Central logger manager for the AutoCracker application.
 * Provides a unified interface for logging across all components.
 */
public class LoggerManager {
    
    /**
     * Get a logger for a specific class
     * 
     * @param clazz Class to get logger for
     * @return Configured logger instance
     */
    public static Logger getLogger(Class<?> clazz) {
        return LogManager.getLogger(clazz);
    }
    
    /**
     * Get a logger with a specific name
     * 
     * @param name Logger name
     * @return Configured logger instance
     */
    public static Logger getLogger(String name) {
        return LogManager.getLogger(name);
    }
    
    /**
     * Initialize the logging system with custom configuration
     */
    public static void initialize() {
        // Set any system properties for logging configuration
        System.setProperty("log4j.configurationFile", "log4j2.xml");
        
        // Get the root logger to force initialization
        LogManager.getRootLogger();
    }
    
    /**
     * Set the log level for the root logger
     * 
     * @param level New log level
     */
    public static void setRootLogLevel(Level level) {
        Configurator.setRootLevel(level);
    }
}