package com.autocracker.module;

import com.autocracker.util.FileUtils;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Module responsible for scanning input directories for JAR files
 * and determining if they are valid Minecraft plugins.
 */
public class InputScanner {
    private static final Logger logger = LoggerManager.getLogger(InputScanner.class);
    
    /**
     * Scans a directory for JAR files.
     *
     * @param dirPath Path to the directory to scan
     * @return List of paths to JAR files
     * @throws IOException if directory reading fails
     */
    public List<Path> scanDirectory(Path dirPath) throws IOException {
        logger.info("Scanning directory: {}", dirPath);
        
        if (!Files.exists(dirPath)) {
            logger.warn("Directory does not exist: {}", dirPath);
            return List.of();
        }
        
        if (!Files.isDirectory(dirPath)) {
            logger.warn("Path is not a directory: {}", dirPath);
            return List.of();
        }
        
        try (Stream<Path> walk = Files.walk(dirPath, 1)) {
            List<Path> jarFiles = walk
                    .filter(Files::isRegularFile)
                    .filter(path -> path.toString().toLowerCase().endsWith(".jar"))
                    .collect(Collectors.toList());
            
            logger.info("Found {} JAR files", jarFiles.size());
            return jarFiles;
        }
    }
    
    /**
     * Checks if a JAR file is a Minecraft plugin.
     * Looks for plugin.yml file which is typical for Bukkit/Spigot plugins.
     *
     * @param jarPath Path to the JAR file
     * @return true if the JAR is a Minecraft plugin, false otherwise
     */
    public boolean isMinecraftPlugin(Path jarPath) {
        logger.debug("Checking if {} is a Minecraft plugin", jarPath);
        
        try (JarFile jarFile = new JarFile(jarPath.toFile())) {
            // Check for plugin.yml which is typical for Bukkit/Spigot plugins
            JarEntry pluginYml = jarFile.getJarEntry("plugin.yml");
            if (pluginYml != null) {
                logger.debug("Found plugin.yml in {}", jarPath);
                return true;
            }
            
            // Check for bungee.yml which is typical for BungeeCord plugins
            JarEntry bungeeYml = jarFile.getJarEntry("bungee.yml");
            if (bungeeYml != null) {
                logger.debug("Found bungee.yml in {}", jarPath);
                return true;
            }
            
            // Check for velocity-plugin.json which is typical for Velocity plugins
            JarEntry velocityJson = jarFile.getJarEntry("velocity-plugin.json");
            if (velocityJson != null) {
                logger.debug("Found velocity-plugin.json in {}", jarPath);
                return true;
            }
            
            // Check for paper-plugin.yml which is typical for Paper plugins
            JarEntry paperYml = jarFile.getJarEntry("paper-plugin.yml");
            if (paperYml != null) {
                logger.debug("Found paper-plugin.yml in {}", jarPath);
                return true;
            }
            
            // Check for fabric.mod.json which is typical for Fabric mods
            JarEntry fabricJson = jarFile.getJarEntry("fabric.mod.json");
            if (fabricJson != null) {
                logger.debug("Found fabric.mod.json in {}", jarPath);
                return true;
            }
            
            // If none of the above are found, it's probably not a Minecraft plugin
            logger.debug("{} does not appear to be a Minecraft plugin", jarPath);
            return false;
            
        } catch (IOException e) {
            logger.error("Error checking JAR file: {}", jarPath, e);
            return false;
        }
    }
    
    /**
     * Recursively scans a directory and its subdirectories for JAR files.
     *
     * @param dirPath Path to the directory to scan
     * @return List of paths to JAR files
     * @throws IOException if directory reading fails
     */
    public List<Path> scanDirectoryRecursively(Path dirPath) throws IOException {
        logger.info("Recursively scanning directory: {}", dirPath);
        
        try (Stream<Path> walk = Files.walk(dirPath)) {
            List<Path> jarFiles = walk
                    .filter(Files::isRegularFile)
                    .filter(path -> path.toString().endsWith(".jar"))
                    .collect(Collectors.toList());
            
            logger.info("Found {} JAR files in {} and its subdirectories", jarFiles.size(), dirPath);
            return jarFiles;
        }
    }
}