package com.autocracker.module;

import com.autocracker.engine.LicenseBypassEngine;
import com.autocracker.engine.bypass.*;
import com.autocracker.exception.BypassException;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Enhanced version of LicenseBypasser that uses the new LicenseBypassEngine.
 * This class serves as a bridge to maintain compatibility with existing code.
 */
public class LicenseBypasserV2 {
    private static final Logger logger = LoggerManager.getLogger(LicenseBypasserV2.class);
    
    private final LicenseBypassEngine engine;
    private final List<BypassStrategy> customStrategies;
    
    /**
     * Constructor that initializes the bypass engine.
     */
    public LicenseBypasserV2() {
        this.engine = new LicenseBypassEngine();
        this.customStrategies = new ArrayList<>();
    }
    
    /**
     * Bypasses license protection in decompiled code.
     *
     * @param decompileDir Directory containing decompiled files
     * @return true if any bypasses were applied, false otherwise
     * @throws BypassException if bypass fails
     */
    public boolean bypass(Path decompileDir) throws BypassException {
        logger.info("Starting enhanced license bypass process on: {}", decompileDir);
        
        try {
            // Register all strategies
            registerDefaultStrategies();
            
            // Add custom strategies if any
            for (BypassStrategy strategy : customStrategies) {
                registerStrategy(strategy);
            }
            
            // Execute the bypass engine
            boolean result = engine.process(decompileDir);
            
            if (result) {
                logger.info("Successfully bypassed license protection mechanisms");
            } else {
                logger.info("No license protection mechanisms detected or bypassed");
            }
            
            return result;
            
        } catch (Exception e) {
            String errorMsg = "Failed to bypass license protection: " + e.getMessage();
            logger.error(errorMsg, e);
            throw new BypassException(errorMsg, e);
        }
    }
    
    /**
     * Registers a custom bypass strategy.
     *
     * @param strategy Strategy to register
     */
    public void registerStrategy(BypassStrategy strategy) {
        customStrategies.add(strategy);
        logger.debug("Registered custom strategy: {}", strategy.getName());
    }
    
    /**
     * Registers all default strategies.
     */
    private void registerDefaultStrategies() {
        // Register standard strategies
        registerStrategy(new HardcodedKeyStrategy());
        registerStrategy(new HttpApiStrategy());
        registerStrategy(new EncryptionTokenStrategy());
        registerStrategy(new ReflectionStrategy());
        registerStrategy(new ObfuscatedCodeStrategy());
        registerStrategy(new KnownSystemStrategy());
    }
}