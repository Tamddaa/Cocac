package com.autocracker.module;

import com.autocracker.exception.BypassException;
import com.autocracker.util.BytecodeUtils;
import com.autocracker.util.FileUtils;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Module responsible for bypassing license protection in decompiled code.
 * Identifies and modifies license checking mechanisms in Java source code.
 */
public class LicenseBypasser {
    private static final Logger logger = LoggerManager.getLogger(LicenseBypasser.class);
    
    // Patterns to identify license checking methods
    private static final List<Pattern> LICENSE_METHOD_PATTERNS = List.of(
        Pattern.compile("\\b(check|verify|validate|is|has|get)(License|Premium|Activated|Paid|Valid|Auth)\\b"),
        Pattern.compile("\\b(license|auth|hwid|premium|activation|valid)\\.(check|verify|validate|isValid)\\b"),
        Pattern.compile("\\b(authenticate|authorize|validate)\\b"),
        Pattern.compile("\\b(checkLicense|verifyLicense|validateLicense|isLicensed|hasLicense|isPremium)\\b")
    );
    
    // Patterns to identify license-related classes
    private static final List<Pattern> LICENSE_CLASS_PATTERNS = List.of(
        Pattern.compile("\\b(License|Auth|Activation|HWID|Premium|Authentication|Authorization|Validation)\\b"),
        Pattern.compile("\\b(license|auth|hwid|premium|activation|authenticator|validator)\\b")
    );
    
    // Patterns to identify network communication related to license checking
    private static final List<Pattern> NETWORK_PATTERNS = List.of(
        Pattern.compile("\\b(https?://|www\\.|api\\.)[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(:[0-9]+)?(/[^\\s]*)?(license|auth|key|valid|verify|check)"),
        Pattern.compile("\\bnew\\s+URL\\s*\\(\\s*\"https?://"),
        Pattern.compile("\\b(HttpClient|HttpRequest|HttpURLConnection|URLConnection)\\b"),
        Pattern.compile("\\b(openConnection|connect|getInputStream|getOutputStream)\\b")
    );
    
    /**
     * Bypasses license protection in decompiled code.
     *
     * @param decompileDir Directory containing decompiled files
     * @return true if any bypasses were applied, false otherwise
     * @throws BypassException if bypass fails
     */
    public boolean bypass(Path decompileDir) throws BypassException {
        logger.info("Starting license bypass process on: {}", decompileDir);
        
        try {
            AtomicBoolean bypassApplied = new AtomicBoolean(false);
            
            // Find all Java source files
            List<Path> javaFiles = findJavaFiles(decompileDir);
            
            if (javaFiles.isEmpty()) {
                logger.warn("No Java files found in: {}", decompileDir);
                return false;
            }
            
            logger.debug("Found {} Java files", javaFiles.size());
            
            // Find potential license checker classes
            List<Path> licenseClasses = findLicenseClasses(javaFiles);
            
            // Process identified license checker classes
            for (Path javaFile : licenseClasses) {
                if (processLicenseClass(javaFile)) {
                    bypassApplied.set(true);
                }
            }
            
            if (!bypassApplied.get()) {
                // If no license classes were found, try to find and process individual license checking methods
                logger.debug("No license classes found, searching for license checking methods");
                for (Path javaFile : javaFiles) {
                    if (processLicenseMethod(javaFile)) {
                        bypassApplied.set(true);
                    }
                }
            }
            
            if (!bypassApplied.get()) {
                // If still no bypasses applied, look for compiled class files that might contain license checks
                logger.debug("No license methods found in source, searching in compiled classes");
                List<Path> classFiles = findClassFiles(decompileDir);
                for (Path classFile : classFiles) {
                    if (processCompiledClass(classFile)) {
                        bypassApplied.set(true);
                    }
                }
            }
            
            // Report results
            if (bypassApplied.get()) {
                logger.info("Successfully bypassed license protection");
            } else {
                logger.info("No license protection detected or bypassed");
            }
            
            return bypassApplied.get();
            
        } catch (IOException e) {
            String errorMsg = "Failed to bypass license protection: " + e.getMessage();
            logger.error(errorMsg, e);
            throw new BypassException(errorMsg, e);
        }
    }
    
    /**
     * Finds all Java source files in the decompiled directory.
     *
     * @param decompileDir Directory containing decompiled files
     * @return List of paths to Java source files
     * @throws IOException if file operations fail
     */
    private List<Path> findJavaFiles(Path decompileDir) throws IOException {
        Path srcDir = decompileDir.resolve("src");
        if (!Files.exists(srcDir)) {
            return new ArrayList<>();
        }
        
        try (Stream<Path> walk = Files.walk(srcDir)) {
            return walk
                    .filter(Files::isRegularFile)
                    .filter(path -> path.toString().endsWith(".java"))
                    .collect(Collectors.toList());
        }
    }
    
    /**
     * Finds compiled class files in the decompiled directory.
     *
     * @param decompileDir Directory containing decompiled files
     * @return List of paths to compiled class files
     * @throws IOException if file operations fail
     */
    private List<Path> findClassFiles(Path decompileDir) throws IOException {
        try (Stream<Path> walk = Files.walk(decompileDir)) {
            return walk
                    .filter(Files::isRegularFile)
                    .filter(path -> path.toString().endsWith(".class"))
                    .collect(Collectors.toList());
        }
    }
    
    /**
     * Identifies potential license checker classes.
     *
     * @param javaFiles List of Java source files
     * @return List of paths to potential license checker classes
     * @throws IOException if file operations fail
     */
    private List<Path> findLicenseClasses(List<Path> javaFiles) throws IOException {
        List<Path> licenseClasses = new ArrayList<>();
        
        for (Path javaFile : javaFiles) {
            String content = Files.readString(javaFile);
            String fileName = javaFile.getFileName().toString();
            
            // Check if filename matches any license patterns
            boolean fileNameMatch = LICENSE_CLASS_PATTERNS.stream()
                    .anyMatch(pattern -> pattern.matcher(fileName).find());
            
            if (fileNameMatch) {
                logger.debug("Found potential license class by name: {}", javaFile);
                licenseClasses.add(javaFile);
                continue;
            }
            
            // Check content for license-related code
            boolean contentMatch = LICENSE_CLASS_PATTERNS.stream()
                    .anyMatch(pattern -> pattern.matcher(content).find()) ||
                   LICENSE_METHOD_PATTERNS.stream()
                    .anyMatch(pattern -> pattern.matcher(content).find()) ||
                   NETWORK_PATTERNS.stream()
                    .anyMatch(pattern -> pattern.matcher(content).find());
            
            if (contentMatch) {
                logger.debug("Found potential license class by content: {}", javaFile);
                licenseClasses.add(javaFile);
            }
        }
        
        return licenseClasses;
    }
    
    /**
     * Processes a potential license checker class.
     *
     * @param javaFile Path to the Java source file
     * @return true if any bypasses were applied, false otherwise
     * @throws IOException if file operations fail
     */
    private boolean processLicenseClass(Path javaFile) throws IOException {
        logger.debug("Processing license class: {}", javaFile);
        String content = Files.readString(javaFile);
        boolean modified = false;
        
        // 1. Replace boolean license checking methods to return true
        for (Pattern pattern : LICENSE_METHOD_PATTERNS) {
            modified |= replaceBooleanMethods(javaFile, pattern, content, true);
        }
        
        // 2. Disable URL connections for license validation
        modified |= disableNetworkCalls(javaFile, content);
        
        // 3. Replace HWID validation to return true
        modified |= replaceHWIDValidation(javaFile, content);
        
        return modified;
    }
    
    /**
     * Processes Java source file to find and modify individual license checking methods.
     *
     * @param javaFile Path to the Java source file
     * @return true if any bypasses were applied, false otherwise
     * @throws IOException if file operations fail
     */
    private boolean processLicenseMethod(Path javaFile) throws IOException {
        logger.debug("Looking for license methods in: {}", javaFile);
        String content = Files.readString(javaFile);
        boolean modified = false;
        
        // Replace boolean methods that might be license checks
        for (Pattern pattern : LICENSE_METHOD_PATTERNS) {
            modified |= replaceBooleanMethods(javaFile, pattern, content, true);
        }
        
        return modified;
    }
    
    /**
     * Processes a compiled class file to find and modify bytecode-level license checks.
     *
     * @param classFile Path to the compiled class file
     * @return true if any bypasses were applied, false otherwise
     */
    private boolean processCompiledClass(Path classFile) {
        try {
            logger.debug("Processing compiled class: {}", classFile);
            
            // Check if this class is likely to contain license checking code
            if (!BytecodeUtils.isLikelyLicenseChecker(classFile)) {
                return false;
            }
            
            boolean modified = false;
            
            // Modify boolean methods matching license patterns to return true
            for (Pattern pattern : LICENSE_METHOD_PATTERNS) {
                String patternStr = pattern.pattern()
                        .replace("\\b", "")
                        .replace("\\.", ".")
                        .replace("(", "")
                        .replace(")", "")
                        .replace("|", ".");
                
                modified |= BytecodeUtils.modifyMatchingBooleanMethods(classFile, patternStr, true);
            }
            
            // Replace strings that might be license-related URLs
            for (Pattern pattern : NETWORK_PATTERNS) {
                String patternStr = pattern.pattern()
                        .replace("\\b", "")
                        .replace("\\.", ".")
                        .replace("(", "")
                        .replace(")", "")
                        .replace("|", ".");
                
                // Find and replace URL strings
                if (BytecodeUtils.replaceStringConstant(classFile, patternStr, "http://localhost")) {
                    modified = true;
                }
            }
            
            return modified;
            
        } catch (Exception e) {
            logger.warn("Failed to process compiled class: {}", classFile, e);
            return false;
        }
    }
    
    /**
     * Replaces boolean methods matching a pattern to always return true or false.
     *
     * @param javaFile Path to the Java source file
     * @param pattern Pattern to match method names
     * @param content Content of the Java file
     * @param returnValue Value to return (true or false)
     * @return true if any changes were made, false otherwise
     * @throws IOException if file operations fail
     */
    private boolean replaceBooleanMethods(Path javaFile, Pattern pattern, String content, boolean returnValue) throws IOException {
        String modified = content;
        
        // Replace implementations of methods matching the pattern
        java.util.regex.Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            String methodName = matcher.group();
            
            // Look for method definition with this name
            Pattern methodDefPattern = Pattern.compile(
                    "(public|private|protected)?\\s+(static)?\\s+boolean\\s+" +
                    Pattern.quote(methodName) + "\\s*\\([^)]*\\)\\s*\\{[^}]*\\}"
            );
            
            java.util.regex.Matcher defMatcher = methodDefPattern.matcher(content);
            if (defMatcher.find()) {
                String methodDef = defMatcher.group();
                String replacement = methodDef.substring(0, methodDef.lastIndexOf('{') + 1) +
                        " return " + returnValue + "; }";
                
                modified = modified.replace(methodDef, replacement);
                
                logger.debug("Modified method {} in {} to return {}", methodName, javaFile, returnValue);
            }
        }
        
        // If changes were made, write the modified content back to the file
        if (!modified.equals(content)) {
            Files.writeString(javaFile, modified);
            return true;
        }
        
        return false;
    }
    
    /**
     * Disables network calls that might be related to license validation.
     *
     * @param javaFile Path to the Java source file
     * @param content Content of the Java file
     * @return true if any changes were made, false otherwise
     * @throws IOException if file operations fail
     */
    private boolean disableNetworkCalls(Path javaFile, String content) throws IOException {
        String modified = content;
        
        // Replace URL initialization with local URLs
        for (Pattern pattern : NETWORK_PATTERNS) {
            java.util.regex.Matcher matcher = pattern.matcher(content);
            
            while (matcher.find()) {
                String match = matcher.group();
                
                // If it's a URL string, replace it with localhost
                if (match.contains("http://") || match.contains("https://")) {
                    String replacement = match.replaceAll("https?://[^/]+", "http://localhost");
                    modified = modified.replace(match, replacement);
                    
                    logger.debug("Replaced URL in {}: {} -> {}", javaFile, match, replacement);
                }
                
                // Add exception handling around network calls
                if (match.contains("openConnection") || match.contains("connect")) {
                    String replacement = "try { " + match + " } catch (Exception e) { /* Bypassed */ }";
                    modified = modified.replace(match, replacement);
                    
                    logger.debug("Added exception handling around network call in {}: {}", javaFile, match);
                }
            }
        }
        
        // If changes were made, write the modified content back to the file
        if (!modified.equals(content)) {
            Files.writeString(javaFile, modified);
            return true;
        }
        
        return false;
    }
    
    /**
     * Replaces HWID validation to always return true.
     *
     * @param javaFile Path to the Java source file
     * @param content Content of the Java file
     * @return true if any changes were made, false otherwise
     * @throws IOException if file operations fail
     */
    private boolean replaceHWIDValidation(Path javaFile, String content) throws IOException {
        String modified = content;
        
        // Replace HWID-related checks
        Pattern hwidPattern = Pattern.compile("\\b(validateHWID|checkHWID|isValidHWID|verifyHWID)\\b");
        Pattern hwComparison = Pattern.compile("([a-zA-Z0-9_]+\\.getHWID\\(\\)|getHWID\\(\\)|hwid)\\.equals\\([^)]+\\)");
        
        // Replace HWID validation methods - fixed to correctly handle return value
        boolean methodsModified = replaceBooleanMethods(javaFile, hwidPattern, content, true);
        
        // Replace direct HWID comparisons
        java.util.regex.Matcher matcher = hwComparison.matcher(content);
        while (matcher.find()) {
            String match = matcher.group();
            modified = modified.replace(match, "true");
            
            logger.debug("Replaced HWID comparison in {}: {} -> true", javaFile, match);
        }
        
        // If changes were made, write the modified content back to the file
        if (!modified.equals(content)) {
            Files.writeString(javaFile, modified);
            return true;
        }
        
        return false;
    }
}