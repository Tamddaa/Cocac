package com.autocracker.util;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Pattern;

/**
 * Utility class for detecting obfuscated code.
 * Provides methods to analyze Java class files and detect common obfuscation patterns.
 */
public class ObfuscationDetector {
    private static final Logger logger = LoggerManager.getLogger(ObfuscationDetector.class);
    
    // Pattern to match common obfuscated class names (short, random letters or single letters)
    private static final Pattern OBFUSCATED_CLASS_PATTERN = 
            Pattern.compile("^[a-zA-Z]{1,3}$|^[a-z][A-Z][a-zA-Z]$|^[a-zA-Z][0-9][a-zA-Z]$");
    
    // Pattern to match common obfuscated method names
    private static final Pattern OBFUSCATED_METHOD_PATTERN = 
            Pattern.compile("^[a-zA-Z]{1,2}$|^[a-z][A-Z][0-9]$|^[a-zA-Z][0-9]{1,2}$");
    
    /**
     * Private constructor to prevent instantiation.
     */
    private ObfuscationDetector() {
        throw new UnsupportedOperationException("Utility class should not be instantiated");
    }
    
    /**
     * Checks if a class name is likely obfuscated.
     *
     * @param className Name of the class to check
     * @return true if the class name appears to be obfuscated, false otherwise
     */
    public static boolean isObfuscatedClassName(String className) {
        // Check if class name matches obfuscated pattern
        return OBFUSCATED_CLASS_PATTERN.matcher(className).matches();
    }
    
    /**
     * Checks if a method name is likely obfuscated.
     *
     * @param methodName Name of the method to check
     * @return true if the method name appears to be obfuscated, false otherwise
     */
    public static boolean isObfuscatedMethodName(String methodName) {
        // Check if method name matches obfuscated pattern
        return OBFUSCATED_METHOD_PATTERN.matcher(methodName).matches();
    }
    
    /**
     * Analyzes a class file to determine if it's likely obfuscated.
     *
     * @param classFile Path to the class file
     * @return true if the class file appears to be obfuscated, false otherwise
     */
    public static boolean isObfuscatedClass(Path classFile) {
        try {
            // Check if class name is obfuscated
            String className = classFile.getFileName().toString().replace(".class", "");
            if (isObfuscatedClassName(className)) {
                return true;
            }
            
            // More detailed analysis would require ASM or Javassist
            // This is a simplified implementation
            byte[] classBytes = Files.readAllBytes(classFile);
            
            // Count short method names in binary representation (simplified approach)
            int shortMethodCount = 0;
            int totalMethods = 0;
            
            String content = new String(classBytes);
            for (String line : content.split("\n")) {
                if (line.contains("(") && line.contains(")") && !line.contains("//")) {
                    totalMethods++;
                    
                    // Extract method name (very simplified)
                    int spaceBeforeName = line.lastIndexOf(' ', line.indexOf('('));
                    if (spaceBeforeName > 0) {
                        String methodName = line.substring(spaceBeforeName + 1, line.indexOf('('));
                        if (methodName.length() <= 2) {
                            shortMethodCount++;
                        }
                    }
                }
            }
            
            // If more than 50% of methods have short names, likely obfuscated
            return totalMethods > 0 && shortMethodCount > 0 && 
                   ((double) shortMethodCount / totalMethods > 0.5);
            
        } catch (IOException e) {
            logger.error("Error reading class file: {}", classFile, e);
            return false;
        } catch (Exception e) {
            logger.error("Error analyzing class file: {}", classFile, e);
            return false;
        }
    }
    
    /**
     * Analyzes a Java source file to determine if it's likely obfuscated.
     *
     * @param javaFile Path to the Java source file
     * @return true if the Java file appears to be obfuscated, false otherwise
     */
    public static boolean isObfuscatedJavaSource(Path javaFile) {
        try {
            // Check if class name is obfuscated
            String className = javaFile.getFileName().toString().replace(".java", "");
            if (isObfuscatedClassName(className)) {
                return true;
            }
            
            // Read file content
            String content = Files.readString(javaFile);
            
            // Count short identifiers
            int shortMethodCount = 0;
            int totalMethods = 0;
            int shortVarCount = 0;
            int totalVars = 0;
            
            // Process file line by line (simplified approach)
            for (String line : content.split("\n")) {
                // Count method declarations
                if (line.contains("(") && line.contains(")") && !line.contains("//") && 
                   (line.contains("public") || line.contains("private") || line.contains("protected"))) {
                    totalMethods++;
                    
                    // Extract method name (very simplified)
                    int spaceBeforeName = line.lastIndexOf(' ', line.indexOf('('));
                    if (spaceBeforeName > 0) {
                        String methodName = line.substring(spaceBeforeName + 1, line.indexOf('('));
                        if (isObfuscatedMethodName(methodName)) {
                            shortMethodCount++;
                        }
                    }
                }
                
                // Count variable declarations
                if ((line.contains("int ") || line.contains("String ") || 
                     line.contains("boolean ") || line.contains("long ") ||
                     line.contains("double ") || line.contains("float ") ||
                     line.contains("Object ")) && line.contains("=") && !line.contains("//")) {
                    totalVars++;
                    
                    // Extract variable name (very simplified)
                    int typeEnd = Math.max(
                        Math.max(line.indexOf("int "), line.indexOf("String ")),
                        Math.max(
                            Math.max(line.indexOf("boolean "), line.indexOf("long ")),
                            Math.max(
                                Math.max(line.indexOf("double "), line.indexOf("float ")),
                                line.indexOf("Object ")
                            )
                        )
                    );
                    
                    if (typeEnd >= 0) {
                        int varNameEnd = line.indexOf("=", typeEnd);
                        if (varNameEnd > typeEnd) {
                            String varName = line.substring(typeEnd + 1, varNameEnd).trim();
                            if (varName.length() <= 2) {
                                shortVarCount++;
                            }
                        }
                    }
                }
            }
            
            // Check for string decryption patterns
            boolean hasStringDecryption = content.contains("new String(new byte[]") ||
                                         content.contains("new String(") && content.contains("decode") ||
                                         content.contains("String.fromCharCode") ||
                                         (content.contains("charAt") && content.contains("substring") && 
                                          content.contains("length") && content.contains("+="));
            
            // Check for control flow obfuscation
            boolean hasControlFlowObfuscation = content.contains("while(true)") &&
                                              content.contains("case ") && 
                                              content.contains("break;") &&
                                              content.contains("switch(");
            
            // If more than 40% of methods have obfuscated names, or string decryption is detected
            return (totalMethods > 0 && shortMethodCount > 0 && 
                   ((double) shortMethodCount / totalMethods > 0.4)) ||
                   (totalVars > 5 && shortVarCount > 0 && 
                   ((double) shortVarCount / totalVars > 0.6)) ||
                   hasStringDecryption ||
                   hasControlFlowObfuscation;
            
        } catch (IOException e) {
            logger.error("Error reading Java file: {}", javaFile, e);
            return false;
        } catch (Exception e) {
            logger.error("Error analyzing Java file: {}", javaFile, e);
            return false;
        }
    }
}