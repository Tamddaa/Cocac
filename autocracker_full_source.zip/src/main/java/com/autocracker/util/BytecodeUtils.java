package com.autocracker.util;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;
import org.objectweb.asm.*;
import org.objectweb.asm.commons.ClassRemapper;
import org.objectweb.asm.commons.SimpleRemapper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Advanced utility class for bytecode manipulation using ASM.
 * Provides methods to analyze and modify Java class files at the bytecode level.
 */
public class BytecodeUtils {
    private static final Logger logger = LoggerManager.getLogger(BytecodeUtils.class);

    /**
     * Private constructor to prevent instantiation.
     */
    private BytecodeUtils() {
        throw new UnsupportedOperationException("Utility class should not be instantiated");
    }
    
    /**
     * Checks if a class file is likely to contain license checking code.
     *
     * @param classFile Path to the class file
     * @return true if the class is likely a license checker, false otherwise
     */
    public static boolean isLikelyLicenseChecker(Path classFile) {
        try {
            String className = classFile.getFileName().toString().toLowerCase();
            
            // Quick check based on filename
            if (className.contains("license") || 
                className.contains("auth") || 
                className.contains("premium") ||
                className.contains("valid") ||
                className.contains("verify") ||
                className.contains("check")) {
                return true;
            }
            
            // More detailed analysis using ASM
            byte[] classBytes = Files.readAllBytes(classFile);
            LicenseCheckerClassVisitor visitor = new LicenseCheckerClassVisitor();
            
            ClassReader reader = new ClassReader(classBytes);
            reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
            
            return visitor.isLicenseChecker();
            
        } catch (IOException e) {
            logger.error("Error reading class file: {}", classFile, e);
            return false;
        } catch (Exception e) {
            logger.error("Error analyzing class file: {}", classFile, e);
            return false;
        }
    }
    
    /**
     * Modifies boolean methods in a class file to always return a specified value.
     *
     * @param classFile Path to the class file
     * @param methodPattern Pattern to match method names
     * @param returnValue Value to return
     * @return true if any methods were modified, false otherwise
     */
    public static boolean modifyMatchingBooleanMethods(Path classFile, String methodPattern, boolean returnValue) {
        try {
            byte[] classBytes = Files.readAllBytes(classFile);
            
            // Create pattern matcher
            Pattern pattern = Pattern.compile(methodPattern, Pattern.CASE_INSENSITIVE);
            
            // Create class visitor to modify boolean methods
            BooleanMethodModifierVisitor visitor = new BooleanMethodModifierVisitor(pattern, returnValue);
            
            ClassReader reader = new ClassReader(classBytes);
            ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES);
            reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
            
            if (visitor.isModified()) {
                byte[] modifiedBytes = writer.toByteArray();
                Files.write(classFile, modifiedBytes);
                logger.debug("Modified boolean methods in: {}", classFile);
                return true;
            }
            
            return false;
            
        } catch (IOException e) {
            logger.error("Error reading/writing class file: {}", classFile, e);
            return false;
        } catch (Exception e) {
            logger.error("Error modifying class file: {}", classFile, e);
            return false;
        }
    }
    
    /**
     * Replaces a string constant in a class file.
     *
     * @param classFile Path to the class file
     * @param pattern Pattern to match string constants
     * @param replacement Replacement string
     * @return true if any strings were replaced, false otherwise
     */
    public static boolean replaceStringConstant(Path classFile, String pattern, String replacement) {
        try {
            byte[] classBytes = Files.readAllBytes(classFile);
            
            // Create pattern matcher
            Pattern regex = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
            
            // Create class visitor to replace string constants
            StringConstantReplacerVisitor visitor = new StringConstantReplacerVisitor(regex, replacement);
            
            ClassReader reader = new ClassReader(classBytes);
            ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES);
            reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
            
            if (visitor.isModified()) {
                byte[] modifiedBytes = writer.toByteArray();
                Files.write(classFile, modifiedBytes);
                logger.debug("Replaced string constants in: {}", classFile);
                return true;
            }
            
            return false;
            
        } catch (IOException e) {
            logger.error("Error reading/writing class file: {}", classFile, e);
            return false;
        } catch (Exception e) {
            logger.error("Error modifying class file: {}", classFile, e);
            return false;
        }
    }
    
    /**
     * ASM class visitor to detect if a class is likely a license checker.
     */
    private static class LicenseCheckerClassVisitor extends ClassVisitor {
        private boolean licenseChecker = false;
        private final List<String> licenseKeywords = List.of(
            "license", "auth", "premium", "valid", "verify", "check", "key", "activation"
        );
        
        public LicenseCheckerClassVisitor() {
            super(Opcodes.ASM9);
        }
        
        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            // Check class name for license-related keywords
            String className = name.toLowerCase();
            for (String keyword : licenseKeywords) {
                if (className.contains(keyword)) {
                    licenseChecker = true;
                    break;
                }
            }
            super.visit(version, access, name, signature, superName, interfaces);
        }
        
        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            // Check method name for license-related keywords
            String methodName = name.toLowerCase();
            for (String keyword : licenseKeywords) {
                if (methodName.contains(keyword)) {
                    licenseChecker = true;
                    break;
                }
            }
            
            // Check if method returns boolean
            if (descriptor.endsWith("Z") && !methodName.equals("equals") && !methodName.startsWith("is")) {
                licenseChecker = true;
            }
            
            return super.visitMethod(access, name, descriptor, signature, exceptions);
        }
        
        @Override
        public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
            // Check field names for license-related keywords
            String fieldName = name.toLowerCase();
            for (String keyword : licenseKeywords) {
                if (fieldName.contains(keyword)) {
                    licenseChecker = true;
                    break;
                }
            }
            
            return super.visitField(access, name, descriptor, signature, value);
        }
        
        public boolean isLicenseChecker() {
            return licenseChecker;
        }
    }
    
    /**
     * ASM class visitor to modify boolean methods to always return a specific value.
     */
    private static class BooleanMethodModifierVisitor extends ClassVisitor {
        private final Pattern methodPattern;
        private final boolean returnValue;
        private boolean modified = false;
        
        public BooleanMethodModifierVisitor(Pattern methodPattern, boolean returnValue) {
            super(Opcodes.ASM9);
            this.methodPattern = methodPattern;
            this.returnValue = returnValue;
        }
        
        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            cv.visit(version, access, name, signature, superName, interfaces);
        }
        
        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            MethodVisitor mv = cv.visitMethod(access, name, descriptor, signature, exceptions);
            
            // Check if method matches pattern and returns boolean
            if (descriptor.endsWith("Z") && methodPattern.matcher(name).find()) {
                modified = true;
                
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    @Override
                    public void visitCode() {
                        // Replace method body with simple return true/false
                        super.visitCode();
                        visitInsn(returnValue ? Opcodes.ICONST_1 : Opcodes.ICONST_0);
                        visitInsn(Opcodes.IRETURN);
                    }
                    
                    @Override
                    public void visitMaxs(int maxStack, int maxLocals) {
                        super.visitMaxs(Math.max(1, maxStack), maxLocals);
                    }
                };
            }
            
            return mv;
        }
        
        public boolean isModified() {
            return modified;
        }
    }
    
    /**
     * ASM class visitor to replace string constants matching a pattern.
     */
    private static class StringConstantReplacerVisitor extends ClassVisitor {
        private final Pattern pattern;
        private final String replacement;
        private boolean modified = false;
        
        public StringConstantReplacerVisitor(Pattern pattern, String replacement) {
            super(Opcodes.ASM9);
            this.pattern = pattern;
            this.replacement = replacement;
        }
        
        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            cv.visit(version, access, name, signature, superName, interfaces);
        }
        
        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            MethodVisitor mv = cv.visitMethod(access, name, descriptor, signature, exceptions);
            
            return new MethodVisitor(Opcodes.ASM9, mv) {
                @Override
                public void visitLdcInsn(Object value) {
                    // Replace string constants matching pattern
                    if (value instanceof String) {
                        String stringValue = (String) value;
                        if (pattern.matcher(stringValue).find()) {
                            modified = true;
                            super.visitLdcInsn(replacement);
                        } else {
                            super.visitLdcInsn(value);
                        }
                    } else {
                        super.visitLdcInsn(value);
                    }
                }
            };
        }
        
        public boolean isModified() {
            return modified;
        }
    }
}