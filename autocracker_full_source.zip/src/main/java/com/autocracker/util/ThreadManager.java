package com.autocracker.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Manages thread pools for the application.
 */
public class ThreadManager {
    
    private static final int DEFAULT_THREAD_COUNT = Runtime.getRuntime().availableProcessors();
    private static ExecutorService executor;
    private static int threadCount = DEFAULT_THREAD_COUNT;
    
    /**
     * Private constructor to prevent instantiation.
     */
    private ThreadManager() {
        throw new UnsupportedOperationException("Utility class should not be instantiated");
    }
    
    /**
     * Initializes the thread pool.
     */
    public static void init() {
        init(threadCount);
    }
    
    /**
     * Initializes the thread pool with a specific number of threads.
     *
     * @param threads Number of threads to use
     */
    public static void init(int threads) {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
        
        threadCount = threads > 0 ? threads : DEFAULT_THREAD_COUNT;
        executor = Executors.newFixedThreadPool(threadCount, new NamedThreadFactory("AutoCracker-Worker"));
    }
    
    /**
     * Gets the executor service.
     *
     * @return The executor service
     */
    public static ExecutorService getExecutor() {
        if (executor == null || executor.isShutdown()) {
            init();
        }
        return executor;
    }
    
    /**
     * Gets the number of threads.
     *
     * @return The number of threads
     */
    public static int getThreadCount() {
        return threadCount;
    }
    
    /**
     * Sets the number of threads and reinitializes the thread pool.
     *
     * @param threads Number of threads to use
     */
    public static void setThreadCount(int threads) {
        threadCount = threads;
        init();
    }
    
    /**
     * Shuts down the thread pool.
     */
    public static void shutdown() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }
    
    /**
     * A thread factory that names threads.
     */
    private static class NamedThreadFactory implements ThreadFactory {
        private final ThreadGroup group;
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final String namePrefix;
        
        NamedThreadFactory(String namePrefix) {
            // SecurityManager is deprecated in Java 17+, use current thread's group directly
            group = Thread.currentThread().getThreadGroup();
            this.namePrefix = namePrefix;
        }
        
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(group, r, namePrefix + "-" + threadNumber.getAndIncrement(), 0);
            if (t.isDaemon()) {
                t.setDaemon(false);
            }
            if (t.getPriority() != Thread.NORM_PRIORITY) {
                t.setPriority(Thread.NORM_PRIORITY);
            }
            return t;
        }
    }
}