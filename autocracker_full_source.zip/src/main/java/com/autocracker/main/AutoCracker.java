package com.autocracker.main;

import com.autocracker.exception.DecompilationException;
import com.autocracker.exception.RebuildException;
import com.autocracker.model.JarTask;
import com.autocracker.model.ProcessingResult;
import com.autocracker.module.InputScanner;
import com.autocracker.module.JarDecompiler;
import com.autocracker.module.JarRebuilder;
import com.autocracker.module.LicenseBypasser;
import com.autocracker.module.LoggerManager;
import com.autocracker.util.FileUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/**
 * Main class for the AutoCracker application.
 * Handles command line arguments, initializes modules, and orchestrates the cracking process.
 */
public class AutoCracker {
    private static final Logger logger = LoggerManager.getLogger(AutoCracker.class);
    
    private static final String DEFAULT_INPUT_DIR = "input";
    private static final String DEFAULT_OUTPUT_DIR = "output";
    private static final int DEFAULT_THREADS = Runtime.getRuntime().availableProcessors();
    private static final boolean DEFAULT_CLEANUP = true;
    
    private String inputDir;
    private String outputDir;
    private int threads;
    private boolean verbose;
    private boolean cleanup;
    
    private final InputScanner scanner;
    private final JarDecompiler decompiler;
    private final LicenseBypasser bypasser;
    private final JarRebuilder rebuilder;
    
    /**
     * Constructor that initializes modules and default configuration.
     */
    public AutoCracker() {
        this.inputDir = DEFAULT_INPUT_DIR;
        this.outputDir = DEFAULT_OUTPUT_DIR;
        this.threads = DEFAULT_THREADS;
        this.verbose = false;
        this.cleanup = DEFAULT_CLEANUP;
        
        this.scanner = new InputScanner();
        this.decompiler = new JarDecompiler();
        this.bypasser = new LicenseBypasser();
        this.rebuilder = new JarRebuilder();
    }
    
    /**
     * Main method that parses command line arguments and starts the application.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        AutoCracker app = new AutoCracker();
        
        try {
            app.parseArguments(args);
            app.setupLogging();
            app.printBanner();
            app.processJars();
        } catch (Exception e) {
            logger.error("Application error: {}", e.getMessage(), e);
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }
    
    /**
     * Parses command line arguments.
     *
     * @param args Command line arguments
     */
    private void parseArguments(String[] args) {
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-i":
                case "--input":
                    if (i + 1 < args.length) {
                        inputDir = args[++i];
                    }
                    break;
                case "-o":
                case "--output":
                    if (i + 1 < args.length) {
                        outputDir = args[++i];
                    }
                    break;
                case "-t":
                case "--threads":
                    if (i + 1 < args.length) {
                        try {
                            threads = Integer.parseInt(args[++i]);
                        } catch (NumberFormatException e) {
                            threads = DEFAULT_THREADS;
                        }
                    }
                    break;
                case "-v":
                case "--verbose":
                    verbose = true;
                    break;
                case "--no-cleanup":
                    cleanup = false;
                    break;
                case "-h":
                case "--help":
                    printHelp();
                    System.exit(0);
                    break;
            }
        }
        
        // Validate arguments
        if (threads < 1) {
            threads = DEFAULT_THREADS;
        }
    }
    
    /**
     * Sets up logging based on configuration.
     */
    private void setupLogging() {
        if (verbose) {
            LoggerManager.setRootLogLevel(Level.DEBUG);
        } else {
            LoggerManager.setRootLogLevel(Level.INFO);
        }
        
        // Ensure logs directory exists
        try {
            FileUtils.createDirectoryIfNotExists(Paths.get("logs"));
        } catch (IOException e) {
            logger.warn("Failed to create logs directory", e);
        }
        
        logger.info("AutoCracker started");
        logger.info("Configuration: input={}, output={}, threads={}, verbose={}, cleanup={}",
                inputDir, outputDir, threads, verbose, cleanup);
    }
    
    /**
     * Processes all JAR files found in the input directory.
     */
    private void processJars() {
        try {
            // Create output directory if it doesn't exist
            Path outputPath = Paths.get(outputDir);
            FileUtils.createDirectoryIfNotExists(outputPath);
            
            // Scan for JAR files
            List<Path> jarFiles = scanner.scanDirectory(Paths.get(inputDir));
            
            if (jarFiles.isEmpty()) {
                logger.warn("No JAR files found in the input directory: {}", inputDir);
                System.out.println("No JAR files found in the input directory: " + inputDir);
                return;
            }
            
            logger.info("Found {} JAR files to process", jarFiles.size());
            System.out.println("Found " + jarFiles.size() + " JAR files to process");
            
            // Process JAR files in parallel
            ExecutorService executor = Executors.newFixedThreadPool(threads);
            List<Future<ProcessingResult>> futures = new ArrayList<>();
            
            for (Path jarFile : jarFiles) {
                JarTask task = new JarTask(jarFile, outputPath);
                futures.add(executor.submit(() -> processJar(task)));
            }
            
            // Collect results
            int success = 0;
            int failed = 0;
            
            for (Future<ProcessingResult> future : futures) {
                try {
                    ProcessingResult result = future.get();
                    if (result.isSuccess()) {
                        success++;
                    } else {
                        failed++;
                        logger.error("Failed to process {}: {}", 
                                result.getJarTask().getJarPath().getFileName(), 
                                result.getErrorMessage());
                    }
                } catch (Exception e) {
                    failed++;
                    logger.error("Task execution failed", e);
                }
            }
            
            executor.shutdown();
            
            logger.info("Processing complete: {} successful, {} failed", success, failed);
            System.out.println("\nProcessing complete:");
            System.out.println("  - " + success + " JARs successfully processed");
            System.out.println("  - " + failed + " JARs failed");
            System.out.println("\nOutput files available in: " + outputPath.toAbsolutePath());
            
        } catch (IOException e) {
            logger.error("Error processing JAR files", e);
            System.err.println("Error processing JAR files: " + e.getMessage());
        }
    }
    
    /**
     * Processes a single JAR file.
     *
     * @param task The JAR processing task
     * @return The processing result
     */
    private ProcessingResult processJar(JarTask task) {
        Path jarPath = task.getJarPath();
        Path outputPath = task.getOutputDir();
        String jarName = jarPath.getFileName().toString();
        
        logger.info("Processing JAR: {}", jarName);
        
        try {
            // Create timestamped working directory
            String timestamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
            Path workDir = Paths.get("temp", timestamp, jarName);
            Files.createDirectories(workDir);
            
            // Step 1: Decompile JAR
            logger.info("Decompiling: {}", jarName);
            Path decompileDir = decompiler.decompile(jarPath, workDir);
            
            // Step 2: Bypass license protection
            logger.info("Bypassing license protection: {}", jarName);
            boolean bypassApplied = bypasser.bypass(decompileDir);
            Path bypassedDir = decompileDir; // Use the same directory after bypass
            
            // Step 3: Rebuild JAR
            logger.info("Rebuilding: {}", jarName);
            Path outputJarPath = outputPath.resolve("cracked_" + jarName);
            Path rebuiltJarPath = rebuilder.rebuild(bypassedDir, outputJarPath);
            
            // Clean up if needed
            if (cleanup) {
                logger.debug("Cleaning up temporary files: {}", workDir);
                FileUtils.deleteDirectory(workDir);
            }
            
            logger.info("Successfully processed: {}", jarName);
            return new ProcessingResult(task, true, rebuiltJarPath, null);
            
        } catch (DecompilationException e) {
            logger.error("Decompilation failed for {}: {}", jarName, e.getMessage());
            return new ProcessingResult(task, false, null, "Decompilation failed: " + e.getMessage());
            
        } catch (RebuildException e) {
            logger.error("Rebuild failed for {}: {}", jarName, e.getMessage());
            return new ProcessingResult(task, false, null, "Rebuild failed: " + e.getMessage());
            
        } catch (Exception e) {
            logger.error("Processing failed for {}: {}", jarName, e.getMessage(), e);
            return new ProcessingResult(task, false, null, "Processing failed: " + e.getMessage());
        }
    }
    
    /**
     * Prints the application banner.
     */
    private void printBanner() {
        System.out.println("\n" +
                "  █████╗ ██╗   ██╗████████╗ ██████╗  ██████╗██████╗  █████╗  ██████╗██╗  ██╗███████╗██████╗ \n" +
                " ██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗\n" +
                " ███████║██║   ██║   ██║   ██║   ██║██║     ██████╔╝███████║██║     █████╔╝ █████╗  ██████╔╝\n" +
                " ██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██╗██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗\n" +
                " ██║  ██║╚██████╔╝   ██║   ╚██████╔╝╚██████╗██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║\n" +
                " ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n" +
                "                            Version 3.5.0 - Ultra Encryption Edition\n" +
                "                  Minecraft Plugin License Patcher and Protection Remover\n" +
                "               🔓 AES • DES • 3DES • RSA • BLOWFISH • REFLECTION • BYTE ARRAYS 🔓\n");
        
        System.out.println(" Input directory:  " + inputDir);
        System.out.println(" Output directory: " + outputDir);
        System.out.println(" Thread count:     " + threads);
        System.out.println(" Verbose logging:  " + (verbose ? "Enabled" : "Disabled"));
        System.out.println(" Auto cleanup:     " + (cleanup ? "Enabled" : "Disabled"));
        System.out.println("\n-----------------------------------------------------------------------\n");
    }
    
    /**
     * Prints help information.
     */
    private void printHelp() {
        System.out.println("\nAutoCracker 3.5.0 - Ultra Encryption Edition - Minecraft Plugin License Patcher");
        System.out.println("\nUsage: java -jar AutoCracker.jar [options]");
        System.out.println("\nOptions:");
        System.out.println("  -i, --input <dir>    Directory containing JAR files to process (default: input)");
        System.out.println("  -o, --output <dir>   Directory to store processed JAR files (default: output)");
        System.out.println("  -t, --threads <num>  Number of parallel processing threads (default: CPU cores)");
        System.out.println("  -v, --verbose        Enable detailed logging");
        System.out.println("  --no-cleanup         Keep temporary decompilation files");
        System.out.println("  -h, --help           Show this help message");
        System.out.println("\nExample: java -jar AutoCracker.jar -i plugins -o cracked -v");
        System.out.println("\nSupported protection methods:");
        System.out.println("  • AES, DES, 3DES, RSA, and Blowfish encryption");
        System.out.println("  • MD5, SHA-1, SHA-256 hash verification");
        System.out.println("  • Reflection-based license verification");
        System.out.println("  • Byte array encoded license keys");
        System.out.println("  • Base64 encoded verification data");
        System.out.println("  • String obfuscation and control flow manipulation");
        System.out.println("  • Remote web API verification");
    }
}