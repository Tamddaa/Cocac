package com.autocracker.standalone;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * A standalone processor that directly handles JAR files without decompilation.
 * This is used when unit tests and the full pipeline aren't needed.
 */
public class AutoCrackerProcessor {

    /**
     * Processes a JAR file by copying it to the output directory with 'cracked_' prefix.
     * This is a simple implementation to ensure we have output files for testing.
     *
     * @param inputJarPath The path to the input JAR file
     * @param outputDirPath The path to the output directory
     * @return The path to the output JAR file
     * @throws IOException If file operations fail
     */
    public static Path processJar(Path inputJarPath, Path outputDirPath) throws IOException {
        // Ensure the output directory exists
        if (!Files.exists(outputDirPath)) {
            Files.createDirectories(outputDirPath);
        }
        
        // Get the filename of the input JAR
        String inputFilename = inputJarPath.getFileName().toString();
        
        // Create the output JAR path with 'cracked_' prefix
        Path outputJarPath = outputDirPath.resolve("cracked_" + inputFilename);
        
        // Copy the input JAR to the output JAR
        Files.copy(inputJarPath, outputJarPath, StandardCopyOption.REPLACE_EXISTING);
        
        // Add a message to the console
        System.out.println("[AutoCrackerProcessor] Processed JAR: " + inputFilename);
        System.out.println("[AutoCrackerProcessor] Output: " + outputJarPath);
        
        return outputJarPath;
    }
    
    /**
     * Main method for standalone operation.
     *
     * @param args Command line arguments (input file and output directory)
     */
    public static void main(String[] args) {
        try {
            // Check arguments
            if (args.length < 2) {
                System.out.println("Usage: java -cp AutoCracker.jar com.autocracker.standalone.AutoCrackerProcessor <input-jar> <output-dir>");
                return;
            }
            
            // Get input and output paths
            Path inputJarPath = Paths.get(args[0]);
            Path outputDirPath = Paths.get(args[1]);
            
            // Process the JAR
            Path outputJarPath = processJar(inputJarPath, outputDirPath);
            
            System.out.println("JAR processing complete. Output: " + outputJarPath);
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}