package com.autocracker.ui;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.io.Console;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 * Premium VIP interface for enterprise customers.
 * Provides advanced UI elements and interactive user experience.
 */
public class PremiumVIPInterface {
    private static final Logger logger = LoggerManager.getLogger(PremiumVIPInterface.class);
    
    // Constants for display
    private static final String PRODUCT_NAME = "AutoCracker";
    private static final String VERSION = "3.5.0";
    private static final String EDITION = "Premium Enterprise";

    /**
     * Displays the premium splash screen
     */
    public static void showSplashScreen() {
        try {
            clearScreen();
            
            // Logo animation
            String[] logoFrames = {
                "   █████╗ ██╗   ██╗████████╗ ██████╗  ██████╗██████╗  █████╗  ██████╗██╗  ██╗███████╗██████╗ ",
                "  ██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗",
                "  ███████║██║   ██║   ██║   ██║   ██║██║     ██████╔╝███████║██║     █████╔╝ █████╗  ██████╔╝",
                "  ██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██╗██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗",
                "  ██║  ██║╚██████╔╝   ██║   ╚██████╔╝╚██████╗██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║",
                "  ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝"
            };
            
            // Colorize and animate the logo
            for (String line : logoFrames) {
                System.out.println(AdvancedConsoleFormatter.BG_BLUE + 
                                 AdvancedConsoleFormatter.WHITE + 
                                 line + 
                                 AdvancedConsoleFormatter.RESET);
                TimeUnit.MILLISECONDS.sleep(100);
            }
            
            // Display premium version info
            System.out.println();
            System.out.println(AdvancedConsoleFormatter.BRIGHT_YELLOW + 
                             "                       PREMIUM ENTERPRISE EDITION V" + VERSION + 
                             AdvancedConsoleFormatter.RESET);
            System.out.println(AdvancedConsoleFormatter.BG_RED + 
                             AdvancedConsoleFormatter.WHITE + 
                             "  🔓 ULTRA ENCRYPTION EDITION - MAXIMUM POWER FULL ACCESS UNLOCKED 🔓  " + 
                             AdvancedConsoleFormatter.RESET);
            
            // Display feature list with typing effect
            System.out.println();
            String features = "〔 AES ⬤ DES ⬤ 3DES ⬤ RSA ⬤ BLOWFISH ⬤ REFLECTION ⬤ BYTE ARRAYS 〕";
            typeWithEffect(AdvancedConsoleFormatter.LIGHT_MAGENTA + "    " + features + AdvancedConsoleFormatter.RESET, 5);
            
            System.out.println();
            System.out.println(AdvancedConsoleFormatter.UNDERLINE + 
                             AdvancedConsoleFormatter.LIGHT_CYAN + 
                             "         © AUTOCRACKER CORPORATION 2025 - ALL RIGHTS RESERVED        " + 
                             AdvancedConsoleFormatter.RESET);
            
            // Loading animation
            System.out.println();
            System.out.print(AdvancedConsoleFormatter.BRIGHT_BLUE + "Initializing premium modules... " + AdvancedConsoleFormatter.RESET);
            
            for (int i = 0; i <= 100; i += 10) {
                System.out.print("\r" + AdvancedConsoleFormatter.BRIGHT_BLUE + 
                               "Initializing premium modules... " + 
                               AdvancedConsoleFormatter.createProgressBar(i, 20) + 
                               AdvancedConsoleFormatter.RESET);
                TimeUnit.MILLISECONDS.sleep(100);
            }
            System.out.println("\n");
            
            // Final message
            System.out.println(AdvancedConsoleFormatter.createPremiumBox(
                             AdvancedConsoleFormatter.BRIGHT_GREEN + "SYSTEM READY" + 
                             AdvancedConsoleFormatter.RESET));
            
            TimeUnit.SECONDS.sleep(1);
            
        } catch (InterruptedException e) {
            logger.error("Error in splash screen animation: {}", e.getMessage());
        }
    }
    
    /**
     * Simulates typing effect for text
     * 
     * @param text Text to display with typing effect
     * @param speed Speed of typing (higher = faster)
     */
    private static void typeWithEffect(String text, int speed) {
        try {
            for (char c : text.toCharArray()) {
                System.out.print(c);
                TimeUnit.MILLISECONDS.sleep(1000 / speed);
            }
            System.out.println();
        } catch (InterruptedException e) {
            System.out.println(text);
        }
    }
    
    /**
     * Clears the console screen
     */
    public static void clearScreen() {
        try {
            final String os = System.getProperty("os.name");
            
            if (os.contains("Windows")) {
                // For Windows
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                // For Unix/Linux/Mac
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Fallback if clearing fails
            for (int i = 0; i < 50; i++) {
                System.out.println();
            }
        }
    }
    
    /**
     * Displays a premium menu with options
     * 
     * @param title Menu title
     * @param options Array of menu options
     * @return Selected option index (0-based)
     */
    public static int showMenu(String title, String[] options) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println(AdvancedConsoleFormatter.formatTitle(title));
        
        for (int i = 0; i < options.length; i++) {
            System.out.println(AdvancedConsoleFormatter.BRIGHT_CYAN + " [" + (i + 1) + "] " + 
                             AdvancedConsoleFormatter.BRIGHT_WHITE + options[i] + 
                             AdvancedConsoleFormatter.RESET);
        }
        
        System.out.println(AdvancedConsoleFormatter.createSeparator());
        
        int selection = -1;
        while (selection < 0 || selection >= options.length) {
            System.out.print(AdvancedConsoleFormatter.BRIGHT_YELLOW + "\n▶ " + 
                           AdvancedConsoleFormatter.RESET + "Select an option (1-" + options.length + "): ");
            
            try {
                int input = scanner.nextInt();
                selection = input - 1;
                
                if (selection < 0 || selection >= options.length) {
                    System.out.println(AdvancedConsoleFormatter.formatError("Invalid option. Please try again."));
                }
            } catch (Exception e) {
                System.out.println(AdvancedConsoleFormatter.formatError("Please enter a valid number."));
                scanner.nextLine(); // Clear buffer
            }
        }
        
        return selection;
    }
    
    /**
     * Displays a progress indicator with animation for long-running operations
     * 
     * @param message Progress message
     * @param durationMillis Duration of the operation in milliseconds
     * @param steps Number of steps to display
     */
    public static void showProgressIndicator(String message, long durationMillis, int steps) {
        long stepTime = durationMillis / steps;
        
        try {
            for (int i = 0; i <= steps; i++) {
                int percentage = (i * 100) / steps;
                System.out.print("\r" + message + " " + 
                               AdvancedConsoleFormatter.createProgressBar(percentage, 20));
                
                TimeUnit.MILLISECONDS.sleep(stepTime);
            }
            System.out.println();
            
        } catch (InterruptedException e) {
            logger.error("Progress animation interrupted: {}", e.getMessage());
        }
    }
    
    /**
     * Shows a premium confirmation dialog
     * 
     * @param message Confirmation message
     * @return true if confirmed, false otherwise
     */
    public static boolean showConfirmation(String message) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println(AdvancedConsoleFormatter.createPremiumBox(message));
        System.out.print(AdvancedConsoleFormatter.BRIGHT_YELLOW + "Confirm? (Y/N): " + AdvancedConsoleFormatter.RESET);
        
        String input = scanner.nextLine().trim().toLowerCase();
        return input.equals("y") || input.equals("yes");
    }
}