package com.autocracker.ui;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Advanced console formatter for premium enterprise edition.
 * Provides rich text formatting for console output with color and styling.
 */
public class AdvancedConsoleFormatter {
    private static final Logger logger = LoggerManager.getLogger(AdvancedConsoleFormatter.class);

    // ANSI color codes
    public static final String RESET = "\u001B[0m";
    public static final String BLACK = "\u001B[30m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE = "\u001B[34m";
    public static final String PURPLE = "\u001B[35m";
    public static final String CYAN = "\u001B[36m";
    public static final String WHITE = "\u001B[37m";

    // Bright colors
    public static final String BRIGHT_BLACK = "\u001B[90m";
    public static final String BRIGHT_RED = "\u001B[91m";
    public static final String BRIGHT_GREEN = "\u001B[92m";
    public static final String BRIGHT_YELLOW = "\u001B[93m";
    public static final String BRIGHT_BLUE = "\u001B[94m";
    public static final String BRIGHT_PURPLE = "\u001B[95m";
    public static final String BRIGHT_CYAN = "\u001B[96m";
    public static final String BRIGHT_WHITE = "\u001B[97m";
    
    // Light colors (aliases for bright colors)
    public static final String LIGHT_RED = BRIGHT_RED;
    public static final String LIGHT_GREEN = BRIGHT_GREEN;
    public static final String LIGHT_YELLOW = BRIGHT_YELLOW;
    public static final String LIGHT_BLUE = BRIGHT_BLUE;
    public static final String LIGHT_MAGENTA = BRIGHT_PURPLE;
    public static final String LIGHT_CYAN = BRIGHT_CYAN;
    public static final String LIGHT_WHITE = BRIGHT_WHITE;

    // Background colors
    public static final String BG_BLACK = "\u001B[40m";
    public static final String BG_RED = "\u001B[41m";
    public static final String BG_GREEN = "\u001B[42m";
    public static final String BG_YELLOW = "\u001B[43m";
    public static final String BG_BLUE = "\u001B[44m";
    public static final String BG_PURPLE = "\u001B[45m";
    public static final String BG_CYAN = "\u001B[46m";
    public static final String BG_WHITE = "\u001B[47m";

    // Styling
    public static final String BOLD = "\u001B[1m";
    public static final String UNDERLINE = "\u001B[4m";
    public static final String BLINK = "\u001B[5m";
    public static final String REVERSE = "\u001B[7m";
    public static final String HIDDEN = "\u001B[8m";

    // Premade UI elements
    private static final String HEADER_LINE = BRIGHT_CYAN + "══════════════════════════════════════════════════════════════" + RESET;
    private static final String SEPARATOR_LINE = BRIGHT_PURPLE + "──────────────────────────────────────────────────────────────" + RESET;
    
    /**
     * Prints a premium-styled license header
     */
    public static void printPremiumHeader() {
        System.out.println();
        System.out.println(BG_BLUE + WHITE + "                                                                  " + RESET);
        System.out.println(BG_BLUE + WHITE + "         AUTOCRACKER PREMIUM ENTERPRISE EDITION v3.5.0           " + RESET);
        System.out.println(BG_BLUE + WHITE + "                  ULTRA ENCRYPTION EDITION                       " + RESET);
        System.out.println(BG_BLUE + WHITE + "                                                                  " + RESET);
        System.out.println();
        System.out.println(BRIGHT_GREEN + "  License Status: " + BOLD + "ENTERPRISE" + RESET);
        System.out.println(BRIGHT_YELLOW + "  License Key: " + BOLD + "XXXX-XXXX-XXXX-XXXX-" + BRIGHT_CYAN + "PREMIUM" + RESET);
        System.out.println(BRIGHT_BLUE + "  Registered to: " + BOLD + "VIP User" + RESET);
        System.out.println(BRIGHT_PURPLE + "  Activation Date: " + BOLD + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + RESET);
        System.out.println();
    }
    
    /**
     * Formats a section title
     * 
     * @param title Title text
     * @return Formatted title
     */
    public static String formatTitle(String title) {
        return "\n" + BG_BLUE + WHITE + " " + title + " " + RESET + "\n" + HEADER_LINE;
    }
    
    /**
     * Formats a section subtitle
     * 
     * @param subtitle Subtitle text
     * @return Formatted subtitle
     */
    public static String formatSubtitle(String subtitle) {
        return BRIGHT_YELLOW + "► " + BRIGHT_WHITE + subtitle + RESET;
    }
    
    /**
     * Formats a success message
     * 
     * @param message Success message
     * @return Formatted success message
     */
    public static String formatSuccess(String message) {
        return BRIGHT_GREEN + "✓ " + GREEN + message + RESET;
    }
    
    /**
     * Formats an error message
     * 
     * @param message Error message
     * @return Formatted error message
     */
    public static String formatError(String message) {
        return BRIGHT_RED + "✗ " + RED + message + RESET;
    }
    
    /**
     * Formats a warning message
     * 
     * @param message Warning message
     * @return Formatted warning message
     */
    public static String formatWarning(String message) {
        return BRIGHT_YELLOW + "⚠ " + YELLOW + message + RESET;
    }
    
    /**
     * Formats an info message
     * 
     * @param message Info message
     * @return Formatted info message
     */
    public static String formatInfo(String message) {
        return BRIGHT_BLUE + "ℹ " + BLUE + message + RESET;
    }
    
    /**
     * Creates a premium progress bar
     * 
     * @param progress Progress percentage (0-100)
     * @param length Length of the progress bar
     * @return Formatted progress bar
     */
    public static String createProgressBar(int progress, int length) {
        if (progress < 0) progress = 0;
        if (progress > 100) progress = 100;
        
        int completed = (int) Math.round(progress * length / 100.0);
        int remaining = length - completed;
        
        StringBuilder bar = new StringBuilder();
        bar.append(BRIGHT_CYAN + "[" + RESET);
        
        // Add completed portion
        if (completed > 0) {
            bar.append(BRIGHT_GREEN);
            for (int i = 0; i < completed; i++) {
                bar.append("■");
            }
            bar.append(RESET);
        }
        
        // Add remaining portion
        if (remaining > 0) {
            bar.append(BRIGHT_BLACK);
            for (int i = 0; i < remaining; i++) {
                bar.append("□");
            }
            bar.append(RESET);
        }
        
        bar.append(BRIGHT_CYAN + "] " + BRIGHT_WHITE + progress + "%" + RESET);
        
        return bar.toString();
    }
    
    /**
     * Creates a separator line
     * 
     * @return Formatted separator line
     */
    public static String createSeparator() {
        return SEPARATOR_LINE;
    }
    
    /**
     * Creates a premium box for important messages
     * 
     * @param message Message to display in the box
     * @return Formatted box with message
     */
    public static String createPremiumBox(String message) {
        StringBuilder box = new StringBuilder();
        
        // Calculate width (accounting for potential ANSI codes)
        String plainMessage = message.replaceAll("\u001B\\[[0-9;]*[a-zA-Z]", "");
        int width = Math.max(plainMessage.length() + 4, 50);
        
        // Create top border
        box.append(BRIGHT_CYAN + "┌");
        for (int i = 0; i < width - 2; i++) {
            box.append("─");
        }
        box.append("┐" + RESET + "\n");
        
        // Add message with padding
        box.append(BRIGHT_CYAN + "│" + RESET + " " + BRIGHT_WHITE + message + RESET);
        
        // Calculate remaining spaces for right border alignment
        int padding = width - plainMessage.length() - 3;
        for (int i = 0; i < padding; i++) {
            box.append(" ");
        }
        box.append(BRIGHT_CYAN + "│" + RESET + "\n");
        
        // Create bottom border
        box.append(BRIGHT_CYAN + "└");
        for (int i = 0; i < width - 2; i++) {
            box.append("─");
        }
        box.append("┘" + RESET);
        
        return box.toString();
    }
}