package com.autocracker.ui;

import com.autocracker.module.LoggerManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;

/**
 * Premium Enterprise license manager for AutoCracker.
 * Manages license validation, storage, and retrieval for professional users.
 */
public class EnterpriseLicenseManager {
    private static final Logger logger = LoggerManager.getLogger(EnterpriseLicenseManager.class);
    
    // License constants
    private static final String LICENSE_FILE = ".license.dat";
    private static final String LICENSE_VERSION = "3.5.0";
    private static final String LICENSE_TYPE = "ENTERPRISE";
    
    // License storage
    private static Properties licenseData = new Properties();
    
    /**
     * License information for the premium version
     */
    public static class LicenseInfo {
        private String licenseKey;
        private String licenseType;
        private String userName;
        private String companyName;
        private Date activationDate;
        private Date expirationDate;
        private boolean valid;
        
        public LicenseInfo() {
            this.licenseKey = "";
            this.licenseType = "";
            this.userName = "";
            this.companyName = "";
            this.activationDate = new Date();
            this.expirationDate = new Date();
            this.valid = false;
        }
        
        public String getLicenseKey() {
            return licenseKey;
        }
        
        public void setLicenseKey(String licenseKey) {
            this.licenseKey = licenseKey;
        }
        
        public String getLicenseType() {
            return licenseType;
        }
        
        public void setLicenseType(String licenseType) {
            this.licenseType = licenseType;
        }
        
        public String getUserName() {
            return userName;
        }
        
        public void setUserName(String userName) {
            this.userName = userName;
        }
        
        public String getCompanyName() {
            return companyName;
        }
        
        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }
        
        public Date getActivationDate() {
            return activationDate;
        }
        
        public void setActivationDate(Date activationDate) {
            this.activationDate = activationDate;
        }
        
        public Date getExpirationDate() {
            return expirationDate;
        }
        
        public void setExpirationDate(Date expirationDate) {
            this.expirationDate = expirationDate;
        }
        
        public boolean isValid() {
            return valid;
        }
        
        public void setValid(boolean valid) {
            this.valid = valid;
        }
        
        @Override
        public String toString() {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            return "License Key: " + licenseKey +
                   "\nLicense Type: " + licenseType +
                   "\nRegistered To: " + userName +
                   (companyName.isEmpty() ? "" : "\nCompany: " + companyName) +
                   "\nActivation Date: " + dateFormat.format(activationDate) +
                   "\nExpiration Date: " + dateFormat.format(expirationDate) +
                   "\nStatus: " + (valid ? "Valid" : "Invalid");
        }
    }
    
    /**
     * Initializes the license manager and loads any existing license
     */
    public static void initialize() {
        try {
            File licenseFile = new File(LICENSE_FILE);
            
            if (licenseFile.exists()) {
                licenseData.load(new FileInputStream(licenseFile));
                logger.debug("License data loaded from file");
            } else {
                // Generate and save a demo license for the premium version
                generateDemoLicense();
                logger.debug("Generated demo license for premium version");
            }
        } catch (Exception e) {
            logger.error("Error initializing license manager: {}", e.getMessage());
            generateDemoLicense();
        }
    }
    
    /**
     * Generates a demo license for the premium version
     */
    private static void generateDemoLicense() {
        try {
            // Generate a unique license key with format XXXX-XXXX-XXXX-XXXX-PREM
            String licenseKey = generateLicenseKey();
            
            // Set license properties
            licenseData.setProperty("license.key", licenseKey);
            licenseData.setProperty("license.type", LICENSE_TYPE);
            licenseData.setProperty("license.version", LICENSE_VERSION);
            licenseData.setProperty("license.user", "Premium VIP User");
            licenseData.setProperty("license.company", "");
            
            // Set dates
            Date now = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            licenseData.setProperty("license.activation", dateFormat.format(now));
            
            // Set expiration to 10 years from now
            Date expiration = new Date(now.getTime() + 10L * 365 * 24 * 60 * 60 * 1000);
            licenseData.setProperty("license.expiration", dateFormat.format(expiration));
            
            // Set validation hash
            String validationData = licenseKey + LICENSE_TYPE + LICENSE_VERSION + dateFormat.format(expiration);
            String validationHash = generateValidationHash(validationData);
            licenseData.setProperty("license.validation", validationHash);
            
            // Save license to file
            licenseData.store(new FileOutputStream(LICENSE_FILE), "AutoCracker Premium License");
            
        } catch (Exception e) {
            logger.error("Error generating demo license: {}", e.getMessage());
        }
    }
    
    /**
     * Generates a unique license key with format XXXX-XXXX-XXXX-XXXX-PREM
     * 
     * @return Generated license key
     */
    private static String generateLicenseKey() {
        String uuid = UUID.randomUUID().toString().replace("-", "").toUpperCase();
        
        StringBuilder key = new StringBuilder();
        key.append(uuid.substring(0, 4)).append("-");
        key.append(uuid.substring(4, 8)).append("-");
        key.append(uuid.substring(8, 12)).append("-");
        key.append(uuid.substring(12, 16)).append("-");
        key.append("PREM");
        
        return key.toString();
    }
    
    /**
     * Generates a validation hash for license integrity
     * 
     * @param data Data to hash
     * @return Hashed validation string
     */
    private static String generateValidationHash(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            logger.error("Error generating validation hash: {}", e.getMessage());
            return "";
        }
    }
    
    /**
     * Gets the current license information
     * 
     * @return License information
     */
    public static LicenseInfo getLicenseInfo() {
        LicenseInfo info = new LicenseInfo();
        
        try {
            // Ensure license data is loaded
            if (licenseData.isEmpty()) {
                initialize();
            }
            
            // Extract license info
            info.setLicenseKey(licenseData.getProperty("license.key", ""));
            info.setLicenseType(licenseData.getProperty("license.type", ""));
            info.setUserName(licenseData.getProperty("license.user", ""));
            info.setCompanyName(licenseData.getProperty("license.company", ""));
            
            // Parse dates
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            try {
                info.setActivationDate(dateFormat.parse(licenseData.getProperty("license.activation", "")));
                info.setExpirationDate(dateFormat.parse(licenseData.getProperty("license.expiration", "")));
            } catch (Exception e) {
                logger.error("Error parsing license dates: {}", e.getMessage());
            }
            
            // Validate license
            info.setValid(validateLicense(info));
            
        } catch (Exception e) {
            logger.error("Error retrieving license info: {}", e.getMessage());
        }
        
        return info;
    }
    
    /**
     * Validates the license integrity and expiration
     * 
     * @param info License information to validate
     * @return true if license is valid, false otherwise
     */
    private static boolean validateLicense(LicenseInfo info) {
        try {
            // Check if license has expired
            Date now = new Date();
            if (info.getExpirationDate().before(now)) {
                logger.warn("License has expired");
                return false;
            }
            
            // Verify license type
            if (!info.getLicenseType().equals(LICENSE_TYPE)) {
                logger.warn("Invalid license type: {}", info.getLicenseType());
                return false;
            }
            
            // Check validation hash
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String validationData = info.getLicenseKey() + info.getLicenseType() + 
                                  LICENSE_VERSION + dateFormat.format(info.getExpirationDate());
            String expectedHash = generateValidationHash(validationData);
            String actualHash = licenseData.getProperty("license.validation", "");
            
            if (!expectedHash.equals(actualHash)) {
                logger.warn("License validation hash mismatch");
                return false;
            }
            
            return true;
            
        } catch (Exception e) {
            logger.error("Error validating license: {}", e.getMessage());
            return false;
        }
    }
    
    /**
     * Displays license information in a premium formatted box
     */
    public static void displayLicenseInfo() {
        LicenseInfo info = getLicenseInfo();
        
        System.out.println(AdvancedConsoleFormatter.formatTitle("LICENSE INFORMATION"));
        
        System.out.println(AdvancedConsoleFormatter.BRIGHT_GREEN + "  License Status: " + 
                         AdvancedConsoleFormatter.BOLD + 
                         (info.isValid() ? "VALID" : "INVALID") + 
                         AdvancedConsoleFormatter.RESET);
        
        System.out.println(AdvancedConsoleFormatter.BRIGHT_YELLOW + "  License Key: " + 
                         AdvancedConsoleFormatter.BOLD + 
                         info.getLicenseKey() + 
                         AdvancedConsoleFormatter.RESET);
        
        System.out.println(AdvancedConsoleFormatter.BRIGHT_BLUE + "  License Type: " + 
                         AdvancedConsoleFormatter.BOLD + 
                         info.getLicenseType() + 
                         AdvancedConsoleFormatter.RESET);
        
        System.out.println(AdvancedConsoleFormatter.BRIGHT_PURPLE + "  Registered To: " + 
                         AdvancedConsoleFormatter.BOLD + 
                         info.getUserName() + 
                         AdvancedConsoleFormatter.RESET);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        System.out.println(AdvancedConsoleFormatter.BRIGHT_CYAN + "  Activation Date: " + 
                         AdvancedConsoleFormatter.BOLD + 
                         dateFormat.format(info.getActivationDate()) + 
                         AdvancedConsoleFormatter.RESET);
        
        System.out.println(AdvancedConsoleFormatter.BRIGHT_RED + "  Expiration Date: " + 
                         AdvancedConsoleFormatter.BOLD + 
                         dateFormat.format(info.getExpirationDate()) + 
                         AdvancedConsoleFormatter.RESET);
        
        System.out.println();
        
        if (!info.isValid()) {
            System.out.println(AdvancedConsoleFormatter.createPremiumBox(
                             AdvancedConsoleFormatter.BRIGHT_RED + 
                             "WARNING: Your license is invalid or has expired!" + 
                             AdvancedConsoleFormatter.RESET));
        }
    }
}