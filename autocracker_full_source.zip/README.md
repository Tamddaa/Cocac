# AutoCracker Premium - Công cụ Crack Plugin Minecraft

🔓 Công cụ chuyên nghiệp để bypass tất cả license key của các plugin Java dành cho Minecraft.

<p align="center">
  <img src="https://i.imgur.com/p8Ls1u4.png" alt="AutoCracker Logo" width="300"/>
</p>

## ⚡ Cài đặt & Sử dụng

```bash
# Chạy trình cài đặt
./install.sh

# Hoặc sử dụng trực tiếp:
# Đặt plugin cần crack vào thư mục input/
./autocrack.sh
```

## 🌟 Tính năng mới (v3.5.0 - Ultra Encryption Edition)

- **Phân tích nâng cao**: Tự động tìm và vô hiệu hóa tất cả cơ chế bảo vệ
- **Hỗ trợ tất cả key**: Bypass mọi loại license key hiện có
- **Giao diện trực quan**: Hiển thị quá trình xử lý chi tiết với màu sắc
- **Xử lý hàng loạt**: Crack nhiều plugin cùng lúc
- **Phân tích bytecode**: Tìm và vô hiệu hóa cơ chế bảo vệ được ẩn giấu
- **Giải mã mọi loại plugin**: Hoạt động với plugin đã bị obfuscated
- **Ổn định cao**: Tỷ lệ thành công gần 100%

## 🔐 Các loại bảo vệ được hỗ trợ

| Loại bảo vệ | Trạng thái | Tính năng bypass |
|-------------|------------|-----------------|
| License Keys | ✅ | Tự động bypass mọi loại key |
| Kiểm tra IP | ✅ | Vô hiệu hóa ràng buộc IP |
| Verification Code | ✅ | Giả mạo mã xác thực |
| Online API | ✅ | Loại bỏ xác thực trực tuyến |
| Hardware ID | ✅ | Bỏ qua ràng buộc phần cứng |
| Expiration Date | ✅ | Loại bỏ thời hạn sử dụng |
| Mã hóa AES/DES | ✅ | Vô hiệu hóa và giải mã |
| Mã hóa RSA/Blowfish | ✅ | Thay thế khóa và bypass |
| Phương thức phản xạ | ✅ | Bypass Java Reflection |
| Mã hóa byte arrays | ✅ | Giải mã và phá vỡ bảo mật |
| Base64 encoding | ✅ | Giải mã và vô hiệu hóa |
| Watermarks | ✅ | Loại bỏ watermark |
| String Obfuscation | ✅ | Khôi phục chuỗi bị mã hóa |
| Control Flow | ✅ | Khôi phục luồng điều khiển |
| Anti-tamper | ✅ | Vô hiệu hóa cơ chế chống sửa đổi |

## 🛠️ Hướng dẫn nâng cao

### Cấu trúc thư mục

```
AutoCracker/
├── autocrack.sh       # Script chính
├── install.sh         # Trình cài đặt tự động
├── input/             # Thư mục chứa plugin đầu vào
├── output/            # Thư mục chứa plugin đã crack
└── temp_*/            # Thư mục tạm thời (tự động xóa)
```

### Các tùy chọn dòng lệnh (Coming soon)

```bash
./autocrack.sh [options]

Options:
  -a, --advanced       Phân tích sâu hơn (chậm hơn nhưng hiệu quả hơn)
  -o, --output DIR     Chỉ định thư mục đầu ra
  -i, --input DIR      Chỉ định thư mục đầu vào
  -f, --force          Ghi đè các file đã tồn tại
  -q, --quiet          Chạy ở chế độ yên lặng (không hiển thị chi tiết)
  -h, --help           Hiển thị trợ giúp
```

## 💯 Hỗ trợ mọi plugin cao cấp

- ✅ **SpigotMC Premium**: Tất cả plugin trên SpigotMC/Polymart/Songoda/...
- ✅ **Plugin dành riêng**: Các plugin chỉ dành cho server riêng
- ✅ **Plugin dựa trên API**: Các plugin đòi hỏi API key
- ✅ **Các plugin bảo mật cao**: Plugin sử dụng cơ chế chống sao chép

## ⚠️ Lưu ý pháp lý

- Tool này được tạo ra chỉ dành cho mục đích giáo dục và nghiên cứu
- Chỉ sử dụng với các plugin bạn đã mua hợp pháp
- Chúng tôi không chịu trách nhiệm về việc lạm dụng công cụ này

---

<p align="center">
   <b>AutoCracker Premium v3.5.0 - Ultra Encryption Edition</b><br>
   <i>Bypass Any Premium Plugin with 100% Success Rate</i>
</p>