#!/bin/bash

# Định nghĩa màu sắc
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

echo -e "${BOLD}${BLUE}=================================================${NC}"
echo -e "${BOLD}${BLUE}   AutoCracker Premium - Trình cài đặt tự động   ${NC}"
echo -e "${BOLD}${BLUE}=================================================${NC}"
echo

# Kiểm tra quyền root
if [ "$(id -u)" -eq 0 ]; then
    echo -e "${YELLOW}Bạn đang chạy script với quyền root. Điều này là không cần thiết và có thể gây ra vấn đề về phân quyền.${NC}"
    echo -e "${YELLOW}Tiếp tục quá trình cài đặt...${NC}"
fi

# Kiểm tra hệ điều hành
echo -e "${CYAN}▶ Kiểm tra hệ điều hành...${NC}"
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
    echo -e "  ✓ Đã phát hiện: ${OS} ${VER}"
else
    OS=$(uname -s)
    VER=$(uname -r)
    echo -e "  ✓ Đã phát hiện: ${OS} ${VER}"
fi

# Kiểm tra và cài đặt các gói cần thiết
echo -e "\n${CYAN}▶ Kiểm tra các gói phụ thuộc...${NC}"
MISSING_PACKAGES=()

# Kiểm tra Java
if ! command -v java >/dev/null 2>&1; then
    echo -e "  ⚠ Java chưa được cài đặt"
    MISSING_PACKAGES+=("default-jdk")
else
    java_version=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2)
    echo -e "  ✓ Java ${java_version} đã được cài đặt"
fi

# Kiểm tra unzip
if ! command -v unzip >/dev/null 2>&1; then
    echo -e "  ⚠ unzip chưa được cài đặt"
    MISSING_PACKAGES+=("unzip")
else
    echo -e "  ✓ unzip đã được cài đặt"
fi

# Kiểm tra grep
if ! command -v grep >/dev/null 2>&1; then
    echo -e "  ⚠ grep chưa được cài đặt"
    MISSING_PACKAGES+=("grep")
else
    echo -e "  ✓ grep đã được cài đặt"
fi

# Cài đặt các gói còn thiếu
if [ ${#MISSING_PACKAGES[@]} -gt 0 ]; then
    echo -e "\n${CYAN}▶ Cài đặt các gói còn thiếu...${NC}"
    
    # Xác định trình quản lý gói
    if command -v apt >/dev/null 2>&1; then
        PKG_MANAGER="apt"
    elif command -v dnf >/dev/null 2>&1; then
        PKG_MANAGER="dnf"
    elif command -v yum >/dev/null 2>&1; then
        PKG_MANAGER="yum"
    elif command -v pacman >/dev/null 2>&1; then
        PKG_MANAGER="pacman -S"
    elif command -v zypper >/dev/null 2>&1; then
        PKG_MANAGER="zypper install"
    elif command -v brew >/dev/null 2>&1; then
        PKG_MANAGER="brew"
    else
        echo -e "${RED}Không tìm thấy trình quản lý gói được hỗ trợ. Vui lòng cài đặt thủ công các gói sau: ${MISSING_PACKAGES[*]}${NC}"
        read -p "Nhấn Enter để tiếp tục..." dummy
    fi
    
    # Cài đặt các gói thiếu
    if [ -n "$PKG_MANAGER" ]; then
        echo -e "  ⚙ Đang cài đặt: ${MISSING_PACKAGES[*]}"
        sudo $PKG_MANAGER update -y >/dev/null 2>&1
        sudo $PKG_MANAGER install -y ${MISSING_PACKAGES[@]} || {
            echo -e "${RED}Lỗi khi cài đặt các gói. Vui lòng cài đặt thủ công: ${MISSING_PACKAGES[*]}${NC}"
            read -p "Nhấn Enter để tiếp tục..." dummy
        }
    fi
fi

# Kiểm tra lại sau khi cài đặt
echo -e "\n${CYAN}▶ Kiểm tra lại cài đặt...${NC}"
ALL_INSTALLED=true

if ! command -v java >/dev/null 2>&1; then
    echo -e "  ${RED}✗ Java vẫn chưa được cài đặt${NC}"
    ALL_INSTALLED=false
else
    echo -e "  ${GREEN}✓ Java đã sẵn sàng${NC}"
fi

if ! command -v unzip >/dev/null 2>&1; then
    echo -e "  ${RED}✗ unzip vẫn chưa được cài đặt${NC}"
    ALL_INSTALLED=false
else
    echo -e "  ${GREEN}✓ unzip đã sẵn sàng${NC}"
fi

if ! command -v grep >/dev/null 2>&1; then
    echo -e "  ${RED}✗ grep vẫn chưa được cài đặt${NC}"
    ALL_INSTALLED=false
else
    echo -e "  ${GREEN}✓ grep đã sẵn sàng${NC}"
fi

# Nếu có vấn đề với cài đặt
if [ "$ALL_INSTALLED" = false ]; then
    echo -e "\n${YELLOW}⚠ Một số gói phụ thuộc vẫn chưa được cài đặt. Điều này có thể sẽ gây lỗi khi chạy AutoCracker.${NC}"
    echo -e "${YELLOW}⚠ Vui lòng cài đặt thủ công các gói còn thiếu.${NC}"
    echo -e "${YELLOW}⚠ Tiếp tục quá trình cài đặt...${NC}"
fi

# Tạo cấu trúc thư mục
echo -e "\n${CYAN}▶ Chuẩn bị cấu trúc thư mục...${NC}"
mkdir -p input output logs
echo -e "  ${GREEN}✓ Đã tạo các thư mục: input, output, logs${NC}"

# Thiết lập quyền thực thi cho script
chmod +x autocrack.sh
echo -e "  ${GREEN}✓ Đã thiết lập quyền thực thi cho autocrack.sh${NC}"

# Tạo plugin mẫu (nếu thư mục input trống)
if [ -z "$(ls -A input)" ]; then
    echo -e "\n${CYAN}▶ Tạo plugin mẫu để thử nghiệm...${NC}"
    echo "name: TestPlugin
version: 1.0.0
main: com.example.TestPlugin
api-version: 1.13
description: Test plugin" > input/plugin.yml
    
    cd input
    jar -cf TestPlugin.jar plugin.yml
    rm plugin.yml
    cd ..
    
    echo -e "  ${GREEN}✓ Đã tạo plugin mẫu: input/TestPlugin.jar${NC}"
else
    echo -e "\n${CYAN}▶ Thư mục input đã có sẵn plugin, không cần tạo plugin mẫu${NC}"
fi

# Kiểm tra cài đặt Maven (không cần thiết nhưng có ích)
if ! command -v mvn >/dev/null 2>&1; then
    echo -e "\n${YELLOW}⚠ Maven chưa được cài đặt.${NC}"
    echo -e "${YELLOW}⚠ Maven không bắt buộc để chạy AutoCracker, nhưng nếu bạn muốn biên dịch lại mã nguồn, bạn sẽ cần cài đặt Maven.${NC}"
else
    mvn_version=$(mvn --version | head -n 1)
    echo -e "\n${CYAN}▶ Maven đã được cài đặt: ${mvn_version}${NC}"
fi

# Tạo alias cho autocrack (tự động)
echo -e "\n${CYAN}▶ Tạo alias cho autocrack...${NC}"
SCRIPT_PATH=$(realpath autocrack.sh 2>/dev/null || echo "$PWD/autocrack.sh")

# Tạo file .autocrack trong thư mục hiện tại để sử dụng nhanh
echo '#!/bin/bash' > .autocrackrc
echo "export AUTOCRACK_PATH=\"$SCRIPT_PATH\"" >> .autocrackrc
echo 'alias autocrack="$AUTOCRACK_PATH"' >> .autocrackrc
chmod +x .autocrackrc

echo -e "  ${GREEN}✓ Đã tạo file .autocrackrc${NC}"
echo -e "  ${BLUE}➤ Để sử dụng alias: source .autocrackrc${NC}"

# Hướng dẫn sử dụng
echo -e "\n${CYAN}▶ Hướng dẫn sử dụng${NC}"
echo -e "  1. Đặt file .jar cần crack vào thư mục 'input/'"
echo -e "  2. Chạy lệnh ./autocrack.sh"
echo -e "  3. Tìm file đã crack trong thư mục 'output/' với tiền tố 'cracked_'"

# Hoàn tất cài đặt
echo -e "\n${GREEN}✅ Cài đặt AutoCracker Premium hoàn tất!${NC}"
echo -e "${BLUE}▶ Chạy ngay: ./autocrack.sh${NC}"
echo -e "${BLUE}▶ Trạng thái: Đã sẵn sàng${NC}"
echo