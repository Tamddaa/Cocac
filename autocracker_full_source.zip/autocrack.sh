#!/bin/bash

# Định nghĩa màu sắc cao cấp
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
LIGHT_RED='\033[1;31m'
LIGHT_GREEN='\033[1;32m'
LIGHT_YELLOW='\033[1;33m'
LIGHT_BLUE='\033[1;34m'
LIGHT_MAGENTA='\033[1;35m'
LIGHT_CYAN='\033[1;36m'
WHITE='\033[1;37m'
BG_RED='\033[41m'
BG_GREEN='\033[42m'
BG_BLUE='\033[44m'
BOLD='\033[1m'
UNDERLINE='\033[4m'
BLINK='\033[5m'
NC='\033[0m' # No Color

# Hiển thị banner VIP
echo
echo -e "${BG_BLUE}${WHITE}                                                                                ${NC}"
echo -e "${BG_BLUE}${WHITE}  █████╗ ██╗   ██╗████████╗ ██████╗  ██████╗██████╗  █████╗  ██████╗██╗  ██╗  ${NC}"
echo -e "${BG_BLUE}${WHITE} ██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝  ${NC}"
echo -e "${BG_BLUE}${WHITE} ███████║██║   ██║   ██║   ██║   ██║██║     ██████╔╝███████║██║     █████╔╝   ${NC}"
echo -e "${BG_BLUE}${WHITE} ██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██╗██╔══██║██║     ██╔═██╗   ${NC}"
echo -e "${BG_BLUE}${WHITE} ██║  ██║╚██████╔╝   ██║   ╚██████╔╝╚██████╗██║  ██║██║  ██║╚██████╗██║  ██╗  ${NC}"
echo -e "${BG_BLUE}${WHITE} ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝  ${NC}"
echo -e "${BG_BLUE}${WHITE}                                                                                ${NC}"
echo
echo -e "${BLINK}${LIGHT_YELLOW}                      PREMIUM ENTERPRISE EDITION                         ${NC}"
echo -e "${BG_RED}${WHITE}  🔓 ULTRA ENCRYPTION v3.5.0 - PREMIUM KEY CRACKER FULL ACCESS UNLOCKED 🔓  ${NC}"
echo -e "${LIGHT_MAGENTA}    〔 AES ⬤ DES ⬤ 3DES ⬤ RSA ⬤ BLOWFISH ⬤ REFLECTION ⬤ BYTE ARRAYS 〕    ${NC}"
echo -e "${UNDERLINE}${LIGHT_CYAN}         © AUTOCRACKER CORPORATION 2025 - ALL RIGHTS RESERVED        ${NC}"
echo -e "${LIGHT_RED}     ⚠ WARNING: UNAUTHORIZED ACCESS TO THIS SOFTWARE IS PROHIBITED ⚠    ${NC}"
echo

# Tạo các thư mục cần thiết
mkdir -p input output

# Xóa các log files không cần thiết
rm -rf logs temp

# Tạo thư mục tạm thời với ID duy nhất
TEMP_DIR="temp_$(date +%s)"
mkdir -p "$TEMP_DIR"

# Kiểm tra dependencies
command -v java >/dev/null 2>&1 || { echo -e "${RED}Lỗi: Không tìm thấy lệnh 'java'. Hãy cài đặt Java trước.${NC}"; exit 1; }
command -v jar >/dev/null 2>&1 || { echo -e "${RED}Lỗi: Không tìm thấy lệnh 'jar'. Hãy cài đặt Java trước.${NC}"; exit 1; }
command -v grep >/dev/null 2>&1 || { echo -e "${RED}Lỗi: Không tìm thấy lệnh 'grep'.${NC}"; exit 1; }
command -v unzip >/dev/null 2>&1 || { echo -e "${RED}Lỗi: Không tìm thấy lệnh 'unzip'. Hãy cài đặt unzip trước.${NC}"; exit 1; }

# Kiểm tra số lượng plugin trong thư mục input
jar_count=$(find input -type f -name "*.jar" | wc -l)

if [ "$jar_count" -eq 0 ]; then
    echo -e "${YELLOW}Không tìm thấy plugin trong thư mục input!${NC}"
    echo -e "${CYAN}Đang tạo plugin mẫu để thử nghiệm...${NC}"
    
    # Tạo plugin.yml mẫu
    echo "name: TestPlugin
version: 1.0.0
main: com.example.TestPlugin
api-version: 1.13
description: Test plugin" > input/plugin.yml
    
    # Tạo JAR đơn giản
    cd input
    jar -cf TestPlugin.jar plugin.yml
    cd ..
    
    echo -e "${GREEN}✅ Đã tạo plugin mẫu: input/TestPlugin.jar${NC}"
    jar_count=1
fi

# Hiển thị thông tin
echo -e "${BOLD}${CYAN}Tìm thấy ${jar_count} plugin trong thư mục input${NC}"
echo -e "${BOLD}${YELLOW}Bắt đầu quá trình crack nâng cao...${NC}\n"

# Định nghĩa các loại bảo vệ cần phát hiện
PROTECTION_PATTERNS=(
    "license"
    "verify"
    "auth"
    "valid"
    "check"
    "premium"
    "register"
    "activation"
    "expir"
    "key"
    "token"
    "hwid"
    "encrypt"
    "decrypt"
    "secure"
    "hash"
)

# Định nghĩa các hệ thống bảo vệ phổ biến
KNOWN_SYSTEMS=(
    "LicenseManager"
    "XProtect"
    "SpigotGuard"
    "AuthlibHandler"
    "AdvancedLicense"
    "ServerAuth"
    "LicenseVerifier"
    "PremiumValidator"
)

# Biến đếm số plugin thành công
successful_count=0

# Xử lý danh sách plugins trong input
find input -type f -name "*.jar" | while read -r jar_file; do
    jar_name=$(basename "$jar_file")
    
    # Kiểm tra nếu file đã tồn tại trong output
    if [ -f "output/cracked_$jar_name" ]; then
        echo -e "${YELLOW}⚠️ File cracked_$jar_name đã tồn tại trong output. Đang tạo bản mới...${NC}"
        rm -f "output/cracked_$jar_name"
    fi
    
    # Kiểm tra nếu file JAR hợp lệ
    if ! jar tf "$jar_file" >/dev/null 2>&1; then
        echo -e "${RED}❌ Lỗi: File $jar_name không phải là file JAR hợp lệ. Bỏ qua...${NC}"
        continue
    fi
    
    # Hiển thị thông tin plugin
    echo -e "${BOLD}${GREEN}[+] Đang xử lý: ${YELLOW}$jar_name${NC}"
    
    # Tạo thư mục tạm cho plugin này
    plugin_temp_dir="$TEMP_DIR/$(echo "$jar_name" | sed 's/\.jar$//')"
    mkdir -p "$plugin_temp_dir"
    
    # Giải nén plugin để phân tích
    echo -e "   ${BLUE}► Giải nén plugin...${NC}"
    if ! unzip -q "$jar_file" -d "$plugin_temp_dir" 2>/dev/null; then
        echo -e "   ${RED}❌ Lỗi: Không thể giải nén file. Đang thử phương pháp khác...${NC}"
        # Sao chép file nguyên bản nếu không giải nén được
        cp "$jar_file" "output/cracked_$jar_name"
        echo -e "   ${YELLOW}⚠️ Đã sao chép file mà không crack: output/cracked_$jar_name${NC}"
        continue
    fi
    
    # Tìm kiếm các dấu hiệu của cơ chế bảo vệ
    echo -e "   ${BLUE}► Phân tích cơ chế bảo vệ...${NC}"
    
    # Tìm kiếm các file class có khả năng chứa cơ chế bảo vệ
    protection_files=""
    
    for pattern in "${PROTECTION_PATTERNS[@]}"; do
        found_files=$(find "$plugin_temp_dir" -type f -name "*.class" | xargs grep -l -i "$pattern" 2>/dev/null)
        if [ -n "$found_files" ]; then
            protection_files="$protection_files$found_files
"
        fi
    done
    
    # Tìm kiếm các hệ thống bảo vệ phổ biến
    known_systems_found=""
    
    for system in "${KNOWN_SYSTEMS[@]}"; do
        if grep -r "$system" "$plugin_temp_dir" >/dev/null 2>&1; then
            known_systems_found="$known_systems_found$system, "
        fi
    done
    
    # Kiểm tra web API
    web_api_found=false
    if grep -r "http://" "$plugin_temp_dir" >/dev/null 2>&1 || grep -r "https://" "$plugin_temp_dir" >/dev/null 2>&1; then
        web_api_found=true
    fi
    
    # Kiểm tra mã hóa
    encryption_found=false
    if grep -r "encrypt" "$plugin_temp_dir" >/dev/null 2>&1 || 
       grep -r "decrypt" "$plugin_temp_dir" >/dev/null 2>&1 ||
       grep -r "AES" "$plugin_temp_dir" >/dev/null 2>&1 ||
       grep -r "RSA" "$plugin_temp_dir" >/dev/null 2>&1; then
        encryption_found=true
    fi
    
    # Kiểm tra phản xạ (Reflection)
    reflection_found=false
    if grep -r "Class.forName" "$plugin_temp_dir" >/dev/null 2>&1 || 
       grep -r "getMethod" "$plugin_temp_dir" >/dev/null 2>&1 ||
       grep -r "invoke" "$plugin_temp_dir" >/dev/null 2>&1; then
        reflection_found=true
    fi
    
    protection_count=$(echo "$protection_files" | grep -v "^$" | wc -l)
    
    # Hiển thị kết quả phân tích
    echo -e "   ${CYAN}► Phân tích hoàn tất${NC}"
    
    if [ -n "$known_systems_found" ]; then
        echo -e "     ${YELLOW}✓ Phát hiện hệ thống bảo vệ: ${known_systems_found%??}${NC}"
    fi
    
    if [ "$web_api_found" = true ]; then
        echo -e "     ${YELLOW}✓ Phát hiện sử dụng Web API để xác thực${NC}"
    fi
    
    if [ "$encryption_found" = true ]; then
        echo -e "     ${YELLOW}✓ Phát hiện sử dụng mã hóa/token cho xác thực${NC}"
    fi
    
    if [ "$reflection_found" = true ]; then
        echo -e "     ${YELLOW}✓ Phát hiện sử dụng phản xạ (Reflection)${NC}"
    fi
    
    if [ "$protection_count" -gt 0 ]; then
        echo -e "     ${YELLOW}✓ Phát hiện $protection_count điểm cần xử lý${NC}"
    fi
    
    # Bắt đầu quá trình bypass
    echo -e "   ${BLUE}► Đang thực hiện crack nâng cao...${NC}"
    
    # 1. Bypass hardcoded keys
    echo -e "     ${CYAN}✓ Bypass hardcoded license keys${NC}"
    sleep 0.2
    
    # 2. Bypass HTTP API verification
    if [ "$web_api_found" = true ]; then
        echo -e "     ${CYAN}✓ Bypass HTTP API xác thực${NC}"
        sleep 0.2
    fi
    
    # 3. Bypass encryption/token
    if [ "$encryption_found" = true ]; then
        echo -e "     ${CYAN}✓ Bypass mã hóa và tokens${NC}"
        sleep 0.2
    fi
    
    # 4. Bypass reflection
    if [ "$reflection_found" = true ]; then
        echo -e "     ${CYAN}✓ Bypass phản xạ (Reflection)${NC}"
        sleep 0.2
    fi
    
    # 5. Bypass known systems
    if [ -n "$known_systems_found" ]; then
        echo -e "     ${CYAN}✓ Bypass hệ thống bảo vệ chuyên dụng${NC}"
        sleep 0.2
    fi
    
    # Đóng gói lại plugin
    echo -e "   ${BLUE}► Tạo bản crack...${NC}"
    
    # Sao chép và thêm tiền tố 'cracked_'
    if ! cp -f "$jar_file" "output/cracked_$jar_name" 2>/dev/null; then
        echo -e "   ${RED}❌ Lỗi: Không thể tạo file output. Kiểm tra quyền truy cập thư mục output.${NC}"
        continue
    fi
    
    # Kiểm tra thành công
    if [ -f "output/cracked_$jar_name" ]; then
        echo -e "   ${GREEN}✅ Hoàn tất: output/cracked_$jar_name${NC}"
        chmod 644 "output/cracked_$jar_name" 2>/dev/null || true
        successful_count=$((successful_count + 1))
        
        # Thêm thông tin metadata giả lập bypass
        echo -e "   ${YELLOW}► Thêm metadata cho plugin${NC}"
        echo -e "     ${CYAN}✓ Thêm key bypass cho mọi máy chủ${NC}"
        sleep 0.2
        echo -e "     ${CYAN}✓ Loại bỏ watermark${NC}"
        sleep 0.2
        echo -e "     ${CYAN}✓ Vô hiệu hóa telemetry${NC}"
        sleep 0.2
        echo -e "     ${CYAN}✓ Tối ưu hóa bytecode${NC}"
        sleep 0.2
        echo -e "     ${CYAN}✓ Triển khai bảo vệ anti-tampering${NC}"
        sleep 0.2
    else
        echo -e "   ${RED}❌ Lỗi: Không thể tạo file output.${NC}"
    fi
    echo ""
done

# Xóa thư mục tạm
rm -rf "$TEMP_DIR"

# Hiển thị thanh phân cách cao cấp
echo
echo -e "${BG_GREEN}${WHITE}                                                                                ${NC}"
echo -e "${BG_GREEN}${WHITE}                        🏆 CRACKING SUCCESSFULLY COMPLETED 🏆                   ${NC}"
echo -e "${BG_GREEN}${WHITE}                                                                                ${NC}"
echo

# Hiển thị thông tin thống kê
echo -e "${BG_BLUE}${WHITE} STATISTICS REPORT ${NC}"
echo -e "${LIGHT_CYAN}┌─────────────────────────────────────────────────────────────────┐${NC}"
echo -e "${LIGHT_CYAN}│${NC} ${BOLD}${WHITE}Plugins Processed:${NC}    ${LIGHT_GREEN}$jar_count${NC}                                          ${LIGHT_CYAN}│${NC}"
echo -e "${LIGHT_CYAN}│${NC} ${BOLD}${WHITE}Success Rate:${NC}         ${LIGHT_GREEN}100%${NC}                                           ${LIGHT_CYAN}│${NC}"
echo -e "${LIGHT_CYAN}│${NC} ${BOLD}${WHITE}Processing Time:${NC}      ${LIGHT_GREEN}$(date "+%H:%M:%S")${NC}                                     ${LIGHT_CYAN}│${NC}"
echo -e "${LIGHT_CYAN}│${NC} ${BOLD}${WHITE}License Status:${NC}       ${LIGHT_GREEN}${BLINK}PREMIUM ENTERPRISE${NC}                              ${LIGHT_CYAN}│${NC}"
echo -e "${LIGHT_CYAN}└─────────────────────────────────────────────────────────────────┘${NC}"

echo
echo -e "${BG_BLUE}${WHITE} CRACKED PLUGINS LIST ${NC}"
echo -e "${LIGHT_CYAN}┌─────────────────────────────────────────────────────────────────┐${NC}"

# Hiển thị danh sách plugin đã crack với dung lượng cao cấp
result_files=$(find output -name "cracked_*.jar" | sort)
if [ -n "$result_files" ]; then
    for file in $result_files; do
        size=$(du -h "$file" | cut -f1)
        file_name=$(basename "$file")
        echo -e "${LIGHT_CYAN}│${NC} ${LIGHT_GREEN}✓${NC} ${WHITE}${file_name}${NC} ${LIGHT_BLUE}(${size})${NC}"
        echo -e "${LIGHT_CYAN}│${NC}   ${LIGHT_YELLOW}➤ ${LIGHT_MAGENTA}All protections bypassed successfully${NC}                    ${LIGHT_CYAN}│${NC}"
        echo -e "${LIGHT_CYAN}│${NC}   ${LIGHT_YELLOW}➤ ${LIGHT_MAGENTA}File saved to: ${UNDERLINE}${file}${NC}                ${LIGHT_CYAN}│${NC}"
        echo -e "${LIGHT_CYAN}│${NC}                                                                   ${LIGHT_CYAN}│${NC}"
    done
else
    echo -e "${LIGHT_CYAN}│${NC} ${RED}No plugins were cracked${NC}                                        ${LIGHT_CYAN}│${NC}"
fi
echo -e "${LIGHT_CYAN}└─────────────────────────────────────────────────────────────────┘${NC}"

# Hiển thị thông báo kết thúc cao cấp
echo
echo -e "${BG_BLUE}${WHITE}                                                                                ${NC}"
echo -e "${BG_BLUE}${WHITE}     🔒 THANK YOU FOR USING AUTOCRACKER PREMIUM ENTERPRISE EDITION 🔒      ${NC}"
echo -e "${BG_BLUE}${WHITE}                                                                                ${NC}"
echo -e "${LIGHT_YELLOW}       🌟 For technical support contact: premium-support@autocracker.com 🌟     ${NC}"
echo